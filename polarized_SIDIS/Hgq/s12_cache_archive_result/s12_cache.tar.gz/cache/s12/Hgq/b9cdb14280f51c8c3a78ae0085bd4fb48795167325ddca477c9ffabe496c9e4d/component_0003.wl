<|"Sector" -> "Real", "Kind" -> "ExtendedResponse", "Index" -> {1, 1, 5}, 
 "Ordinary" -> (-4*Pi*s23*(2*Q^4*s23*SUNN - Q^4*SUNN*t + Q^2*s*SUNN*t))/
    ((Q^2 + s)*(s23 - t)*t*(Q^2*s23 + s*t)) + 
   (2*Pi*s*(Q^4 + Q^2*s - Q^2*s23 + Q^2*s23*SUNN^2 + Q^2*t - Q^2*SUNN^2*t))/
    ((Q^2 + s)^3*SUNN*t) + (2*Pi*(2*Q^2*s23 + s*s23 - Q^2*t)*
     (Q^2*s23 + Q^4*SUNN^2 + Q^2*s*SUNN^2 - Q^2*s23*SUNN^2 - Q^2*t + 
      Q^2*SUNN^2*t))/((Q^2 + s)^3*SUNN*(s23 - t)*t) + 
   (4*Pi*(-(Q^8*s23) - 3*Q^6*s*s23 - 3*Q^4*s^2*s23 - Q^2*s^3*s23 + 
      2*Q^4*s*s23^2 + 2*Q^2*s^2*s23^2 - Q^2*s*s23^3 + 2*Q^8*s23*SUNN^2 + 
      5*Q^6*s*s23*SUNN^2 + 4*Q^4*s^2*s23*SUNN^2 + Q^2*s^3*s23*SUNN^2 - 
      Q^6*s23^2*SUNN^2 - 3*Q^4*s*s23^2*SUNN^2 - 2*Q^2*s^2*s23^2*SUNN^2 + 
      Q^2*s*s23^3*SUNN^2 + Q^8*t + 3*Q^6*s*t + 3*Q^4*s^2*t + Q^2*s^3*t - 
      4*Q^4*s*s23*t - 4*Q^2*s^2*s23*t + 3*Q^2*s*s23^2*t - Q^8*SUNN^2*t - 
      2*Q^6*s*SUNN^2*t - Q^4*s^2*SUNN^2*t + Q^6*s23*SUNN^2*t + 
      4*Q^4*s*s23*SUNN^2*t + 3*Q^2*s^2*s23*SUNN^2*t - 
      3*Q^2*s*s23^2*SUNN^2*t + 2*Q^4*s*t^2 + 2*Q^2*s^2*t^2 - 
      3*Q^2*s*s23*t^2 - Q^4*s*SUNN^2*t^2 - Q^2*s^2*SUNN^2*t^2 + 
      3*Q^2*s*s23*SUNN^2*t^2 + Q^2*s*t^3 - Q^2*s*SUNN^2*t^3))/
    ((Q^2 + s)^3*SUNN*(s23 - t)*t*(Q^2 + s - s23 + t)) - 
   (2*Pi*(8*Q^6*s23^5*SUNN - 16*Q^6*s23^4*SUNN*t + 16*Q^4*s*s23^4*SUNN*t + 
      12*Q^6*s23^3*SUNN*t^2 - 36*Q^4*s*s23^3*SUNN*t^2 + 
      8*Q^2*s^2*s23^3*SUNN*t^2 + 4*Q^4*s23^4*SUNN*t^2 - 
      4*Q^6*s23^2*SUNN*t^3 + 28*Q^4*s*s23^2*SUNN*t^3 - 
      20*Q^2*s^2*s23^2*SUNN*t^3 - 12*Q^4*s23^3*SUNN*t^3 + 
      4*Q^2*s*s23^3*SUNN*t^3 - 6*Q^4*s*s23*SUNN*t^4 + 
      18*Q^2*s^2*s23*SUNN*t^4 + 16*Q^4*s23^2*SUNN*t^4 - 
      12*Q^2*s*s23^2*SUNN*t^4 + Q^6*SUNN*t^5 - 5*Q^2*s^2*SUNN*t^5 - 
      12*Q^4*s23*SUNN*t^5 + 12*Q^2*s*s23*SUNN*t^5 + 4*Q^4*SUNN*t^6 - 
      4*Q^2*s*SUNN*t^6))/((Q^2 + s)^2*(s23 - t)*t^4*(Q^2*s23 + s*t)) + 
   (Pi*(2*Q^8*s^6*s23^3*t + 4*Q^6*s^7*s23^3*t + 2*Q^4*s^8*s23^3*t + 
      24*Q^10*s^4*s23^4*t + 48*Q^8*s^5*s23^4*t + 20*Q^6*s^6*s23^4*t - 
      4*Q^4*s^7*s23^4*t + 96*Q^12*s^2*s23^5*t + 192*Q^10*s^3*s23^5*t + 
      48*Q^8*s^4*s23^5*t - 48*Q^6*s^5*s23^5*t + 2*Q^4*s^6*s23^5*t + 
      128*Q^14*s23^6*t + 256*Q^12*s*s23^6*t - 64*Q^10*s^2*s23^6*t - 
      192*Q^8*s^3*s23^6*t + 24*Q^6*s^4*s23^6*t - 256*Q^12*s23^7*t - 
      256*Q^10*s*s23^7*t + 96*Q^8*s^2*s23^7*t + 128*Q^10*s23^8*t + 
      6*Q^8*s^6*s23^3*SUNN^2*t + 12*Q^6*s^7*s23^3*SUNN^2*t + 
      6*Q^4*s^8*s23^3*SUNN^2*t + 72*Q^10*s^4*s23^4*SUNN^2*t + 
      144*Q^8*s^5*s23^4*SUNN^2*t + 60*Q^6*s^6*s23^4*SUNN^2*t - 
      12*Q^4*s^7*s23^4*SUNN^2*t + 288*Q^12*s^2*s23^5*SUNN^2*t + 
      576*Q^10*s^3*s23^5*SUNN^2*t + 144*Q^8*s^4*s23^5*SUNN^2*t - 
      144*Q^6*s^5*s23^5*SUNN^2*t + 6*Q^4*s^6*s23^5*SUNN^2*t + 
      384*Q^14*s23^6*SUNN^2*t + 768*Q^12*s*s23^6*SUNN^2*t - 
      192*Q^10*s^2*s23^6*SUNN^2*t - 576*Q^8*s^3*s23^6*SUNN^2*t + 
      72*Q^6*s^4*s23^6*SUNN^2*t - 768*Q^12*s23^7*SUNN^2*t - 
      768*Q^10*s*s23^7*SUNN^2*t + 288*Q^8*s^2*s23^7*SUNN^2*t + 
      384*Q^10*s23^8*SUNN^2*t - 4*Q^8*s^6*s23^2*t^2 - 4*Q^6*s^7*s23^2*t^2 + 
      2*Q^4*s^8*s23^2*t^2 + 2*Q^2*s^9*s23^2*t^2 - 48*Q^10*s^4*s23^3*t^2 - 
      36*Q^8*s^5*s23^3*t^2 + 56*Q^6*s^6*s23^3*t^2 + 42*Q^4*s^7*s23^3*t^2 - 
      4*Q^2*s^8*s23^3*t^2 - 192*Q^12*s^2*s23^4*t^2 - 96*Q^10*s^3*s23^4*t^2 + 
      384*Q^8*s^4*s23^4*t^2 + 240*Q^6*s^5*s23^4*t^2 - 80*Q^4*s^6*s23^4*t^2 + 
      2*Q^2*s^7*s23^4*t^2 - 256*Q^14*s23^5*t^2 - 64*Q^12*s*s23^5*t^2 + 
      896*Q^10*s^2*s23^5*t^2 + 416*Q^8*s^3*s23^5*t^2 - 
      480*Q^6*s^4*s23^5*t^2 + 36*Q^4*s^5*s23^5*t^2 + 512*Q^12*s23^6*t^2 - 
      1024*Q^8*s^2*s23^6*t^2 + 192*Q^6*s^3*s23^6*t^2 - 512*Q^10*s23^7*t^2 + 
      320*Q^8*s*s23^7*t^2 + 12*Q^8*s^6*s23^2*SUNN^2*t^2 + 
      16*Q^6*s^7*s23^2*SUNN^2*t^2 + 10*Q^4*s^8*s23^2*SUNN^2*t^2 + 
      6*Q^2*s^9*s23^2*SUNN^2*t^2 + 144*Q^10*s^4*s23^3*SUNN^2*t^2 + 
      228*Q^8*s^5*s23^3*SUNN^2*t^2 + 208*Q^6*s^6*s23^3*SUNN^2*t^2 + 
      122*Q^4*s^7*s23^3*SUNN^2*t^2 - 12*Q^2*s^8*s23^3*SUNN^2*t^2 + 
      576*Q^12*s^2*s23^4*SUNN^2*t^2 + 1056*Q^10*s^3*s23^4*SUNN^2*t^2 + 
      1248*Q^8*s^4*s23^4*SUNN^2*t^2 + 672*Q^6*s^5*s23^4*SUNN^2*t^2 - 
      240*Q^4*s^6*s23^4*SUNN^2*t^2 + 6*Q^2*s^7*s23^4*SUNN^2*t^2 + 
      768*Q^14*s23^5*SUNN^2*t^2 + 1600*Q^12*s*s23^5*SUNN^2*t^2 + 
      2560*Q^10*s^2*s23^5*SUNN^2*t^2 + 1056*Q^8*s^3*s23^5*SUNN^2*t^2 - 
      1440*Q^6*s^4*s23^5*SUNN^2*t^2 + 108*Q^4*s^5*s23^5*SUNN^2*t^2 + 
      1024*Q^12*s23^6*SUNN^2*t^2 - 256*Q^10*s*s23^6*SUNN^2*t^2 - 
      3072*Q^8*s^2*s23^6*SUNN^2*t^2 + 576*Q^6*s^3*s23^6*SUNN^2*t^2 - 
      1536*Q^10*s23^7*SUNN^2*t^2 + 960*Q^8*s*s23^7*SUNN^2*t^2 + 
      6*Q^8*s^6*s23*t^3 + 6*Q^6*s^7*s23*t^3 - 2*Q^4*s^8*s23*t^3 - 
      2*Q^2*s^9*s23*t^3 + 72*Q^10*s^4*s23^2*t^3 + 48*Q^8*s^5*s23^2*t^3 - 
      58*Q^6*s^6*s23^2*t^3 - 18*Q^4*s^7*s23^2*t^3 + 22*Q^2*s^8*s23^2*t^3 + 
      288*Q^12*s^2*s23^3*t^3 + 96*Q^10*s^3*s23^3*t^3 - 
      378*Q^8*s^4*s23^3*t^3 + 36*Q^6*s^5*s23^3*t^3 + 296*Q^4*s^6*s23^3*t^3 - 
      32*Q^2*s^7*s23^3*t^3 + 384*Q^14*s23^4*t^3 - 848*Q^10*s^2*s23^4*t^3 + 
      448*Q^8*s^3*s23^4*t^3 + 1212*Q^6*s^4*s23^4*t^3 - 
      396*Q^4*s^5*s23^4*t^3 + 12*Q^2*s^6*s23^4*t^3 - 544*Q^12*s23^5*t^3 + 
      576*Q^10*s*s23^5*t^3 + 1696*Q^8*s^2*s23^5*t^3 - 
      1440*Q^6*s^3*s23^5*t^3 + 126*Q^4*s^4*s23^5*t^3 + 704*Q^10*s23^6*t^3 - 
      1472*Q^8*s*s23^6*t^3 + 336*Q^6*s^2*s23^6*t^3 + 96*Q^8*s23^7*t^3 - 
      4*Q^8*s^6*s23*SUNN^2*t^3 + 18*Q^6*s^7*s23*SUNN^2*t^3 + 
      20*Q^4*s^8*s23*SUNN^2*t^3 - 2*Q^2*s^9*s23*SUNN^2*t^3 - 
      48*Q^10*s^4*s23^2*SUNN^2*t^3 + 288*Q^8*s^5*s23^2*SUNN^2*t^3 + 
      320*Q^6*s^6*s23^2*SUNN^2*t^3 + 16*Q^4*s^7*s23^2*SUNN^2*t^3 + 
      62*Q^2*s^8*s23^2*SUNN^2*t^3 - 192*Q^12*s^2*s23^3*SUNN^2*t^3 + 
      1440*Q^10*s^3*s23^3*SUNN^2*t^3 + 1626*Q^8*s^4*s23^3*SUNN^2*t^3 + 
      420*Q^6*s^5*s23^3*SUNN^2*t^3 + 816*Q^4*s^6*s23^3*SUNN^2*t^3 - 
      96*Q^2*s^7*s23^3*SUNN^2*t^3 - 256*Q^14*s23^4*SUNN^2*t^3 + 
      2304*Q^12*s*s23^4*SUNN^2*t^3 + 2480*Q^10*s^2*s23^4*SUNN^2*t^3 + 
      1504*Q^8*s^3*s23^4*SUNN^2*t^3 + 3252*Q^6*s^4*s23^4*SUNN^2*t^3 - 
      1188*Q^4*s^5*s23^4*SUNN^2*t^3 + 36*Q^2*s^6*s23^4*SUNN^2*t^3 - 
      736*Q^12*s23^5*SUNN^2*t^3 + 832*Q^10*s*s23^5*SUNN^2*t^3 + 
      4448*Q^8*s^2*s23^5*SUNN^2*t^3 - 4320*Q^6*s^3*s23^5*SUNN^2*t^3 + 
      378*Q^4*s^4*s23^5*SUNN^2*t^3 + 2112*Q^10*s23^6*SUNN^2*t^3 - 
      4416*Q^8*s*s23^6*SUNN^2*t^3 + 1008*Q^6*s^2*s23^6*SUNN^2*t^3 + 
      288*Q^8*s23^7*SUNN^2*t^3 + 6*Q^6*s^7*t^4 + 10*Q^4*s^8*t^4 + 
      4*Q^2*s^9*t^4 + 108*Q^8*s^5*s23*t^4 + 162*Q^6*s^6*s23*t^4 + 
      34*Q^4*s^7*s23*t^4 - 26*Q^2*s^8*s23*t^4 + 576*Q^10*s^3*s23^2*t^4 + 
      780*Q^8*s^4*s23^2*t^4 - 48*Q^6*s^5*s23^2*t^4 - 282*Q^4*s^6*s23^2*t^4 + 
      104*Q^2*s^7*s23^2*t^4 + 960*Q^12*s*s23^3*t^4 + 
      1216*Q^10*s^2*s23^3*t^4 - 760*Q^8*s^3*s23^3*t^4 - 
      952*Q^6*s^4*s23^3*t^4 + 1006*Q^4*s^5*s23^3*t^4 - 
      108*Q^2*s^6*s23^3*t^4 + 192*Q^12*s23^4*t^4 - 1184*Q^10*s*s23^4*t^4 - 
      1184*Q^8*s^2*s23^4*t^4 + 2848*Q^6*s^3*s23^4*t^4 - 
      872*Q^4*s^4*s23^4*t^4 + 30*Q^2*s^5*s23^4*t^4 - 384*Q^10*s23^5*t^4 + 
      2336*Q^8*s*s23^5*t^4 - 1728*Q^6*s^2*s23^5*t^4 + 184*Q^4*s^3*s23^5*t^4 - 
      384*Q^8*s23^6*t^4 + 192*Q^6*s*s23^6*t^4 - 2*Q^8*s^6*SUNN^2*t^4 - 
      10*Q^6*s^7*SUNN^2*t^4 + 8*Q^2*s^9*SUNN^2*t^4 - 
      24*Q^10*s^4*s23*SUNN^2*t^4 - 144*Q^8*s^5*s23*SUNN^2*t^4 + 
      130*Q^6*s^6*s23*SUNN^2*t^4 + 242*Q^4*s^7*s23*SUNN^2*t^4 - 
      38*Q^2*s^8*s23*SUNN^2*t^4 - 96*Q^12*s^2*s23^2*SUNN^2*t^4 - 
      672*Q^10*s^3*s23^2*SUNN^2*t^4 + 1308*Q^8*s^4*s23^2*SUNN^2*t^4 + 
      1800*Q^6*s^5*s23^2*SUNN^2*t^4 - 422*Q^4*s^6*s23^2*SUNN^2*t^4 + 
      280*Q^2*s^7*s23^2*SUNN^2*t^4 - 128*Q^14*s23^3*SUNN^2*t^4 - 
      1024*Q^12*s*s23^3*SUNN^2*t^4 + 3648*Q^10*s^2*s23^3*SUNN^2*t^4 + 
      4184*Q^8*s^3*s23^3*SUNN^2*t^4 - 1728*Q^6*s^4*s23^3*SUNN^2*t^4 + 
      2670*Q^4*s^5*s23^3*SUNN^2*t^4 - 324*Q^2*s^6*s23^3*SUNN^2*t^4 + 
      1984*Q^12*s23^4*SUNN^2*t^4 + 1184*Q^10*s*s23^4*SUNN^2*t^4 - 
      3488*Q^8*s^2*s23^4*SUNN^2*t^4 + 7488*Q^6*s^3*s23^4*SUNN^2*t^4 - 
      2616*Q^4*s^4*s23^4*SUNN^2*t^4 + 90*Q^2*s^5*s23^4*SUNN^2*t^4 - 
      2048*Q^10*s23^5*SUNN^2*t^4 + 6304*Q^8*s*s23^5*SUNN^2*t^4 - 
      5184*Q^6*s^2*s23^5*SUNN^2*t^4 + 552*Q^4*s^3*s23^5*SUNN^2*t^4 - 
      1152*Q^8*s23^6*SUNN^2*t^4 + 576*Q^6*s*s23^6*SUNN^2*t^4 + 
      36*Q^6*s^6*t^5 + 66*Q^4*s^7*t^5 + 32*Q^2*s^8*t^5 + 
      378*Q^8*s^4*s23*t^5 + 678*Q^6*s^5*s23*t^5 + 250*Q^4*s^6*s23*t^5 - 
      126*Q^2*s^7*s23*t^5 + 1008*Q^10*s^2*s23^2*t^5 + 
      1888*Q^8*s^3*s23^2*t^5 + 346*Q^6*s^4*s23^2*t^5 - 
      1082*Q^4*s^5*s23^2*t^5 + 274*Q^2*s^6*s23^2*t^5 + 288*Q^12*s23^3*t^5 + 
      1056*Q^10*s*s23^3*t^5 - 466*Q^8*s^2*s23^3*t^5 - 
      2708*Q^6*s^3*s23^3*t^5 + 1848*Q^4*s^4*s23^3*t^5 - 
      200*Q^2*s^5*s23^3*t^5 - 200*Q^10*s23^4*t^5 - 1776*Q^8*s*s23^4*t^5 + 
      3084*Q^6*s^2*s23^4*t^5 - 988*Q^4*s^3*s23^4*t^5 + 40*Q^2*s^4*s23^4*t^5 + 
      624*Q^8*s23^5*t^5 - 816*Q^6*s*s23^5*t^5 + 126*Q^4*s^2*s23^5*t^5 + 
      24*Q^6*s23^6*t^5 - 12*Q^8*s^5*SUNN^2*t^5 - 70*Q^6*s^6*SUNN^2*t^5 - 
      8*Q^4*s^7*SUNN^2*t^5 + 60*Q^2*s^8*SUNN^2*t^5 - 
      96*Q^10*s^3*s23*SUNN^2*t^5 - 660*Q^8*s^4*s23*SUNN^2*t^5 + 
      306*Q^6*s^5*s23*SUNN^2*t^5 + 1012*Q^4*s^6*s23*SUNN^2*t^5 - 
      206*Q^2*s^7*s23*SUNN^2*t^5 - 192*Q^12*s*s23^2*SUNN^2*t^5 - 
      1728*Q^10*s^2*s23^2*SUNN^2*t^5 + 2208*Q^8*s^3*s23^2*SUNN^2*t^5 + 
      4448*Q^6*s^4*s23^2*SUNN^2*t^5 - 1996*Q^4*s^5*s23^2*SUNN^2*t^5 + 
      714*Q^2*s^6*s23^2*SUNN^2*t^5 - 832*Q^12*s23^3*SUNN^2*t^5 + 
      3040*Q^10*s*s23^3*SUNN^2*t^5 + 5274*Q^8*s^2*s23^3*SUNN^2*t^5 - 
      6124*Q^6*s^3*s23^3*SUNN^2*t^5 + 4792*Q^4*s^4*s23^3*SUNN^2*t^5 - 
      600*Q^2*s^5*s23^3*SUNN^2*t^5 + 1096*Q^10*s23^4*SUNN^2*t^5 - 
      5552*Q^8*s*s23^4*SUNN^2*t^5 + 8100*Q^6*s^2*s23^4*SUNN^2*t^5 - 
      2964*Q^4*s^3*s23^4*SUNN^2*t^5 + 120*Q^2*s^4*s23^4*SUNN^2*t^5 + 
      1872*Q^8*s23^5*SUNN^2*t^5 - 2448*Q^6*s*s23^5*SUNN^2*t^5 + 
      378*Q^4*s^2*s23^5*SUNN^2*t^5 + 72*Q^6*s23^6*SUNN^2*t^5 + 
      90*Q^6*s^5*t^6 + 186*Q^4*s^6*t^6 + 112*Q^2*s^7*t^6 + 
      552*Q^8*s^3*s23*t^6 + 1218*Q^6*s^4*s23*t^6 + 674*Q^4*s^5*s23*t^6 - 
      322*Q^2*s^6*s23*t^6 + 576*Q^10*s*s23^2*t^6 + 1716*Q^8*s^2*s23^2*t^6 + 
      844*Q^6*s^3*s23^2*t^6 - 1950*Q^4*s^4*s23^2*t^6 + 
      440*Q^2*s^5*s23^2*t^6 + 240*Q^10*s23^3*t^6 + 28*Q^8*s*s23^3*t^6 - 
      2808*Q^6*s^2*s23^3*t^6 + 1894*Q^4*s^3*s23^3*t^6 - 
      220*Q^2*s^4*s23^3*t^6 - 480*Q^8*s23^4*t^6 + 1392*Q^6*s*s23^4*t^6 - 
      576*Q^4*s^2*s23^4*t^6 + 30*Q^2*s^3*s23^4*t^6 - 96*Q^6*s23^5*t^6 + 
      36*Q^4*s*s23^5*t^6 - 30*Q^8*s^4*SUNN^2*t^6 - 210*Q^6*s^5*SUNN^2*t^6 - 
      56*Q^4*s^6*SUNN^2*t^6 + 196*Q^2*s^7*SUNN^2*t^6 - 
      144*Q^10*s^2*s23*SUNN^2*t^6 - 1280*Q^8*s^3*s23*SUNN^2*t^6 + 
      210*Q^6*s^4*s23*SUNN^2*t^6 + 2158*Q^4*s^5*s23*SUNN^2*t^6 - 
      550*Q^2*s^6*s23*SUNN^2*t^6 - 96*Q^12*s23^2*SUNN^2*t^6 - 
      1632*Q^10*s*s23^2*SUNN^2*t^6 + 1476*Q^8*s^2*s23^2*SUNN^2*t^6 + 
      5824*Q^6*s^3*s23^2*SUNN^2*t^6 - 3838*Q^4*s^4*s23^2*SUNN^2*t^6 + 
      1120*Q^2*s^5*s23^2*SUNN^2*t^6 + 688*Q^10*s23^3*SUNN^2*t^6 + 
      3652*Q^8*s*s23^3*SUNN^2*t^6 - 6864*Q^6*s^2*s23^3*SUNN^2*t^6 + 
      4854*Q^4*s^3*s23^3*SUNN^2*t^6 - 660*Q^2*s^4*s23^3*SUNN^2*t^6 - 
      1920*Q^8*s23^4*SUNN^2*t^6 + 3744*Q^6*s*s23^4*SUNN^2*t^6 - 
      1728*Q^4*s^2*s23^4*SUNN^2*t^6 + 90*Q^2*s^3*s23^4*SUNN^2*t^6 - 
      288*Q^6*s23^5*SUNN^2*t^6 + 108*Q^4*s*s23^5*SUNN^2*t^6 + 
      120*Q^6*s^4*t^7 + 290*Q^4*s^5*t^7 + 224*Q^2*s^6*t^7 + 
      378*Q^8*s^2*s23*t^7 + 1122*Q^6*s^3*s23*t^7 + 950*Q^4*s^4*s23*t^7 - 
      490*Q^2*s^5*s23*t^7 + 72*Q^10*s23^2*t^7 + 624*Q^8*s*s23^2*t^7 + 
      762*Q^6*s^2*s23^2*t^7 - 1878*Q^4*s^3*s23^2*t^7 + 
      442*Q^2*s^4*s23^2*t^7 + 74*Q^8*s23^3*t^7 - 1172*Q^6*s*s23^3*t^7 + 
      1040*Q^4*s^2*s23^3*t^7 - 144*Q^2*s^3*s23^3*t^7 + 164*Q^6*s23^4*t^7 - 
      148*Q^4*s*s23^4*t^7 + 12*Q^2*s^2*s23^4*t^7 + 2*Q^4*s23^5*t^7 - 
      40*Q^8*s^3*SUNN^2*t^7 - 350*Q^6*s^4*SUNN^2*t^7 - 
      168*Q^4*s^5*SUNN^2*t^7 + 364*Q^2*s^6*SUNN^2*t^7 - 
      96*Q^10*s*s23*SUNN^2*t^7 - 1260*Q^8*s^2*s23*SUNN^2*t^7 - 
      250*Q^6*s^3*s23*SUNN^2*t^7 + 2680*Q^4*s^4*s23*SUNN^2*t^7 - 
      850*Q^2*s^5*s23*SUNN^2*t^7 - 528*Q^10*s23^2*SUNN^2*t^7 + 
      192*Q^8*s*s23^2*SUNN^2*t^7 + 4320*Q^6*s^2*s23^2*SUNN^2*t^7 - 
      3832*Q^4*s^3*s23^2*SUNN^2*t^7 + 1106*Q^2*s^4*s23^2*SUNN^2*t^7 + 
      1158*Q^8*s23^3*SUNN^2*t^7 - 3204*Q^6*s*s23^3*SUNN^2*t^7 + 
      2664*Q^4*s^2*s23^3*SUNN^2*t^7 - 432*Q^2*s^3*s23^3*SUNN^2*t^7 + 
      492*Q^6*s23^4*SUNN^2*t^7 - 444*Q^4*s*s23^4*SUNN^2*t^7 + 
      36*Q^2*s^2*s23^4*SUNN^2*t^7 + 6*Q^4*s23^5*SUNN^2*t^7 + 90*Q^6*s^3*t^8 + 
      270*Q^4*s^4*t^8 + 280*Q^2*s^5*t^8 + 108*Q^8*s*s23*t^8 + 
      534*Q^6*s^2*s23*t^8 + 758*Q^4*s^3*s23*t^8 - 462*Q^2*s^4*s23*t^8 + 
      68*Q^8*s23^2*t^8 + 296*Q^6*s*s23^2*t^8 - 958*Q^4*s^2*s23^2*t^8 + 
      272*Q^2*s^3*s23^2*t^8 - 136*Q^6*s23^3*t^8 + 258*Q^4*s*s23^3*t^8 - 
      52*Q^2*s^2*s23^3*t^8 - 8*Q^4*s23^4*t^8 + 2*Q^2*s*s23^4*t^8 - 
      30*Q^8*s^2*SUNN^2*t^8 - 350*Q^6*s^3*SUNN^2*t^8 - 
      280*Q^4*s^4*SUNN^2*t^8 + 420*Q^2*s^5*SUNN^2*t^8 - 
      24*Q^10*s23*SUNN^2*t^8 - 624*Q^8*s*s23*SUNN^2*t^8 - 
      522*Q^6*s^2*s23*SUNN^2*t^8 + 2030*Q^4*s^3*s23*SUNN^2*t^8 - 
      802*Q^2*s^4*s23*SUNN^2*t^8 - 108*Q^8*s23^2*SUNN^2*t^8 + 
      1768*Q^6*s*s23^2*SUNN^2*t^8 - 2042*Q^4*s^2*s23^2*SUNN^2*t^8 + 
      672*Q^2*s^3*s23^2*SUNN^2*t^8 - 512*Q^6*s23^3*SUNN^2*t^8 + 
      674*Q^4*s*s23^3*SUNN^2*t^8 - 156*Q^2*s^2*s23^3*SUNN^2*t^8 - 
      24*Q^4*s23^4*SUNN^2*t^8 + 6*Q^2*s*s23^4*SUNN^2*t^8 + 36*Q^6*s^2*t^9 + 
      150*Q^4*s^3*t^9 + 224*Q^2*s^4*t^9 + 6*Q^8*s23*t^9 + 114*Q^6*s*s23*t^9 + 
      334*Q^4*s^2*s23*t^9 - 266*Q^2*s^3*s23*t^9 + 38*Q^6*s23^2*t^9 - 
      222*Q^4*s*s23^2*t^9 + 94*Q^2*s^2*s23^2*t^9 + 14*Q^4*s23^3*t^9 - 
      8*Q^2*s*s23^3*t^9 - 12*Q^8*s*SUNN^2*t^9 - 210*Q^6*s^2*SUNN^2*t^9 - 
      280*Q^4*s^3*SUNN^2*t^9 + 308*Q^2*s^4*SUNN^2*t^9 - 
      124*Q^8*s23*SUNN^2*t^9 - 330*Q^6*s*s23*SUNN^2*t^9 + 
      932*Q^4*s^2*s23*SUNN^2*t^9 - 458*Q^2*s^3*s23*SUNN^2*t^9 + 
      320*Q^6*s23^2*SUNN^2*t^9 - 524*Q^4*s*s23^2*SUNN^2*t^9 + 
      230*Q^2*s^2*s23^2*SUNN^2*t^9 + 42*Q^4*s23^3*SUNN^2*t^9 - 
      24*Q^2*s*s23^3*SUNN^2*t^9 + 6*Q^6*s*t^10 + 46*Q^4*s^2*t^10 + 
      112*Q^2*s^3*t^10 + 6*Q^6*s23*t^10 + 70*Q^4*s*s23*t^10 - 
      86*Q^2*s^2*s23*t^10 - 12*Q^4*s23^2*t^10 + 14*Q^2*s*s23^2*t^10 - 
      2*Q^8*SUNN^2*t^10 - 70*Q^6*s*SUNN^2*t^10 - 168*Q^4*s^2*SUNN^2*t^10 + 
      140*Q^2*s^3*SUNN^2*t^10 - 74*Q^6*s23*SUNN^2*t^10 + 
      242*Q^4*s*s23*SUNN^2*t^10 - 146*Q^2*s^2*s23*SUNN^2*t^10 - 
      44*Q^4*s23^2*SUNN^2*t^10 + 34*Q^2*s*s23^2*SUNN^2*t^10 + 6*Q^4*s*t^11 + 
      32*Q^2*s^2*t^11 + 4*Q^4*s23*t^11 - 12*Q^2*s*s23*t^11 - 
      10*Q^6*SUNN^2*t^11 - 56*Q^4*s*SUNN^2*t^11 + 36*Q^2*s^2*SUNN^2*t^11 + 
      28*Q^4*s23*SUNN^2*t^11 - 20*Q^2*s*s23*SUNN^2*t^11 + 4*Q^2*s*t^12 - 
      8*Q^4*SUNN^2*t^12 + 4*Q^2*s*SUNN^2*t^12))/((Q^2 + s)^2*SUNN*t^3*
     (-s23 + t)*(Q^2 + s - s23 + t)*(Q^2*s23 + s*t)*
     (s^2 + 4*Q^2*s23 + 2*s*t + t^2)^3), 
 "Branches" -> <|1 -> <|"Delta" -> 0, "L0" -> 0, "L1" -> 0, 
     "Regular" -> (-4*Pi*s23*(-(Q^4*(omega - s)*SUNN) + Q^2*(omega - s)*s*
           SUNN + 2*Q^4*s23*SUNN))/((omega - s)*(Q^2 + s)*(-omega + s + s23)*
         ((omega - s)*s + Q^2*s23)) - 
       (2*Pi*(Q^6*(omega - s)^5*SUNN + 4*Q^4*(omega - s)^6*SUNN - 
          4*Q^2*(omega - s)^6*s*SUNN - 5*Q^2*(omega - s)^5*s^2*SUNN - 
          12*Q^4*(omega - s)^5*s23*SUNN - 6*Q^4*(omega - s)^4*s*s23*SUNN + 
          12*Q^2*(omega - s)^5*s*s23*SUNN + 18*Q^2*(omega - s)^4*s^2*s23*
           SUNN - 4*Q^6*(omega - s)^3*s23^2*SUNN + 16*Q^4*(omega - s)^4*s23^2*
           SUNN + 28*Q^4*(omega - s)^3*s*s23^2*SUNN - 12*Q^2*(omega - s)^4*s*
           s23^2*SUNN - 20*Q^2*(omega - s)^3*s^2*s23^2*SUNN + 
          12*Q^6*(omega - s)^2*s23^3*SUNN - 12*Q^4*(omega - s)^3*s23^3*SUNN - 
          36*Q^4*(omega - s)^2*s*s23^3*SUNN + 4*Q^2*(omega - s)^3*s*s23^3*
           SUNN + 8*Q^2*(omega - s)^2*s^2*s23^3*SUNN - 16*Q^6*(omega - s)*
           s23^4*SUNN + 4*Q^4*(omega - s)^2*s23^4*SUNN + 16*Q^4*(omega - s)*s*
           s23^4*SUNN + 8*Q^6*s23^5*SUNN))/((omega - s)^4*(Q^2 + s)^2*
         (-omega + s + s23)*((omega - s)*s + Q^2*s23)) + 
       (2*Pi*(-(Q^2*(omega - s)) + 2*Q^2*s23 + s*s23)*(-(Q^2*(omega - s)) + 
          Q^2*s23 + Q^4*SUNN^2 + Q^2*(omega - s)*SUNN^2 + Q^2*s*SUNN^2 - 
          Q^2*s23*SUNN^2))/((omega - s)*(Q^2 + s)^3*(-omega + s + s23)*
         SUNN) + (2*Pi*s*(Q^4 + Q^2*(omega - s) + Q^2*s - Q^2*s23 - 
          Q^2*(omega - s)*SUNN^2 + Q^2*s23*SUNN^2))/((omega - s)*(Q^2 + s)^3*
         SUNN) + (4*Pi*(Q^8*(omega - s) + 3*Q^6*(omega - s)*s + 
          2*Q^4*(omega - s)^2*s + Q^2*(omega - s)^3*s + 3*Q^4*(omega - s)*
           s^2 + 2*Q^2*(omega - s)^2*s^2 + Q^2*(omega - s)*s^3 - Q^8*s23 - 
          3*Q^6*s*s23 - 4*Q^4*(omega - s)*s*s23 - 3*Q^2*(omega - s)^2*s*s23 - 
          3*Q^4*s^2*s23 - 4*Q^2*(omega - s)*s^2*s23 - Q^2*s^3*s23 + 
          2*Q^4*s*s23^2 + 3*Q^2*(omega - s)*s*s23^2 + 2*Q^2*s^2*s23^2 - 
          Q^2*s*s23^3 - Q^8*(omega - s)*SUNN^2 - 2*Q^6*(omega - s)*s*SUNN^2 - 
          Q^4*(omega - s)^2*s*SUNN^2 - Q^2*(omega - s)^3*s*SUNN^2 - 
          Q^4*(omega - s)*s^2*SUNN^2 - Q^2*(omega - s)^2*s^2*SUNN^2 + 
          2*Q^8*s23*SUNN^2 + Q^6*(omega - s)*s23*SUNN^2 + 
          5*Q^6*s*s23*SUNN^2 + 4*Q^4*(omega - s)*s*s23*SUNN^2 + 
          3*Q^2*(omega - s)^2*s*s23*SUNN^2 + 4*Q^4*s^2*s23*SUNN^2 + 
          3*Q^2*(omega - s)*s^2*s23*SUNN^2 + Q^2*s^3*s23*SUNN^2 - 
          Q^6*s23^2*SUNN^2 - 3*Q^4*s*s23^2*SUNN^2 - 3*Q^2*(omega - s)*s*s23^2*
           SUNN^2 - 2*Q^2*s^2*s23^2*SUNN^2 + Q^2*s*s23^3*SUNN^2))/
        ((omega - s)*(Q^2 + s)^3*(omega + Q^2 - s23)*(-omega + s + s23)*
         SUNN) + (Pi*(6*Q^6*(omega - s)^10*s + 6*Q^4*(omega - s)^11*s + 
          4*Q^2*(omega - s)^12*s + 36*Q^6*(omega - s)^9*s^2 + 
          46*Q^4*(omega - s)^10*s^2 + 32*Q^2*(omega - s)^11*s^2 + 
          90*Q^6*(omega - s)^8*s^3 + 150*Q^4*(omega - s)^9*s^3 + 
          112*Q^2*(omega - s)^10*s^3 + 120*Q^6*(omega - s)^7*s^4 + 
          270*Q^4*(omega - s)^8*s^4 + 224*Q^2*(omega - s)^9*s^4 + 
          90*Q^6*(omega - s)^6*s^5 + 290*Q^4*(omega - s)^7*s^5 + 
          280*Q^2*(omega - s)^8*s^5 + 36*Q^6*(omega - s)^5*s^6 + 
          186*Q^4*(omega - s)^6*s^6 + 224*Q^2*(omega - s)^7*s^6 + 
          6*Q^6*(omega - s)^4*s^7 + 66*Q^4*(omega - s)^5*s^7 + 
          112*Q^2*(omega - s)^6*s^7 + 10*Q^4*(omega - s)^4*s^8 + 
          32*Q^2*(omega - s)^5*s^8 + 4*Q^2*(omega - s)^4*s^9 + 
          6*Q^8*(omega - s)^9*s23 + 6*Q^6*(omega - s)^10*s23 + 
          4*Q^4*(omega - s)^11*s23 + 108*Q^8*(omega - s)^8*s*s23 + 
          114*Q^6*(omega - s)^9*s*s23 + 70*Q^4*(omega - s)^10*s*s23 - 
          12*Q^2*(omega - s)^11*s*s23 + 378*Q^8*(omega - s)^7*s^2*s23 + 
          534*Q^6*(omega - s)^8*s^2*s23 + 334*Q^4*(omega - s)^9*s^2*s23 - 
          86*Q^2*(omega - s)^10*s^2*s23 + 552*Q^8*(omega - s)^6*s^3*s23 + 
          1122*Q^6*(omega - s)^7*s^3*s23 + 758*Q^4*(omega - s)^8*s^3*s23 - 
          266*Q^2*(omega - s)^9*s^3*s23 + 378*Q^8*(omega - s)^5*s^4*s23 + 
          1218*Q^6*(omega - s)^6*s^4*s23 + 950*Q^4*(omega - s)^7*s^4*s23 - 
          462*Q^2*(omega - s)^8*s^4*s23 + 108*Q^8*(omega - s)^4*s^5*s23 + 
          678*Q^6*(omega - s)^5*s^5*s23 + 674*Q^4*(omega - s)^6*s^5*s23 - 
          490*Q^2*(omega - s)^7*s^5*s23 + 6*Q^8*(omega - s)^3*s^6*s23 + 
          162*Q^6*(omega - s)^4*s^6*s23 + 250*Q^4*(omega - s)^5*s^6*s23 - 
          322*Q^2*(omega - s)^6*s^6*s23 + 6*Q^6*(omega - s)^3*s^7*s23 + 
          34*Q^4*(omega - s)^4*s^7*s23 - 126*Q^2*(omega - s)^5*s^7*s23 - 
          2*Q^4*(omega - s)^3*s^8*s23 - 26*Q^2*(omega - s)^4*s^8*s23 - 
          2*Q^2*(omega - s)^3*s^9*s23 + 72*Q^10*(omega - s)^7*s23^2 + 
          68*Q^8*(omega - s)^8*s23^2 + 38*Q^6*(omega - s)^9*s23^2 - 
          12*Q^4*(omega - s)^10*s23^2 + 576*Q^10*(omega - s)^6*s*s23^2 + 
          624*Q^8*(omega - s)^7*s*s23^2 + 296*Q^6*(omega - s)^8*s*s23^2 - 
          222*Q^4*(omega - s)^9*s*s23^2 + 14*Q^2*(omega - s)^10*s*s23^2 + 
          1008*Q^10*(omega - s)^5*s^2*s23^2 + 1716*Q^8*(omega - s)^6*s^2*
           s23^2 + 762*Q^6*(omega - s)^7*s^2*s23^2 - 958*Q^4*(omega - s)^8*
           s^2*s23^2 + 94*Q^2*(omega - s)^9*s^2*s23^2 + 
          576*Q^10*(omega - s)^4*s^3*s23^2 + 1888*Q^8*(omega - s)^5*s^3*
           s23^2 + 844*Q^6*(omega - s)^6*s^3*s23^2 - 1878*Q^4*(omega - s)^7*
           s^3*s23^2 + 272*Q^2*(omega - s)^8*s^3*s23^2 + 
          72*Q^10*(omega - s)^3*s^4*s23^2 + 780*Q^8*(omega - s)^4*s^4*s23^2 + 
          346*Q^6*(omega - s)^5*s^4*s23^2 - 1950*Q^4*(omega - s)^6*s^4*
           s23^2 + 442*Q^2*(omega - s)^7*s^4*s23^2 + 48*Q^8*(omega - s)^3*s^5*
           s23^2 - 48*Q^6*(omega - s)^4*s^5*s23^2 - 1082*Q^4*(omega - s)^5*
           s^5*s23^2 + 440*Q^2*(omega - s)^6*s^5*s23^2 - 4*Q^8*(omega - s)^2*
           s^6*s23^2 - 58*Q^6*(omega - s)^3*s^6*s23^2 - 282*Q^4*(omega - s)^4*
           s^6*s23^2 + 274*Q^2*(omega - s)^5*s^6*s23^2 - 4*Q^6*(omega - s)^2*
           s^7*s23^2 - 18*Q^4*(omega - s)^3*s^7*s23^2 + 104*Q^2*(omega - s)^4*
           s^7*s23^2 + 2*Q^4*(omega - s)^2*s^8*s23^2 + 22*Q^2*(omega - s)^3*
           s^8*s23^2 + 2*Q^2*(omega - s)^2*s^9*s23^2 + 288*Q^12*(omega - s)^5*
           s23^3 + 240*Q^10*(omega - s)^6*s23^3 + 74*Q^8*(omega - s)^7*
           s23^3 - 136*Q^6*(omega - s)^8*s23^3 + 14*Q^4*(omega - s)^9*s23^3 + 
          960*Q^12*(omega - s)^4*s*s23^3 + 1056*Q^10*(omega - s)^5*s*s23^3 + 
          28*Q^8*(omega - s)^6*s*s23^3 - 1172*Q^6*(omega - s)^7*s*s23^3 + 
          258*Q^4*(omega - s)^8*s*s23^3 - 8*Q^2*(omega - s)^9*s*s23^3 + 
          288*Q^12*(omega - s)^3*s^2*s23^3 + 1216*Q^10*(omega - s)^4*s^2*
           s23^3 - 466*Q^8*(omega - s)^5*s^2*s23^3 - 2808*Q^6*(omega - s)^6*
           s^2*s23^3 + 1040*Q^4*(omega - s)^7*s^2*s23^3 - 
          52*Q^2*(omega - s)^8*s^2*s23^3 + 96*Q^10*(omega - s)^3*s^3*s23^3 - 
          760*Q^8*(omega - s)^4*s^3*s23^3 - 2708*Q^6*(omega - s)^5*s^3*
           s23^3 + 1894*Q^4*(omega - s)^6*s^3*s23^3 - 144*Q^2*(omega - s)^7*
           s^3*s23^3 - 48*Q^10*(omega - s)^2*s^4*s23^3 - 
          378*Q^8*(omega - s)^3*s^4*s23^3 - 952*Q^6*(omega - s)^4*s^4*s23^3 + 
          1848*Q^4*(omega - s)^5*s^4*s23^3 - 220*Q^2*(omega - s)^6*s^4*
           s23^3 - 36*Q^8*(omega - s)^2*s^5*s23^3 + 36*Q^6*(omega - s)^3*s^5*
           s23^3 + 1006*Q^4*(omega - s)^4*s^5*s23^3 - 200*Q^2*(omega - s)^5*
           s^5*s23^3 + 2*Q^8*(omega - s)*s^6*s23^3 + 56*Q^6*(omega - s)^2*s^6*
           s23^3 + 296*Q^4*(omega - s)^3*s^6*s23^3 - 108*Q^2*(omega - s)^4*
           s^6*s23^3 + 4*Q^6*(omega - s)*s^7*s23^3 + 42*Q^4*(omega - s)^2*s^7*
           s23^3 - 32*Q^2*(omega - s)^3*s^7*s23^3 + 2*Q^4*(omega - s)*s^8*
           s23^3 - 4*Q^2*(omega - s)^2*s^8*s23^3 + 384*Q^14*(omega - s)^3*
           s23^4 + 192*Q^12*(omega - s)^4*s23^4 - 200*Q^10*(omega - s)^5*
           s23^4 - 480*Q^8*(omega - s)^6*s23^4 + 164*Q^6*(omega - s)^7*
           s23^4 - 8*Q^4*(omega - s)^8*s23^4 - 1184*Q^10*(omega - s)^4*s*
           s23^4 - 1776*Q^8*(omega - s)^5*s*s23^4 + 1392*Q^6*(omega - s)^6*s*
           s23^4 - 148*Q^4*(omega - s)^7*s*s23^4 + 2*Q^2*(omega - s)^8*s*
           s23^4 - 192*Q^12*(omega - s)^2*s^2*s23^4 - 848*Q^10*(omega - s)^3*
           s^2*s23^4 - 1184*Q^8*(omega - s)^4*s^2*s23^4 + 
          3084*Q^6*(omega - s)^5*s^2*s23^4 - 576*Q^4*(omega - s)^6*s^2*
           s23^4 + 12*Q^2*(omega - s)^7*s^2*s23^4 - 96*Q^10*(omega - s)^2*s^3*
           s23^4 + 448*Q^8*(omega - s)^3*s^3*s23^4 + 2848*Q^6*(omega - s)^4*
           s^3*s23^4 - 988*Q^4*(omega - s)^5*s^3*s23^4 + 30*Q^2*(omega - s)^6*
           s^3*s23^4 + 24*Q^10*(omega - s)*s^4*s23^4 + 384*Q^8*(omega - s)^2*
           s^4*s23^4 + 1212*Q^6*(omega - s)^3*s^4*s23^4 - 
          872*Q^4*(omega - s)^4*s^4*s23^4 + 40*Q^2*(omega - s)^5*s^4*s23^4 + 
          48*Q^8*(omega - s)*s^5*s23^4 + 240*Q^6*(omega - s)^2*s^5*s23^4 - 
          396*Q^4*(omega - s)^3*s^5*s23^4 + 30*Q^2*(omega - s)^4*s^5*s23^4 + 
          20*Q^6*(omega - s)*s^6*s23^4 - 80*Q^4*(omega - s)^2*s^6*s23^4 + 
          12*Q^2*(omega - s)^3*s^6*s23^4 - 4*Q^4*(omega - s)*s^7*s23^4 + 
          2*Q^2*(omega - s)^2*s^7*s23^4 - 256*Q^14*(omega - s)^2*s23^5 - 
          544*Q^12*(omega - s)^3*s23^5 - 384*Q^10*(omega - s)^4*s23^5 + 
          624*Q^8*(omega - s)^5*s23^5 - 96*Q^6*(omega - s)^6*s23^5 + 
          2*Q^4*(omega - s)^7*s23^5 - 64*Q^12*(omega - s)^2*s*s23^5 + 
          576*Q^10*(omega - s)^3*s*s23^5 + 2336*Q^8*(omega - s)^4*s*s23^5 - 
          816*Q^6*(omega - s)^5*s*s23^5 + 36*Q^4*(omega - s)^6*s*s23^5 + 
          96*Q^12*(omega - s)*s^2*s23^5 + 896*Q^10*(omega - s)^2*s^2*s23^5 + 
          1696*Q^8*(omega - s)^3*s^2*s23^5 - 1728*Q^6*(omega - s)^4*s^2*
           s23^5 + 126*Q^4*(omega - s)^5*s^2*s23^5 + 192*Q^10*(omega - s)*s^3*
           s23^5 + 416*Q^8*(omega - s)^2*s^3*s23^5 - 1440*Q^6*(omega - s)^3*
           s^3*s23^5 + 184*Q^4*(omega - s)^4*s^3*s23^5 + 48*Q^8*(omega - s)*
           s^4*s23^5 - 480*Q^6*(omega - s)^2*s^4*s23^5 + 
          126*Q^4*(omega - s)^3*s^4*s23^5 - 48*Q^6*(omega - s)*s^5*s23^5 + 
          36*Q^4*(omega - s)^2*s^5*s23^5 + 2*Q^4*(omega - s)*s^6*s23^5 + 
          128*Q^14*(omega - s)*s23^6 + 512*Q^12*(omega - s)^2*s23^6 + 
          704*Q^10*(omega - s)^3*s23^6 - 384*Q^8*(omega - s)^4*s23^6 + 
          24*Q^6*(omega - s)^5*s23^6 + 256*Q^12*(omega - s)*s*s23^6 - 
          1472*Q^8*(omega - s)^3*s*s23^6 + 192*Q^6*(omega - s)^4*s*s23^6 - 
          64*Q^10*(omega - s)*s^2*s23^6 - 1024*Q^8*(omega - s)^2*s^2*s23^6 + 
          336*Q^6*(omega - s)^3*s^2*s23^6 - 192*Q^8*(omega - s)*s^3*s23^6 + 
          192*Q^6*(omega - s)^2*s^3*s23^6 + 24*Q^6*(omega - s)*s^4*s23^6 - 
          256*Q^12*(omega - s)*s23^7 - 512*Q^10*(omega - s)^2*s23^7 + 
          96*Q^8*(omega - s)^3*s23^7 - 256*Q^10*(omega - s)*s*s23^7 + 
          320*Q^8*(omega - s)^2*s*s23^7 + 96*Q^8*(omega - s)*s^2*s23^7 + 
          128*Q^10*(omega - s)*s23^8 - 2*Q^8*(omega - s)^10*SUNN^2 - 
          10*Q^6*(omega - s)^11*SUNN^2 - 8*Q^4*(omega - s)^12*SUNN^2 - 
          12*Q^8*(omega - s)^9*s*SUNN^2 - 70*Q^6*(omega - s)^10*s*SUNN^2 - 
          56*Q^4*(omega - s)^11*s*SUNN^2 + 4*Q^2*(omega - s)^12*s*SUNN^2 - 
          30*Q^8*(omega - s)^8*s^2*SUNN^2 - 210*Q^6*(omega - s)^9*s^2*
           SUNN^2 - 168*Q^4*(omega - s)^10*s^2*SUNN^2 + 36*Q^2*(omega - s)^11*
           s^2*SUNN^2 - 40*Q^8*(omega - s)^7*s^3*SUNN^2 - 
          350*Q^6*(omega - s)^8*s^3*SUNN^2 - 280*Q^4*(omega - s)^9*s^3*
           SUNN^2 + 140*Q^2*(omega - s)^10*s^3*SUNN^2 - 30*Q^8*(omega - s)^6*
           s^4*SUNN^2 - 350*Q^6*(omega - s)^7*s^4*SUNN^2 - 
          280*Q^4*(omega - s)^8*s^4*SUNN^2 + 308*Q^2*(omega - s)^9*s^4*
           SUNN^2 - 12*Q^8*(omega - s)^5*s^5*SUNN^2 - 210*Q^6*(omega - s)^6*
           s^5*SUNN^2 - 168*Q^4*(omega - s)^7*s^5*SUNN^2 + 
          420*Q^2*(omega - s)^8*s^5*SUNN^2 - 2*Q^8*(omega - s)^4*s^6*SUNN^2 - 
          70*Q^6*(omega - s)^5*s^6*SUNN^2 - 56*Q^4*(omega - s)^6*s^6*SUNN^2 + 
          364*Q^2*(omega - s)^7*s^6*SUNN^2 - 10*Q^6*(omega - s)^4*s^7*
           SUNN^2 - 8*Q^4*(omega - s)^5*s^7*SUNN^2 + 196*Q^2*(omega - s)^6*
           s^7*SUNN^2 + 60*Q^2*(omega - s)^5*s^8*SUNN^2 + 
          8*Q^2*(omega - s)^4*s^9*SUNN^2 - 24*Q^10*(omega - s)^8*s23*SUNN^2 - 
          124*Q^8*(omega - s)^9*s23*SUNN^2 - 74*Q^6*(omega - s)^10*s23*
           SUNN^2 + 28*Q^4*(omega - s)^11*s23*SUNN^2 - 96*Q^10*(omega - s)^7*
           s*s23*SUNN^2 - 624*Q^8*(omega - s)^8*s*s23*SUNN^2 - 
          330*Q^6*(omega - s)^9*s*s23*SUNN^2 + 242*Q^4*(omega - s)^10*s*s23*
           SUNN^2 - 20*Q^2*(omega - s)^11*s*s23*SUNN^2 - 
          144*Q^10*(omega - s)^6*s^2*s23*SUNN^2 - 1260*Q^8*(omega - s)^7*s^2*
           s23*SUNN^2 - 522*Q^6*(omega - s)^8*s^2*s23*SUNN^2 + 
          932*Q^4*(omega - s)^9*s^2*s23*SUNN^2 - 146*Q^2*(omega - s)^10*s^2*
           s23*SUNN^2 - 96*Q^10*(omega - s)^5*s^3*s23*SUNN^2 - 
          1280*Q^8*(omega - s)^6*s^3*s23*SUNN^2 - 250*Q^6*(omega - s)^7*s^3*
           s23*SUNN^2 + 2030*Q^4*(omega - s)^8*s^3*s23*SUNN^2 - 
          458*Q^2*(omega - s)^9*s^3*s23*SUNN^2 - 24*Q^10*(omega - s)^4*s^4*
           s23*SUNN^2 - 660*Q^8*(omega - s)^5*s^4*s23*SUNN^2 + 
          210*Q^6*(omega - s)^6*s^4*s23*SUNN^2 + 2680*Q^4*(omega - s)^7*s^4*
           s23*SUNN^2 - 802*Q^2*(omega - s)^8*s^4*s23*SUNN^2 - 
          144*Q^8*(omega - s)^4*s^5*s23*SUNN^2 + 306*Q^6*(omega - s)^5*s^5*
           s23*SUNN^2 + 2158*Q^4*(omega - s)^6*s^5*s23*SUNN^2 - 
          850*Q^2*(omega - s)^7*s^5*s23*SUNN^2 - 4*Q^8*(omega - s)^3*s^6*s23*
           SUNN^2 + 130*Q^6*(omega - s)^4*s^6*s23*SUNN^2 + 
          1012*Q^4*(omega - s)^5*s^6*s23*SUNN^2 - 550*Q^2*(omega - s)^6*s^6*
           s23*SUNN^2 + 18*Q^6*(omega - s)^3*s^7*s23*SUNN^2 + 
          242*Q^4*(omega - s)^4*s^7*s23*SUNN^2 - 206*Q^2*(omega - s)^5*s^7*
           s23*SUNN^2 + 20*Q^4*(omega - s)^3*s^8*s23*SUNN^2 - 
          38*Q^2*(omega - s)^4*s^8*s23*SUNN^2 - 2*Q^2*(omega - s)^3*s^9*s23*
           SUNN^2 - 96*Q^12*(omega - s)^6*s23^2*SUNN^2 - 
          528*Q^10*(omega - s)^7*s23^2*SUNN^2 - 108*Q^8*(omega - s)^8*s23^2*
           SUNN^2 + 320*Q^6*(omega - s)^9*s23^2*SUNN^2 - 
          44*Q^4*(omega - s)^10*s23^2*SUNN^2 - 192*Q^12*(omega - s)^5*s*s23^2*
           SUNN^2 - 1632*Q^10*(omega - s)^6*s*s23^2*SUNN^2 + 
          192*Q^8*(omega - s)^7*s*s23^2*SUNN^2 + 1768*Q^6*(omega - s)^8*s*
           s23^2*SUNN^2 - 524*Q^4*(omega - s)^9*s*s23^2*SUNN^2 + 
          34*Q^2*(omega - s)^10*s*s23^2*SUNN^2 - 96*Q^12*(omega - s)^4*s^2*
           s23^2*SUNN^2 - 1728*Q^10*(omega - s)^5*s^2*s23^2*SUNN^2 + 
          1476*Q^8*(omega - s)^6*s^2*s23^2*SUNN^2 + 4320*Q^6*(omega - s)^7*
           s^2*s23^2*SUNN^2 - 2042*Q^4*(omega - s)^8*s^2*s23^2*SUNN^2 + 
          230*Q^2*(omega - s)^9*s^2*s23^2*SUNN^2 - 672*Q^10*(omega - s)^4*s^3*
           s23^2*SUNN^2 + 2208*Q^8*(omega - s)^5*s^3*s23^2*SUNN^2 + 
          5824*Q^6*(omega - s)^6*s^3*s23^2*SUNN^2 - 3832*Q^4*(omega - s)^7*
           s^3*s23^2*SUNN^2 + 672*Q^2*(omega - s)^8*s^3*s23^2*SUNN^2 - 
          48*Q^10*(omega - s)^3*s^4*s23^2*SUNN^2 + 1308*Q^8*(omega - s)^4*s^4*
           s23^2*SUNN^2 + 4448*Q^6*(omega - s)^5*s^4*s23^2*SUNN^2 - 
          3838*Q^4*(omega - s)^6*s^4*s23^2*SUNN^2 + 1106*Q^2*(omega - s)^7*
           s^4*s23^2*SUNN^2 + 288*Q^8*(omega - s)^3*s^5*s23^2*SUNN^2 + 
          1800*Q^6*(omega - s)^4*s^5*s23^2*SUNN^2 - 1996*Q^4*(omega - s)^5*
           s^5*s23^2*SUNN^2 + 1120*Q^2*(omega - s)^6*s^5*s23^2*SUNN^2 + 
          12*Q^8*(omega - s)^2*s^6*s23^2*SUNN^2 + 320*Q^6*(omega - s)^3*s^6*
           s23^2*SUNN^2 - 422*Q^4*(omega - s)^4*s^6*s23^2*SUNN^2 + 
          714*Q^2*(omega - s)^5*s^6*s23^2*SUNN^2 + 16*Q^6*(omega - s)^2*s^7*
           s23^2*SUNN^2 + 16*Q^4*(omega - s)^3*s^7*s23^2*SUNN^2 + 
          280*Q^2*(omega - s)^4*s^7*s23^2*SUNN^2 + 10*Q^4*(omega - s)^2*s^8*
           s23^2*SUNN^2 + 62*Q^2*(omega - s)^3*s^8*s23^2*SUNN^2 + 
          6*Q^2*(omega - s)^2*s^9*s23^2*SUNN^2 - 128*Q^14*(omega - s)^4*s23^3*
           SUNN^2 - 832*Q^12*(omega - s)^5*s23^3*SUNN^2 + 
          688*Q^10*(omega - s)^6*s23^3*SUNN^2 + 1158*Q^8*(omega - s)^7*s23^3*
           SUNN^2 - 512*Q^6*(omega - s)^8*s23^3*SUNN^2 + 42*Q^4*(omega - s)^9*
           s23^3*SUNN^2 - 1024*Q^12*(omega - s)^4*s*s23^3*SUNN^2 + 
          3040*Q^10*(omega - s)^5*s*s23^3*SUNN^2 + 3652*Q^8*(omega - s)^6*s*
           s23^3*SUNN^2 - 3204*Q^6*(omega - s)^7*s*s23^3*SUNN^2 + 
          674*Q^4*(omega - s)^8*s*s23^3*SUNN^2 - 24*Q^2*(omega - s)^9*s*s23^3*
           SUNN^2 - 192*Q^12*(omega - s)^3*s^2*s23^3*SUNN^2 + 
          3648*Q^10*(omega - s)^4*s^2*s23^3*SUNN^2 + 5274*Q^8*(omega - s)^5*
           s^2*s23^3*SUNN^2 - 6864*Q^6*(omega - s)^6*s^2*s23^3*SUNN^2 + 
          2664*Q^4*(omega - s)^7*s^2*s23^3*SUNN^2 - 156*Q^2*(omega - s)^8*s^2*
           s23^3*SUNN^2 + 1440*Q^10*(omega - s)^3*s^3*s23^3*SUNN^2 + 
          4184*Q^8*(omega - s)^4*s^3*s23^3*SUNN^2 - 6124*Q^6*(omega - s)^5*
           s^3*s23^3*SUNN^2 + 4854*Q^4*(omega - s)^6*s^3*s23^3*SUNN^2 - 
          432*Q^2*(omega - s)^7*s^3*s23^3*SUNN^2 + 144*Q^10*(omega - s)^2*s^4*
           s23^3*SUNN^2 + 1626*Q^8*(omega - s)^3*s^4*s23^3*SUNN^2 - 
          1728*Q^6*(omega - s)^4*s^4*s23^3*SUNN^2 + 4792*Q^4*(omega - s)^5*
           s^4*s23^3*SUNN^2 - 660*Q^2*(omega - s)^6*s^4*s23^3*SUNN^2 + 
          228*Q^8*(omega - s)^2*s^5*s23^3*SUNN^2 + 420*Q^6*(omega - s)^3*s^5*
           s23^3*SUNN^2 + 2670*Q^4*(omega - s)^4*s^5*s23^3*SUNN^2 - 
          600*Q^2*(omega - s)^5*s^5*s23^3*SUNN^2 + 6*Q^8*(omega - s)*s^6*
           s23^3*SUNN^2 + 208*Q^6*(omega - s)^2*s^6*s23^3*SUNN^2 + 
          816*Q^4*(omega - s)^3*s^6*s23^3*SUNN^2 - 324*Q^2*(omega - s)^4*s^6*
           s23^3*SUNN^2 + 12*Q^6*(omega - s)*s^7*s23^3*SUNN^2 + 
          122*Q^4*(omega - s)^2*s^7*s23^3*SUNN^2 - 96*Q^2*(omega - s)^3*s^7*
           s23^3*SUNN^2 + 6*Q^4*(omega - s)*s^8*s23^3*SUNN^2 - 
          12*Q^2*(omega - s)^2*s^8*s23^3*SUNN^2 - 256*Q^14*(omega - s)^3*
           s23^4*SUNN^2 + 1984*Q^12*(omega - s)^4*s23^4*SUNN^2 + 
          1096*Q^10*(omega - s)^5*s23^4*SUNN^2 - 1920*Q^8*(omega - s)^6*s23^4*
           SUNN^2 + 492*Q^6*(omega - s)^7*s23^4*SUNN^2 - 24*Q^4*(omega - s)^8*
           s23^4*SUNN^2 + 2304*Q^12*(omega - s)^3*s*s23^4*SUNN^2 + 
          1184*Q^10*(omega - s)^4*s*s23^4*SUNN^2 - 5552*Q^8*(omega - s)^5*s*
           s23^4*SUNN^2 + 3744*Q^6*(omega - s)^6*s*s23^4*SUNN^2 - 
          444*Q^4*(omega - s)^7*s*s23^4*SUNN^2 + 6*Q^2*(omega - s)^8*s*s23^4*
           SUNN^2 + 576*Q^12*(omega - s)^2*s^2*s23^4*SUNN^2 + 
          2480*Q^10*(omega - s)^3*s^2*s23^4*SUNN^2 - 3488*Q^8*(omega - s)^4*
           s^2*s23^4*SUNN^2 + 8100*Q^6*(omega - s)^5*s^2*s23^4*SUNN^2 - 
          1728*Q^4*(omega - s)^6*s^2*s23^4*SUNN^2 + 36*Q^2*(omega - s)^7*s^2*
           s23^4*SUNN^2 + 1056*Q^10*(omega - s)^2*s^3*s23^4*SUNN^2 + 
          1504*Q^8*(omega - s)^3*s^3*s23^4*SUNN^2 + 7488*Q^6*(omega - s)^4*
           s^3*s23^4*SUNN^2 - 2964*Q^4*(omega - s)^5*s^3*s23^4*SUNN^2 + 
          90*Q^2*(omega - s)^6*s^3*s23^4*SUNN^2 + 72*Q^10*(omega - s)*s^4*
           s23^4*SUNN^2 + 1248*Q^8*(omega - s)^2*s^4*s23^4*SUNN^2 + 
          3252*Q^6*(omega - s)^3*s^4*s23^4*SUNN^2 - 2616*Q^4*(omega - s)^4*
           s^4*s23^4*SUNN^2 + 120*Q^2*(omega - s)^5*s^4*s23^4*SUNN^2 + 
          144*Q^8*(omega - s)*s^5*s23^4*SUNN^2 + 672*Q^6*(omega - s)^2*s^5*
           s23^4*SUNN^2 - 1188*Q^4*(omega - s)^3*s^5*s23^4*SUNN^2 + 
          90*Q^2*(omega - s)^4*s^5*s23^4*SUNN^2 + 60*Q^6*(omega - s)*s^6*
           s23^4*SUNN^2 - 240*Q^4*(omega - s)^2*s^6*s23^4*SUNN^2 + 
          36*Q^2*(omega - s)^3*s^6*s23^4*SUNN^2 - 12*Q^4*(omega - s)*s^7*
           s23^4*SUNN^2 + 6*Q^2*(omega - s)^2*s^7*s23^4*SUNN^2 + 
          768*Q^14*(omega - s)^2*s23^5*SUNN^2 - 736*Q^12*(omega - s)^3*s23^5*
           SUNN^2 - 2048*Q^10*(omega - s)^4*s23^5*SUNN^2 + 
          1872*Q^8*(omega - s)^5*s23^5*SUNN^2 - 288*Q^6*(omega - s)^6*s23^5*
           SUNN^2 + 6*Q^4*(omega - s)^7*s23^5*SUNN^2 + 
          1600*Q^12*(omega - s)^2*s*s23^5*SUNN^2 + 832*Q^10*(omega - s)^3*s*
           s23^5*SUNN^2 + 6304*Q^8*(omega - s)^4*s*s23^5*SUNN^2 - 
          2448*Q^6*(omega - s)^5*s*s23^5*SUNN^2 + 108*Q^4*(omega - s)^6*s*
           s23^5*SUNN^2 + 288*Q^12*(omega - s)*s^2*s23^5*SUNN^2 + 
          2560*Q^10*(omega - s)^2*s^2*s23^5*SUNN^2 + 4448*Q^8*(omega - s)^3*
           s^2*s23^5*SUNN^2 - 5184*Q^6*(omega - s)^4*s^2*s23^5*SUNN^2 + 
          378*Q^4*(omega - s)^5*s^2*s23^5*SUNN^2 + 576*Q^10*(omega - s)*s^3*
           s23^5*SUNN^2 + 1056*Q^8*(omega - s)^2*s^3*s23^5*SUNN^2 - 
          4320*Q^6*(omega - s)^3*s^3*s23^5*SUNN^2 + 552*Q^4*(omega - s)^4*s^3*
           s23^5*SUNN^2 + 144*Q^8*(omega - s)*s^4*s23^5*SUNN^2 - 
          1440*Q^6*(omega - s)^2*s^4*s23^5*SUNN^2 + 378*Q^4*(omega - s)^3*s^4*
           s23^5*SUNN^2 - 144*Q^6*(omega - s)*s^5*s23^5*SUNN^2 + 
          108*Q^4*(omega - s)^2*s^5*s23^5*SUNN^2 + 6*Q^4*(omega - s)*s^6*
           s23^5*SUNN^2 + 384*Q^14*(omega - s)*s23^6*SUNN^2 + 
          1024*Q^12*(omega - s)^2*s23^6*SUNN^2 + 2112*Q^10*(omega - s)^3*
           s23^6*SUNN^2 - 1152*Q^8*(omega - s)^4*s23^6*SUNN^2 + 
          72*Q^6*(omega - s)^5*s23^6*SUNN^2 + 768*Q^12*(omega - s)*s*s23^6*
           SUNN^2 - 256*Q^10*(omega - s)^2*s*s23^6*SUNN^2 - 
          4416*Q^8*(omega - s)^3*s*s23^6*SUNN^2 + 576*Q^6*(omega - s)^4*s*
           s23^6*SUNN^2 - 192*Q^10*(omega - s)*s^2*s23^6*SUNN^2 - 
          3072*Q^8*(omega - s)^2*s^2*s23^6*SUNN^2 + 1008*Q^6*(omega - s)^3*
           s^2*s23^6*SUNN^2 - 576*Q^8*(omega - s)*s^3*s23^6*SUNN^2 + 
          576*Q^6*(omega - s)^2*s^3*s23^6*SUNN^2 + 72*Q^6*(omega - s)*s^4*
           s23^6*SUNN^2 - 768*Q^12*(omega - s)*s23^7*SUNN^2 - 
          1536*Q^10*(omega - s)^2*s23^7*SUNN^2 + 288*Q^8*(omega - s)^3*s23^7*
           SUNN^2 - 768*Q^10*(omega - s)*s*s23^7*SUNN^2 + 
          960*Q^8*(omega - s)^2*s*s23^7*SUNN^2 + 288*Q^8*(omega - s)*s^2*
           s23^7*SUNN^2 + 384*Q^10*(omega - s)*s23^8*SUNN^2))/
        ((omega - s)^3*(Q^2 + s)^2*(omega + Q^2 - s23)*(omega - s - s23)*
         ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
           4*Q^2*s23)^3*SUNN), "SoftCoefficients" -> {}, 
     "Assumptions" -> Q > 0 && s > 0 && omega > 0 && B > 0 && 
       -Q^2 - s < omega - s < 0 && SUNN > 1 && Nc > 1|>, 
   -1 -> <|"Delta" -> 0, "L0" -> 0, "L1" -> 0, 
     "Regular" -> (-4*Pi*s23*(-(Q^4*(-omega - s)*SUNN) + Q^2*(-omega - s)*s*
           SUNN + 2*Q^4*s23*SUNN))/((-omega - s)*(Q^2 + s)*(omega + s + s23)*
         ((-omega - s)*s + Q^2*s23)) - 
       (2*Pi*(Q^6*(-omega - s)^5*SUNN + 4*Q^4*(-omega - s)^6*SUNN - 
          4*Q^2*(-omega - s)^6*s*SUNN - 5*Q^2*(-omega - s)^5*s^2*SUNN - 
          12*Q^4*(-omega - s)^5*s23*SUNN - 6*Q^4*(-omega - s)^4*s*s23*SUNN + 
          12*Q^2*(-omega - s)^5*s*s23*SUNN + 18*Q^2*(-omega - s)^4*s^2*s23*
           SUNN - 4*Q^6*(-omega - s)^3*s23^2*SUNN + 16*Q^4*(-omega - s)^4*
           s23^2*SUNN + 28*Q^4*(-omega - s)^3*s*s23^2*SUNN - 
          12*Q^2*(-omega - s)^4*s*s23^2*SUNN - 20*Q^2*(-omega - s)^3*s^2*
           s23^2*SUNN + 12*Q^6*(-omega - s)^2*s23^3*SUNN - 
          12*Q^4*(-omega - s)^3*s23^3*SUNN - 36*Q^4*(-omega - s)^2*s*s23^3*
           SUNN + 4*Q^2*(-omega - s)^3*s*s23^3*SUNN + 8*Q^2*(-omega - s)^2*
           s^2*s23^3*SUNN - 16*Q^6*(-omega - s)*s23^4*SUNN + 
          4*Q^4*(-omega - s)^2*s23^4*SUNN + 16*Q^4*(-omega - s)*s*s23^4*
           SUNN + 8*Q^6*s23^5*SUNN))/((-omega - s)^4*(Q^2 + s)^2*
         (omega + s + s23)*((-omega - s)*s + Q^2*s23)) + 
       (2*Pi*(-(Q^2*(-omega - s)) + 2*Q^2*s23 + s*s23)*(-(Q^2*(-omega - s)) + 
          Q^2*s23 + Q^4*SUNN^2 + Q^2*(-omega - s)*SUNN^2 + Q^2*s*SUNN^2 - 
          Q^2*s23*SUNN^2))/((-omega - s)*(Q^2 + s)^3*(omega + s + s23)*
         SUNN) + (2*Pi*s*(Q^4 + Q^2*(-omega - s) + Q^2*s - Q^2*s23 - 
          Q^2*(-omega - s)*SUNN^2 + Q^2*s23*SUNN^2))/
        ((-omega - s)*(Q^2 + s)^3*SUNN) + 
       (4*Pi*(Q^8*(-omega - s) + 3*Q^6*(-omega - s)*s + 2*Q^4*(-omega - s)^2*
           s + Q^2*(-omega - s)^3*s + 3*Q^4*(-omega - s)*s^2 + 
          2*Q^2*(-omega - s)^2*s^2 + Q^2*(-omega - s)*s^3 - Q^8*s23 - 
          3*Q^6*s*s23 - 4*Q^4*(-omega - s)*s*s23 - 3*Q^2*(-omega - s)^2*s*
           s23 - 3*Q^4*s^2*s23 - 4*Q^2*(-omega - s)*s^2*s23 - Q^2*s^3*s23 + 
          2*Q^4*s*s23^2 + 3*Q^2*(-omega - s)*s*s23^2 + 2*Q^2*s^2*s23^2 - 
          Q^2*s*s23^3 - Q^8*(-omega - s)*SUNN^2 - 2*Q^6*(-omega - s)*s*
           SUNN^2 - Q^4*(-omega - s)^2*s*SUNN^2 - Q^2*(-omega - s)^3*s*
           SUNN^2 - Q^4*(-omega - s)*s^2*SUNN^2 - Q^2*(-omega - s)^2*s^2*
           SUNN^2 + 2*Q^8*s23*SUNN^2 + Q^6*(-omega - s)*s23*SUNN^2 + 
          5*Q^6*s*s23*SUNN^2 + 4*Q^4*(-omega - s)*s*s23*SUNN^2 + 
          3*Q^2*(-omega - s)^2*s*s23*SUNN^2 + 4*Q^4*s^2*s23*SUNN^2 + 
          3*Q^2*(-omega - s)*s^2*s23*SUNN^2 + Q^2*s^3*s23*SUNN^2 - 
          Q^6*s23^2*SUNN^2 - 3*Q^4*s*s23^2*SUNN^2 - 3*Q^2*(-omega - s)*s*
           s23^2*SUNN^2 - 2*Q^2*s^2*s23^2*SUNN^2 + Q^2*s*s23^3*SUNN^2))/
        ((-omega - s)*(Q^2 + s)^3*(-omega + Q^2 - s23)*(omega + s + s23)*
         SUNN) + (Pi*(6*Q^6*(-omega - s)^10*s + 6*Q^4*(-omega - s)^11*s + 
          4*Q^2*(-omega - s)^12*s + 36*Q^6*(-omega - s)^9*s^2 + 
          46*Q^4*(-omega - s)^10*s^2 + 32*Q^2*(-omega - s)^11*s^2 + 
          90*Q^6*(-omega - s)^8*s^3 + 150*Q^4*(-omega - s)^9*s^3 + 
          112*Q^2*(-omega - s)^10*s^3 + 120*Q^6*(-omega - s)^7*s^4 + 
          270*Q^4*(-omega - s)^8*s^4 + 224*Q^2*(-omega - s)^9*s^4 + 
          90*Q^6*(-omega - s)^6*s^5 + 290*Q^4*(-omega - s)^7*s^5 + 
          280*Q^2*(-omega - s)^8*s^5 + 36*Q^6*(-omega - s)^5*s^6 + 
          186*Q^4*(-omega - s)^6*s^6 + 224*Q^2*(-omega - s)^7*s^6 + 
          6*Q^6*(-omega - s)^4*s^7 + 66*Q^4*(-omega - s)^5*s^7 + 
          112*Q^2*(-omega - s)^6*s^7 + 10*Q^4*(-omega - s)^4*s^8 + 
          32*Q^2*(-omega - s)^5*s^8 + 4*Q^2*(-omega - s)^4*s^9 + 
          6*Q^8*(-omega - s)^9*s23 + 6*Q^6*(-omega - s)^10*s23 + 
          4*Q^4*(-omega - s)^11*s23 + 108*Q^8*(-omega - s)^8*s*s23 + 
          114*Q^6*(-omega - s)^9*s*s23 + 70*Q^4*(-omega - s)^10*s*s23 - 
          12*Q^2*(-omega - s)^11*s*s23 + 378*Q^8*(-omega - s)^7*s^2*s23 + 
          534*Q^6*(-omega - s)^8*s^2*s23 + 334*Q^4*(-omega - s)^9*s^2*s23 - 
          86*Q^2*(-omega - s)^10*s^2*s23 + 552*Q^8*(-omega - s)^6*s^3*s23 + 
          1122*Q^6*(-omega - s)^7*s^3*s23 + 758*Q^4*(-omega - s)^8*s^3*s23 - 
          266*Q^2*(-omega - s)^9*s^3*s23 + 378*Q^8*(-omega - s)^5*s^4*s23 + 
          1218*Q^6*(-omega - s)^6*s^4*s23 + 950*Q^4*(-omega - s)^7*s^4*s23 - 
          462*Q^2*(-omega - s)^8*s^4*s23 + 108*Q^8*(-omega - s)^4*s^5*s23 + 
          678*Q^6*(-omega - s)^5*s^5*s23 + 674*Q^4*(-omega - s)^6*s^5*s23 - 
          490*Q^2*(-omega - s)^7*s^5*s23 + 6*Q^8*(-omega - s)^3*s^6*s23 + 
          162*Q^6*(-omega - s)^4*s^6*s23 + 250*Q^4*(-omega - s)^5*s^6*s23 - 
          322*Q^2*(-omega - s)^6*s^6*s23 + 6*Q^6*(-omega - s)^3*s^7*s23 + 
          34*Q^4*(-omega - s)^4*s^7*s23 - 126*Q^2*(-omega - s)^5*s^7*s23 - 
          2*Q^4*(-omega - s)^3*s^8*s23 - 26*Q^2*(-omega - s)^4*s^8*s23 - 
          2*Q^2*(-omega - s)^3*s^9*s23 + 72*Q^10*(-omega - s)^7*s23^2 + 
          68*Q^8*(-omega - s)^8*s23^2 + 38*Q^6*(-omega - s)^9*s23^2 - 
          12*Q^4*(-omega - s)^10*s23^2 + 576*Q^10*(-omega - s)^6*s*s23^2 + 
          624*Q^8*(-omega - s)^7*s*s23^2 + 296*Q^6*(-omega - s)^8*s*s23^2 - 
          222*Q^4*(-omega - s)^9*s*s23^2 + 14*Q^2*(-omega - s)^10*s*s23^2 + 
          1008*Q^10*(-omega - s)^5*s^2*s23^2 + 1716*Q^8*(-omega - s)^6*s^2*
           s23^2 + 762*Q^6*(-omega - s)^7*s^2*s23^2 - 958*Q^4*(-omega - s)^8*
           s^2*s23^2 + 94*Q^2*(-omega - s)^9*s^2*s23^2 + 
          576*Q^10*(-omega - s)^4*s^3*s23^2 + 1888*Q^8*(-omega - s)^5*s^3*
           s23^2 + 844*Q^6*(-omega - s)^6*s^3*s23^2 - 1878*Q^4*(-omega - s)^7*
           s^3*s23^2 + 272*Q^2*(-omega - s)^8*s^3*s23^2 + 
          72*Q^10*(-omega - s)^3*s^4*s23^2 + 780*Q^8*(-omega - s)^4*s^4*
           s23^2 + 346*Q^6*(-omega - s)^5*s^4*s23^2 - 1950*Q^4*(-omega - s)^6*
           s^4*s23^2 + 442*Q^2*(-omega - s)^7*s^4*s23^2 + 
          48*Q^8*(-omega - s)^3*s^5*s23^2 - 48*Q^6*(-omega - s)^4*s^5*s23^2 - 
          1082*Q^4*(-omega - s)^5*s^5*s23^2 + 440*Q^2*(-omega - s)^6*s^5*
           s23^2 - 4*Q^8*(-omega - s)^2*s^6*s23^2 - 58*Q^6*(-omega - s)^3*s^6*
           s23^2 - 282*Q^4*(-omega - s)^4*s^6*s23^2 + 274*Q^2*(-omega - s)^5*
           s^6*s23^2 - 4*Q^6*(-omega - s)^2*s^7*s23^2 - 18*Q^4*(-omega - s)^3*
           s^7*s23^2 + 104*Q^2*(-omega - s)^4*s^7*s23^2 + 
          2*Q^4*(-omega - s)^2*s^8*s23^2 + 22*Q^2*(-omega - s)^3*s^8*s23^2 + 
          2*Q^2*(-omega - s)^2*s^9*s23^2 + 288*Q^12*(-omega - s)^5*s23^3 + 
          240*Q^10*(-omega - s)^6*s23^3 + 74*Q^8*(-omega - s)^7*s23^3 - 
          136*Q^6*(-omega - s)^8*s23^3 + 14*Q^4*(-omega - s)^9*s23^3 + 
          960*Q^12*(-omega - s)^4*s*s23^3 + 1056*Q^10*(-omega - s)^5*s*
           s23^3 + 28*Q^8*(-omega - s)^6*s*s23^3 - 1172*Q^6*(-omega - s)^7*s*
           s23^3 + 258*Q^4*(-omega - s)^8*s*s23^3 - 8*Q^2*(-omega - s)^9*s*
           s23^3 + 288*Q^12*(-omega - s)^3*s^2*s23^3 + 
          1216*Q^10*(-omega - s)^4*s^2*s23^3 - 466*Q^8*(-omega - s)^5*s^2*
           s23^3 - 2808*Q^6*(-omega - s)^6*s^2*s23^3 + 
          1040*Q^4*(-omega - s)^7*s^2*s23^3 - 52*Q^2*(-omega - s)^8*s^2*
           s23^3 + 96*Q^10*(-omega - s)^3*s^3*s23^3 - 760*Q^8*(-omega - s)^4*
           s^3*s23^3 - 2708*Q^6*(-omega - s)^5*s^3*s23^3 + 
          1894*Q^4*(-omega - s)^6*s^3*s23^3 - 144*Q^2*(-omega - s)^7*s^3*
           s23^3 - 48*Q^10*(-omega - s)^2*s^4*s23^3 - 378*Q^8*(-omega - s)^3*
           s^4*s23^3 - 952*Q^6*(-omega - s)^4*s^4*s23^3 + 
          1848*Q^4*(-omega - s)^5*s^4*s23^3 - 220*Q^2*(-omega - s)^6*s^4*
           s23^3 - 36*Q^8*(-omega - s)^2*s^5*s23^3 + 36*Q^6*(-omega - s)^3*
           s^5*s23^3 + 1006*Q^4*(-omega - s)^4*s^5*s23^3 - 
          200*Q^2*(-omega - s)^5*s^5*s23^3 + 2*Q^8*(-omega - s)*s^6*s23^3 + 
          56*Q^6*(-omega - s)^2*s^6*s23^3 + 296*Q^4*(-omega - s)^3*s^6*
           s23^3 - 108*Q^2*(-omega - s)^4*s^6*s23^3 + 4*Q^6*(-omega - s)*s^7*
           s23^3 + 42*Q^4*(-omega - s)^2*s^7*s23^3 - 32*Q^2*(-omega - s)^3*
           s^7*s23^3 + 2*Q^4*(-omega - s)*s^8*s23^3 - 4*Q^2*(-omega - s)^2*
           s^8*s23^3 + 384*Q^14*(-omega - s)^3*s23^4 + 
          192*Q^12*(-omega - s)^4*s23^4 - 200*Q^10*(-omega - s)^5*s23^4 - 
          480*Q^8*(-omega - s)^6*s23^4 + 164*Q^6*(-omega - s)^7*s23^4 - 
          8*Q^4*(-omega - s)^8*s23^4 - 1184*Q^10*(-omega - s)^4*s*s23^4 - 
          1776*Q^8*(-omega - s)^5*s*s23^4 + 1392*Q^6*(-omega - s)^6*s*s23^4 - 
          148*Q^4*(-omega - s)^7*s*s23^4 + 2*Q^2*(-omega - s)^8*s*s23^4 - 
          192*Q^12*(-omega - s)^2*s^2*s23^4 - 848*Q^10*(-omega - s)^3*s^2*
           s23^4 - 1184*Q^8*(-omega - s)^4*s^2*s23^4 + 
          3084*Q^6*(-omega - s)^5*s^2*s23^4 - 576*Q^4*(-omega - s)^6*s^2*
           s23^4 + 12*Q^2*(-omega - s)^7*s^2*s23^4 - 96*Q^10*(-omega - s)^2*
           s^3*s23^4 + 448*Q^8*(-omega - s)^3*s^3*s23^4 + 
          2848*Q^6*(-omega - s)^4*s^3*s23^4 - 988*Q^4*(-omega - s)^5*s^3*
           s23^4 + 30*Q^2*(-omega - s)^6*s^3*s23^4 + 24*Q^10*(-omega - s)*s^4*
           s23^4 + 384*Q^8*(-omega - s)^2*s^4*s23^4 + 1212*Q^6*(-omega - s)^3*
           s^4*s23^4 - 872*Q^4*(-omega - s)^4*s^4*s23^4 + 
          40*Q^2*(-omega - s)^5*s^4*s23^4 + 48*Q^8*(-omega - s)*s^5*s23^4 + 
          240*Q^6*(-omega - s)^2*s^5*s23^4 - 396*Q^4*(-omega - s)^3*s^5*
           s23^4 + 30*Q^2*(-omega - s)^4*s^5*s23^4 + 20*Q^6*(-omega - s)*s^6*
           s23^4 - 80*Q^4*(-omega - s)^2*s^6*s23^4 + 12*Q^2*(-omega - s)^3*
           s^6*s23^4 - 4*Q^4*(-omega - s)*s^7*s23^4 + 2*Q^2*(-omega - s)^2*
           s^7*s23^4 - 256*Q^14*(-omega - s)^2*s23^5 - 
          544*Q^12*(-omega - s)^3*s23^5 - 384*Q^10*(-omega - s)^4*s23^5 + 
          624*Q^8*(-omega - s)^5*s23^5 - 96*Q^6*(-omega - s)^6*s23^5 + 
          2*Q^4*(-omega - s)^7*s23^5 - 64*Q^12*(-omega - s)^2*s*s23^5 + 
          576*Q^10*(-omega - s)^3*s*s23^5 + 2336*Q^8*(-omega - s)^4*s*s23^5 - 
          816*Q^6*(-omega - s)^5*s*s23^5 + 36*Q^4*(-omega - s)^6*s*s23^5 + 
          96*Q^12*(-omega - s)*s^2*s23^5 + 896*Q^10*(-omega - s)^2*s^2*
           s23^5 + 1696*Q^8*(-omega - s)^3*s^2*s23^5 - 
          1728*Q^6*(-omega - s)^4*s^2*s23^5 + 126*Q^4*(-omega - s)^5*s^2*
           s23^5 + 192*Q^10*(-omega - s)*s^3*s23^5 + 416*Q^8*(-omega - s)^2*
           s^3*s23^5 - 1440*Q^6*(-omega - s)^3*s^3*s23^5 + 
          184*Q^4*(-omega - s)^4*s^3*s23^5 + 48*Q^8*(-omega - s)*s^4*s23^5 - 
          480*Q^6*(-omega - s)^2*s^4*s23^5 + 126*Q^4*(-omega - s)^3*s^4*
           s23^5 - 48*Q^6*(-omega - s)*s^5*s23^5 + 36*Q^4*(-omega - s)^2*s^5*
           s23^5 + 2*Q^4*(-omega - s)*s^6*s23^5 + 128*Q^14*(-omega - s)*
           s23^6 + 512*Q^12*(-omega - s)^2*s23^6 + 704*Q^10*(-omega - s)^3*
           s23^6 - 384*Q^8*(-omega - s)^4*s23^6 + 24*Q^6*(-omega - s)^5*
           s23^6 + 256*Q^12*(-omega - s)*s*s23^6 - 1472*Q^8*(-omega - s)^3*s*
           s23^6 + 192*Q^6*(-omega - s)^4*s*s23^6 - 64*Q^10*(-omega - s)*s^2*
           s23^6 - 1024*Q^8*(-omega - s)^2*s^2*s23^6 + 336*Q^6*(-omega - s)^3*
           s^2*s23^6 - 192*Q^8*(-omega - s)*s^3*s23^6 + 
          192*Q^6*(-omega - s)^2*s^3*s23^6 + 24*Q^6*(-omega - s)*s^4*s23^6 - 
          256*Q^12*(-omega - s)*s23^7 - 512*Q^10*(-omega - s)^2*s23^7 + 
          96*Q^8*(-omega - s)^3*s23^7 - 256*Q^10*(-omega - s)*s*s23^7 + 
          320*Q^8*(-omega - s)^2*s*s23^7 + 96*Q^8*(-omega - s)*s^2*s23^7 + 
          128*Q^10*(-omega - s)*s23^8 - 2*Q^8*(-omega - s)^10*SUNN^2 - 
          10*Q^6*(-omega - s)^11*SUNN^2 - 8*Q^4*(-omega - s)^12*SUNN^2 - 
          12*Q^8*(-omega - s)^9*s*SUNN^2 - 70*Q^6*(-omega - s)^10*s*SUNN^2 - 
          56*Q^4*(-omega - s)^11*s*SUNN^2 + 4*Q^2*(-omega - s)^12*s*SUNN^2 - 
          30*Q^8*(-omega - s)^8*s^2*SUNN^2 - 210*Q^6*(-omega - s)^9*s^2*
           SUNN^2 - 168*Q^4*(-omega - s)^10*s^2*SUNN^2 + 
          36*Q^2*(-omega - s)^11*s^2*SUNN^2 - 40*Q^8*(-omega - s)^7*s^3*
           SUNN^2 - 350*Q^6*(-omega - s)^8*s^3*SUNN^2 - 
          280*Q^4*(-omega - s)^9*s^3*SUNN^2 + 140*Q^2*(-omega - s)^10*s^3*
           SUNN^2 - 30*Q^8*(-omega - s)^6*s^4*SUNN^2 - 350*Q^6*(-omega - s)^7*
           s^4*SUNN^2 - 280*Q^4*(-omega - s)^8*s^4*SUNN^2 + 
          308*Q^2*(-omega - s)^9*s^4*SUNN^2 - 12*Q^8*(-omega - s)^5*s^5*
           SUNN^2 - 210*Q^6*(-omega - s)^6*s^5*SUNN^2 - 
          168*Q^4*(-omega - s)^7*s^5*SUNN^2 + 420*Q^2*(-omega - s)^8*s^5*
           SUNN^2 - 2*Q^8*(-omega - s)^4*s^6*SUNN^2 - 70*Q^6*(-omega - s)^5*
           s^6*SUNN^2 - 56*Q^4*(-omega - s)^6*s^6*SUNN^2 + 
          364*Q^2*(-omega - s)^7*s^6*SUNN^2 - 10*Q^6*(-omega - s)^4*s^7*
           SUNN^2 - 8*Q^4*(-omega - s)^5*s^7*SUNN^2 + 196*Q^2*(-omega - s)^6*
           s^7*SUNN^2 + 60*Q^2*(-omega - s)^5*s^8*SUNN^2 + 
          8*Q^2*(-omega - s)^4*s^9*SUNN^2 - 24*Q^10*(-omega - s)^8*s23*
           SUNN^2 - 124*Q^8*(-omega - s)^9*s23*SUNN^2 - 
          74*Q^6*(-omega - s)^10*s23*SUNN^2 + 28*Q^4*(-omega - s)^11*s23*
           SUNN^2 - 96*Q^10*(-omega - s)^7*s*s23*SUNN^2 - 
          624*Q^8*(-omega - s)^8*s*s23*SUNN^2 - 330*Q^6*(-omega - s)^9*s*s23*
           SUNN^2 + 242*Q^4*(-omega - s)^10*s*s23*SUNN^2 - 
          20*Q^2*(-omega - s)^11*s*s23*SUNN^2 - 144*Q^10*(-omega - s)^6*s^2*
           s23*SUNN^2 - 1260*Q^8*(-omega - s)^7*s^2*s23*SUNN^2 - 
          522*Q^6*(-omega - s)^8*s^2*s23*SUNN^2 + 932*Q^4*(-omega - s)^9*s^2*
           s23*SUNN^2 - 146*Q^2*(-omega - s)^10*s^2*s23*SUNN^2 - 
          96*Q^10*(-omega - s)^5*s^3*s23*SUNN^2 - 1280*Q^8*(-omega - s)^6*s^3*
           s23*SUNN^2 - 250*Q^6*(-omega - s)^7*s^3*s23*SUNN^2 + 
          2030*Q^4*(-omega - s)^8*s^3*s23*SUNN^2 - 458*Q^2*(-omega - s)^9*s^3*
           s23*SUNN^2 - 24*Q^10*(-omega - s)^4*s^4*s23*SUNN^2 - 
          660*Q^8*(-omega - s)^5*s^4*s23*SUNN^2 + 210*Q^6*(-omega - s)^6*s^4*
           s23*SUNN^2 + 2680*Q^4*(-omega - s)^7*s^4*s23*SUNN^2 - 
          802*Q^2*(-omega - s)^8*s^4*s23*SUNN^2 - 144*Q^8*(-omega - s)^4*s^5*
           s23*SUNN^2 + 306*Q^6*(-omega - s)^5*s^5*s23*SUNN^2 + 
          2158*Q^4*(-omega - s)^6*s^5*s23*SUNN^2 - 850*Q^2*(-omega - s)^7*s^5*
           s23*SUNN^2 - 4*Q^8*(-omega - s)^3*s^6*s23*SUNN^2 + 
          130*Q^6*(-omega - s)^4*s^6*s23*SUNN^2 + 1012*Q^4*(-omega - s)^5*s^6*
           s23*SUNN^2 - 550*Q^2*(-omega - s)^6*s^6*s23*SUNN^2 + 
          18*Q^6*(-omega - s)^3*s^7*s23*SUNN^2 + 242*Q^4*(-omega - s)^4*s^7*
           s23*SUNN^2 - 206*Q^2*(-omega - s)^5*s^7*s23*SUNN^2 + 
          20*Q^4*(-omega - s)^3*s^8*s23*SUNN^2 - 38*Q^2*(-omega - s)^4*s^8*
           s23*SUNN^2 - 2*Q^2*(-omega - s)^3*s^9*s23*SUNN^2 - 
          96*Q^12*(-omega - s)^6*s23^2*SUNN^2 - 528*Q^10*(-omega - s)^7*s23^2*
           SUNN^2 - 108*Q^8*(-omega - s)^8*s23^2*SUNN^2 + 
          320*Q^6*(-omega - s)^9*s23^2*SUNN^2 - 44*Q^4*(-omega - s)^10*s23^2*
           SUNN^2 - 192*Q^12*(-omega - s)^5*s*s23^2*SUNN^2 - 
          1632*Q^10*(-omega - s)^6*s*s23^2*SUNN^2 + 192*Q^8*(-omega - s)^7*s*
           s23^2*SUNN^2 + 1768*Q^6*(-omega - s)^8*s*s23^2*SUNN^2 - 
          524*Q^4*(-omega - s)^9*s*s23^2*SUNN^2 + 34*Q^2*(-omega - s)^10*s*
           s23^2*SUNN^2 - 96*Q^12*(-omega - s)^4*s^2*s23^2*SUNN^2 - 
          1728*Q^10*(-omega - s)^5*s^2*s23^2*SUNN^2 + 1476*Q^8*(-omega - s)^6*
           s^2*s23^2*SUNN^2 + 4320*Q^6*(-omega - s)^7*s^2*s23^2*SUNN^2 - 
          2042*Q^4*(-omega - s)^8*s^2*s23^2*SUNN^2 + 230*Q^2*(-omega - s)^9*
           s^2*s23^2*SUNN^2 - 672*Q^10*(-omega - s)^4*s^3*s23^2*SUNN^2 + 
          2208*Q^8*(-omega - s)^5*s^3*s23^2*SUNN^2 + 5824*Q^6*(-omega - s)^6*
           s^3*s23^2*SUNN^2 - 3832*Q^4*(-omega - s)^7*s^3*s23^2*SUNN^2 + 
          672*Q^2*(-omega - s)^8*s^3*s23^2*SUNN^2 - 48*Q^10*(-omega - s)^3*
           s^4*s23^2*SUNN^2 + 1308*Q^8*(-omega - s)^4*s^4*s23^2*SUNN^2 + 
          4448*Q^6*(-omega - s)^5*s^4*s23^2*SUNN^2 - 3838*Q^4*(-omega - s)^6*
           s^4*s23^2*SUNN^2 + 1106*Q^2*(-omega - s)^7*s^4*s23^2*SUNN^2 + 
          288*Q^8*(-omega - s)^3*s^5*s23^2*SUNN^2 + 1800*Q^6*(-omega - s)^4*
           s^5*s23^2*SUNN^2 - 1996*Q^4*(-omega - s)^5*s^5*s23^2*SUNN^2 + 
          1120*Q^2*(-omega - s)^6*s^5*s23^2*SUNN^2 + 12*Q^8*(-omega - s)^2*
           s^6*s23^2*SUNN^2 + 320*Q^6*(-omega - s)^3*s^6*s23^2*SUNN^2 - 
          422*Q^4*(-omega - s)^4*s^6*s23^2*SUNN^2 + 714*Q^2*(-omega - s)^5*
           s^6*s23^2*SUNN^2 + 16*Q^6*(-omega - s)^2*s^7*s23^2*SUNN^2 + 
          16*Q^4*(-omega - s)^3*s^7*s23^2*SUNN^2 + 280*Q^2*(-omega - s)^4*s^7*
           s23^2*SUNN^2 + 10*Q^4*(-omega - s)^2*s^8*s23^2*SUNN^2 + 
          62*Q^2*(-omega - s)^3*s^8*s23^2*SUNN^2 + 6*Q^2*(-omega - s)^2*s^9*
           s23^2*SUNN^2 - 128*Q^14*(-omega - s)^4*s23^3*SUNN^2 - 
          832*Q^12*(-omega - s)^5*s23^3*SUNN^2 + 688*Q^10*(-omega - s)^6*
           s23^3*SUNN^2 + 1158*Q^8*(-omega - s)^7*s23^3*SUNN^2 - 
          512*Q^6*(-omega - s)^8*s23^3*SUNN^2 + 42*Q^4*(-omega - s)^9*s23^3*
           SUNN^2 - 1024*Q^12*(-omega - s)^4*s*s23^3*SUNN^2 + 
          3040*Q^10*(-omega - s)^5*s*s23^3*SUNN^2 + 3652*Q^8*(-omega - s)^6*s*
           s23^3*SUNN^2 - 3204*Q^6*(-omega - s)^7*s*s23^3*SUNN^2 + 
          674*Q^4*(-omega - s)^8*s*s23^3*SUNN^2 - 24*Q^2*(-omega - s)^9*s*
           s23^3*SUNN^2 - 192*Q^12*(-omega - s)^3*s^2*s23^3*SUNN^2 + 
          3648*Q^10*(-omega - s)^4*s^2*s23^3*SUNN^2 + 5274*Q^8*(-omega - s)^5*
           s^2*s23^3*SUNN^2 - 6864*Q^6*(-omega - s)^6*s^2*s23^3*SUNN^2 + 
          2664*Q^4*(-omega - s)^7*s^2*s23^3*SUNN^2 - 156*Q^2*(-omega - s)^8*
           s^2*s23^3*SUNN^2 + 1440*Q^10*(-omega - s)^3*s^3*s23^3*SUNN^2 + 
          4184*Q^8*(-omega - s)^4*s^3*s23^3*SUNN^2 - 6124*Q^6*(-omega - s)^5*
           s^3*s23^3*SUNN^2 + 4854*Q^4*(-omega - s)^6*s^3*s23^3*SUNN^2 - 
          432*Q^2*(-omega - s)^7*s^3*s23^3*SUNN^2 + 144*Q^10*(-omega - s)^2*
           s^4*s23^3*SUNN^2 + 1626*Q^8*(-omega - s)^3*s^4*s23^3*SUNN^2 - 
          1728*Q^6*(-omega - s)^4*s^4*s23^3*SUNN^2 + 4792*Q^4*(-omega - s)^5*
           s^4*s23^3*SUNN^2 - 660*Q^2*(-omega - s)^6*s^4*s23^3*SUNN^2 + 
          228*Q^8*(-omega - s)^2*s^5*s23^3*SUNN^2 + 420*Q^6*(-omega - s)^3*
           s^5*s23^3*SUNN^2 + 2670*Q^4*(-omega - s)^4*s^5*s23^3*SUNN^2 - 
          600*Q^2*(-omega - s)^5*s^5*s23^3*SUNN^2 + 6*Q^8*(-omega - s)*s^6*
           s23^3*SUNN^2 + 208*Q^6*(-omega - s)^2*s^6*s23^3*SUNN^2 + 
          816*Q^4*(-omega - s)^3*s^6*s23^3*SUNN^2 - 324*Q^2*(-omega - s)^4*
           s^6*s23^3*SUNN^2 + 12*Q^6*(-omega - s)*s^7*s23^3*SUNN^2 + 
          122*Q^4*(-omega - s)^2*s^7*s23^3*SUNN^2 - 96*Q^2*(-omega - s)^3*s^7*
           s23^3*SUNN^2 + 6*Q^4*(-omega - s)*s^8*s23^3*SUNN^2 - 
          12*Q^2*(-omega - s)^2*s^8*s23^3*SUNN^2 - 256*Q^14*(-omega - s)^3*
           s23^4*SUNN^2 + 1984*Q^12*(-omega - s)^4*s23^4*SUNN^2 + 
          1096*Q^10*(-omega - s)^5*s23^4*SUNN^2 - 1920*Q^8*(-omega - s)^6*
           s23^4*SUNN^2 + 492*Q^6*(-omega - s)^7*s23^4*SUNN^2 - 
          24*Q^4*(-omega - s)^8*s23^4*SUNN^2 + 2304*Q^12*(-omega - s)^3*s*
           s23^4*SUNN^2 + 1184*Q^10*(-omega - s)^4*s*s23^4*SUNN^2 - 
          5552*Q^8*(-omega - s)^5*s*s23^4*SUNN^2 + 3744*Q^6*(-omega - s)^6*s*
           s23^4*SUNN^2 - 444*Q^4*(-omega - s)^7*s*s23^4*SUNN^2 + 
          6*Q^2*(-omega - s)^8*s*s23^4*SUNN^2 + 576*Q^12*(-omega - s)^2*s^2*
           s23^4*SUNN^2 + 2480*Q^10*(-omega - s)^3*s^2*s23^4*SUNN^2 - 
          3488*Q^8*(-omega - s)^4*s^2*s23^4*SUNN^2 + 8100*Q^6*(-omega - s)^5*
           s^2*s23^4*SUNN^2 - 1728*Q^4*(-omega - s)^6*s^2*s23^4*SUNN^2 + 
          36*Q^2*(-omega - s)^7*s^2*s23^4*SUNN^2 + 1056*Q^10*(-omega - s)^2*
           s^3*s23^4*SUNN^2 + 1504*Q^8*(-omega - s)^3*s^3*s23^4*SUNN^2 + 
          7488*Q^6*(-omega - s)^4*s^3*s23^4*SUNN^2 - 2964*Q^4*(-omega - s)^5*
           s^3*s23^4*SUNN^2 + 90*Q^2*(-omega - s)^6*s^3*s23^4*SUNN^2 + 
          72*Q^10*(-omega - s)*s^4*s23^4*SUNN^2 + 1248*Q^8*(-omega - s)^2*s^4*
           s23^4*SUNN^2 + 3252*Q^6*(-omega - s)^3*s^4*s23^4*SUNN^2 - 
          2616*Q^4*(-omega - s)^4*s^4*s23^4*SUNN^2 + 120*Q^2*(-omega - s)^5*
           s^4*s23^4*SUNN^2 + 144*Q^8*(-omega - s)*s^5*s23^4*SUNN^2 + 
          672*Q^6*(-omega - s)^2*s^5*s23^4*SUNN^2 - 1188*Q^4*(-omega - s)^3*
           s^5*s23^4*SUNN^2 + 90*Q^2*(-omega - s)^4*s^5*s23^4*SUNN^2 + 
          60*Q^6*(-omega - s)*s^6*s23^4*SUNN^2 - 240*Q^4*(-omega - s)^2*s^6*
           s23^4*SUNN^2 + 36*Q^2*(-omega - s)^3*s^6*s23^4*SUNN^2 - 
          12*Q^4*(-omega - s)*s^7*s23^4*SUNN^2 + 6*Q^2*(-omega - s)^2*s^7*
           s23^4*SUNN^2 + 768*Q^14*(-omega - s)^2*s23^5*SUNN^2 - 
          736*Q^12*(-omega - s)^3*s23^5*SUNN^2 - 2048*Q^10*(-omega - s)^4*
           s23^5*SUNN^2 + 1872*Q^8*(-omega - s)^5*s23^5*SUNN^2 - 
          288*Q^6*(-omega - s)^6*s23^5*SUNN^2 + 6*Q^4*(-omega - s)^7*s23^5*
           SUNN^2 + 1600*Q^12*(-omega - s)^2*s*s23^5*SUNN^2 + 
          832*Q^10*(-omega - s)^3*s*s23^5*SUNN^2 + 6304*Q^8*(-omega - s)^4*s*
           s23^5*SUNN^2 - 2448*Q^6*(-omega - s)^5*s*s23^5*SUNN^2 + 
          108*Q^4*(-omega - s)^6*s*s23^5*SUNN^2 + 288*Q^12*(-omega - s)*s^2*
           s23^5*SUNN^2 + 2560*Q^10*(-omega - s)^2*s^2*s23^5*SUNN^2 + 
          4448*Q^8*(-omega - s)^3*s^2*s23^5*SUNN^2 - 5184*Q^6*(-omega - s)^4*
           s^2*s23^5*SUNN^2 + 378*Q^4*(-omega - s)^5*s^2*s23^5*SUNN^2 + 
          576*Q^10*(-omega - s)*s^3*s23^5*SUNN^2 + 1056*Q^8*(-omega - s)^2*
           s^3*s23^5*SUNN^2 - 4320*Q^6*(-omega - s)^3*s^3*s23^5*SUNN^2 + 
          552*Q^4*(-omega - s)^4*s^3*s23^5*SUNN^2 + 144*Q^8*(-omega - s)*s^4*
           s23^5*SUNN^2 - 1440*Q^6*(-omega - s)^2*s^4*s23^5*SUNN^2 + 
          378*Q^4*(-omega - s)^3*s^4*s23^5*SUNN^2 - 144*Q^6*(-omega - s)*s^5*
           s23^5*SUNN^2 + 108*Q^4*(-omega - s)^2*s^5*s23^5*SUNN^2 + 
          6*Q^4*(-omega - s)*s^6*s23^5*SUNN^2 + 384*Q^14*(-omega - s)*s23^6*
           SUNN^2 + 1024*Q^12*(-omega - s)^2*s23^6*SUNN^2 + 
          2112*Q^10*(-omega - s)^3*s23^6*SUNN^2 - 1152*Q^8*(-omega - s)^4*
           s23^6*SUNN^2 + 72*Q^6*(-omega - s)^5*s23^6*SUNN^2 + 
          768*Q^12*(-omega - s)*s*s23^6*SUNN^2 - 256*Q^10*(-omega - s)^2*s*
           s23^6*SUNN^2 - 4416*Q^8*(-omega - s)^3*s*s23^6*SUNN^2 + 
          576*Q^6*(-omega - s)^4*s*s23^6*SUNN^2 - 192*Q^10*(-omega - s)*s^2*
           s23^6*SUNN^2 - 3072*Q^8*(-omega - s)^2*s^2*s23^6*SUNN^2 + 
          1008*Q^6*(-omega - s)^3*s^2*s23^6*SUNN^2 - 576*Q^8*(-omega - s)*s^3*
           s23^6*SUNN^2 + 576*Q^6*(-omega - s)^2*s^3*s23^6*SUNN^2 + 
          72*Q^6*(-omega - s)*s^4*s23^6*SUNN^2 - 768*Q^12*(-omega - s)*s23^7*
           SUNN^2 - 1536*Q^10*(-omega - s)^2*s23^7*SUNN^2 + 
          288*Q^8*(-omega - s)^3*s23^7*SUNN^2 - 768*Q^10*(-omega - s)*s*s23^7*
           SUNN^2 + 960*Q^8*(-omega - s)^2*s*s23^7*SUNN^2 + 
          288*Q^8*(-omega - s)*s^2*s23^7*SUNN^2 + 384*Q^10*(-omega - s)*s23^8*
           SUNN^2))/((-omega - s)^3*(Q^2 + s)^2*(-omega + Q^2 - s23)*
         (-omega - s - s23)*((-omega - s)*s + Q^2*s23)*
         ((-omega - s)^2 + 2*(-omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN), 
     "SoftCoefficients" -> {}, "Assumptions" -> Q > 0 && s > 0 && 
       omega > 0 && B > 0 && -Q^2 - s < -omega - s < 0 && SUNN > 1 && 
       Nc > 1|>|>, "InputHash" -> 8404130403822451896056658867629854935142308\
7313263679471630553916353572281933, 
 "Checks" -> <|"physical transverse coordinate inserted" -> True, 
   "candidate preserves transverse substitution" -> True, 
   "native master retains its regulator remainder" -> True, 
   "coefficient valuation is rational" -> True, 
   "integer coefficient regulator valuation" -> True, 
   "actual coefficient preserves required master depth" -> True, 
   "integer master Laurent support" -> True, 
   "master Laurent coefficients independent of regulator" -> True, 
   "complete master Laurent reconstruction" -> True, 
   "rational coefficient has polynomial regulator support" -> True, 
   "integer rational identity coverage" -> True, 
   "complete truncated rational numerator reconstruction" -> True, 
   "product agrees through requested regulator order" -> True, 
   "native product contains no higher regulator powers" -> True, 
   "ordinary cut contraction is symbolic and evaluated" -> True, 
   "regulated soft power is affine with integer recoil degree" -> True, 
   "exact factored recoil coefficient" -> True, 
   "exact reduced logarithmic derivative" -> True, 
   "factored recoil valuation is an unconditional integer" -> True, 
   "spin coefficient has integer recoil valuation" -> True, 
   "endpoint regulator has the defining convergence orientation" -> True, 
   "no higher logarithmic plus distribution survives" -> True|>, 
 "Accepted" -> True, "ElapsedSeconds" -> 16.697114`7.674186405829918|>
