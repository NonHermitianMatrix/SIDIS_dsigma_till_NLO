<|"Sector" -> "Real", "Kind" -> "ExtendedResponse", "Index" -> {5, 4, 1}, 
 "Ordinary" -> 0, "Branches" -> 
  <|1 -> <|"Delta" -> 0, "L0" -> 0, "L1" -> 0, "Regular" -> 0, 
     "SoftCoefficients" -> {}, "Assumptions" -> Q > 0 && s > 0 && 
       omega > 0 && B > 0 && -Q^2 - s < omega - s < 0 && SUNN > 1 && 
       Nc > 1|>, -1 -> <|"Delta" -> 0, "L0" -> 0, "L1" -> 0, "Regular" -> 0, 
     "SoftCoefficients" -> {}, "Assumptions" -> Q > 0 && s > 0 && 
       omega > 0 && B > 0 && -Q^2 - s < -omega - s < 0 && SUNN > 1 && 
       Nc > 1|>|>, "InputHash" -> 8404130403822451896056658867629854935142308\
7313263679471630553916353572281933, 
 "Checks" -> <|"physical transverse coordinate inserted" -> True, 
   "candidate preserves transverse substitution" -> True, 
   "ordinary cut contraction is symbolic and evaluated" -> True, 
   "endpoint regulator has the defining convergence orientation" -> True, 
   "no higher logarithmic plus distribution survives" -> True|>, 
 "Accepted" -> True, "ElapsedSeconds" -> 0.01095`4.490959112672108|>
