<|"Diagram" -> 14, "Components" -> {<|"Kind" -> "ExtendedResponse", 
    "Index" -> {1, 1, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^2*s - s^2 + 2*Q^2*t - 6*s*t))/((Q^2 + s)^2*SUNN*t), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 - 5*Q^4*s - 5*Q^2*s^2 + s^3 - 4*Q^2*s*t + 4*s^2*t))/
        ((Q^2 + s)^3*SUNN*t), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - 2*Q^4*s - 3*Q^2*s^2 + 
          Q^4*t - 6*Q^2*s*t + s^2*t))/((Q^2 + s)^3*SUNN*t), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/2*I)*(-2 + D)*(Q^2 - 3*s)*(-1 + SUNN)*
         (1 + SUNN))/((Q^2 + s)^2*SUNN), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 - 7*Q^4*s - 
          8*Q^2*s^2 + s^3 - 4*Q^2*s*t + 4*s^2*t))/((Q^2 + s)^3*SUNN)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/2)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(3*Q^4 + 2*Q^2*s - s^2 + 
          2*Q^2*t - 2*s*t))/((Q^2 + s)^3*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 1, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^2*s - s^2 + 2*Q^2*t - 
          6*s*t))/((Q^2 + s)^2*SUNN*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - 5*Q^4*s - 5*Q^2*s^2 + 
          s^3 - 4*Q^2*s*t + 4*s^2*t))/((Q^2 + s)^3*SUNN*t), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 - 2*Q^4*s - 3*Q^2*s^2 + Q^4*t - 6*Q^2*s*t + s^2*t))/
        ((Q^2 + s)^3*SUNN*t), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/2*I)*(-2 + D)*(Q^2 - 3*s)*(-1 + SUNN)*(1 + SUNN))/
        ((Q^2 + s)^2*SUNN), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 - 7*Q^4*s - 
          8*Q^2*s^2 + s^3 - 4*Q^2*s*t + 4*s^2*t))/((Q^2 + s)^3*SUNN)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/2)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(3*Q^4 + 2*Q^2*s - s^2 + 
          2*Q^2*t - 2*s*t))/((Q^2 + s)^3*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 1, 5}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       (I*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(s + 2*t))/
        ((Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-I)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(-3*Q^4 - 2*Q^2*s + s^2 - 
          2*Q^2*t + 2*s*t))/((Q^2 + s)^3*SUNN*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-I)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^4 + 3*Q^2*s + 3*Q^2*t - s*t))/((Q^2 + s)^3*SUNN*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-I)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*t)/
        ((Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       (I*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*t*(-4*Q^4 - 3*Q^2*s + s^2 - 
          2*Q^2*t + 2*s*t))/((Q^2 + s)^3*SUNN*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-I)*(-2 + D)*(Q^2 - s)*s*(-1 + SUNN)*(1 + SUNN)*t)/
        ((Q^2 + s)^3*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 4, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^2*s + s^2 + 2*Q^2*t - 2*s*t))/
        (2*(Q^2 + s)^2*SUNN*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN))/(2*(Q^2 + s)*SUNN*t), 
      GLI["V10", {1, 1, 0, -1}] -> -1/2*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^4 + 3*Q^2*s + Q^2*t - s*t))/((Q^2 + s)^2*SUNN*t), 
      GLI["V10", {1, 1, -1, 0}] -> -1/2*((-2 + D)*(Q^2 - s)*(-1 + SUNN)*
          (1 + SUNN))/((Q^2 + s)^2*SUNN), GLI["V10", {1, 1, 0, 0}] -> 
       -1/2*((-2 + D)*(Q^2 - s)*(2*Q^2 + s)*(-1 + SUNN)*(1 + SUNN))/
         ((Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/
        (2*(Q^2 + s)*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 4, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^2*s + s^2 + 2*Q^2*t - 
          2*s*t))/((Q^2 + s)^2*SUNN*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/2)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN*t), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + 3*Q^2*s + Q^2*t - s*t))/((Q^2 + s)^2*SUNN*t), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/2*I)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*
         (1 + SUNN))/((Q^2 + s)^2*SUNN), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/2*I)*(-2 + D)*(Q^2 - s)*(2*Q^2 + s)*(-1 + SUNN)*(1 + SUNN))/
        ((Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/2)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/
        ((Q^2 + s)*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 1, 1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 + 4*Q^6*s + 
          3*Q^4*s^2 + 2*Q^2*s^3 + s^4 - 6*Q^4*s*t - 2*Q^2*s^2*t + 4*s^3*t - 
          10*Q^4*t^2 - 8*Q^2*s*t^2 + 10*s^2*t^2 - 8*Q^2*t^3 + 8*s*t^3))/
        ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (2*Q^8 + 3*Q^6*s + Q^4*s^2 + Q^2*s^3 + s^4 + 2*Q^6*t - 4*Q^4*s*t - 
          2*Q^2*s^2*t + 4*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8*s + 3*Q^6*s^2 + 
          3*Q^4*s^3 + Q^2*s^4 - 4*Q^8*t - 5*Q^6*s*t - Q^4*s^2*t - 
          3*Q^2*s^3*t - 3*s^4*t - 8*Q^6*t^2 + 2*Q^4*s*t^2 + 4*Q^2*s^2*t^2 - 
          6*s^3*t^2 - 4*Q^4*t^3 + 8*Q^2*s*t^3 - 4*s^2*t^3))/
        ((Q^2 + s)^3*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (2*Q^4 + Q^2*s - s^2 + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (4*Q^8 + 6*Q^6*s + Q^4*s^2 + s^4 + 4*Q^6*t - 4*Q^4*s*t - 
          4*Q^2*s^2*t + 4*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^8 + 2*Q^6*s + 2*Q^4*s^2 + 2*Q^2*s^3 + s^4 + Q^6*t - 3*Q^4*s*t - 
          Q^2*s^2*t + 3*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 1, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^2 + 3*s + 4*t)*
         (Q^4*s + Q^2*s^2 - 2*s^2*t + 2*Q^2*t^2 - 2*s*t^2))/
        ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (Q^8 - Q^6*s - 5*Q^4*s^2 - 3*Q^2*s^3 + 2*Q^6*t - 4*Q^4*s*t - 
          2*Q^2*s^2*t + 4*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^10 + 3*Q^8*s + 
          3*Q^6*s^2 + Q^4*s^3 + 3*Q^8*t - Q^6*s*t - 11*Q^4*s^2*t - 
          7*Q^2*s^3*t + 6*Q^6*t^2 - 8*Q^4*s*t^2 - 10*Q^2*s^2*t^2 + 
          4*s^3*t^2 + 4*Q^4*t^3 - 8*Q^2*s*t^3 + 4*s^2*t^3))/
        ((Q^2 + s)^3*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (Q^4 - Q^2*s - 2*s^2 + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (2*Q^8 - Q^6*s - 8*Q^4*s^2 - 5*Q^2*s^3 + 4*Q^6*t - 4*Q^4*s*t - 
          4*Q^2*s^2*t + 4*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6*s + 4*Q^4*s^2 + 2*Q^2*s^3 - Q^6*t + 3*Q^4*s*t + Q^2*s^2*t - 
          3*s^3*t + 4*Q^2*s*t^2 - 4*s^2*t^2))/((Q^2 + s)^3*SUNN*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 1, 5}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^8 + 2*D*Q^8 - 28*Q^6*s + 7*D*Q^6*s - 36*Q^4*s^2 + 
          9*D*Q^4*s^2 - 20*Q^2*s^3 + 5*D*Q^2*s^3 - 4*s^4 + D*s^4 + 
          10*Q^4*s*t - 2*D*Q^4*s*t + 16*Q^2*s^2*t - 4*D*Q^2*s^2*t + 6*s^3*t - 
          2*D*s^3*t + 20*Q^4*t^2 - 4*D*Q^4*t^2 + 36*Q^2*s*t^2 - 
          8*D*Q^2*s*t^2 + 8*s^2*t^2 - 4*D*s^2*t^2 + 8*Q^2*t^3 - 8*s*t^3))/
        ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (-4*Q^8 + D*Q^8 - 16*Q^6*s + 4*D*Q^6*s - 24*Q^4*s^2 + 6*D*Q^4*s^2 - 
          16*Q^2*s^3 + 4*D*Q^2*s^3 - 4*s^4 + D*s^4 - 2*Q^6*t + 2*Q^4*s*t + 
          2*Q^2*s^2*t - 2*s^3*t + 8*Q^2*s*t^2 - 8*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^10 + D*Q^10 - 16*Q^8*s + 
          4*D*Q^8*s - 24*Q^6*s^2 + 6*D*Q^6*s^2 - 16*Q^4*s^3 + 4*D*Q^4*s^3 - 
          4*Q^2*s^4 + D*Q^2*s^4 + 6*Q^8*t - D*Q^8*t + 26*Q^6*s*t - 
          6*D*Q^6*s*t + 46*Q^4*s^2*t - 12*D*Q^4*s^2*t + 38*Q^2*s^3*t - 
          10*D*Q^2*s^3*t + 12*s^4*t - 3*D*s^4*t + 14*Q^6*t^2 - 2*D*Q^6*t^2 + 
          18*Q^4*s*t^2 - 6*D*Q^4*s*t^2 + 18*Q^2*s^2*t^2 - 6*D*Q^2*s^2*t^2 + 
          14*s^3*t^2 - 2*D*s^3*t^2 + 4*Q^4*t^3 - 16*Q^2*s*t^3 + 12*s^2*t^3))/
        ((Q^2 + s)^3*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 - 2*Q^2*t + 
          2*s*t))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*(-8*Q^8 + 2*D*Q^8 - 28*Q^6*s + 7*D*Q^6*s - 
          36*Q^4*s^2 + 9*D*Q^4*s^2 - 20*Q^2*s^3 + 5*D*Q^2*s^3 - 4*s^4 + 
          D*s^4 - 4*Q^6*t + 2*Q^4*s*t + 4*Q^2*s^2*t - 2*s^3*t + 8*Q^2*s*t^2 - 
          8*s^2*t^2))/((Q^2 + s)^3*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^10 + D*Q^10 - 
          20*Q^8*s + 5*D*Q^8*s - 40*Q^6*s^2 + 10*D*Q^6*s^2 - 40*Q^4*s^3 + 
          10*D*Q^4*s^3 - 20*Q^2*s^4 + 5*D*Q^2*s^4 - 4*s^5 + D*s^5 - 4*Q^8*t + 
          D*Q^8*t - 14*Q^6*s*t + 4*D*Q^6*s*t - 22*Q^4*s^2*t + 6*D*Q^4*s^2*t - 
          18*Q^2*s^3*t + 4*D*Q^2*s^3*t - 6*s^4*t + D*s^4*t + 8*Q^4*s*t^2 - 
          8*s^3*t^2 + 8*Q^2*s*t^3 - 8*s^2*t^3))/((Q^2 + s)^3*SUNN*t*
         (Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 4, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6*s + 2*Q^4*s^2 + Q^2*s^3 - 
          4*Q^6*t - 8*Q^4*s*t - 8*Q^2*s^2*t - 4*s^3*t - 2*Q^4*t^2 - 
          6*Q^2*s*t^2 - 8*s^2*t^2 + 4*Q^2*t^3 - 4*s*t^3))/
        (4*(Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-Q^4 - Q^2*s + 2*s*t + 2*t^2))/
        (4*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 + 2*Q^6*s + Q^4*s^2 + 3*Q^6*t + 
          2*Q^4*s*t - Q^2*s^2*t - 2*Q^2*s*t^2 + 2*s^2*t^2 - 2*Q^2*t^3 + 
          2*s*t^3))/(4*(Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 + 4*Q^4*s + 5*Q^2*s^2 + 2*s^3 + 4*Q^2*s*t + 4*s^2*t - 
          2*Q^2*t^2 + 2*s*t^2))/(4*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 + 7*Q^6*s + 8*Q^4*s^2 + 3*Q^2*s^3 + 2*Q^4*s*t - 2*s^3*t - 
          4*Q^4*t^2 - 2*Q^2*s*t^2 - 2*s^2*t^2))/(4*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN))/
         SUNN|>, "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 4, 4}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 + 4*Q^6*s + Q^4*s^2 - 2*Q^2*s^3 - s^4 - 8*Q^4*s*t - 
          12*Q^2*s^2*t - 4*s^3*t - 6*Q^4*t^2 - 10*Q^2*s*t^2 - 4*Q^2*t^3 + 
          4*s*t^3))/((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + 3*Q^4*s - s^3 + 4*Q^4*t - 2*Q^2*s*t - 6*s^2*t + 2*Q^2*t^2 - 
          6*s*t^2))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6*s + 2*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t + 5*Q^4*s*t - 3*s^3*t + 
          4*Q^4*t^2 + 2*Q^2*s*t^2 - 6*s^2*t^2 + 2*Q^2*t^3 - 2*s*t^3))/
        ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 + 5*Q^4*s + 
          4*Q^2*s^2 + s^3 + 4*Q^4*t + 4*Q^2*s*t + 2*Q^2*t^2 - 2*s*t^2))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^8 + 10*Q^6*s + 
          7*Q^4*s^2 - s^4 + 8*Q^6*t + 6*Q^4*s*t - 8*Q^2*s^2*t - 6*s^3*t + 
          4*Q^4*t^2 - 6*Q^2*s*t^2 - 6*s^2*t^2))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 - s^2 + Q^2*t - 3*s*t))/((Q^2 + s)*SUNN*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 1, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + 2*Q^4*s + Q^2*s^2 + s^3 + 2*Q^2*s*t + 4*s^2*t - 2*Q^2*t^2 + 
          2*s*t^2))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + Q^4*s + s^3 + 2*Q^4*t + 2*s^2*t))/((Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/4)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(Q^2 + t)*(Q^2 + s + 2*t))/
        ((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 + Q^2*s - s^2 + 
          2*Q^2*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^6 + 2*Q^4*s - Q^2*s^2 + s^3 + 4*Q^4*t + 2*s^2*t))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + s^2 + Q^2*t + s*t))/((Q^2 + s)*SUNN*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 1, 2}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^4*s + 3*Q^2*s^2 + 4*Q^4*t + 4*Q^2*s*t - 2*s^2*t + 2*Q^2*t^2 - 
          2*s*t^2))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/4)*(-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 - 2*Q^2*s - 3*s^2 - 4*s*t))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/4*I)*(-2 + D)*Q^2*(-1 + SUNN)*
         (1 + SUNN)*(Q^2 + t)*(Q^2 + s + 2*t))/((Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 - Q^2*s - 2*s^2 - 
          2*s*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*Q^2*(-1 + SUNN)*
         (1 + SUNN)*(2*Q^4 - 3*Q^2*s - 5*s^2 - 6*s*t))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^2*s + Q^2*t + s*t))/((Q^2 + s)*SUNN*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 1, 5}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^6 + 2*D*Q^6 - 20*Q^4*s + 5*D*Q^4*s - 16*Q^2*s^2 + 
          4*D*Q^2*s^2 - 4*s^3 + D*s^3 + 2*Q^2*s*t - 2*s^2*t + 4*Q^2*t^2 - 
          4*s*t^2))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 12*Q^4*s + 3*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 
          4*s^3 + D*s^3 - 2*Q^4*t + 4*Q^2*s*t - 2*s^2*t))/
        ((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + t)*
         (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 
          2*s*t))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 - 2*Q^2*t + 
          2*s*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^6 + 2*D*Q^6 - 20*Q^4*s + 5*D*Q^4*s - 16*Q^2*s^2 + 
          4*D*Q^2*s^2 - 4*s^3 + D*s^3 - 4*Q^4*t + 6*Q^2*s*t - 2*s^2*t))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 12*Q^4*s + 3*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 
          4*s^3 + D*s^3 - 4*Q^4*t + D*Q^4*t - 6*Q^2*s*t + 2*D*Q^2*s*t - 
          6*s^2*t + D*s^2*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 4, 3}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s + Q^2*s^2 - 4*Q^2*s*t - 4*s^2*t - 6*Q^2*t^2 - 8*s*t^2 - 
          4*t^3))/(4*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^6 + 2*Q^4*s + Q^2*s^2 + 4*Q^4*t + 2*Q^2*s*t - 2*s^2*t + 
           2*Q^2*t^2 - 2*s*t^2))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + t)*
         (Q^4 + Q^2*s + 2*Q^2*t + 2*s*t + 2*t^2))/(4*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 + 3*Q^2*s + 2*s^2 + 4*Q^2*t + 
          4*s*t + 2*t^2))/(4*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + 5*Q^4*s + 3*Q^2*s^2 + 8*Q^4*t + 6*Q^2*s*t - 2*s^2*t + 
          4*Q^2*t^2 - 2*s*t^2))/(4*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN))/(4*(Q^2 + s)*SUNN)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 4, 4}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + 2*Q^4*s - Q^2*s^2 - s^3 - 4*Q^2*s*t - 4*s^2*t - 6*Q^2*t^2 - 
          8*s*t^2 - 4*t^3))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + 3*Q^4*s - s^3 + 4*Q^4*t + 2*Q^2*s*t - 2*s^2*t + 2*Q^2*t^2 - 
          2*s*t^2))/((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + t)*(Q^2*s + s^2 + 2*Q^2*t + 2*s*t + 2*t^2))/
        ((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 + 3*Q^2*s + s^2 + 
          4*Q^2*t + 4*s*t + 2*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^6 + 6*Q^4*s + Q^2*s^2 - s^3 + 8*Q^4*t + 6*Q^2*s*t - 2*s^2*t + 
          4*Q^2*t^2 - 2*s*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + t))/
        ((Q^2 + s)*SUNN*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 1, 1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(7*Q^6*s + 5*Q^4*s^2 - 
          Q^2*s^3 + s^4 + 2*Q^6*t - 7*Q^4*s*t - 22*Q^2*s^2*t + 3*s^3*t + 
          2*Q^4*t^2 - 24*Q^2*s*t^2 + 6*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^10 - 7*Q^8*s - 12*Q^6*s^2 + 
          3*Q^2*s^4 - s^5 + Q^8*t - 16*Q^6*s*t + 10*Q^4*s^2*t + 
          24*Q^2*s^3*t - 3*s^4*t - 4*Q^4*s*t^2 + 24*Q^2*s^2*t^2 - 4*s^3*t^2)*
         transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^10 + 4*Q^4*s^3 + 3*Q^2*s^4 + 2*Q^8*t - 15*Q^6*s*t - 5*Q^4*s^2*t + 
          11*Q^2*s^3*t - s^4*t + Q^6*t^2 - 15*Q^4*s*t^2 + 15*Q^2*s^2*t^2 - 
          s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 - 7*Q^4*s - 7*Q^2*s^2 + s^3 + Q^4*t - 12*Q^2*s*t + 3*s^2*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^10 - 13*Q^8*s - 26*Q^6*s^2 - 6*Q^4*s^3 + 4*Q^2*s^4 - s^5 + 
          2*Q^8*t - 27*Q^6*s*t + Q^4*s^2*t + 27*Q^2*s^3*t - 3*s^4*t - 
          4*Q^4*s*t^2 + 24*Q^2*s^2*t^2 - 4*s^3*t^2)*transverseK)/
        (Q*s*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^8 + 5*Q^6*s - Q^4*s^2 - Q^2*s^3 + s^4 + 6*Q^6*t - 10*Q^4*s*t - 
          14*Q^2*s^2*t + 2*s^3*t + 2*Q^4*t^2 - 12*Q^2*s*t^2 + 2*s^2*t^2)*
         transverseK)/(Q*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 1, 2}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^6*s - 2*Q^4*s^2 - 6*Q^2*s^3 - 9*Q^4*s*t - 20*Q^2*s^2*t + 
          5*s^3*t + 2*Q^4*t^2 - 24*Q^2*s*t^2 + 6*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(10*Q^8*s + 14*Q^6*s^2 - 
          2*Q^4*s^3 - 6*Q^2*s^4 - Q^8*t + 16*Q^6*s*t - 10*Q^4*s^2*t - 
          24*Q^2*s^3*t + 3*s^4*t + 4*Q^4*s*t^2 - 24*Q^2*s^2*t^2 + 4*s^3*t^2)*
         transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (6*Q^8*s + 12*Q^6*s^2 + 6*Q^4*s^3 - Q^8*t + 17*Q^6*s*t + 
          5*Q^4*s^2*t - 13*Q^2*s^3*t - Q^6*t^2 + 15*Q^4*s*t^2 - 
          15*Q^2*s^2*t^2 + s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(8*Q^4*s + 6*Q^2*s^2 - 2*s^3 - 
          Q^4*t + 12*Q^2*s*t - 3*s^2*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(18*Q^8*s + 28*Q^6*s^2 + 
          2*Q^4*s^3 - 8*Q^2*s^4 - 2*Q^8*t + 27*Q^6*s*t - Q^4*s^2*t - 
          27*Q^2*s^3*t + 3*s^4*t + 4*Q^4*s*t^2 - 24*Q^2*s^2*t^2 + 4*s^3*t^2)*
         transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^8 + Q^6*s - 7*Q^4*s^2 - 
          5*Q^2*s^3 + 6*Q^6*t - 10*Q^4*s*t - 14*Q^2*s^2*t + 2*s^3*t + 
          2*Q^4*t^2 - 12*Q^2*s*t^2 + 2*s^2*t^2)*transverseK)/
        (Q*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 1, 5}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-12*Q^8*s + 3*D*Q^8*s - 
          40*Q^6*s^2 + 10*D*Q^6*s^2 - 48*Q^4*s^3 + 12*D*Q^4*s^3 - 
          24*Q^2*s^4 + 6*D*Q^2*s^4 - 4*s^5 + D*s^5 - 8*Q^8*t + 2*D*Q^8*t - 
          28*Q^6*s*t + 7*D*Q^6*s*t - 18*Q^4*s^2*t + 7*D*Q^4*s^2*t + 
          4*Q^2*s^3*t + D*Q^2*s^3*t + 2*s^4*t - D*s^4*t - 8*Q^6*t^2 + 
          2*D*Q^6*t^2 + 12*Q^4*s*t^2 + 2*D*Q^4*s*t^2 + 36*Q^2*s^2*t^2 - 
          2*D*Q^2*s^2*t^2 - 2*D*s^3*t^2 + 24*Q^2*s*t^3 - 8*s^2*t^3)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^12 + D*Q^12 - 16*Q^10*s + 4*D*Q^10*s - 20*Q^8*s^2 + 
          5*D*Q^8*s^2 + 20*Q^4*s^4 - 5*D*Q^4*s^4 + 16*Q^2*s^5 - 4*D*Q^2*s^5 + 
          4*s^6 - D*s^6 - 4*Q^10*t + D*Q^10*t + 2*Q^8*s*t + 3*D*Q^8*s*t + 
          4*Q^6*s^2*t + 2*D*Q^6*s^2*t - 8*Q^4*s^3*t - 2*D*Q^4*s^3*t - 
          3*D*Q^2*s^4*t + 6*s^5*t - D*s^5*t + 24*Q^6*s*t^2 - 40*Q^4*s^2*t^2 - 
          56*Q^2*s^3*t^2 + 8*s^4*t^2 + 8*Q^4*s*t^3 - 48*Q^2*s^2*t^3 + 
          8*s^3*t^3)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^12 + D*Q^12 - 28*Q^10*s + 7*D*Q^10*s - 72*Q^8*s^2 + 
          18*D*Q^8*s^2 - 88*Q^6*s^3 + 22*D*Q^6*s^3 - 52*Q^4*s^4 + 
          13*D*Q^4*s^4 - 12*Q^2*s^5 + 3*D*Q^2*s^5 - 8*Q^10*t + 2*D*Q^10*t - 
          22*Q^8*s*t + 9*D*Q^8*s*t - 34*Q^6*s^2*t + 14*D*Q^6*s^2*t - 
          30*Q^4*s^3*t + 8*D*Q^4*s^3*t - 6*Q^2*s^4*t + 4*s^5*t - D*s^5*t - 
          4*Q^8*t^2 + D*Q^8*t^2 + 26*Q^6*s*t^2 + 2*D*Q^6*s*t^2 - 
          10*Q^4*s^2*t^2 - 34*Q^2*s^3*t^2 - 2*D*Q^2*s^3*t^2 + 6*s^4*t^2 - 
          D*s^4*t^2 + 20*Q^4*s*t^3 - 40*Q^2*s^2*t^3 + 4*s^3*t^3)*transverseK)/
        (Q*s*(Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^8 + D*Q^8 - 8*Q^6*s + 2*D*Q^6*s + 8*Q^2*s^3 - 2*D*Q^2*s^3 + 
          4*s^4 - D*s^4 - 4*Q^6*t + D*Q^6*t + 6*Q^4*s*t + D*Q^4*s*t + 
          12*Q^2*s^2*t - D*Q^2*s^2*t + 2*s^3*t - D*s^3*t + 12*Q^2*s*t^2 - 
          4*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^12 + 2*D*Q^12 - 28*Q^10*s + 7*D*Q^10*s - 28*Q^8*s^2 + 
          7*D*Q^8*s^2 + 8*Q^6*s^3 - 2*D*Q^6*s^3 + 32*Q^4*s^4 - 8*D*Q^4*s^4 + 
          20*Q^2*s^5 - 5*D*Q^2*s^5 + 4*s^6 - D*s^6 - 8*Q^10*t + 2*D*Q^10*t + 
          4*Q^8*s*t + 5*D*Q^8*s*t + 22*Q^6*s^2*t + 2*D*Q^6*s^2*t + 
          6*Q^4*s^3*t - 4*D*Q^4*s^3*t + 2*Q^2*s^4*t - 4*D*Q^2*s^4*t + 
          6*s^5*t - D*s^5*t + 36*Q^6*s*t^2 - 32*Q^4*s^2*t^2 - 
          60*Q^2*s^3*t^2 + 8*s^4*t^2 + 8*Q^4*s*t^3 - 48*Q^2*s^2*t^3 + 
          8*s^3*t^3)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^8 + D*Q^8 - 16*Q^6*s + 
          4*D*Q^6*s - 24*Q^4*s^2 + 6*D*Q^4*s^2 - 16*Q^2*s^3 + 4*D*Q^2*s^3 - 
          4*s^4 + D*s^4 - 2*Q^6*t + 10*Q^4*s*t + 10*Q^2*s^2*t - 2*s^3*t - 
          4*Q^4*t^2 + 24*Q^2*s*t^2 - 4*s^2*t^2)*transverseK)/
        (Q*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 4, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6*s + 4*Q^4*s^2 + 3*Q^4*s*t - 
          2*Q^2*s^2*t + 3*s^3*t + 2*Q^4*t^2 - 12*Q^2*s*t^2 + 2*s^2*t^2)*
         transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(Q^4 - 4*Q^2*s - s^2)*(-1 + SUNN)*
         (1 + SUNN)*transverseK)/(8*Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (4*Q^6*s + 4*Q^4*s^2 + Q^6*t + 2*Q^4*s*t - 7*Q^2*s^2*t + Q^4*t^2 - 
           6*Q^2*s*t^2 + s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*
          (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s - 2*s^3 - Q^4*t + 
          6*Q^2*s*t - s^2*t)*transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6*s - 2*Q^2*s^3 - 2*Q^6*t + 
          9*Q^4*s*t + 4*Q^2*s^2*t + s^3*t)*transverseK)/
        (8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*transverseK)/(8*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 4, 4}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (7*Q^6*s + 9*Q^4*s^2 + Q^2*s^3 - s^4 + 2*Q^6*t + Q^4*s*t - 
          12*Q^2*s^2*t - 3*s^3*t + 2*Q^4*t^2 - 12*Q^2*s*t^2 + 2*s^2*t^2)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 - 5*Q^4*s - 5*Q^2*s^2 + s^3 + Q^4*t - 8*Q^2*s*t + 3*s^2*t)*
         transverseK)/(Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^8 + 3*Q^6*s - Q^4*s^2 - 3*Q^2*s^3 + 2*Q^6*t - 3*Q^4*s*t - 
          12*Q^2*s^2*t + s^3*t + Q^4*t^2 - 6*Q^2*s*t^2 + s^2*t^2)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 - 3*Q^4*s - 5*Q^2*s^2 - s^3 + Q^4*t - 6*Q^2*s*t + s^2*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 - 7*Q^6*s - 15*Q^4*s^2 - 5*Q^2*s^3 + s^4 + 2*Q^6*t - 
          13*Q^4*s*t - 4*Q^2*s^2*t + 3*s^3*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^4 + 3*Q^2*s - s^2 + 4*Q^2*t - 2*s*t)*transverseK)/
        (Q*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 1, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^4*s + 4*Q^2*s^2 + 
          3*Q^2*s*t - 5*s^2*t + 2*Q^2*t^2 - 6*s*t^2)*transverseK)/
        (Q*s*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6*s + 8*Q^4*s^2 + 
          4*Q^2*s^3 - Q^6*t + 7*Q^4*s*t + 5*Q^2*s^2*t - 3*s^3*t + 
          4*Q^2*s*t^2 - 4*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - 2*Q^4*s - 3*Q^2*s^2 + 
          Q^4*t - 6*Q^2*s*t + s^2*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^2*s + 2*s^2 - Q^2*t + 
          3*s*t)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (6*Q^6*s + 12*Q^4*s^2 + 6*Q^2*s^3 - 2*Q^6*t + 9*Q^4*s*t + 
          8*Q^2*s^2*t - 3*s^3*t + 4*Q^2*s*t^2 - 4*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^6 + 6*Q^4*s + 3*Q^2*s^2 + 6*Q^4*t + 4*Q^2*s*t - 2*s^2*t + 
          2*Q^2*t^2 - 2*s*t^2)*transverseK)/(Q*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 1, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4*s + 2*Q^2*s^2 + s^3 - 
           2*Q^4*t + Q^2*s*t + 3*s^2*t - 2*Q^2*t^2 + 6*s*t^2)*transverseK)/
         (Q*s*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 - 2*Q^4*s^2 + s^4 + Q^6*t - 
          7*Q^4*s*t - 5*Q^2*s^2*t + 3*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2)*
         transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^6 - 2*Q^4*s - 3*Q^2*s^2 + Q^4*t - 6*Q^2*s*t + s^2*t)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 - s^2 + Q^2*t - 3*s*t)*
          transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (2*Q^8 + Q^6*s - 3*Q^4*s^2 - Q^2*s^3 + s^4 + 2*Q^6*t - 9*Q^4*s*t - 
           8*Q^2*s^2*t + 3*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2)*transverseK)/
         (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^4*s + 2*Q^2*s^2 + s^3 - 2*Q^4*t + 2*s^2*t - 2*Q^2*t^2 + 2*s*t^2)*
          transverseK)/(Q*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 4, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^6*s - Q^4*s^2 - 3*Q^2*s^3 - s^4 - 2*Q^6*t - 9*Q^4*s*t - 
           14*Q^2*s^2*t - 3*s^3*t - 2*Q^4*t^2 - 8*Q^2*s*t^2 + 2*s^2*t^2)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 + 3*Q^4*s + Q^2*s^2 - s^3 + Q^4*t + 2*Q^2*s*t - 3*s^2*t)*
         transverseK)/(8*Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^8 + 3*Q^6*s + 5*Q^4*s^2 + 3*Q^2*s^3 + 2*Q^6*t + 7*Q^4*s*t + 
           8*Q^2*s^2*t - s^3*t + Q^4*t^2 + 4*Q^2*s*t^2 - s^2*t^2)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^6 + 5*Q^4*s + 5*Q^2*s^2 + s^3 + Q^4*t + 4*Q^2*s*t - s^2*t)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (2*Q^8 + 9*Q^6*s + 9*Q^4*s^2 + Q^2*s^3 - s^4 + 2*Q^6*t + 
           7*Q^4*s*t - 2*Q^2*s^2*t - 3*s^3*t)*transverseK)/
         (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*transverseK)/(8*Q*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 4, 2}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (4*Q^6*s + 6*Q^4*s^2 + 2*Q^2*s^3 - Q^4*s*t - 8*Q^2*s^2*t - 
           3*s^3*t + 2*Q^4*t^2 - 8*Q^2*s*t^2 - 2*s^2*t^2)*transverseK)/
         (Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s + 2*Q^2*s^2 - Q^4*t + 
          2*Q^2*s*t - s^2*t)*transverseK)/(8*Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6*s + 2*Q^4*s^2 + Q^6*t + 2*Q^4*s*t - 3*Q^2*s^2*t + Q^4*t^2 - 
          4*Q^2*s*t^2 - s^2*t^2)*transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^4*s + 6*Q^2*s^2 + 2*s^3 - 
           Q^4*t + 4*Q^2*s*t + s^2*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
          (Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(6*Q^6*s + 10*Q^4*s^2 + 
           4*Q^2*s^3 - 2*Q^6*t + 5*Q^4*s*t + 2*Q^2*s^2*t - s^3*t)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       -1/8*((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*transverseK)/
         (SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 4, 5}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-12*Q^8*s + 3*D*Q^8*s - 40*Q^6*s^2 + 
          10*D*Q^6*s^2 - 48*Q^4*s^3 + 12*D*Q^4*s^3 - 24*Q^2*s^4 + 
          6*D*Q^2*s^4 - 4*s^5 + D*s^5 - 8*Q^8*t + 2*D*Q^8*t - 28*Q^6*s*t + 
          7*D*Q^6*s*t - 34*Q^4*s^2*t + 7*D*Q^4*s^2*t - 12*Q^2*s^3*t + 
          D*Q^2*s^3*t + 2*s^4*t - D*s^4*t - 8*Q^6*t^2 + 2*D*Q^6*t^2 - 
          20*Q^4*s*t^2 + 2*D*Q^4*s*t^2 - 16*Q^2*s^2*t^2 - 2*D*Q^2*s^2*t^2 + 
          4*s^3*t^2 - 2*D*s^3*t^2 - 16*Q^2*s*t^3)*transverseK)/
        (16*Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 12*Q^4*s + 3*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 
          4*s^3 + D*s^3 - 4*Q^4*t + D*Q^4*t - 10*Q^2*s*t + 2*D*Q^2*s*t - 
          6*s^2*t + D*s^2*t - 4*s*t^2)*transverseK)/(16*Q*s*SUNN*t^2*
         (Q^2 + s + t)^2), GLI["V10", {1, 1, 0, -1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^10 + D*Q^10 - 24*Q^8*s + 
           6*D*Q^8*s - 48*Q^6*s^2 + 12*D*Q^6*s^2 - 40*Q^4*s^3 + 
           10*D*Q^4*s^3 - 12*Q^2*s^4 + 3*D*Q^2*s^4 - 8*Q^8*t + 2*D*Q^8*t - 
           30*Q^6*s*t + 7*D*Q^6*s*t - 36*Q^4*s^2*t + 7*D*Q^4*s^2*t - 
           10*Q^2*s^3*t + D*Q^2*s^3*t + 4*s^4*t - D*s^4*t - 4*Q^6*t^2 + 
           D*Q^6*t^2 - 14*Q^4*s*t^2 + D*Q^4*s*t^2 - 12*Q^2*s^2*t^2 - 
           D*Q^2*s^2*t^2 + 6*s^3*t^2 - D*s^3*t^2 - 8*Q^2*s*t^3)*transverseK)/
         (Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, -1, 0}] -> -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (-4*Q^8 + D*Q^8 - 8*Q^6*s + 2*D*Q^6*s + 8*Q^2*s^3 - 2*D*Q^2*s^3 + 
           4*s^4 - D*s^4 - 4*Q^6*t + D*Q^6*t - 10*Q^4*s*t + D*Q^4*s*t - 
           4*Q^2*s^2*t - D*Q^2*s^2*t + 2*s^3*t - D*s^3*t - 8*Q^2*s*t^2)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, 0, 0}] -> -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (-8*Q^10 + 2*D*Q^10 - 20*Q^8*s + 5*D*Q^8*s - 8*Q^6*s^2 + 
           2*D*Q^6*s^2 + 16*Q^4*s^3 - 4*D*Q^4*s^3 + 16*Q^2*s^4 - 
           4*D*Q^2*s^4 + 4*s^5 - D*s^5 - 8*Q^8*t + 2*D*Q^8*t - 20*Q^6*s*t + 
           3*D*Q^6*s*t - 6*Q^4*s^2*t - D*Q^4*s^2*t + 12*Q^2*s^3*t - 
           3*D*Q^2*s^3*t + 6*s^4*t - D*s^4*t - 12*Q^4*s*t^2 + 4*s^3*t^2)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^2 + D*Q^2 - 4*s + 
          D*s - 2*t)*transverseK)/(16*Q*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {6, 1, 3}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 - s - 2*t))/((Q^2 + s)*SUNN*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 - s^2 - 2*s*t))/
        ((Q^2 + s)^2*SUNN*t), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/2*I)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN))/
        ((Q^2 + s)^2*SUNN), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^4 + Q^2*s - s^2 - 2*s*t))/((Q^2 + s)^2*SUNN)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 - Q^2*s - 2*s^2 - 
          2*s*t))/((Q^2 + s)^2*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 1, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 - s^2 - 2*s*t))/(2*(Q^2 + s)^2*SUNN*t), 
      GLI["V10", {1, 1, 0, -1}] -> -1/2*((-2 + D)*(Q^2 - s)*(-1 + SUNN)*
          (1 + SUNN)*(Q^2 + s + t))/((Q^2 + s)^2*SUNN*t), 
      GLI["V10", {1, 1, -1, 0}] -> -1/2*((-2 + D)*(-1 + SUNN)*(1 + SUNN))/
         ((Q^2 + s)*SUNN), GLI["V10", {1, 1, 0, 0}] -> 
       -1/2*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 + Q^2*s - s^2 - 2*s*t))/
         ((Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t))/(4*(Q^2 + s)^2*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 4, 1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       -1/2*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(Q^2 - 2*t))/
         ((Q^2 + s)^2*SUNN*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/(2*(Q^2 + s)*SUNN*t), 
      GLI["V10", {1, 1, 0, -1}] -> -1/2*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
          (s + t))/((Q^2 + s)^2*SUNN*t), GLI["V10", {1, 1, -1, 0}] -> 
       -1/2*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)^2*SUNN), 
      GLI["V10", {1, 1, 0, 0}] -> -1/2*((-2 + D)*s*(2*Q^2 + s)*(-1 + SUNN)*
          (1 + SUNN))/((Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/4*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/
         ((Q^2 + s)*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 4, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN)*(Q^2 - 2*t))/
        (2*(Q^2 + s)^2*SUNN*t), GLI["V10", {0, 1, 0, 0}] -> 
       -1/2*((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN*t), 
      GLI["V10", {1, 1, 0, -1}] -> ((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN)*
         (s + t))/(2*(Q^2 + s)^2*SUNN*t), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN))/(2*(Q^2 + s)^2*SUNN), 
      GLI["V10", {1, 1, 0, 0}] -> ((-2 + D)*Q^2*(2*Q^2 + s)*(-1 + SUNN)*
         (1 + SUNN))/(2*(Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN))/
        (4*(Q^2 + s)*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 4, 5}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(s + 2*t)*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 
          2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 2*s*t))/
        (8*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 
          2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 2*s*t))/
        (8*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + 2*s + t)*
          (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 
           2*s*t))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 
           2*s*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(2*Q^2 + s)*(-1 + SUNN)*
          (1 + SUNN)*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 
           2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 0|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 1, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s - 2*Q^2*s^2 - s^3 - 2*Q^4*t - 7*Q^2*s*t - 3*s^2*t - 
          2*Q^2*t^2 - 6*s*t^2)*transverseK)/(8*Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^6 + 3*Q^4*s + Q^2*s^2 - s^3 + Q^4*t - 2*Q^2*s*t - 3*s^2*t - 
           4*s*t^2)*transverseK)/(Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 + 2*Q^4*s + 3*Q^2*s^2 + 2*Q^4*t + Q^2*s*t - s^2*t + Q^2*t^2 - 
          s*t^2)*transverseK)/(8*Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + 4*Q^2*s + s^2 + Q^2*t + 3*s*t)*transverseK)/
        (8*Q*s*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 + 7*Q^4*s + 2*Q^2*s^2 - s^3 + 
          2*Q^4*t + Q^2*s*t - 3*s^2*t - 4*s*t^2)*transverseK)/
        (8*Q*s*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^2*s + s^2 + 2*Q^2*t + 2*s*t + 2*t^2)*transverseK)/
         (Q*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 1, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^4*s + 2*Q^2*s^2 - 7*Q^2*s*t - 
          5*s^2*t - 2*Q^2*t^2 - 6*s*t^2)*transverseK)/
        (8*Q*s*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s + 2*Q^2*s^2 + Q^4*t - 
           2*Q^2*s*t - 3*s^2*t - 4*s*t^2)*transverseK)/
         (Q*s*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s - Q^4*t - Q^2*s*t - 
           Q^2*t^2 + s*t^2)*transverseK)/(Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^2*s + 2*s^2 + Q^2*t + 3*s*t)*transverseK)/
        (8*Q*s*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(6*Q^4*s + 4*Q^2*s^2 + 2*Q^4*t + 
          Q^2*s*t - 3*s^2*t - 4*s*t^2)*transverseK)/(8*Q*s*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + Q^2*s - 2*Q^2*t - 2*s*t - 2*t^2)*transverseK)/
        (8*Q*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 1, 5}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-12*Q^6*s + 3*D*Q^6*s - 
           28*Q^4*s^2 + 7*D*Q^4*s^2 - 20*Q^2*s^3 + 5*D*Q^2*s^3 - 4*s^4 + 
           D*s^4 - 8*Q^6*t + 2*D*Q^6*t - 20*Q^4*s*t + 5*D*Q^4*s*t - 
           14*Q^2*s^2*t + 2*D*Q^2*s^2*t + 2*s^3*t - D*s^3*t - 8*Q^4*t^2 + 
           2*D*Q^4*t^2 - 12*Q^2*s*t^2 - 2*D*s^2*t^2 - 8*s*t^3)*transverseK)/
         (Q*s*SUNN*t^2*(Q^2 + s + t)^2), GLI["V10", {0, 1, 0, 0}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^8 + D*Q^8 - 8*Q^6*s + 
           2*D*Q^6*s + 8*Q^2*s^3 - 2*D*Q^2*s^3 + 4*s^4 - D*s^4 - 4*Q^6*t + 
           D*Q^6*t - 6*Q^4*s*t + D*Q^4*s*t + 4*Q^2*s^2*t - D*Q^2*s^2*t + 
           6*s^3*t - D*s^3*t + 8*Q^2*s*t^2 + 8*s^2*t^2 + 8*s*t^3)*
          transverseK)/(Q*s*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^8 + D*Q^8 - 20*Q^6*s + 5*D*Q^6*s - 28*Q^4*s^2 + 7*D*Q^4*s^2 - 
          12*Q^2*s^3 + 3*D*Q^2*s^3 - 8*Q^6*t + 2*D*Q^6*t - 22*Q^4*s*t + 
          5*D*Q^4*s*t - 14*Q^2*s^2*t + 2*D*Q^2*s^2*t + 4*s^3*t - D*s^3*t - 
          4*Q^4*t^2 + D*Q^4*t^2 + 2*Q^2*s*t^2 + 6*s^2*t^2 - D*s^2*t^2 + 
          4*s*t^3)*transverseK)/(16*Q*s*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, -1, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 4*Q^4*s + D*Q^4*s + 4*Q^2*s^2 - D*Q^2*s^2 + 
          4*s^3 - D*s^3 - 4*Q^4*t + D*Q^4*t - 6*Q^2*s*t + 2*s^2*t - D*s^2*t - 
          4*s*t^2)*transverseK)/(16*Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^8 + 2*D*Q^8 - 12*Q^6*s + 3*D*Q^6*s + 4*Q^4*s^2 - D*Q^4*s^2 + 
          12*Q^2*s^3 - 3*D*Q^2*s^3 + 4*s^4 - D*s^4 - 8*Q^6*t + 2*D*Q^6*t - 
          12*Q^4*s*t + D*Q^4*s*t + 6*Q^2*s^2*t - 2*D*Q^2*s^2*t + 6*s^3*t - 
          D*s^3*t + 4*Q^2*s*t^2 + 8*s^2*t^2 + 8*s*t^3)*transverseK)/
        (16*Q*s*SUNN*t*(Q^2 + s + t)^2)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 - 2*Q^2*t - 
           2*s*t - 4*t^2)*transverseK)/(Q*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 4, 3}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)*
         (1 + SUNN)*(4*Q^2*s - 3*s*t - 2*t^2)*transverseK)/
        (Q*s*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^4*s + 4*Q^2*s^2 + Q^4*t + 
          4*Q^2*s*t - s^2*t)*transverseK)/(Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + 5*Q^2*s + Q^2*t + s*t)*transverseK)/
        (Q*s*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*(2*s + t)*
         transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(6*Q^4*s + 6*Q^2*s^2 + 
          2*Q^4*t + 5*Q^2*s*t - s^2*t)*transverseK)/
        (Q*s*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*Q*(-1 + SUNN)*
         (1 + SUNN)*(3*Q^2 + 3*s + 2*t)*transverseK)/
        (SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 4, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*(Q^2*s + s^2 - 2*Q^2*t + 
          3*s*t - 2*t^2)*transverseK)/(8*Q*s*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^6 - Q^4*s - Q^2*s^2 + s^3 + Q^4*t + 3*s^2*t)*transverseK)/
         (Q*s*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 - 3*Q^2*s + Q^2*t + s*t)*
         transverseK)/(8*Q*s*SUNN*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*(Q^2 - s + t)*transverseK)/
        (8*Q*s*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 - Q^4*s - 2*Q^2*s^2 + s^3 + 
          2*Q^4*t + Q^2*s*t + 3*s^2*t)*transverseK)/(8*Q*s*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*transverseK)/(8*Q*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 1, 3}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^4*s - 3*Q^2*s*t + 5*s^2*t - 2*Q^2*t^2 + 6*s*t^2)*transverseK)/
        (8*Q*s*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - 7*Q^4*s - 5*Q^2*s^2 + 
           3*s^3 - 4*Q^2*s*t + 4*s^2*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
          (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6*s + 4*Q^4*s^2 - Q^6*t + 
           6*Q^4*s*t + 7*Q^2*s^2*t - Q^4*t^2 + 6*Q^2*s*t^2 - s^2*t^2)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^2*s - 2*s^2 + Q^2*t - 3*s*t)*transverseK)/
        (8*Q*s*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6*s - 2*Q^2*s^3 + 2*Q^6*t - 
          9*Q^4*s*t - 8*Q^2*s^2*t + 3*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2)*
         transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 + 2*Q^4*s + Q^2*s^2 - 2*Q^4*t + 
          2*s^2*t - 2*Q^2*t^2 + 2*s*t^2)*transverseK)/(8*Q*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 1, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(7*Q^4*s + 2*Q^2*s^2 - s^3 + 
          2*Q^4*t - Q^2*s*t - 3*s^2*t + 2*Q^2*t^2 - 6*s*t^2)*transverseK)/
        (Q*s*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 - 4*Q^6*s - 10*Q^4*s^2 - 
          4*Q^2*s^3 + s^4 + Q^6*t - 7*Q^4*s*t - 5*Q^2*s^2*t + 3*s^3*t - 
          4*Q^2*s*t^2 + 4*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 + 3*Q^6*s - Q^4*s^2 - 
          3*Q^2*s^3 + 2*Q^6*t - 3*Q^4*s*t - 4*Q^2*s^2*t + s^3*t + Q^4*t^2 - 
          6*Q^2*s*t^2 + s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 - 4*Q^2*s - s^2 + 
          Q^2*t - 3*s*t)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 - 7*Q^6*s - 15*Q^4*s^2 - 5*Q^2*s^3 + s^4 + 2*Q^6*t - 
          9*Q^4*s*t - 8*Q^2*s^2*t + 3*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6 + 7*Q^4*s + 2*Q^2*s^2 - 
          s^3 + 6*Q^4*t + 4*Q^2*s*t - 2*s^2*t + 2*Q^2*t^2 - 2*s*t^2)*
         transverseK)/(Q*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 4, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (7*Q^6*s + 5*Q^4*s^2 - Q^2*s^3 + s^4 + 2*Q^6*t - 7*Q^4*s*t - 
          10*Q^2*s^2*t + 3*s^3*t + 2*Q^4*t^2 - 8*Q^2*s*t^2 - 2*s^2*t^2)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^8 - 8*Q^6*s - 4*Q^4*s^2 + 4*Q^2*s^3 - s^4 + Q^6*t - 5*Q^4*s*t + 
          7*Q^2*s^2*t - 3*s^3*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 - Q^6*s + Q^4*s^2 + 
          3*Q^2*s^3 + 2*Q^6*t - 5*Q^4*s*t + 4*Q^2*s^2*t - s^3*t + Q^4*t^2 - 
          4*Q^2*s*t^2 - s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - 7*Q^4*s - 7*Q^2*s^2 + 
          s^3 + Q^4*t - 4*Q^2*s*t - s^2*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 - 15*Q^6*s - 
          11*Q^4*s^2 + 5*Q^2*s^3 - s^4 + 2*Q^6*t - 9*Q^4*s*t + 6*Q^2*s^2*t - 
          3*s^3*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6 + Q^4*s - 2*Q^2*s^2 + 
          s^3 + 4*Q^4*t - 2*Q^2*s*t + 2*s^2*t)*transverseK)/
        (Q*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 4, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6*s - 2*Q^4*s^2 - 
          6*Q^2*s^3 - 15*Q^4*s*t - 16*Q^2*s^2*t + 3*s^3*t - 2*Q^4*t^2 - 
          8*Q^2*s*t^2 + 2*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(10*Q^6*s + 4*Q^4*s^2 - 
          6*Q^2*s^3 + Q^6*t + 7*Q^4*s*t - 9*Q^2*s^2*t + s^3*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(6*Q^6*s + 6*Q^4*s^2 + Q^6*t + 
          14*Q^4*s*t + Q^2*s^2*t + Q^4*t^2 + 4*Q^2*s*t^2 - s^2*t^2)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (8*Q^4*s + 6*Q^2*s^2 - 2*s^3 + Q^4*t + 4*Q^2*s*t - s^2*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (18*Q^6*s + 10*Q^4*s^2 - 8*Q^2*s^3 + 2*Q^6*t + 11*Q^4*s*t - 
          10*Q^2*s^2*t + s^3*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^4 - 2*Q^2*s - 5*s^2 + 2*Q^2*t - 6*s*t)*transverseK)/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 4, 5}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-12*Q^8*s + 3*D*Q^8*s - 
          40*Q^6*s^2 + 10*D*Q^6*s^2 - 48*Q^4*s^3 + 12*D*Q^4*s^3 - 
          24*Q^2*s^4 + 6*D*Q^2*s^4 - 4*s^5 + D*s^5 - 8*Q^8*t + 2*D*Q^8*t - 
          28*Q^6*s*t + 7*D*Q^6*s*t - 18*Q^4*s^2*t + 7*D*Q^4*s^2*t + 
          4*Q^2*s^3*t + D*Q^2*s^3*t + 2*s^4*t - D*s^4*t - 8*Q^6*t^2 + 
          2*D*Q^6*t^2 + 12*Q^4*s*t^2 + 2*D*Q^4*s*t^2 + 32*Q^2*s^2*t^2 - 
          2*D*Q^2*s^2*t^2 + 4*s^3*t^2 - 2*D*s^3*t^2 + 16*Q^2*s*t^3)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/16)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*
         (1 + SUNN)*(-4*Q^8 + D*Q^8 - 16*Q^6*s + 4*D*Q^6*s - 24*Q^4*s^2 + 
          6*D*Q^4*s^2 - 16*Q^2*s^3 + 4*D*Q^2*s^3 - 4*s^4 + D*s^4 - 4*Q^6*t + 
          D*Q^6*t + 2*Q^4*s*t + 3*D*Q^4*s*t + 3*D*Q^2*s^2*t - 6*s^3*t + 
          D*s^3*t + 12*Q^2*s*t^2 - 4*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^10 + D*Q^10 - 24*Q^8*s + 6*D*Q^8*s - 48*Q^6*s^2 + 
          12*D*Q^6*s^2 - 40*Q^4*s^3 + 10*D*Q^4*s^3 - 12*Q^2*s^4 + 
          3*D*Q^2*s^4 - 8*Q^8*t + 2*D*Q^8*t - 14*Q^6*s*t + 7*D*Q^6*s*t - 
          20*Q^4*s^2*t + 7*D*Q^4*s^2*t - 10*Q^2*s^3*t + D*Q^2*s^3*t + 
          4*s^4*t - D*s^4*t - 4*Q^6*t^2 + D*Q^6*t^2 + 18*Q^4*s*t^2 + 
          D*Q^4*s*t^2 + 4*Q^2*s^2*t^2 - D*Q^2*s^2*t^2 + 6*s^3*t^2 - 
          D*s^3*t^2 + 8*Q^2*s*t^3)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^8 + D*Q^8 - 8*Q^6*s + 
          2*D*Q^6*s + 8*Q^2*s^3 - 2*D*Q^2*s^3 + 4*s^4 - D*s^4 - 4*Q^6*t + 
          D*Q^6*t + 6*Q^4*s*t + D*Q^4*s*t + 12*Q^2*s^2*t - D*Q^2*s^2*t + 
          2*s^3*t - D*s^3*t + 8*Q^2*s*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^10 + 2*D*Q^10 - 
          20*Q^8*s + 5*D*Q^8*s - 8*Q^6*s^2 + 2*D*Q^6*s^2 + 16*Q^4*s^3 - 
          4*D*Q^4*s^3 + 16*Q^2*s^4 - 4*D*Q^2*s^4 + 4*s^5 - D*s^5 - 8*Q^8*t + 
          2*D*Q^8*t + 12*Q^6*s*t + 3*D*Q^6*s*t + 10*Q^4*s^2*t - D*Q^4*s^2*t - 
          4*Q^2*s^3*t - 3*D*Q^2*s^3*t + 6*s^4*t - D*s^4*t + 20*Q^4*s*t^2 - 
          16*Q^2*s^2*t^2 + 4*s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 12*Q^4*s + 3*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 
          4*s^3 + D*s^3 - 2*Q^4*t + 12*Q^2*s*t - 2*s^2*t)*transverseK)/
        (Q*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 1, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4*s + Q^2*s^2 - 2*Q^4*t - 
          4*Q^2*s*t - 4*s^2*t - 4*Q^2*t^2 - 8*s*t^2 - 4*t^3))/
        (4*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + 
           Q^2*s^3 + 2*Q^6*t + 2*Q^4*s*t - 2*Q^2*s^2*t - 2*s^3*t + 
           2*Q^4*t^2 - 4*Q^2*s*t^2 - 6*s^2*t^2 - 4*s*t^3))/
         ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 + Q^2*s + Q^2*t - s*t)*
         (Q^4 + Q^2*s + 2*Q^2*t + 2*s*t + 2*t^2))/(4*(Q^2 + s)^2*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 + 3*Q^2*s + 2*s^2 + 2*Q^2*t + 
          4*s*t + 2*t^2))/(4*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 + 7*Q^6*s + 8*Q^4*s^2 + 3*Q^2*s^3 + 4*Q^6*t + 8*Q^4*s*t + 
          2*Q^2*s^2*t - 2*s^3*t + 4*Q^4*t^2 - 2*Q^2*s*t^2 - 6*s^2*t^2 - 
          4*s*t^3))/(4*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       -1/4*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t))/
         ((Q^2 + s)^2*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 1, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 + 2*Q^4*s - Q^2*s^2 - 
          s^3 - 6*Q^2*s*t - 4*s^2*t - 6*Q^2*t^2 - 6*s*t^2 - 4*t^3))/
        ((Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 + 5*Q^6*s + 3*Q^4*s^2 - 
          Q^2*s^3 - s^4 + 4*Q^6*t + 4*Q^4*s*t - 4*Q^2*s^2*t - 4*s^3*t + 
          2*Q^4*t^2 - 4*Q^2*s*t^2 - 6*s^2*t^2 - 4*s*t^3))/
        ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 + Q^2*s + Q^2*t - s*t)*
         (Q^2*s + s^2 + 2*Q^2*t + 2*s*t + 2*t^2))/((Q^2 + s)^2*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 + 3*Q^2*s + s^2 + 
          4*Q^2*t + 2*s*t + 2*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^8 + 10*Q^6*s + 7*Q^4*s^2 - s^4 + 8*Q^6*t + 10*Q^4*s*t - 
          2*Q^2*s^2*t - 4*s^3*t + 4*Q^4*t^2 - 2*Q^2*s*t^2 - 6*s^2*t^2 - 
          4*s*t^3))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 + Q^4*s - Q^2*s^2 - 
          s^3 + Q^4*t - Q^2*s*t - 2*s^2*t - 2*s*t^2))/((Q^2 + s)^2*SUNN*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 4, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 + 4*Q^6*s + 3*Q^4*s^2 + 2*Q^2*s^3 + s^4 - 2*Q^4*s*t + 
          2*Q^2*s^2*t + 4*s^3*t - 6*Q^4*t^2 - 4*Q^2*s*t^2 + 4*s^2*t^2 - 
          4*Q^2*t^3))/((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 + 3*Q^6*s + Q^4*s^2 + Q^2*s^3 + s^4 + 4*Q^6*t + 4*s^3*t + 
          2*Q^4*t^2 - 2*Q^2*s*t^2 + 4*s^2*t^2))/((Q^2 + s)^2*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6*s + 2*Q^4*s^2 + Q^2*s^3 - 
          2*Q^6*t + Q^4*s*t + 2*Q^2*s^2*t - s^3*t - 4*Q^4*t^2 - 2*s^2*t^2 - 
          2*Q^2*t^3))/((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + 3*Q^4*s - s^3 + 4*Q^4*t + 2*Q^2*s*t - 2*s^2*t + 2*Q^2*t^2))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^8 + 6*Q^6*s + Q^4*s^2 + 
          s^4 + 8*Q^6*t + 2*Q^4*s*t - 2*Q^2*s^2*t + 4*s^3*t + 4*Q^4*t^2 - 
          2*Q^2*s*t^2 + 4*s^2*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 + Q^4*s + Q^2*s^2 + 
          s^3 + Q^4*t - Q^2*s*t + 2*s^2*t))/((Q^2 + s)^2*SUNN*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 4, 2}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^6*s + 6*Q^4*s^2 + 3*Q^2*s^3 + 2*Q^6*t + 6*Q^4*s*t - 4*s^3*t + 
          4*Q^4*t^2 - 2*Q^2*s*t^2 - 8*s^2*t^2 - 4*s*t^3))/
        ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 - Q^6*s - 5*Q^4*s^2 - 
          3*Q^2*s^3 + 2*Q^6*t - 6*Q^4*s*t - 6*Q^2*s^2*t + 2*s^3*t - 
          6*Q^2*s*t^2 + 2*s^2*t^2))/((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^8 + 2*Q^6*s + Q^4*s^2 + 3*Q^6*t - 3*Q^2*s^2*t + 2*Q^4*t^2 - 
          6*Q^2*s*t^2 - 2*s^2*t^2 - 2*s*t^3))/((Q^2 + s)^2*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - 3*Q^2*s^2 - 2*s^3 + 
          2*Q^4*t - 2*Q^2*s*t - 4*s^2*t - 2*s*t^2))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 - Q^6*s - 8*Q^4*s^2 - 
          5*Q^2*s^3 + 4*Q^6*t - 8*Q^4*s*t - 10*Q^2*s^2*t + 2*s^3*t - 
          8*Q^2*s*t^2 + 2*s^2*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 + 2*Q^2*s + 3*Q^2*t - 
          s*t))/((Q^2 + s)^2*SUNN*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 4, 5}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^6 + 2*D*Q^6 - 
          20*Q^4*s + 5*D*Q^4*s - 16*Q^2*s^2 + 4*D*Q^2*s^2 - 4*s^3 + D*s^3 + 
          8*Q^4*t - 2*D*Q^4*t + 18*Q^2*s*t - 4*D*Q^2*s*t + 6*s^2*t - 
          2*D*s^2*t + 4*Q^2*t^2 - 4*s*t^2))/((Q^2 + s)^2*SUNN*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^8 + D*Q^8 - 16*Q^6*s + 4*D*Q^6*s - 24*Q^4*s^2 + 6*D*Q^4*s^2 - 
          16*Q^2*s^3 + 4*D*Q^2*s^3 - 4*s^4 + D*s^4 - 6*Q^6*t + D*Q^6*t - 
          10*Q^4*s*t + 3*D*Q^4*s*t - 10*Q^2*s^2*t + 3*D*Q^2*s^2*t - 6*s^3*t + 
          D*s^3*t - 2*Q^4*t^2 + 8*Q^2*s*t^2 - 6*s^2*t^2))/
        ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^8 + D*Q^8 - 12*Q^6*s + 
          3*D*Q^6*s - 12*Q^4*s^2 + 3*D*Q^4*s^2 - 4*Q^2*s^3 + D*Q^2*s^3 + 
          2*Q^6*t + 4*Q^4*s*t - D*Q^4*s*t + 6*Q^2*s^2*t - 2*D*Q^2*s^2*t + 
          4*s^3*t - D*s^3*t + 8*Q^4*t^2 - D*Q^4*t^2 + 2*Q^2*s*t^2 - 
          2*D*Q^2*s*t^2 + 6*s^2*t^2 - D*s^2*t^2 + 2*Q^2*t^3 - 2*s*t^3))/
        ((Q^2 + s)^2*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 
          2*D*Q^2*s - 4*s^2 + D*s^2 - 2*Q^2*t + 2*s*t))/((Q^2 + s)^2*SUNN*t), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^8 + 2*D*Q^8 - 28*Q^6*s + 7*D*Q^6*s - 36*Q^4*s^2 + 
          9*D*Q^4*s^2 - 20*Q^2*s^3 + 5*D*Q^2*s^3 - 4*s^4 + D*s^4 - 12*Q^6*t + 
          2*D*Q^6*t - 18*Q^4*s*t + 5*D*Q^4*s*t - 12*Q^2*s^2*t + 
          4*D*Q^2*s^2*t - 6*s^3*t + D*s^3*t - 4*Q^4*t^2 + 10*Q^2*s*t^2 - 
          6*s^2*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^8 + D*Q^8 - 16*Q^6*s + 
          4*D*Q^6*s - 24*Q^4*s^2 + 6*D*Q^4*s^2 - 16*Q^2*s^3 + 4*D*Q^2*s^3 - 
          4*s^4 + D*s^4 - 4*Q^6*t + D*Q^6*t - 10*Q^4*s*t + 3*D*Q^4*s*t - 
          12*Q^2*s^2*t + 3*D*Q^2*s^2*t - 6*s^3*t + D*s^3*t + 4*Q^2*s*t^2 - 
          4*s^2*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonMetricD", "Index" -> {}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((-8*I)*Q^6 + (4*I)*D*Q^6 + 
          (16*I)*eIn*Q^6 - (12*I)*D*eIn*Q^6 + (2*I)*D^2*eIn*Q^6 + 
          (24*I)*hIn*hOut*Q^6 - (4*I)*D*hIn*hOut*Q^6 - (8*I)*Q^4*s + 
          (4*I)*D*Q^4*s + (40*I)*eIn*Q^4*s - (30*I)*D*eIn*Q^4*s + 
          (5*I)*D^2*eIn*Q^4*s + (24*I)*hIn*hOut*Q^4*s - (4*I)*D*hIn*hOut*Q^4*
           s - (4*I)*Q^2*s^2 + (2*I)*D*Q^2*s^2 + (32*I)*eIn*Q^2*s^2 - 
          (24*I)*D*eIn*Q^2*s^2 + (4*I)*D^2*eIn*Q^2*s^2 - (12*I)*hIn*hOut*Q^2*
           s^2 + (2*I)*D*hIn*hOut*Q^2*s^2 - (4*I)*s^3 + (2*I)*D*s^3 + 
          (8*I)*eIn*s^3 - (6*I)*D*eIn*s^3 + I*D^2*eIn*s^3 - 
          (12*I)*hIn*hOut*s^3 + (2*I)*D*hIn*hOut*s^3 + (16*I)*Q^4*t - 
          (4*I)*D*Q^4*t - (16*I)*eIn*Q^4*t + (4*I)*D*eIn*Q^4*t - 
          (16*I)*hIn*hOut*Q^4*t + (4*I)*D*hIn*hOut*Q^4*t + (12*I)*Q^2*s*t - 
          (2*I)*D*Q^2*s*t - (20*I)*eIn*Q^2*s*t + (6*I)*D*eIn*Q^2*s*t - 
          (52*I)*hIn*hOut*Q^2*s*t + (10*I)*D*hIn*hOut*Q^2*s*t - 
          (12*I)*s^2*t + (6*I)*D*s^2*t + (4*I)*eIn*s^2*t - 
          (2*I)*D*eIn*s^2*t - (36*I)*hIn*hOut*s^2*t + (6*I)*D*hIn*hOut*s^2*
           t - (4*I)*D*Q^2*t^2 + (8*I)*eIn*Q^2*t^2 - (32*I)*hIn*hOut*Q^2*
           t^2 + (4*I)*D*hIn*hOut*Q^2*t^2 - (20*I)*s*t^2 + (4*I)*D*s*t^2 + 
          (28*I)*eIn*s*t^2 - (8*I)*D*eIn*s*t^2 - (36*I)*hIn*hOut*s*t^2 + 
          (4*I)*D*hIn*hOut*s*t^2 - (8*I)*t^3 + (8*I)*eIn*t^3 - 
          (8*I)*hIn*hOut*t^3 + (12*I)*Q^4*s*xIn - (6*I)*D*Q^4*s*xIn + 
          (12*I)*Q^2*s^2*xIn - (6*I)*D*Q^2*s^2*xIn + (8*I)*Q^4*t*xIn - 
          (4*I)*D*Q^4*t*xIn + (4*I)*Q^2*s*t*xIn - (2*I)*D*Q^2*s*t*xIn - 
          (12*I)*s^2*t*xIn + (6*I)*D*s^2*t*xIn + (8*I)*Q^2*t^2*xIn - 
          (4*I)*D*Q^2*t^2*xIn - (12*I)*s*t^2*xIn + (4*I)*D*s*t^2*xIn - 
          (8*I)*t^3*xIn - 12*hOut*Q^4*s*yIn + 2*D*hOut*Q^4*s*yIn - 
          12*hOut*Q^2*s^2*yIn + 2*D*hOut*Q^2*s^2*yIn + 24*hOut*Q^4*t*yIn - 
          4*D*hOut*Q^4*t*yIn + 68*hOut*Q^2*s*t*yIn - 10*D*hOut*Q^2*s*t*yIn + 
          44*hOut*s^2*t*yIn - 6*D*hOut*s^2*t*yIn + 40*hOut*Q^2*t^2*yIn - 
          4*D*hOut*Q^2*t^2*yIn + 44*hOut*s*t^2*yIn - 4*D*hOut*s*t^2*yIn + 
          8*hOut*t^3*yIn))/(8*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         ((8*I)*Q^6 - (4*I)*D*Q^6 - (8*I)*eIn*Q^6 + (6*I)*D*eIn*Q^6 - 
          I*D^2*eIn*Q^6 - (24*I)*hIn*hOut*Q^6 + (4*I)*D*hIn*hOut*Q^6 + 
          (4*I)*Q^4*s - (2*I)*D*Q^4*s - (24*I)*eIn*Q^4*s + 
          (18*I)*D*eIn*Q^4*s - (3*I)*D^2*eIn*Q^4*s - (36*I)*hIn*hOut*Q^4*s + 
          (6*I)*D*hIn*hOut*Q^4*s - (24*I)*eIn*Q^2*s^2 + (18*I)*D*eIn*Q^2*
           s^2 - (3*I)*D^2*eIn*Q^2*s^2 + (4*I)*s^3 - (2*I)*D*s^3 - 
          (8*I)*eIn*s^3 + (6*I)*D*eIn*s^3 - I*D^2*eIn*s^3 + 
          (12*I)*hIn*hOut*s^3 - (2*I)*D*hIn*hOut*s^3 - (4*I)*Q^4*t - 
          (2*I)*D*Q^4*t + (12*I)*eIn*Q^4*t - (2*I)*D*eIn*Q^4*t - 
          (20*I)*hIn*hOut*Q^4*t + (2*I)*D*hIn*hOut*Q^4*t - (24*I)*Q^2*s*t + 
          (4*I)*D*Q^2*s*t + (40*I)*eIn*Q^2*s*t - (12*I)*D*eIn*Q^2*s*t - 
          (4*I)*s^2*t - (2*I)*D*s^2*t + (12*I)*eIn*s^2*t - 
          (2*I)*D*eIn*s^2*t + (20*I)*hIn*hOut*s^2*t - (2*I)*D*hIn*hOut*s^2*
           t - (4*I)*Q^2*t^2 + (4*I)*eIn*Q^2*t^2 - (4*I)*hIn*hOut*Q^2*t^2 - 
          (4*I)*s*t^2 + (4*I)*eIn*s*t^2 + (12*I)*hIn*hOut*s*t^2 + 
          (4*I)*Q^6*xIn - (2*I)*D*Q^6*xIn - (8*I)*Q^4*s*xIn + 
          (4*I)*D*Q^4*s*xIn - (12*I)*Q^2*s^2*xIn + (6*I)*D*Q^2*s^2*xIn + 
          (4*I)*Q^4*t*xIn - (2*I)*D*Q^4*t*xIn - (8*I)*Q^2*s*t*xIn + 
          (4*I)*D*Q^2*s*t*xIn + (4*I)*s^2*t*xIn - (2*I)*D*s^2*t*xIn - 
          (4*I)*Q^2*t^2*xIn - (4*I)*s*t^2*xIn + 12*hOut*Q^6*yIn - 
          2*D*hOut*Q^6*yIn + 24*hOut*Q^4*s*yIn - 4*D*hOut*Q^4*s*yIn + 
          12*hOut*Q^2*s^2*yIn - 2*D*hOut*Q^2*s^2*yIn + 20*hOut*Q^4*t*yIn - 
          2*D*hOut*Q^4*t*yIn - 20*hOut*s^2*t*yIn + 2*D*hOut*s^2*t*yIn + 
          4*hOut*Q^2*t^2*yIn - 12*hOut*s*t^2*yIn))/(8*(Q^2 + s)*SUNN*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((-8*I)*eIn*Q^6 + (6*I)*D*eIn*Q^6 - 
          I*D^2*eIn*Q^6 + (4*I)*Q^4*s - (2*I)*D*Q^4*s - (16*I)*eIn*Q^4*s + 
          (12*I)*D*eIn*Q^4*s - (2*I)*D^2*eIn*Q^4*s + (12*I)*hIn*hOut*Q^4*s - 
          (2*I)*D*hIn*hOut*Q^4*s + (4*I)*Q^2*s^2 - (2*I)*D*Q^2*s^2 - 
          (8*I)*eIn*Q^2*s^2 + (6*I)*D*eIn*Q^2*s^2 - I*D^2*eIn*Q^2*s^2 + 
          (12*I)*hIn*hOut*Q^2*s^2 - (2*I)*D*hIn*hOut*Q^2*s^2 - (4*I)*Q^4*t + 
          (2*I)*D*Q^4*t - (4*I)*eIn*Q^4*t + (4*I)*D*eIn*Q^4*t - 
          I*D^2*eIn*Q^4*t + (12*I)*hIn*hOut*Q^4*t - (2*I)*D*hIn*hOut*Q^4*t + 
          (16*I)*Q^2*s*t - (4*I)*D*Q^2*s*t - (36*I)*eIn*Q^2*s*t + 
          (18*I)*D*eIn*Q^2*s*t - (2*I)*D^2*eIn*Q^2*s*t + (16*I)*hIn*hOut*Q^2*
           s*t - (4*I)*D*hIn*hOut*Q^2*s*t + (12*I)*s^2*t - (2*I)*D*s^2*t - 
          (24*I)*eIn*s^2*t + (10*I)*D*eIn*s^2*t - I*D^2*eIn*s^2*t + 
          (4*I)*hIn*hOut*s^2*t - (2*I)*D*hIn*hOut*s^2*t + (2*I)*D*Q^2*t^2 - 
          (2*I)*D*eIn*Q^2*t^2 + (16*I)*hIn*hOut*Q^2*t^2 - 
          (2*I)*D*hIn*hOut*Q^2*t^2 + (12*I)*s*t^2 - (2*I)*D*s*t^2 - 
          (12*I)*eIn*s*t^2 + (2*I)*D*eIn*s*t^2 + (4*I)*hIn*hOut*s*t^2 - 
          (2*I)*D*hIn*hOut*s*t^2 + (4*I)*t^3 - (4*I)*eIn*t^3 + 
          (4*I)*hIn*hOut*t^3 - (4*I)*Q^6*xIn + (2*I)*D*Q^6*xIn - 
          (4*I)*Q^4*s*xIn + (2*I)*D*Q^4*s*xIn - (8*I)*Q^4*t*xIn + 
          (4*I)*D*Q^4*t*xIn + (2*I)*D*Q^2*t^2*xIn + (12*I)*s*t^2*xIn - 
          (2*I)*D*s*t^2*xIn + (4*I)*t^3*xIn - 12*hOut*Q^6*yIn + 
          2*D*hOut*Q^6*yIn - 12*hOut*Q^4*s*yIn + 2*D*hOut*Q^4*s*yIn - 
          32*hOut*Q^4*t*yIn + 4*D*hOut*Q^4*t*yIn - 32*hOut*Q^2*s*t*yIn + 
          4*D*hOut*Q^2*s*t*yIn - 24*hOut*Q^2*t^2*yIn + 2*D*hOut*Q^2*t^2*yIn - 
          12*hOut*s*t^2*yIn + 2*D*hOut*s*t^2*yIn - 4*hOut*t^3*yIn))/
        (8*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((-8*I)*Q^4 + (4*I)*D*Q^4 + 
          (8*I)*eIn*Q^4 - (6*I)*D*eIn*Q^4 + I*D^2*eIn*Q^4 + 
          (24*I)*hIn*hOut*Q^4 - (4*I)*D*hIn*hOut*Q^4 - (4*I)*Q^2*s + 
          (2*I)*D*Q^2*s + (16*I)*eIn*Q^2*s - (12*I)*D*eIn*Q^2*s + 
          (2*I)*D^2*eIn*Q^2*s + (36*I)*hIn*hOut*Q^2*s - (6*I)*D*hIn*hOut*Q^2*
           s + (4*I)*s^2 - (2*I)*D*s^2 + (8*I)*eIn*s^2 - (6*I)*D*eIn*s^2 + 
          I*D^2*eIn*s^2 + (12*I)*hIn*hOut*s^2 - (2*I)*D*hIn*hOut*s^2 + 
          (4*I)*Q^2*t + (2*I)*D*Q^2*t - (12*I)*eIn*Q^2*t + 
          (2*I)*D*eIn*Q^2*t + (20*I)*hIn*hOut*Q^2*t - (2*I)*D*hIn*hOut*Q^2*
           t + (12*I)*s*t - (2*I)*D*s*t - (20*I)*eIn*s*t + (6*I)*D*eIn*s*t + 
          (20*I)*hIn*hOut*s*t - (2*I)*D*hIn*hOut*s*t + (4*I)*t^2 - 
          (4*I)*eIn*t^2 + (4*I)*hIn*hOut*t^2 - (4*I)*Q^4*xIn + 
          (2*I)*D*Q^4*xIn + (4*I)*Q^2*s*xIn - (2*I)*D*Q^2*s*xIn + 
          (8*I)*s^2*xIn - (4*I)*D*s^2*xIn - (4*I)*Q^2*t*xIn + 
          (2*I)*D*Q^2*t*xIn + (4*I)*s*t*xIn - (2*I)*D*s*t*xIn + 
          (4*I)*t^2*xIn - 12*hOut*Q^4*yIn + 2*D*hOut*Q^4*yIn - 
          36*hOut*Q^2*s*yIn + 6*D*hOut*Q^2*s*yIn - 24*hOut*s^2*yIn + 
          4*D*hOut*s^2*yIn - 20*hOut*Q^2*t*yIn + 2*D*hOut*Q^2*t*yIn - 
          20*hOut*s*t*yIn + 2*D*hOut*s*t*yIn - 4*hOut*t^2*yIn))/
        (8*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((-16*I)*Q^6 + (8*I)*D*Q^6 + 
          (16*I)*eIn*Q^6 - (12*I)*D*eIn*Q^6 + (2*I)*D^2*eIn*Q^6 + 
          (48*I)*hIn*hOut*Q^6 - (8*I)*D*hIn*hOut*Q^6 - (8*I)*Q^4*s + 
          (4*I)*D*Q^4*s + (40*I)*eIn*Q^4*s - (30*I)*D*eIn*Q^4*s + 
          (5*I)*D^2*eIn*Q^4*s + (72*I)*hIn*hOut*Q^4*s - (12*I)*D*hIn*hOut*Q^4*
           s + (4*I)*Q^2*s^2 - (2*I)*D*Q^2*s^2 + (32*I)*eIn*Q^2*s^2 - 
          (24*I)*D*eIn*Q^2*s^2 + (4*I)*D^2*eIn*Q^2*s^2 + (12*I)*hIn*hOut*Q^2*
           s^2 - (2*I)*D*hIn*hOut*Q^2*s^2 - (4*I)*s^3 + (2*I)*D*s^3 + 
          (8*I)*eIn*s^3 - (6*I)*D*eIn*s^3 + I*D^2*eIn*s^3 - 
          (12*I)*hIn*hOut*s^3 + (2*I)*D*hIn*hOut*s^3 + (8*I)*Q^4*t + 
          (4*I)*D*Q^4*t - (24*I)*eIn*Q^4*t + (4*I)*D*eIn*Q^4*t + 
          (40*I)*hIn*hOut*Q^4*t - (4*I)*D*hIn*hOut*Q^4*t + (36*I)*Q^2*s*t - 
          (6*I)*D*Q^2*s*t - (60*I)*eIn*Q^2*s*t + (18*I)*D*eIn*Q^2*s*t + 
          (20*I)*hIn*hOut*Q^2*s*t - (2*I)*D*hIn*hOut*Q^2*s*t + (4*I)*s^2*t + 
          (2*I)*D*s^2*t - (12*I)*eIn*s^2*t + (2*I)*D*eIn*s^2*t - 
          (20*I)*hIn*hOut*s^2*t + (2*I)*D*hIn*hOut*s^2*t + (8*I)*Q^2*t^2 - 
          (8*I)*eIn*Q^2*t^2 + (8*I)*hIn*hOut*Q^2*t^2 + (4*I)*s*t^2 - 
          (4*I)*eIn*s*t^2 - (12*I)*hIn*hOut*s*t^2 - (8*I)*Q^6*xIn + 
          (4*I)*D*Q^6*xIn + (12*I)*Q^4*s*xIn - (6*I)*D*Q^4*s*xIn + 
          (20*I)*Q^2*s^2*xIn - (10*I)*D*Q^2*s^2*xIn - (8*I)*Q^4*t*xIn + 
          (4*I)*D*Q^4*t*xIn + (12*I)*Q^2*s*t*xIn - (6*I)*D*Q^2*s*t*xIn - 
          (4*I)*s^2*t*xIn + (2*I)*D*s^2*t*xIn + (8*I)*Q^2*t^2*xIn + 
          (4*I)*s*t^2*xIn - 24*hOut*Q^6*yIn + 4*D*hOut*Q^6*yIn - 
          60*hOut*Q^4*s*yIn + 10*D*hOut*Q^4*s*yIn - 36*hOut*Q^2*s^2*yIn + 
          6*D*hOut*Q^2*s^2*yIn - 40*hOut*Q^4*t*yIn + 4*D*hOut*Q^4*t*yIn - 
          20*hOut*Q^2*s*t*yIn + 2*D*hOut*Q^2*s*t*yIn + 20*hOut*s^2*t*yIn - 
          2*D*hOut*s^2*t*yIn - 8*hOut*Q^2*t^2*yIn + 12*hOut*s*t^2*yIn))/
        (8*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         ((-4*I)*Q^6 + (2*I)*D*Q^6 + (8*I)*eIn*Q^6 - (6*I)*D*eIn*Q^6 + 
          I*D^2*eIn*Q^6 + (12*I)*hIn*hOut*Q^6 - (2*I)*D*hIn*hOut*Q^6 - 
          (4*I)*Q^4*s + (2*I)*D*Q^4*s + (24*I)*eIn*Q^4*s - 
          (18*I)*D*eIn*Q^4*s + (3*I)*D^2*eIn*Q^4*s + (12*I)*hIn*hOut*Q^4*s - 
          (2*I)*D*hIn*hOut*Q^4*s - (4*I)*Q^2*s^2 + (2*I)*D*Q^2*s^2 + 
          (24*I)*eIn*Q^2*s^2 - (18*I)*D*eIn*Q^2*s^2 + (3*I)*D^2*eIn*Q^2*s^2 - 
          (12*I)*hIn*hOut*Q^2*s^2 + (2*I)*D*hIn*hOut*Q^2*s^2 - (4*I)*s^3 + 
          (2*I)*D*s^3 + (8*I)*eIn*s^3 - (6*I)*D*eIn*s^3 + I*D^2*eIn*s^3 - 
          (12*I)*hIn*hOut*s^3 + (2*I)*D*hIn*hOut*s^3 + (2*I)*D*Q^4*t - 
          (4*I)*D*eIn*Q^4*t + I*D^2*eIn*Q^4*t + (16*I)*hIn*hOut*Q^4*t - 
          (2*I)*D*hIn*hOut*Q^4*t + (8*I)*Q^2*s*t - (4*I)*eIn*Q^2*s*t - 
          (6*I)*D*eIn*Q^2*s*t + (2*I)*D^2*eIn*Q^2*s*t + (2*I)*D*s^2*t + 
          (4*I)*eIn*s^2*t - (6*I)*D*eIn*s^2*t + I*D^2*eIn*s^2*t - 
          (16*I)*hIn*hOut*s^2*t + (2*I)*D*hIn*hOut*s^2*t + (4*I)*Q^2*t^2 - 
          (8*I)*eIn*Q^2*t^2 + (2*I)*D*eIn*Q^2*t^2 + (4*I)*hIn*hOut*Q^2*t^2 + 
          (4*I)*s*t^2 - (8*I)*eIn*s*t^2 + (2*I)*D*eIn*s*t^2 - 
          (4*I)*hIn*hOut*s*t^2 + (8*I)*Q^4*s*xIn - (4*I)*D*Q^4*s*xIn + 
          (8*I)*Q^2*s^2*xIn - (4*I)*D*Q^2*s^2*xIn + (8*I)*Q^2*s*t*xIn - 
          (4*I)*D*Q^2*s*t*xIn + 8*hOut*Q^2*s*t*yIn + 8*hOut*s^2*t*yIn + 
          8*hOut*s*t^2*yIn))/(8*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonWardLeft", "Index" -> {1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*(I*Q^4*s + I*hIn*hOut*Q^4*s + 
          (2*I)*hIn*hOut*Q^2*s^2 - I*s^3 + I*hIn*hOut*s^3 - (2*I)*Q^4*t - 
          (2*I)*hIn*hOut*Q^4*t - (7*I)*Q^2*s*t - (3*I)*hIn*hOut*Q^2*s*t - 
          (7*I)*s^2*t + (2*I)*eIn*s^2*t - I*hIn*hOut*s^2*t - (2*I)*Q^2*t^2 - 
          (2*I)*hIn*hOut*Q^2*t^2 - (6*I)*s*t^2 + (4*I)*eIn*s*t^2 - 
          (2*I)*hIn*hOut*s*t^2 + I*Q^4*s*xIn - I*s^3*xIn - (2*I)*Q^4*t*xIn - 
          (7*I)*Q^2*s*t*xIn - (7*I)*s^2*t*xIn - (2*I)*Q^2*t^2*xIn - 
          (6*I)*s*t^2*xIn + hOut*Q^4*s*yIn + 2*hOut*Q^2*s^2*yIn + 
          hOut*s^3*yIn - 2*hOut*Q^4*t*yIn - 3*hOut*Q^2*s*t*yIn - 
          hOut*s^2*t*yIn - 2*hOut*Q^2*t^2*yIn - 2*hOut*s*t^2*yIn))/
        (2*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/2*I)*(-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*(Q^6 + hIn*hOut*Q^6 + 
          Q^4*s + 3*hIn*hOut*Q^4*s - Q^2*s^2 + 3*hIn*hOut*Q^2*s^2 - s^3 + 
          hIn*hOut*s^3 + Q^4*t + hIn*hOut*Q^4*t - 4*Q^2*s*t + 2*eIn*Q^2*s*t + 
          2*hIn*hOut*Q^2*s*t - 5*s^2*t + 2*eIn*s^2*t + hIn*hOut*s^2*t - 
          4*s*t^2 + 4*eIn*s*t^2 + Q^6*xIn + Q^4*s*xIn - Q^2*s^2*xIn - 
          s^3*xIn + Q^4*t*xIn - 4*Q^2*s*t*xIn - 5*s^2*t*xIn - 4*s*t^2*xIn - 
          I*hOut*Q^6*yIn - (3*I)*hOut*Q^4*s*yIn - (3*I)*hOut*Q^2*s^2*yIn - 
          I*hOut*s^3*yIn - I*hOut*Q^4*t*yIn - (2*I)*hOut*Q^2*s*t*yIn - 
          I*hOut*s^2*t*yIn))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + t)*(I*Q^4 + I*hIn*hOut*Q^4 + (2*I)*hIn*hOut*Q^2*s - I*s^2 + 
          I*hIn*hOut*s^2 + I*Q^2*t + I*hIn*hOut*Q^2*t - I*s*t + 
          (2*I)*eIn*s*t + I*hIn*hOut*s*t + I*Q^4*xIn - I*s^2*xIn + 
          I*Q^2*t*xIn - I*s*t*xIn + hOut*Q^4*yIn + 2*hOut*Q^2*s*yIn + 
          hOut*s^2*yIn + hOut*Q^2*t*yIn + hOut*s*t*yIn))/
        (2*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*(I*Q^4 + I*hIn*hOut*Q^4 + 
          (4*I)*Q^2*s + (2*I)*hIn*hOut*Q^2*s + (3*I)*s^2 + I*hIn*hOut*s^2 + 
          I*Q^2*t + I*hIn*hOut*Q^2*t + (3*I)*s*t - (2*I)*eIn*s*t + 
          I*hIn*hOut*s*t + I*Q^4*xIn + (4*I)*Q^2*s*xIn + (3*I)*s^2*xIn + 
          I*Q^2*t*xIn + (3*I)*s*t*xIn + hOut*Q^4*yIn + 2*hOut*Q^2*s*yIn + 
          hOut*s^2*yIn + hOut*Q^2*t*yIn + hOut*s*t*yIn))/
        (2*(Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*((2*I)*Q^6 + (2*I)*hIn*hOut*Q^6 + 
          (5*I)*Q^4*s + (5*I)*hIn*hOut*Q^4*s + (2*I)*Q^2*s^2 + 
          (4*I)*hIn*hOut*Q^2*s^2 - I*s^3 + I*hIn*hOut*s^3 + (2*I)*Q^4*t + 
          (2*I)*hIn*hOut*Q^4*t - I*Q^2*s*t + (3*I)*hIn*hOut*Q^2*s*t - 
          (5*I)*s^2*t + (2*I)*eIn*s^2*t + I*hIn*hOut*s^2*t - (4*I)*s*t^2 + 
          (4*I)*eIn*s*t^2 + (2*I)*Q^6*xIn + (5*I)*Q^4*s*xIn + 
          (2*I)*Q^2*s^2*xIn - I*s^3*xIn + (2*I)*Q^4*t*xIn - I*Q^2*s*t*xIn - 
          (5*I)*s^2*t*xIn - (4*I)*s*t^2*xIn + 2*hOut*Q^6*yIn + 
          5*hOut*Q^4*s*yIn + 4*hOut*Q^2*s^2*yIn + hOut*s^3*yIn + 
          2*hOut*Q^4*t*yIn + 3*hOut*Q^2*s*t*yIn + hOut*s^2*t*yIn))/
        (2*(Q^2 + s)^2*SUNN*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*Q*s*(-1 + SUNN)*(1 + SUNN)*
         ((-I)*Q^2 + I*hIn*hOut*Q^2 - I*s + I*hIn*hOut*s - (2*I)*t + 
          (2*I)*eIn*t - I*Q^2*xIn - I*s*xIn - (2*I)*t*xIn + hOut*Q^2*yIn + 
          hOut*s*yIn))/(2*(Q^2 + s)^2*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonWardLeft", "Index" -> {2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*((2*I)*Q^8*s - 
          (4*I)*eIn*Q^8*s + I*D*eIn*Q^8*s + (2*I)*hIn*hOut*Q^8*s + 
          (4*I)*Q^6*s^2 - (16*I)*eIn*Q^6*s^2 + (4*I)*D*eIn*Q^6*s^2 + 
          (4*I)*hIn*hOut*Q^6*s^2 + (4*I)*Q^4*s^3 - (24*I)*eIn*Q^4*s^3 + 
          (6*I)*D*eIn*Q^4*s^3 + (4*I)*Q^2*s^4 - (16*I)*eIn*Q^2*s^4 + 
          (4*I)*D*eIn*Q^2*s^4 - (4*I)*hIn*hOut*Q^2*s^4 + (2*I)*s^5 - 
          (4*I)*eIn*s^5 + I*D*eIn*s^5 - (2*I)*hIn*hOut*s^5 - (4*I)*Q^8*t + 
          (8*I)*eIn*Q^8*t - (2*I)*D*eIn*Q^8*t - (4*I)*hIn*hOut*Q^8*t - 
          (12*I)*Q^6*s*t + (28*I)*eIn*Q^6*s*t - (7*I)*D*eIn*Q^6*s*t - 
          (12*I)*hIn*hOut*Q^6*s*t - (16*I)*Q^4*s^2*t + (38*I)*eIn*Q^4*s^2*t - 
          (9*I)*D*eIn*Q^4*s^2*t - (20*I)*hIn*hOut*Q^4*s^2*t + 
          (20*I)*eIn*Q^2*s^3*t - (5*I)*D*eIn*Q^2*s^3*t - (20*I)*hIn*hOut*Q^2*
           s^3*t + (8*I)*s^4*t + (2*I)*eIn*s^4*t - I*D*eIn*s^4*t - 
          (8*I)*hIn*hOut*s^4*t - (8*I)*Q^6*t^2 + (8*I)*eIn*Q^6*t^2 - 
          (2*I)*D*eIn*Q^6*t^2 - (8*I)*hIn*hOut*Q^6*t^2 - (22*I)*Q^4*s*t^2 + 
          (28*I)*eIn*Q^4*s*t^2 - (6*I)*D*eIn*Q^4*s*t^2 - (14*I)*hIn*hOut*Q^4*
           s*t^2 - (4*I)*Q^2*s^2*t^2 + (28*I)*eIn*Q^2*s^2*t^2 - 
          (6*I)*D*eIn*Q^2*s^2*t^2 - (8*I)*hIn*hOut*Q^2*s^2*t^2 + 
          (18*I)*s^3*t^2 - (2*I)*D*eIn*s^3*t^2 - (2*I)*hIn*hOut*s^3*t^2 - 
          (4*I)*Q^4*t^3 - (4*I)*hIn*hOut*Q^4*t^3 - (8*I)*Q^2*s*t^3 + 
          (8*I)*eIn*Q^2*s*t^3 + (12*I)*s^2*t^3 - (8*I)*eIn*s^2*t^3 + 
          (4*I)*hIn*hOut*s^2*t^3 - (4*I)*Q^6*s^2*xIn - (8*I)*Q^4*s^3*xIn - 
          (4*I)*Q^2*s^4*xIn + (2*I)*Q^6*s*t*xIn + (2*I)*Q^4*s^2*t*xIn + 
          (10*I)*Q^2*s^3*t*xIn + (10*I)*s^4*t*xIn - (4*I)*Q^6*t^2*xIn - 
          (10*I)*Q^4*s*t^2*xIn + (8*I)*Q^2*s^2*t^2*xIn + (22*I)*s^3*t^2*xIn - 
          (4*I)*Q^4*t^3*xIn - (8*I)*Q^2*s*t^3*xIn + (12*I)*s^2*t^3*xIn + 
          10*hOut*Q^6*s*t*yIn + 26*hOut*Q^4*s^2*t*yIn + 22*hOut*Q^2*s^3*t*
           yIn + 6*hOut*s^4*t*yIn - 4*hOut*Q^6*t^2*yIn + 
          6*hOut*Q^4*s*t^2*yIn + 20*hOut*Q^2*s^2*t^2*yIn + 
          10*hOut*s^3*t^2*yIn - 4*hOut*Q^4*t^3*yIn + 4*hOut*s^2*t^3*yIn))/
        (8*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)^2), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*
         (2*Q^10 - 4*eIn*Q^10 + D*eIn*Q^10 + 2*hIn*hOut*Q^10 + 6*Q^8*s - 
          20*eIn*Q^8*s + 5*D*eIn*Q^8*s + 6*hIn*hOut*Q^8*s + 8*Q^6*s^2 - 
          40*eIn*Q^6*s^2 + 10*D*eIn*Q^6*s^2 + 4*hIn*hOut*Q^6*s^2 + 
          8*Q^4*s^3 - 40*eIn*Q^4*s^3 + 10*D*eIn*Q^4*s^3 - 
          4*hIn*hOut*Q^4*s^3 + 6*Q^2*s^4 - 20*eIn*Q^2*s^4 + 5*D*eIn*Q^2*s^4 - 
          6*hIn*hOut*Q^2*s^4 + 2*s^5 - 4*eIn*s^5 + D*eIn*s^5 - 
          2*hIn*hOut*s^5 + 4*Q^8*t - 4*eIn*Q^8*t + D*eIn*Q^8*t + 
          4*hIn*hOut*Q^8*t - 14*eIn*Q^6*s*t + 4*D*eIn*Q^6*s*t + 
          4*hIn*hOut*Q^6*s*t - 4*Q^4*s^2*t - 22*eIn*Q^4*s^2*t + 
          6*D*eIn*Q^4*s^2*t - 12*hIn*hOut*Q^4*s^2*t + 8*Q^2*s^3*t - 
          18*eIn*Q^2*s^3*t + 4*D*eIn*Q^2*s^3*t - 20*hIn*hOut*Q^2*s^3*t + 
          8*s^4*t - 6*eIn*s^4*t + D*eIn*s^4*t - 8*hIn*hOut*s^4*t + 
          2*Q^6*t^2 + 2*hIn*hOut*Q^6*t^2 - 14*Q^4*s*t^2 + 8*eIn*Q^4*s*t^2 - 
          2*hIn*hOut*Q^4*s*t^2 - 2*Q^2*s^2*t^2 - 10*hIn*hOut*Q^2*s^2*t^2 + 
          14*s^3*t^2 - 8*eIn*s^3*t^2 - 6*hIn*hOut*s^3*t^2 - 8*Q^2*s*t^3 + 
          8*eIn*Q^2*s*t^3 + 8*s^2*t^3 - 8*eIn*s^2*t^3 - 4*Q^8*s*xIn - 
          12*Q^6*s^2*xIn - 12*Q^4*s^3*xIn - 4*Q^2*s^4*xIn + 2*Q^8*t*xIn - 
          8*Q^6*s*t*xIn - 16*Q^4*s^2*t*xIn + 6*s^4*t*xIn + 2*Q^6*t^2*xIn - 
          14*Q^4*s*t^2*xIn - 2*Q^2*s^2*t^2*xIn + 14*s^3*t^2*xIn - 
          8*Q^2*s*t^3*xIn + 8*s^2*t^3*xIn - (2*I)*hOut*Q^8*t*yIn - 
          (8*I)*hOut*Q^6*s*t*yIn - (12*I)*hOut*Q^4*s^2*t*yIn - 
          (8*I)*hOut*Q^2*s^3*t*yIn - (2*I)*hOut*s^4*t*yIn - 
          (2*I)*hOut*Q^6*t^2*yIn - (6*I)*hOut*Q^4*s*t^2*yIn - 
          (6*I)*hOut*Q^2*s^2*t^2*yIn - (2*I)*hOut*s^3*t^2*yIn))/
        (s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)^2), GLI["V10", {1, 1, 0, -1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + t)*transverseK*
         ((2*I)*Q^8 - (4*I)*eIn*Q^8 + I*D*eIn*Q^8 + (2*I)*hIn*hOut*Q^8 + 
          (4*I)*Q^6*s - (16*I)*eIn*Q^6*s + (4*I)*D*eIn*Q^6*s + 
          (4*I)*hIn*hOut*Q^6*s + (4*I)*Q^4*s^2 - (24*I)*eIn*Q^4*s^2 + 
          (6*I)*D*eIn*Q^4*s^2 + (4*I)*Q^2*s^3 - (16*I)*eIn*Q^2*s^3 + 
          (4*I)*D*eIn*Q^2*s^3 - (4*I)*hIn*hOut*Q^2*s^3 + (2*I)*s^4 - 
          (4*I)*eIn*s^4 + I*D*eIn*s^4 - (2*I)*hIn*hOut*s^4 + (4*I)*Q^6*t - 
          (4*I)*eIn*Q^6*t + I*D*eIn*Q^6*t + (4*I)*hIn*hOut*Q^6*t - 
          (10*I)*eIn*Q^4*s*t + (3*I)*D*eIn*Q^4*s*t + (4*I)*hIn*hOut*Q^4*s*t - 
          (12*I)*eIn*Q^2*s^2*t + (3*I)*D*eIn*Q^2*s^2*t - (4*I)*hIn*hOut*Q^2*
           s^2*t + (4*I)*s^3*t - (6*I)*eIn*s^3*t + I*D*eIn*s^3*t - 
          (4*I)*hIn*hOut*s^3*t + (2*I)*Q^4*t^2 + (2*I)*hIn*hOut*Q^4*t^2 - 
          (4*I)*Q^2*s*t^2 + (4*I)*eIn*Q^2*s*t^2 + (2*I)*s^2*t^2 - 
          (4*I)*eIn*s^2*t^2 - (2*I)*hIn*hOut*s^2*t^2 - (4*I)*Q^6*s*xIn - 
          (8*I)*Q^4*s^2*xIn - (4*I)*Q^2*s^3*xIn + (2*I)*Q^6*t*xIn - 
          (6*I)*Q^4*s*t*xIn - (6*I)*Q^2*s^2*t*xIn + (2*I)*s^3*t*xIn + 
          (2*I)*Q^4*t^2*xIn - (4*I)*Q^2*s*t^2*xIn + (2*I)*s^2*t^2*xIn + 
          2*hOut*Q^6*t*yIn + 2*hOut*Q^4*s*t*yIn - 2*hOut*Q^2*s^2*t*yIn - 
          2*hOut*s^3*t*yIn + 2*hOut*Q^4*t^2*yIn - 2*hOut*s^2*t^2*yIn))/
        (8*s*(Q^2 + s)*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, -1, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         transverseK*((2*I)*Q^8 - (4*I)*eIn*Q^8 + I*D*eIn*Q^8 + 
          (2*I)*hIn*hOut*Q^8 + (8*I)*Q^6*s - (16*I)*eIn*Q^6*s + 
          (4*I)*D*eIn*Q^6*s + (8*I)*hIn*hOut*Q^6*s + (8*I)*Q^4*s^2 - 
          (24*I)*eIn*Q^4*s^2 + (6*I)*D*eIn*Q^4*s^2 + (12*I)*hIn*hOut*Q^4*
           s^2 - (16*I)*eIn*Q^2*s^3 + (4*I)*D*eIn*Q^2*s^3 + 
          (8*I)*hIn*hOut*Q^2*s^3 - (2*I)*s^4 - (4*I)*eIn*s^4 + I*D*eIn*s^4 + 
          (2*I)*hIn*hOut*s^4 + (4*I)*Q^6*t - (4*I)*eIn*Q^6*t + 
          I*D*eIn*Q^6*t + (4*I)*hIn*hOut*Q^6*t + (12*I)*Q^4*s*t - 
          (14*I)*eIn*Q^4*s*t + (3*I)*D*eIn*Q^4*s*t + (8*I)*hIn*hOut*Q^4*s*t - 
          (12*I)*eIn*Q^2*s^2*t + (3*I)*D*eIn*Q^2*s^2*t + (4*I)*hIn*hOut*Q^2*
           s^2*t - (8*I)*s^3*t - (2*I)*eIn*s^3*t + I*D*eIn*s^3*t + 
          (2*I)*Q^4*t^2 + (2*I)*hIn*hOut*Q^4*t^2 + (4*I)*Q^2*s*t^2 - 
          (4*I)*eIn*Q^2*s*t^2 - (6*I)*s^2*t^2 + (4*I)*eIn*s^2*t^2 - 
          (2*I)*hIn*hOut*s^2*t^2 - (4*I)*Q^4*s^2*xIn - (8*I)*Q^2*s^3*xIn - 
          (4*I)*s^4*xIn + (2*I)*Q^6*t*xIn + (6*I)*Q^4*s*t*xIn - 
          (6*I)*Q^2*s^2*t*xIn - (10*I)*s^3*t*xIn + (2*I)*Q^4*t^2*xIn + 
          (4*I)*Q^2*s*t^2*xIn - (6*I)*s^2*t^2*xIn - 4*hOut*Q^6*s*yIn - 
          12*hOut*Q^4*s^2*yIn - 12*hOut*Q^2*s^3*yIn - 4*hOut*s^4*yIn + 
          2*hOut*Q^6*t*yIn - 2*hOut*Q^4*s*t*yIn - 10*hOut*Q^2*s^2*t*yIn - 
          6*hOut*s^3*t*yIn + 2*hOut*Q^4*t^2*yIn - 2*hOut*s^2*t^2*yIn))/
        (8*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*((4*I)*Q^10 - 
          (8*I)*eIn*Q^10 + (2*I)*D*eIn*Q^10 + (4*I)*hIn*hOut*Q^10 + 
          (14*I)*Q^8*s - (36*I)*eIn*Q^8*s + (9*I)*D*eIn*Q^8*s + 
          (14*I)*hIn*hOut*Q^8*s + (16*I)*Q^6*s^2 - (64*I)*eIn*Q^6*s^2 + 
          (16*I)*D*eIn*Q^6*s^2 + (16*I)*hIn*hOut*Q^6*s^2 + (8*I)*Q^4*s^3 - 
          (56*I)*eIn*Q^4*s^3 + (14*I)*D*eIn*Q^4*s^3 + (4*I)*hIn*hOut*Q^4*
           s^3 + (4*I)*Q^2*s^4 - (24*I)*eIn*Q^2*s^4 + (6*I)*D*eIn*Q^2*s^4 - 
          (4*I)*hIn*hOut*Q^2*s^4 + (2*I)*s^5 - (4*I)*eIn*s^5 + I*D*eIn*s^5 - 
          (2*I)*hIn*hOut*s^5 + (8*I)*Q^8*t - (8*I)*eIn*Q^8*t + 
          (2*I)*D*eIn*Q^8*t + (8*I)*hIn*hOut*Q^8*t + (12*I)*Q^6*s*t - 
          (28*I)*eIn*Q^6*s*t + (7*I)*D*eIn*Q^6*s*t + (12*I)*hIn*hOut*Q^6*s*
           t - (4*I)*Q^4*s^2*t - (34*I)*eIn*Q^4*s^2*t + (9*I)*D*eIn*Q^4*s^2*
           t - (8*I)*hIn*hOut*Q^4*s^2*t - (20*I)*eIn*Q^2*s^3*t + 
          (5*I)*D*eIn*Q^2*s^3*t - (20*I)*hIn*hOut*Q^2*s^3*t + (8*I)*s^4*t - 
          (6*I)*eIn*s^4*t + I*D*eIn*s^4*t - (8*I)*hIn*hOut*s^4*t + 
          (4*I)*Q^6*t^2 + (4*I)*hIn*hOut*Q^6*t^2 - (10*I)*Q^4*s*t^2 + 
          (4*I)*eIn*Q^4*s*t^2 - (2*I)*hIn*hOut*Q^4*s*t^2 - 
          (8*I)*Q^2*s^2*t^2 + (4*I)*eIn*Q^2*s^2*t^2 - (12*I)*hIn*hOut*Q^2*s^2*
           t^2 + (14*I)*s^3*t^2 - (8*I)*eIn*s^3*t^2 - (6*I)*hIn*hOut*s^3*
           t^2 - (8*I)*Q^2*s*t^3 + (8*I)*eIn*Q^2*s*t^3 + (8*I)*s^2*t^3 - 
          (8*I)*eIn*s^2*t^3 - (4*I)*Q^8*s*xIn - (16*I)*Q^6*s^2*xIn - 
          (20*I)*Q^4*s^3*xIn - (8*I)*Q^2*s^4*xIn + (4*I)*Q^8*t*xIn - 
          (2*I)*Q^6*s*t*xIn - (22*I)*Q^4*s^2*t*xIn - (10*I)*Q^2*s^3*t*xIn + 
          (6*I)*s^4*t*xIn + (4*I)*Q^6*t^2*xIn - (10*I)*Q^4*s*t^2*xIn - 
          (8*I)*Q^2*s^2*t^2*xIn + (14*I)*s^3*t^2*xIn - (8*I)*Q^2*s*t^3*xIn + 
          (8*I)*s^2*t^3*xIn - 4*hOut*Q^8*s*yIn - 12*hOut*Q^6*s^2*yIn - 
          12*hOut*Q^4*s^3*yIn - 4*hOut*Q^2*s^4*yIn + 4*hOut*Q^8*t*yIn + 
          6*hOut*Q^6*s*t*yIn + 2*hOut*Q^4*s^2*t*yIn + 2*hOut*Q^2*s^3*t*yIn + 
          2*hOut*s^4*t*yIn + 4*hOut*Q^6*t^2*yIn + 6*hOut*Q^4*s*t^2*yIn + 
          4*hOut*Q^2*s^2*t^2*yIn + 2*hOut*s^3*t^2*yIn))/
        (8*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         transverseK*((-4*I)*eIn*Q^6 + I*D*eIn*Q^6 + (2*I)*Q^4*s - 
          (12*I)*eIn*Q^4*s + (3*I)*D*eIn*Q^4*s - (2*I)*hIn*hOut*Q^4*s + 
          (4*I)*Q^2*s^2 - (12*I)*eIn*Q^2*s^2 + (3*I)*D*eIn*Q^2*s^2 - 
          (4*I)*hIn*hOut*Q^2*s^2 + (2*I)*s^3 - (4*I)*eIn*s^3 + I*D*eIn*s^3 - 
          (2*I)*hIn*hOut*s^3 - (4*I)*Q^4*t + (2*I)*eIn*Q^4*t - 
          (4*I)*hIn*hOut*Q^2*s*t + (4*I)*s^2*t - (2*I)*eIn*s^2*t - 
          (4*I)*hIn*hOut*s^2*t - (4*I)*Q^2*t^2 + (4*I)*eIn*Q^2*t^2 + 
          (4*I)*s*t^2 - (4*I)*eIn*s*t^2 - (2*I)*Q^6*xIn - (4*I)*Q^4*s*xIn - 
          (2*I)*Q^2*s^2*xIn - (4*I)*Q^4*t*xIn + (4*I)*s^2*t*xIn - 
          (4*I)*Q^2*t^2*xIn + (4*I)*s*t^2*xIn + 2*hOut*Q^6*yIn + 
          4*hOut*Q^4*s*yIn + 2*hOut*Q^2*s^2*yIn + 4*hOut*Q^4*t*yIn + 
          4*hOut*Q^2*s*t*yIn))/(8*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonWardLeft", "Index" -> {3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*(2*hIn*Q^6*s + 
          2*hOut*Q^6*s - 4*eIn*hOut*Q^6*s + D*eIn*hOut*Q^6*s + 
          2*hIn*Q^4*s^2 + 2*hOut*Q^4*s^2 - 12*eIn*hOut*Q^4*s^2 + 
          3*D*eIn*hOut*Q^4*s^2 - 2*hIn*Q^2*s^3 + 2*hOut*Q^2*s^3 - 
          12*eIn*hOut*Q^2*s^3 + 3*D*eIn*hOut*Q^2*s^3 - 2*hIn*s^4 + 
          2*hOut*s^4 - 4*eIn*hOut*s^4 + D*eIn*hOut*s^4 - 4*hIn*Q^6*t - 
          4*hOut*Q^6*t + 8*eIn*hOut*Q^6*t - 2*D*eIn*hOut*Q^6*t - 
          8*hIn*Q^4*s*t - 8*hOut*Q^4*s*t + 20*eIn*hOut*Q^4*s*t - 
          5*D*eIn*hOut*Q^4*s*t - 12*hIn*Q^2*s^2*t + 18*eIn*hOut*Q^2*s^2*t - 
          4*D*eIn*hOut*Q^2*s^2*t - 8*hIn*s^3*t + 8*hOut*s^3*t + 
          2*eIn*hOut*s^3*t - D*eIn*hOut*s^3*t - 8*hIn*Q^4*t^2 - 
          8*hOut*Q^4*t^2 + 8*eIn*hOut*Q^4*t^2 - 2*D*eIn*hOut*Q^4*t^2 - 
          22*hIn*Q^2*s*t^2 - 14*hOut*Q^2*s*t^2 + 20*eIn*hOut*Q^2*s*t^2 - 
          4*D*eIn*hOut*Q^2*s*t^2 - 18*hIn*s^2*t^2 + 2*hOut*s^2*t^2 + 
          4*eIn*hOut*s^2*t^2 - 2*D*eIn*hOut*s^2*t^2 - 4*hIn*Q^2*t^3 - 
          4*hOut*Q^2*t^3 - 12*hIn*s*t^3 - 4*hOut*s*t^3 - 4*hOut*Q^4*s^2*xIn - 
          4*hOut*Q^2*s^3*xIn - 2*hOut*Q^4*s*t*xIn + 6*hOut*s^3*t*xIn + 
          4*hOut*Q^4*t^2*xIn + 6*hOut*Q^2*s*t^2*xIn + 10*hOut*s^2*t^2*xIn + 
          4*hOut*Q^2*t^3*xIn + 4*hOut*s*t^3*xIn - (6*I)*Q^4*s*t*yIn - 
          (16*I)*Q^2*s^2*t*yIn - (10*I)*s^3*t*yIn - (4*I)*Q^4*t^2*yIn - 
          (22*I)*Q^2*s*t^2*yIn - (22*I)*s^2*t^2*yIn - (4*I)*Q^2*t^3*yIn - 
          (12*I)*s*t^3*yIn))/(8*s*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {0, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          transverseK*(2*hIn*Q^8 + 2*hOut*Q^8 - 4*eIn*hOut*Q^8 + 
           D*eIn*hOut*Q^8 + 4*hIn*Q^6*s + 4*hOut*Q^6*s - 16*eIn*hOut*Q^6*s + 
           4*D*eIn*hOut*Q^6*s + 4*hOut*Q^4*s^2 - 24*eIn*hOut*Q^4*s^2 + 
           6*D*eIn*hOut*Q^4*s^2 - 4*hIn*Q^2*s^3 + 4*hOut*Q^2*s^3 - 
           16*eIn*hOut*Q^2*s^3 + 4*D*eIn*hOut*Q^2*s^3 - 2*hIn*s^4 + 
           2*hOut*s^4 - 4*eIn*hOut*s^4 + D*eIn*hOut*s^4 + 4*hIn*Q^6*t + 
           4*hOut*Q^6*t - 4*eIn*hOut*Q^6*t + D*eIn*hOut*Q^6*t + 
           4*hOut*Q^4*s*t - 10*eIn*hOut*Q^4*s*t + 3*D*eIn*hOut*Q^4*s*t - 
           12*hIn*Q^2*s^2*t + 8*hOut*Q^2*s^2*t - 12*eIn*hOut*Q^2*s^2*t + 
           3*D*eIn*hOut*Q^2*s^2*t - 8*hIn*s^3*t + 8*hOut*s^3*t - 
           6*eIn*hOut*s^3*t + D*eIn*hOut*s^3*t + 2*hIn*Q^4*t^2 + 
           2*hOut*Q^4*t^2 - 12*hIn*Q^2*s*t^2 + 4*eIn*hOut*Q^2*s*t^2 - 
           14*hIn*s^2*t^2 + 6*hOut*s^2*t^2 - 4*eIn*hOut*s^2*t^2 - 
           8*hIn*s*t^3 - 4*hOut*Q^6*s*xIn - 8*hOut*Q^4*s^2*xIn - 
           4*hOut*Q^2*s^3*xIn - 2*hOut*Q^6*t*xIn - 14*hOut*Q^4*s*t*xIn - 
           10*hOut*Q^2*s^2*t*xIn + 2*hOut*s^3*t*xIn - 2*hOut*Q^4*t^2*xIn - 
           8*hOut*Q^2*s*t^2*xIn + 2*hOut*s^2*t^2*xIn + (2*I)*Q^6*t*yIn - 
           (2*I)*Q^4*s*t*yIn - (10*I)*Q^2*s^2*t*yIn - (6*I)*s^3*t*yIn + 
           (2*I)*Q^4*t^2*yIn - (12*I)*Q^2*s*t^2*yIn - (14*I)*s^2*t^2*yIn - 
           (8*I)*s*t^3*yIn))/(s*SUNN*t^2*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + t)*
         transverseK*(2*hIn*Q^6 + 2*hOut*Q^6 - 4*eIn*hOut*Q^6 + 
          D*eIn*hOut*Q^6 + 2*hIn*Q^4*s + 2*hOut*Q^4*s - 12*eIn*hOut*Q^4*s + 
          3*D*eIn*hOut*Q^4*s - 2*hIn*Q^2*s^2 + 2*hOut*Q^2*s^2 - 
          12*eIn*hOut*Q^2*s^2 + 3*D*eIn*hOut*Q^2*s^2 - 2*hIn*s^3 + 
          2*hOut*s^3 - 4*eIn*hOut*s^3 + D*eIn*hOut*s^3 + 4*hIn*Q^4*t + 
          4*hOut*Q^4*t - 4*eIn*hOut*Q^4*t + D*eIn*hOut*Q^4*t + 
          4*hOut*Q^2*s*t - 6*eIn*hOut*Q^2*s*t + 2*D*eIn*hOut*Q^2*s*t - 
          4*hIn*s^2*t + 4*hOut*s^2*t - 6*eIn*hOut*s^2*t + D*eIn*hOut*s^2*t + 
          2*hIn*Q^2*t^2 + 2*hOut*Q^2*t^2 - 2*hIn*s*t^2 + 2*hOut*s*t^2 - 
          4*hOut*Q^4*s*xIn - 4*hOut*Q^2*s^2*xIn - 2*hOut*Q^4*t*xIn - 
          8*hOut*Q^2*s*t*xIn - 2*hOut*s^2*t*xIn - 2*hOut*Q^2*t^2*xIn - 
          2*hOut*s*t^2*xIn + (2*I)*Q^4*t*yIn - (2*I)*s^2*t*yIn + 
          (2*I)*Q^2*t^2*yIn - (2*I)*s*t^2*yIn))/(8*s*SUNN*t^2*
         (Q^2 + s + t)^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*(2*hIn*Q^6 + 2*hOut*Q^6 - 
          4*eIn*hOut*Q^6 + D*eIn*hOut*Q^6 + 6*hIn*Q^4*s + 6*hOut*Q^4*s - 
          12*eIn*hOut*Q^4*s + 3*D*eIn*hOut*Q^4*s + 6*hIn*Q^2*s^2 + 
          2*hOut*Q^2*s^2 - 12*eIn*hOut*Q^2*s^2 + 3*D*eIn*hOut*Q^2*s^2 + 
          2*hIn*s^3 - 2*hOut*s^3 - 4*eIn*hOut*s^3 + D*eIn*hOut*s^3 + 
          4*hIn*Q^4*t + 4*hOut*Q^4*t - 4*eIn*hOut*Q^4*t + D*eIn*hOut*Q^4*t + 
          12*hIn*Q^2*s*t + 8*hOut*Q^2*s*t - 10*eIn*hOut*Q^2*s*t + 
          2*D*eIn*hOut*Q^2*s*t + 8*hIn*s^2*t - 2*eIn*hOut*s^2*t + 
          D*eIn*hOut*s^2*t + 2*hIn*Q^2*t^2 + 2*hOut*Q^2*t^2 + 6*hIn*s*t^2 + 
          2*hOut*s*t^2 - 4*hOut*Q^2*s^2*xIn - 4*hOut*s^3*xIn - 
          2*hOut*Q^4*t*xIn - 4*hOut*Q^2*s*t*xIn - 6*hOut*s^2*t*xIn - 
          2*hOut*Q^2*t^2*xIn - 2*hOut*s*t^2*xIn + (4*I)*Q^4*s*yIn + 
          (8*I)*Q^2*s^2*yIn + (4*I)*s^3*yIn + (2*I)*Q^4*t*yIn + 
          (12*I)*Q^2*s*t*yIn + (10*I)*s^2*t*yIn + (2*I)*Q^2*t^2*yIn + 
          (6*I)*s*t^2*yIn))/(8*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V10", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         transverseK*(4*hIn*Q^8 + 4*hOut*Q^8 - 8*eIn*hOut*Q^8 + 
          2*D*eIn*hOut*Q^8 + 10*hIn*Q^6*s + 10*hOut*Q^6*s - 
          28*eIn*hOut*Q^6*s + 7*D*eIn*hOut*Q^6*s + 6*hIn*Q^4*s^2 + 
          6*hOut*Q^4*s^2 - 36*eIn*hOut*Q^4*s^2 + 9*D*eIn*hOut*Q^4*s^2 - 
          2*hIn*Q^2*s^3 + 2*hOut*Q^2*s^3 - 20*eIn*hOut*Q^2*s^3 + 
          5*D*eIn*hOut*Q^2*s^3 - 2*hIn*s^4 + 2*hOut*s^4 - 4*eIn*hOut*s^4 + 
          D*eIn*hOut*s^4 + 8*hIn*Q^6*t + 8*hOut*Q^6*t - 8*eIn*hOut*Q^6*t + 
          2*D*eIn*hOut*Q^6*t + 12*hIn*Q^4*s*t + 12*hOut*Q^4*s*t - 
          20*eIn*hOut*Q^4*s*t + 5*D*eIn*hOut*Q^4*s*t - 4*hIn*Q^2*s^2*t + 
          8*hOut*Q^2*s^2*t - 14*eIn*hOut*Q^2*s^2*t + 4*D*eIn*hOut*Q^2*s^2*t - 
          8*hIn*s^3*t + 8*hOut*s^3*t - 6*eIn*hOut*s^3*t + D*eIn*hOut*s^3*t + 
          4*hIn*Q^4*t^2 + 4*hOut*Q^4*t^2 - 6*hIn*Q^2*s*t^2 + 
          2*hOut*Q^2*s*t^2 + 4*eIn*hOut*Q^2*s*t^2 - 14*hIn*s^2*t^2 + 
          6*hOut*s^2*t^2 - 4*eIn*hOut*s^2*t^2 - 8*hIn*s*t^3 - 
          4*hOut*Q^6*s*xIn - 12*hOut*Q^4*s^2*xIn - 8*hOut*Q^2*s^3*xIn - 
          4*hOut*Q^6*t*xIn - 18*hOut*Q^4*s*t*xIn - 16*hOut*Q^2*s^2*t*xIn + 
          2*hOut*s^3*t*xIn - 4*hOut*Q^4*t^2*xIn - 10*hOut*Q^2*s*t^2*xIn + 
          2*hOut*s^2*t^2*xIn + (4*I)*Q^6*s*yIn + (8*I)*Q^4*s^2*yIn + 
          (4*I)*Q^2*s^3*yIn + (4*I)*Q^6*t*yIn + (10*I)*Q^4*s*t*yIn - 
          (6*I)*s^3*t*yIn + (4*I)*Q^4*t^2*yIn - (6*I)*Q^2*s*t^2*yIn - 
          (14*I)*s^2*t^2*yIn - (8*I)*s*t^3*yIn))/(8*s*SUNN*t*
         (Q^2 + s + t)^2)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          transverseK*(4*eIn*hOut*Q^4 - D*eIn*hOut*Q^4 + 2*hIn*Q^2*s - 
           2*hOut*Q^2*s + 8*eIn*hOut*Q^2*s - 2*D*eIn*hOut*Q^2*s + 2*hIn*s^2 - 
           2*hOut*s^2 + 4*eIn*hOut*s^2 - D*eIn*hOut*s^2 + 4*hIn*Q^2*t - 
           2*eIn*hOut*Q^2*t + 4*hIn*s*t - 4*hOut*s*t + 2*eIn*hOut*s*t + 
           4*hIn*t^2 + 2*hOut*Q^4*xIn + 2*hOut*Q^2*s*xIn + 4*hOut*Q^2*t*xIn + 
           (2*I)*Q^4*yIn + (2*I)*Q^2*s*yIn + (4*I)*Q^2*t*yIn + 
           (4*I)*s*t*yIn + (4*I)*t^2*yIn))/(SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>}, "InputHash" -> 9393304692673827435719976734310\
2248854109580349781554778512317217311291292487, 
 "ReconstructionPassed" -> True, "ReducedReferenceChecksPassed" -> True|>
