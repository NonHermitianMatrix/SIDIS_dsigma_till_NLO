<|"Diagram" -> 15, "Components" -> {<|"Kind" -> "ExtendedResponse", 
    "Index" -> {1, 1, 1}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^4 - 7*Q^2*s - 5*s^2 + 2*Q^2*t - 6*s*t))/((Q^2 + s)^2*SUNN*
         (Q^2 + s + t)), GLI["V11", {0, 0, 0, 1}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - Q^4*s - 5*Q^2*s^2 - 
          3*s^3 + 4*Q^2*s*t - 4*s^2*t))/((Q^2 + s)^3*SUNN*(Q^2 + s + t)), 
      GLI["V11", {-1, 1, 0, 1}] -> ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^4*s + 2*Q^2*s^2 - s^3 - Q^4*t + 6*Q^2*s*t - s^2*t))/
        ((Q^2 + s)^3*SUNN*(Q^2 + s + t)), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/2*I)*(-2 + D)*(Q^2 - 3*s)*(-1 + SUNN)*(1 + SUNN))/
        ((Q^2 + s)^2*SUNN), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 - 3*Q^4*s - 
          8*Q^2*s^2 - 3*s^3 + 4*Q^2*s*t - 4*s^2*t))/((Q^2 + s)^3*SUNN)|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((I/2)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(Q^4 + 2*Q^2*s + s^2 - 
          2*Q^2*t + 2*s*t))/((Q^2 + s)^3*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 1, 2}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 - 7*Q^2*s - 5*s^2 + 
          2*Q^2*t - 6*s*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 - Q^4*s - 5*Q^2*s^2 - 3*s^3 + 4*Q^2*s*t - 4*s^2*t))/
        ((Q^2 + s)^3*SUNN*(Q^2 + s + t)), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^4*s + 2*Q^2*s^2 - s^3 - 
          Q^4*t + 6*Q^2*s*t - s^2*t))/((Q^2 + s)^3*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 1, -1, 1}] -> ((-1/2*I)*(-2 + D)*(Q^2 - 3*s)*(-1 + SUNN)*
         (1 + SUNN))/((Q^2 + s)^2*SUNN), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 - 3*Q^4*s - 
          8*Q^2*s^2 - 3*s^3 + 4*Q^2*s*t - 4*s^2*t))/((Q^2 + s)^3*SUNN)|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((I/2)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(Q^4 + 2*Q^2*s + s^2 - 
          2*Q^2*t + 2*s*t))/((Q^2 + s)^3*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 1, 5}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       (I*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(2*Q^2 + s + 2*t))/
        ((Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V11", {0, 0, 0, 1}] -> 
       ((-I)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(Q^4 + 2*Q^2*s + s^2 - 
          2*Q^2*t + 2*s*t))/((Q^2 + s)^3*SUNN*(Q^2 + s + t)), 
      GLI["V11", {-1, 1, 0, 1}] -> (I*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
         (Q^2*s + s^2 - 3*Q^2*t + s*t))/((Q^2 + s)^3*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 1, -1, 1}] -> ((-I)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/
        ((Q^2 + s)^2*SUNN), GLI["V11", {0, 1, 0, 1}] -> 
       ((-I)*(-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 + 3*Q^2*s + s^2 - 
          2*Q^2*t + 2*s*t))/((Q^2 + s)^3*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> (I*(-2 + D)*(Q^2 - s)*s*(-1 + SUNN)*
         (1 + SUNN)*t)/((Q^2 + s)^3*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 4, 3}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       -1/2*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 - 3*Q^2*s - 3*s^2 + 
           2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 0, 0, 1}] -> ((-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN))/
        (2*(Q^2 + s)*SUNN*(Q^2 + s + t)), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/2*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^2*s + s^2 - Q^2*t + s*t))/
         ((Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V11", {0, 1, -1, 1}] -> 
       ((-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN))/(2*(Q^2 + s)^2*SUNN), 
      GLI["V11", {0, 1, 0, 1}] -> ((-2 + D)*(Q^2 - s)*(2*Q^2 + s)*(-1 + SUNN)*
         (1 + SUNN))/(2*(Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> -1/2*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/
         ((Q^2 + s)*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 4, 4}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 - 3*Q^2*s - 3*s^2 + 
          2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 0, 0, 1}] -> ((I/2)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*
         (1 + SUNN))/((Q^2 + s)*SUNN*(Q^2 + s + t)), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^2*s + s^2 - Q^2*t + s*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 1, -1, 1}] -> ((I/2)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*
         (1 + SUNN))/((Q^2 + s)^2*SUNN), GLI["V11", {0, 1, 0, 1}] -> 
       ((I/2)*(-2 + D)*(Q^2 - s)*(2*Q^2 + s)*(-1 + SUNN)*(1 + SUNN))/
        ((Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/2*I)*(-2 + D)*s*(-1 + SUNN)*
         (1 + SUNN))/((Q^2 + s)*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 1, 1}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6*s + 5*Q^4*s^2 + 
          4*Q^2*s^3 + s^4 - 4*Q^6*t + 6*Q^4*s*t + 18*Q^2*s^2*t + 8*s^3*t - 
          14*Q^4*t^2 + 8*Q^2*s*t^2 + 14*s^2*t^2 - 8*Q^2*t^3 + 8*s*t^3))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (Q^6*s + 3*Q^4*s^2 + 3*Q^2*s^3 + s^4 - 2*Q^6*t - 4*Q^4*s*t + 
          2*Q^2*s^2*t + 4*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6*s^2 + 3*Q^4*s^3 + 
          3*Q^2*s^4 + s^5 - 7*Q^6*s*t - 11*Q^4*s^2*t - Q^2*s^3*t + 3*s^4*t + 
          4*Q^6*t^2 - 10*Q^4*s*t^2 - 8*Q^2*s^2*t^2 + 6*s^3*t^2 + 4*Q^4*t^3 - 
          8*Q^2*s*t^3 + 4*s^2*t^3))/((Q^2 + s)^3*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*(Q^2*s + s^2 - 2*Q^2*t + 2*s*t))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (2*Q^6*s + 5*Q^4*s^2 + 4*Q^2*s^3 + s^4 - 4*Q^6*t - 4*Q^4*s*t + 
          4*Q^2*s^2*t + 4*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-2*Q^4*s^2 - 4*Q^2*s^3 - 2*s^4 + Q^6*t + 5*Q^4*s*t - Q^2*s^2*t - 
          5*s^3*t + 4*Q^2*s*t^2 - 4*s^2*t^2))/((Q^2 + s)^3*SUNN*
         (Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 1, 2}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 4*t)*
         (2*Q^6 + 3*Q^4*s + Q^2*s^2 + 4*Q^4*t - 2*s^2*t + 2*Q^2*t^2 - 
          2*s*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t + 
          4*Q^4*s*t - 2*Q^2*s^2*t - 4*s^3*t + 4*Q^2*s*t^2 - 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8*s + 3*Q^6*s^2 + 
          3*Q^4*s^3 + Q^2*s^4 - 3*Q^8*t - 3*Q^6*s*t - Q^4*s^2*t - 
          5*Q^2*s^3*t - 4*s^4*t - 6*Q^6*t^2 + 4*Q^4*s*t^2 + 2*Q^2*s^2*t^2 - 
          8*s^3*t^2 - 4*Q^4*t^3 + 8*Q^2*s*t^3 - 4*s^2*t^3))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (Q^4 + Q^2*s + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*(2*Q^8 + 5*Q^6*s + 4*Q^4*s^2 + Q^2*s^3 + 4*Q^6*t + 
          4*Q^4*s*t - 4*Q^2*s^2*t - 4*s^3*t + 4*Q^2*s*t^2 - 4*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^8 + 4*Q^6*s + 4*Q^4*s^2 - s^4 + Q^6*t + 5*Q^4*s*t - Q^2*s^2*t - 
          5*s^3*t + 4*Q^2*s*t^2 - 4*s^2*t^2))/((Q^2 + s)^3*SUNN*
         (Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 1, 5}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^8 + 2*D*Q^8 - 
          28*Q^6*s + 7*D*Q^6*s - 36*Q^4*s^2 + 9*D*Q^4*s^2 - 20*Q^2*s^3 + 
          5*D*Q^2*s^3 - 4*s^4 + D*s^4 - 28*Q^6*t + 8*D*Q^6*t - 86*Q^4*s*t + 
          22*D*Q^4*s*t - 84*Q^2*s^2*t + 20*D*Q^2*s^2*t - 26*s^3*t + 
          6*D*s^3*t - 4*Q^4*t^2 + 4*D*Q^4*t^2 - 36*Q^2*s*t^2 + 
          8*D*Q^2*s*t^2 - 24*s^2*t^2 + 4*D*s^2*t^2 + 8*Q^2*t^3 - 8*s*t^3))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (-4*Q^8 + D*Q^8 - 16*Q^6*s + 4*D*Q^6*s - 24*Q^4*s^2 + 6*D*Q^4*s^2 - 
          16*Q^2*s^3 + 4*D*Q^2*s^3 - 4*s^4 + D*s^4 + 2*Q^6*t + 6*Q^4*s*t - 
          2*Q^2*s^2*t - 6*s^3*t + 8*Q^2*s*t^2 - 8*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^8*s + D*Q^8*s - 
          16*Q^6*s^2 + 4*D*Q^6*s^2 - 24*Q^4*s^3 + 6*D*Q^4*s^3 - 16*Q^2*s^4 + 
          4*D*Q^2*s^4 - 4*s^5 + D*s^5 + 12*Q^8*t - 3*D*Q^8*t + 46*Q^6*s*t - 
          10*D*Q^6*s*t + 54*Q^4*s^2*t - 12*D*Q^4*s^2*t + 18*Q^2*s^3*t - 
          6*D*Q^2*s^3*t - 2*s^4*t - D*s^4*t + 6*Q^6*t^2 - 2*D*Q^6*t^2 + 
          42*Q^4*s*t^2 - 6*D*Q^4*s*t^2 + 26*Q^2*s^2*t^2 - 6*D*Q^2*s^2*t^2 - 
          10*s^3*t^2 - 2*D*s^3*t^2 - 4*Q^4*t^3 + 16*Q^2*s*t^3 - 12*s^2*t^3))/
        ((Q^2 + s)^3*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s + 2*t)*
         (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 
          2*s*t))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*(-8*Q^8 + 2*D*Q^8 - 28*Q^6*s + 7*D*Q^6*s - 
          36*Q^4*s^2 + 9*D*Q^4*s^2 - 20*Q^2*s^3 + 5*D*Q^2*s^3 - 4*s^4 + 
          D*s^4 + 4*Q^6*t + 6*Q^4*s*t - 4*Q^2*s^2*t - 6*s^3*t + 8*Q^2*s*t^2 - 
          8*s^2*t^2))/((Q^2 + s)^3*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^8 + D*Q^8 - 14*Q^6*s + 
          4*D*Q^6*s - 22*Q^4*s^2 + 6*D*Q^4*s^2 - 18*Q^2*s^3 + 4*D*Q^2*s^3 - 
          6*s^4 + D*s^4 + 8*Q^4*s*t - 8*s^3*t + 8*Q^2*s*t^2 - 8*s^2*t^2))/
        ((Q^2 + s)^3*SUNN*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 4, 3}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 + 5*Q^6*s + 4*Q^4*s^2 + 
           Q^2*s^3 + 12*Q^6*t + 20*Q^4*s*t + 8*Q^2*s^2*t + 14*Q^4*t^2 + 
           6*Q^2*s*t^2 - 4*s^2*t^2 + 4*Q^2*t^3 - 4*s*t^3))/
         ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 + Q^2*s + 4*Q^2*t + 2*s*t + 
          2*t^2))/(4*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6*s + 2*Q^4*s^2 + Q^2*s^3 - 
           3*Q^6*t + 5*Q^2*s^2*t + 2*s^3*t - 6*Q^4*t^2 + 2*Q^2*s*t^2 + 
           4*s^2*t^2 - 2*Q^2*t^3 + 2*s*t^3))/((Q^2 + s)^2*SUNN*t*
          (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 + 2*Q^4*s + Q^2*s^2 + 4*Q^4*t + 
          4*Q^2*s*t + 2*Q^2*t^2 - 2*s*t^2))/(4*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 + 5*Q^6*s + 4*Q^4*s^2 + 
          Q^2*s^3 + 8*Q^6*t + 14*Q^4*s*t + 8*Q^2*s^2*t + 2*s^3*t + 
          4*Q^4*t^2 + 2*Q^2*s*t^2 + 2*s^2*t^2))/(4*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN))/
        (4*SUNN)|>, "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 4, 4}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6*s + 5*Q^4*s^2 + 4*Q^2*s^3 + s^4 + 12*Q^4*s*t + 20*Q^2*s^2*t + 
          8*s^3*t - 6*Q^4*t^2 + 10*Q^2*s*t^2 + 12*s^2*t^2 - 4*Q^2*t^3 + 
          4*s*t^3))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s + 2*Q^2*s^2 + s^3 + 6*Q^2*s*t + 6*s^2*t - 2*Q^2*t^2 + 
          6*s*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s^2 + 2*Q^2*s^3 + s^4 - Q^4*s*t + 2*Q^2*s^2*t + 3*s^3*t + 
          2*Q^4*t^2 - 2*Q^2*s*t^2 + 2*Q^2*t^3 - 2*s*t^3))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4*s + 2*Q^2*s^2 + s^3 + 
          4*Q^2*s*t + 4*s^2*t - 2*Q^2*t^2 + 2*s*t^2))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6*s + 5*Q^4*s^2 + 
          4*Q^2*s^3 + s^4 + 10*Q^4*s*t + 16*Q^2*s^2*t + 6*s^3*t - 4*Q^4*t^2 + 
          6*Q^2*s*t^2 + 6*s^2*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^2*s + 2*s^2 - Q^2*t + 
          3*s*t))/((Q^2 + s)*SUNN*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 1, 1}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s + 3*Q^2*s^2 + s^3 + 
          4*Q^4*t + 2*Q^2*s*t + 2*Q^2*t^2 - 2*s*t^2))/((Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4*s + 2*Q^2*s^2 + s^3 + 
          2*Q^4*t + 2*s^2*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*s*(-1 + SUNN)*
         (1 + SUNN)*(s + t)*(Q^2 + s + 2*t))/((Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2*s + s^2 + 2*Q^2*t))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s + 3*Q^2*s^2 + s^3 + 
          4*Q^4*t + 2*s^2*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^2*s + Q^2*t + s*t))/
        ((Q^2 + s)*SUNN*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 1, 2}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 + 3*Q^4*s + Q^2*s^2 + 
          4*Q^2*s*t + 2*s^2*t - 2*Q^2*t^2 + 2*s*t^2))/((Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN)*(Q^4 + 2*Q^2*s + s^2 + 
          4*s*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((I/4)*(-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN)*
         (s + t)*(Q^2 + s + 2*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + Q^2*s + 2*s*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*Q^2*(-1 + SUNN)*
         (1 + SUNN)*(2*Q^4 + 3*Q^2*s + s^2 + 6*s*t))/((Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + s^2 + Q^2*t + s*t))/((Q^2 + s)*SUNN*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 1, 5}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^6 + 2*D*Q^6 - 20*Q^4*s + 5*D*Q^4*s - 16*Q^2*s^2 + 
          4*D*Q^2*s^2 - 4*s^3 + D*s^3 + 4*Q^4*t - 2*Q^2*s*t - 2*s^2*t + 
          4*Q^2*t^2 - 4*s*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 12*Q^4*s + 3*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 
          4*s^3 + D*s^3 + 2*Q^4*t - 4*Q^2*s*t + 2*s^2*t))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(s + t)*(-4*Q^4 + D*Q^4 - 
          8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 - 2*Q^2*t + 2*s*t))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 
          2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 2*s*t))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^6 + 2*D*Q^6 - 
          20*Q^4*s + 5*D*Q^4*s - 16*Q^2*s^2 + 4*D*Q^2*s^2 - 4*s^3 + D*s^3 + 
          4*Q^4*t - 6*Q^2*s*t + 2*s^2*t))/((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-4*Q^4 + D*Q^4 - 6*Q^2*s + 2*D*Q^2*s - 6*s^2 + D*s^2)*
         (-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 4, 3}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (2*Q^6 + 3*Q^4*s + Q^2*s^2 - 6*Q^2*t^2 - 4*s*t^2 - 4*t^3))/
         ((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 + 2*Q^4*s + Q^2*s^2 + 
          2*Q^2*s*t + 2*s^2*t - 2*Q^2*t^2 + 2*s*t^2))/(4*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(s + t)*(Q^4 + Q^2*s + 2*Q^2*t + 
           2*s*t + 2*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + Q^2*s - 2*t^2))/(4*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + 3*Q^4*s + Q^2*s^2 + 2*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + 
          2*s*t^2))/(4*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       -1/4*((-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 4, 4}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^4*s + 3*Q^2*s^2 + s^3 - 6*Q^2*t^2 - 4*s*t^2 - 4*t^3))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4*s + 2*Q^2*s^2 + s^3 + 
          2*Q^2*s*t + 2*s^2*t - 2*Q^2*t^2 + 2*s*t^2))/((Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(s + t)*(Q^2*s + s^2 + 
          2*Q^2*t + 2*s*t + 2*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^2*s + s^2 - 2*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^4*s + 3*Q^2*s^2 + s^3 + 2*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + 
          2*s*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN)*t)/
        ((Q^2 + s)*SUNN*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 1, 1}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(8*Q^6*s + 6*Q^4*s^2 - 
          6*Q^2*s^3 - 4*s^4 - 2*Q^6*t + 37*Q^4*s*t + 14*Q^2*s^2*t - 9*s^3*t - 
          2*Q^4*t^2 + 24*Q^2*s*t^2 - 6*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^8*s + 10*Q^6*s^2 + 
          6*Q^4*s^3 - 2*Q^2*s^4 - 2*s^5 - Q^8*t + 8*Q^6*s*t + 30*Q^4*s^2*t + 
          16*Q^2*s^3*t - 5*s^4*t - 4*Q^4*s*t^2 + 24*Q^2*s^2*t^2 - 4*s^3*t^2)*
         transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (6*Q^6*s^2 + 12*Q^4*s^3 + 6*Q^2*s^4 - 13*Q^6*s*t + 5*Q^4*s^2*t + 
          17*Q^2*s^3*t - s^4*t + Q^6*t^2 - 15*Q^4*s*t^2 + 15*Q^2*s^2*t^2 - 
          s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^4*s + 2*Q^2*s^2 - 2*s^3 - Q^4*t + 12*Q^2*s*t - 3*s^2*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (8*Q^8*s + 16*Q^6*s^2 + 6*Q^4*s^3 - 4*Q^2*s^4 - 2*s^5 - 2*Q^8*t + 
          19*Q^6*s*t + 39*Q^4*s^2*t + 13*Q^2*s^3*t - 5*s^4*t - 4*Q^4*s*t^2 + 
          24*Q^2*s^2*t^2 - 4*s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6*s + 3*Q^4*s^2 + 3*Q^2*s^3 + s^4 - 2*Q^6*t - 10*Q^4*s*t - 
          6*Q^2*s^2*t + 2*s^3*t + 2*Q^4*t^2 - 12*Q^2*s*t^2 + 2*s^2*t^2)*
         transverseK)/(Q*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 1, 2}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 - 7*Q^6*s - 13*Q^4*s^2 - 3*Q^2*s^3 + s^4 + 4*Q^6*t - 
          35*Q^4*s*t - 16*Q^2*s^2*t + 7*s^3*t + 2*Q^4*t^2 - 24*Q^2*s*t^2 + 
          6*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^10 - Q^8*s - 8*Q^6*s^2 - 8*Q^4*s^3 - Q^2*s^4 + s^5 + Q^8*t - 
          8*Q^6*s*t - 30*Q^4*s^2*t - 16*Q^2*s^3*t + 5*s^4*t + 4*Q^4*s*t^2 - 
          24*Q^2*s^2*t^2 + 4*s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^8*s + 4*Q^6*s^2 + s^5 - 
          Q^8*t + 11*Q^6*s*t - 5*Q^4*s^2*t - 15*Q^2*s^3*t + 2*s^4*t - 
          Q^6*t^2 + 15*Q^4*s*t^2 - 15*Q^2*s^2*t^2 + s^3*t^2)*transverseK)/
        (Q*s*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 - 3*Q^4*s - 3*Q^2*s^2 + s^3 + Q^4*t - 12*Q^2*s*t + 3*s^2*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^10 - 3*Q^8*s - 14*Q^6*s^2 - 10*Q^4*s^3 + s^5 + 2*Q^8*t - 
          19*Q^6*s*t - 39*Q^4*s^2*t - 13*Q^2*s^3*t + 5*s^4*t + 4*Q^4*s*t^2 - 
          24*Q^2*s^2*t^2 + 4*s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t + 10*Q^4*s*t + 
          6*Q^2*s^2*t - 2*s^3*t - 2*Q^4*t^2 + 12*Q^2*s*t^2 - 2*s^2*t^2)*
         transverseK)/(Q*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 1, 5}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^8 + 2*D*Q^8 - 8*Q^6*s + D*Q^6*s + 26*Q^4*s^2 - 7*D*Q^4*s^2 + 
          40*Q^2*s^3 - 9*D*Q^2*s^3 + 14*s^4 - 3*D*s^4 - 8*Q^6*t + 2*D*Q^6*t - 
          36*Q^4*s*t + 2*D*Q^4*s*t + 4*Q^2*s^2*t - 2*D*Q^2*s^2*t + 16*s^3*t - 
          2*D*s^3*t - 24*Q^2*s*t^2 + 8*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^10 + D*Q^10 - 14*Q^8*s + 
          3*D*Q^8*s - 12*Q^6*s^2 + 2*D*Q^6*s^2 + 8*Q^4*s^3 - 2*D*Q^4*s^3 + 
          16*Q^2*s^4 - 3*D*Q^2*s^4 + 6*s^5 - D*s^5 - 8*Q^6*s*t - 
          40*Q^4*s^2*t - 24*Q^2*s^3*t + 8*s^4*t + 8*Q^4*s*t^2 - 
          48*Q^2*s^2*t^2 + 8*s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-12*Q^8*s + 3*D*Q^8*s - 
          42*Q^6*s^2 + 10*D*Q^6*s^2 - 50*Q^4*s^3 + 12*D*Q^4*s^3 - 
          22*Q^2*s^4 + 6*D*Q^2*s^4 - 2*s^5 + D*s^5 + 4*Q^8*t - D*Q^8*t + 
          14*Q^6*s*t - 2*D*Q^6*s*t - 30*Q^4*s^2*t - 38*Q^2*s^3*t + 
          2*D*Q^2*s^3*t + 2*s^4*t + D*s^4*t + 20*Q^4*s*t^2 - 40*Q^2*s^2*t^2 + 
          4*s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 6*Q^4*s + D*Q^4*s + 4*Q^2*s^2 - D*Q^2*s^2 + 
          6*s^3 - D*s^3 - 12*Q^2*s*t + 4*s^2*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^10 + 2*D*Q^10 - 
          24*Q^8*s + 5*D*Q^8*s - 14*Q^6*s^2 + 2*D*Q^6*s^2 + 18*Q^4*s^3 - 
          4*D*Q^4*s^3 + 22*Q^2*s^4 - 4*D*Q^2*s^4 + 6*s^5 - D*s^5 - 
          20*Q^6*s*t - 48*Q^4*s^2*t - 20*Q^2*s^3*t + 8*s^4*t + 8*Q^4*s*t^2 - 
          48*Q^2*s^2*t^2 + 8*s^3*t^2)*transverseK)/(Q*s*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^8 + D*Q^8 - 16*Q^6*s + 4*D*Q^6*s - 24*Q^4*s^2 + 6*D*Q^4*s^2 - 
          16*Q^2*s^3 + 4*D*Q^2*s^3 - 4*s^4 + D*s^4 - 2*Q^6*t + 10*Q^4*s*t + 
          10*Q^2*s^2*t - 2*s^3*t - 4*Q^4*t^2 + 24*Q^2*s*t^2 - 4*s^2*t^2)*
         transverseK)/(Q*(Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 4, 3}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (2*Q^8 - 7*Q^6*s - 17*Q^4*s^2 - 9*Q^2*s^3 - s^4 + 4*Q^6*t - 
           23*Q^4*s*t - 18*Q^2*s^2*t + s^3*t + 2*Q^4*t^2 - 12*Q^2*s*t^2 + 
           2*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-2 + D)*(Q^4 - 4*Q^2*s - s^2)*(-1 + SUNN)*
         (1 + SUNN)*transverseK)/(8*Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {-1, 1, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (3*Q^6*s + Q^4*s^2 - 3*Q^2*s^3 - s^4 - Q^6*t + 12*Q^4*s*t + 
           3*Q^2*s^2*t - 2*s^3*t - Q^4*t^2 + 6*Q^2*s*t^2 - s^2*t^2)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 - 3*Q^4*s - 5*Q^2*s^2 - s^3 + Q^4*t - 6*Q^2*s*t + s^2*t)*
         transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 - 5*Q^6*s - 13*Q^4*s^2 - 7*Q^2*s^3 - s^4 + 2*Q^6*t - 
          9*Q^4*s*t - 4*Q^2*s^2*t - s^3*t)*transverseK)/
        (8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> -1/8*((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*
          (Q^2 + s + 2*t)*transverseK)/(SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 4, 4}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^6*s - 8*Q^2*s^3 - 4*s^4 - 2*Q^6*t + 21*Q^4*s*t + 8*Q^2*s^2*t - 
          7*s^3*t - 2*Q^4*t^2 + 12*Q^2*s*t^2 - 2*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s - 2*s^3 - Q^4*t + 
          8*Q^2*s*t - 3*s^2*t)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^4*s^2 + 4*Q^2*s^3 - 7*Q^4*s*t + 2*Q^2*s^2*t + s^3*t + Q^4*t^2 - 
          6*Q^2*s*t^2 + s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s - 2*s^3 - Q^4*t + 
          6*Q^2*s*t - s^2*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6*s + 2*Q^4*s^2 - 
          4*Q^2*s^3 - 2*s^4 - 2*Q^6*t + 13*Q^4*s*t + 4*Q^2*s^2*t - 3*s^3*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2*s + s^2 - 4*Q^2*t + 2*s*t)*
         transverseK)/(Q*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 1, 3}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 - Q^4*s - 4*Q^2*s^2 - 
          s^3 + 4*Q^4*t - 11*Q^2*s*t - 7*s^2*t + 2*Q^2*t^2 - 6*s*t^2)*
         transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^8 + 2*Q^6*s - 2*Q^2*s^3 - s^4 + Q^6*t + Q^4*s*t - 5*Q^2*s^2*t - 
          5*s^3*t + 4*Q^2*s*t^2 - 4*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^4*s + 2*Q^2*s^2 - s^3 - 
          Q^4*t + 6*Q^2*s*t - s^2*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 - s^2 + Q^2*t - 3*s*t)*
         transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 + 3*Q^6*s - Q^4*s^2 - 
          3*Q^2*s^3 - s^4 + 2*Q^6*t - Q^4*s*t - 8*Q^2*s^2*t - 5*s^3*t + 
          4*Q^2*s*t^2 - 4*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 + 2*Q^4*s + Q^2*s^2 + 2*Q^4*t + 4*Q^2*s*t + 2*s^2*t - 
          2*Q^2*t^2 + 2*s*t^2)*transverseK)/(Q*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 1, 4}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^4*s + 8*Q^2*s^2 + 4*s^3 - 
           2*Q^4*t + 7*Q^2*s*t + 9*s^2*t - 2*Q^2*t^2 + 6*s*t^2)*transverseK)/
         (Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6*s + 6*Q^4*s^2 + 6*Q^2*s^3 + 
          2*s^4 - Q^6*t - Q^4*s*t + 5*Q^2*s^2*t + 5*s^3*t - 4*Q^2*s*t^2 + 
          4*s^2*t^2)*transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^4*s + 2*Q^2*s^2 - s^3 - Q^4*t + 6*Q^2*s*t - s^2*t)*transverseK)/
        (8*Q*s*(Q^2 + s)*SUNN*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^2*s + 2*s^2 - Q^2*t + 3*s*t)*
         transverseK)/(8*Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^6*s + 10*Q^4*s^2 + 8*Q^2*s^3 + 2*s^4 - 2*Q^6*t + Q^4*s*t + 
          8*Q^2*s^2*t + 5*s^3*t - 4*Q^2*s*t^2 + 4*s^2*t^2)*transverseK)/
        (8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s + 2*Q^2*s^2 + s^3 - 2*Q^4*t + 2*s^2*t - 2*Q^2*t^2 + 2*s*t^2)*
         transverseK)/(8*Q*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 4, 1}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (-6*Q^4*s^2 - 10*Q^2*s^3 - 4*s^4 + 2*Q^6*t + 11*Q^4*s*t - 
           2*Q^2*s^2*t - 7*s^3*t + 2*Q^4*t^2 + 8*Q^2*s*t^2 - 2*s^2*t^2)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-2*Q^2*s^2 - 2*s^3 + Q^4*t + 2*Q^2*s*t - 3*s^2*t)*transverseK)/
        (8*Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s^2 + 2*Q^2*s^3 - 
           3*Q^4*s*t + 2*Q^2*s^2*t + s^3*t - Q^4*t^2 - 4*Q^2*s*t^2 + s^2*t^2)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-2*Q^2*s^2 - 2*s^3 + Q^4*t + 4*Q^2*s*t - s^2*t)*transverseK)/
        (8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^4*s^2 - 6*Q^2*s^3 - 2*s^4 + 
          2*Q^6*t + 7*Q^4*s*t - 2*Q^2*s^2*t - 3*s^3*t)*transverseK)/
        (8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> -1/8*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
          (Q^2 + s + 2*t)*transverseK)/(Q*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 4, 2}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 + Q^6*s - Q^4*s^2 + Q^2*s^3 + s^4 + 4*Q^6*t - 11*Q^4*s*t - 
          12*Q^2*s^2*t - s^3*t + 2*Q^4*t^2 - 8*Q^2*s*t^2 - 2*s^2*t^2)*
         transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^6 + Q^4*s + Q^2*s^2 + s^3 + Q^4*t - 2*Q^2*s*t + s^2*t)*
          transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^6*s + 5*Q^4*s^2 + 3*Q^2*s^3 + s^4 - Q^6*t + 8*Q^4*s*t + 
          7*Q^2*s^2*t + 2*s^3*t - Q^4*t^2 + 4*Q^2*s*t^2 + s^2*t^2)*
         transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^6 + Q^4*s + Q^2*s^2 + s^3 + Q^4*t - 4*Q^2*s*t - s^2*t)*
          transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (2*Q^8 + 3*Q^6*s + 3*Q^4*s^2 + 3*Q^2*s^3 + s^4 + 2*Q^6*t - 
           5*Q^4*s*t - 2*Q^2*s^2*t + s^3*t)*transverseK)/
         (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t)*transverseK)/(8*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 4, 5}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (-8*Q^8 + 2*D*Q^8 - 8*Q^6*s + D*Q^6*s + 26*Q^4*s^2 - 7*D*Q^4*s^2 + 
           40*Q^2*s^3 - 9*D*Q^2*s^3 + 14*s^4 - 3*D*s^4 - 8*Q^6*t + 
           2*D*Q^6*t - 28*Q^4*s*t + 2*D*Q^4*s*t - 2*D*Q^2*s^2*t + 12*s^3*t - 
           2*D*s^3*t - 16*Q^2*s*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
          (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^4 + D*Q^4 - 
          10*Q^2*s + 2*D*Q^2*s - 6*s^2 + D*s^2 - 4*s*t)*transverseK)/
        (16*Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-12*Q^6*s + 3*D*Q^6*s - 
           30*Q^4*s^2 + 7*D*Q^4*s^2 - 20*Q^2*s^3 + 5*D*Q^2*s^3 - 2*s^4 + 
           D*s^4 + 4*Q^6*t - D*Q^6*t + 10*Q^4*s*t - D*Q^4*s*t - 4*Q^2*s^2*t + 
           D*Q^2*s^2*t - 2*s^3*t + D*s^3*t + 8*Q^2*s*t^2)*transverseK)/
         (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^6 + D*Q^6 - 6*Q^4*s + D*Q^4*s + 
          4*Q^2*s^2 - D*Q^2*s^2 + 6*s^3 - D*s^3 - 8*Q^2*s*t)*transverseK)/
        (16*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^8 + 2*D*Q^8 - 16*Q^6*s + 
          3*D*Q^6*s + 2*Q^4*s^2 - D*Q^4*s^2 + 16*Q^2*s^3 - 3*D*Q^2*s^3 + 
          6*s^4 - D*s^4 - 12*Q^4*s*t + 4*s^3*t)*transverseK)/
        (16*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^2 + D*Q^2 - 
           4*s + D*s - 2*t)*transverseK)/(Q*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {6, 1, 3}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/2)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (3*Q^2 + s + 2*t))/((Q^2 + s)*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + 2*Q^2*s + s^2 + 2*s*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-1/2*I)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*
         (1 + SUNN))/((Q^2 + s)^2*SUNN), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN), 
      GLI["V11", {0, 1, 0, 1}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^4 + 3*Q^2*s + s^2 + 2*s*t))/((Q^2 + s)^2*SUNN)|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 + Q^2*s + 2*s*t))/
        ((Q^2 + s)^2*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 1, 4}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN), 
      GLI["V11", {0, 0, 0, 1}] -> -1/2*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^4 + 2*Q^2*s + s^2 + 2*s*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {-1, 1, 0, 1}] -> -1/2*((-2 + D)*(Q^2 - s)*(-1 + SUNN)*
          (1 + SUNN)*t)/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 1, -1, 1}] -> -1/2*((-2 + D)*(-1 + SUNN)*(1 + SUNN))/
         ((Q^2 + s)*SUNN), GLI["V11", {0, 1, 0, 1}] -> 
       -1/2*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4 + 3*Q^2*s + s^2 + 2*s*t))/
         ((Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> -1/4*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
          (Q^2 + s + 2*t))/((Q^2 + s)^2*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 4, 1}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       -1/2*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*(3*Q^2 + 2*s + 2*t))/
         ((Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/(2*(Q^2 + s)*SUNN*(Q^2 + s + t)), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + t))/(2*(Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 1, -1, 1}] -> ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/
        (2*(Q^2 + s)^2*SUNN), GLI["V11", {0, 1, 0, 1}] -> 
       ((-2 + D)*s*(2*Q^2 + s)*(-1 + SUNN)*(1 + SUNN))/
        (2*(Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN))/
        (4*(Q^2 + s)*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 4, 2}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN)*(3*Q^2 + 2*s + 2*t))/
        (2*(Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V11", {0, 0, 0, 1}] -> 
       -1/2*((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)*SUNN*
          (Q^2 + s + t)), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/2*((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN)*(Q^2 + t))/
         ((Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V11", {0, 1, -1, 1}] -> 
       -1/2*((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN))/((Q^2 + s)^2*SUNN), 
      GLI["V11", {0, 1, 0, 1}] -> -1/2*((-2 + D)*Q^2*(2*Q^2 + s)*(-1 + SUNN)*
          (1 + SUNN))/((Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> -1/4*((-2 + D)*Q^2*(-1 + SUNN)*(1 + SUNN))/
         ((Q^2 + s)*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 4, 5}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^2 + s + 2*t)*
          (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 
           2*s*t))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 0, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 
          2*s*t))/(8*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {-1, 1, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (s - t)*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 
           2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, -1, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 
          2*s*t))/(8*(Q^2 + s)^2*SUNN*t), GLI["V11", {0, 1, 0, 1}] -> 
       ((-2 + D)*(2*Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^4 + D*Q^4 - 
          8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 2*s*t))/
        (8*(Q^2 + s)^2*SUNN*t)|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> 0|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 1, 1}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(6*Q^2*s^2 + 4*s^3 + 2*Q^4*t + 
           9*Q^2*s*t + 9*s^2*t + 2*Q^2*t^2 + 6*s*t^2)*transverseK)/
         (Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^2*s^2 + 2*s^3 + Q^4*t + 
          6*Q^2*s*t + 5*s^2*t + 4*s*t^2)*transverseK)/
        (8*Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^2*s^2 - Q^2*s*t - s^2*t + 
          Q^2*t^2 - s*t^2)*transverseK)/(8*Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*s^2 + Q^2*t + 3*s*t)*transverseK)/(8*Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^2*s^2 + 2*s^3 + 2*Q^4*t + 9*Q^2*s*t + 5*s^2*t + 4*s*t^2)*
         transverseK)/(8*Q*s*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2*s + s^2 + 2*Q^2*t + 2*s*t + 
          2*t^2)*transverseK)/(8*Q*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 1, 2}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (2*Q^6 - Q^4*s + s^3 + 4*Q^4*t + 9*Q^2*s*t + 7*s^2*t + 2*Q^2*t^2 + 
           6*s*t^2)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6 + Q^4*s + Q^2*s^2 + s^3 + Q^4*t + 6*Q^2*s*t + 5*s^2*t + 
          4*s*t^2)*transverseK)/(8*Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (3*Q^4*s + 2*Q^2*s^2 + s^3 - Q^4*t + Q^2*s*t + 2*s^2*t - Q^2*t^2 + 
           s*t^2)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4 + s^2 + Q^2*t + 3*s*t)*transverseK)/(8*Q*s*SUNN*t*
         (Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 + Q^4*s + 2*Q^2*s^2 + s^3 + 
          2*Q^4*t + 9*Q^2*s*t + 5*s^2*t + 4*s*t^2)*transverseK)/
        (8*Q*s*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (Q^4 + Q^2*s - 2*Q^2*t - 2*s*t - 2*t^2)*transverseK)/
         (Q*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 1, 5}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^6 + 2*D*Q^6 - D*Q^4*s + 
          26*Q^2*s^2 - 6*D*Q^2*s^2 + 14*s^3 - 3*D*s^3 - 8*Q^4*t + 2*D*Q^4*t + 
          4*Q^2*s*t + 16*s^2*t - 2*D*s^2*t + 8*s*t^2)*transverseK)/
        (16*Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^6 + D*Q^6 - 6*Q^4*s + 
           D*Q^4*s + 4*Q^2*s^2 - D*Q^2*s^2 + 6*s^3 - D*s^3 + 8*Q^2*s*t + 
           8*s^2*t + 8*s*t^2)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-12*Q^4*s + 3*D*Q^4*s - 18*Q^2*s^2 + 4*D*Q^2*s^2 - 2*s^3 + D*s^3 + 
          4*Q^4*t - D*Q^4*t + 6*Q^2*s*t + 2*s^2*t + D*s^2*t + 4*s*t^2)*
         transverseK)/(16*Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (-4*Q^4 + D*Q^4 - 2*Q^2*s + 6*s^2 - D*s^2 + 4*s*t)*transverseK)/
         (Q*s*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^6 + 2*D*Q^6 - 8*Q^4*s + 
           D*Q^4*s + 10*Q^2*s^2 - 2*D*Q^2*s^2 + 6*s^3 - D*s^3 + 12*Q^2*s*t + 
           8*s^2*t + 8*s*t^2)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 
          2*D*Q^2*s - 4*s^2 + D*s^2 - 2*Q^2*t - 2*s*t - 4*t^2)*transverseK)/
        (16*Q*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 4, 3}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^4 - 3*Q^2*s - s^2 + 4*Q^2*t + s*t + 2*t^2)*transverseK)/
        (Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 + Q^4*s - Q^2*s^2 - s^3 + 
          Q^4*t + 4*Q^2*s*t - s^2*t)*transverseK)/(Q*s*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^2*s - s^2 - Q^2*t - 
          s*t)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, -1, 1}] -> ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)*
         (1 + SUNN)*(Q^2 - s + t)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6 + Q^4*s - 2*Q^2*s^2 - s^3 + 2*Q^4*t + 5*Q^2*s*t - s^2*t)*
         transverseK)/(Q*s*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*(Q^2 + s - 2*t)*
         transverseK)/(SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 4, 4}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*(4*Q^2*s + 4*s^2 + 
          2*Q^2*t + 7*s*t + 2*t^2)*transverseK)/(8*Q*s*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s + 4*Q^2*s^2 + 2*s^3 + 
           Q^4*t + 3*s^2*t)*transverseK)/(Q*s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (5*Q^2*s + s^2 + Q^2*t + s*t)*transverseK)/
         (Q*s*SUNN*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)*(1 + SUNN)*(2*s + t)*transverseK)/
         (Q*s*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^4*s + 6*Q^2*s^2 + 2*s^3 + 
           2*Q^4*t + Q^2*s*t + 3*s^2*t)*transverseK)/
         (Q*s*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> -1/8*((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
          (Q^2 + s + 2*t)*transverseK)/(Q*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 1, 3}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          (2*Q^6 - 9*Q^4*s - 8*Q^2*s^2 - s^3 + 4*Q^4*t - 11*Q^2*s*t - 
           7*s^2*t + 2*Q^2*t^2 - 6*s*t^2)*transverseK)/
         (Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - 3*Q^4*s - 5*Q^2*s^2 - s^3 + 
          4*Q^2*s*t - 4*s^2*t)*transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^6*s + Q^4*s^2 - 3*Q^2*s^3 - 
           s^4 - Q^6*t + 4*Q^4*s*t + 3*Q^2*s^2*t - 2*s^3*t - Q^4*t^2 + 
           6*Q^2*s*t^2 - s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
          (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 - 4*Q^2*s - s^2 + Q^2*t - 3*s*t)*
         transverseK)/(8*Q*s*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 - 5*Q^6*s - 13*Q^4*s^2 - 7*Q^2*s^3 - s^4 + 2*Q^6*t - 
          Q^4*s*t - 8*Q^2*s^2*t - 5*s^3*t + 4*Q^2*s*t^2 - 4*s^2*t^2)*
         transverseK)/(8*Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 + 2*Q^4*s + Q^2*s^2 - 
           2*Q^4*t + 2*s^2*t - 2*Q^2*t^2 + 2*s*t^2)*transverseK)/
         (Q*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 1, 4}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^4*s - 4*Q^2*s^2 - 4*s^3 + 
          2*Q^4*t - 7*Q^2*s*t - 9*s^2*t + 2*Q^2*t^2 - 6*s*t^2)*transverseK)/
        (Q*s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6*s + 2*Q^4*s^2 - 
          2*Q^2*s^3 - 2*s^4 + Q^6*t + Q^4*s*t - 5*Q^2*s^2*t - 5*s^3*t + 
          4*Q^2*s*t^2 - 4*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^4*s^2 + 4*Q^2*s^3 + 
          7*Q^4*s*t + 6*Q^2*s^2*t - s^3*t - Q^4*t^2 + 6*Q^2*s*t^2 - s^2*t^2)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^2*s - 2*s^2 + Q^2*t - 3*s*t)*transverseK)/
        (Q*s*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6*s + 2*Q^4*s^2 - 
          4*Q^2*s^3 - 2*s^4 + 2*Q^6*t - Q^4*s*t - 8*Q^2*s^2*t - 5*s^3*t + 
          4*Q^2*s*t^2 - 4*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s + 2*Q^2*s^2 + s^3 + 2*Q^4*t + 4*Q^2*s*t + 2*s^2*t - 
          2*Q^2*t^2 + 2*s*t^2)*transverseK)/(Q*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 4, 1}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(8*Q^6*s + 6*Q^4*s^2 - 
          6*Q^2*s^3 - 4*s^4 + 2*Q^6*t - 5*Q^4*s*t - 10*Q^2*s^2*t - 7*s^3*t + 
          2*Q^4*t^2 - 8*Q^2*s*t^2 - 2*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(4*Q^6*s + 6*Q^4*s^2 - 2*s^4 + 
          Q^6*t - 5*Q^4*s*t + 7*Q^2*s^2*t - 3*s^3*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(6*Q^4*s^2 + 6*Q^2*s^3 + 
          Q^4*s*t + 14*Q^2*s^2*t + s^3*t - Q^4*t^2 + 4*Q^2*s*t^2 + s^2*t^2)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (4*Q^4*s + 2*Q^2*s^2 - 2*s^3 + Q^4*t - 4*Q^2*s*t - s^2*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (8*Q^6*s + 8*Q^4*s^2 - 2*Q^2*s^3 - 2*s^4 + 2*Q^6*t - 9*Q^4*s*t + 
          6*Q^2*s^2*t - 3*s^3*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s + 2*Q^2*s^2 + s^3 + 4*Q^4*t - 2*Q^2*s*t + 2*s^2*t)*
         transverseK)/(Q*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 4, 2}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 - 7*Q^6*s - 13*Q^4*s^2 - 3*Q^2*s^3 + s^4 + 4*Q^6*t + 
          5*Q^4*s*t - 4*Q^2*s^2*t - s^3*t + 2*Q^4*t^2 + 8*Q^2*s*t^2 - 
          2*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^8 - 2*Q^6*s - 6*Q^4*s^2 - 2*Q^2*s^3 + s^4 + Q^6*t + 7*Q^4*s*t - 
          9*Q^2*s^2*t + s^3*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(3*Q^6*s + Q^4*s^2 - Q^2*s^3 + 
          s^4 - Q^6*t + 4*Q^4*s*t - 5*Q^2*s^2*t + 2*s^3*t - Q^4*t^2 - 
          4*Q^2*s*t^2 + s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 - 3*Q^4*s - 3*Q^2*s^2 + 
          s^3 + Q^4*t + 4*Q^2*s*t - s^2*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 - 5*Q^6*s - 
          9*Q^4*s^2 - Q^2*s^3 + s^4 + 2*Q^6*t + 11*Q^4*s*t - 10*Q^2*s^2*t + 
          s^3*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*(Q^4 + 2*Q^2*s + s^2 - 
          2*Q^2*t + 6*s*t)*transverseK)/((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 4, 5}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^8 + 2*D*Q^8 - 8*Q^6*s + D*Q^6*s + 26*Q^4*s^2 - 7*D*Q^4*s^2 + 
          40*Q^2*s^3 - 9*D*Q^2*s^3 + 14*s^4 - 3*D*s^4 - 8*Q^6*t + 2*D*Q^6*t + 
          4*Q^4*s*t + 2*D*Q^4*s*t + 16*Q^2*s^2*t - 2*D*Q^2*s^2*t + 12*s^3*t - 
          2*D*s^3*t + 16*Q^2*s*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/16)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 14*Q^4*s + 3*D*Q^4*s - 16*Q^2*s^2 + 3*D*Q^2*s^2 - 
          6*s^3 + D*s^3 + 12*Q^2*s*t - 4*s^2*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-12*Q^6*s + 3*D*Q^6*s - 
          30*Q^4*s^2 + 7*D*Q^4*s^2 - 20*Q^2*s^3 + 5*D*Q^2*s^3 - 2*s^4 + 
          D*s^4 + 4*Q^6*t - D*Q^6*t + 10*Q^4*s*t - D*Q^4*s*t - 20*Q^2*s^2*t + 
          D*Q^2*s^2*t - 2*s^3*t + D*s^3*t - 8*Q^2*s*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^6 + D*Q^6 - 6*Q^4*s + 
          D*Q^4*s + 4*Q^2*s^2 - D*Q^2*s^2 + 6*s^3 - D*s^3 + 8*Q^2*s*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^8 + 2*D*Q^8 - 16*Q^6*s + 3*D*Q^6*s + 2*Q^4*s^2 - D*Q^4*s^2 + 
          16*Q^2*s^3 - 3*D*Q^2*s^3 + 6*s^4 - D*s^4 + 20*Q^4*s*t - 
          16*Q^2*s^2*t + 4*s^3*t)*transverseK)/(Q*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-4*Q^6 + D*Q^6 - 12*Q^4*s + 3*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 
          4*s^3 + D*s^3 - 2*Q^4*t + 12*Q^2*s*t - 2*s^2*t)*transverseK)/
        (Q*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 1, 3}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6 + 3*Q^4*s + Q^2*s^2 + 
           6*Q^4*t + 4*Q^2*s*t + 8*Q^2*t^2 + 4*s*t^2 + 4*t^3))/
         ((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + 
          Q^2*s^3 + 2*Q^6*t + 6*Q^4*s*t + 6*Q^2*s^2*t + 2*s^3*t + 2*Q^4*t^2 + 
          8*Q^2*s*t^2 + 6*s^2*t^2 + 4*s*t^3))/(4*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2*s + s^2 - Q^2*t + s*t)*
          (Q^4 + Q^2*s + 2*Q^2*t + 2*s*t + 2*t^2))/((Q^2 + s)^2*SUNN*t*
          (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4 + Q^2*s + 2*Q^2*t + 2*t^2))/
        (4*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^8 + 5*Q^6*s + 4*Q^4*s^2 + 
          Q^2*s^3 + 4*Q^6*t + 8*Q^4*s*t + 6*Q^2*s^2*t + 2*s^3*t + 4*Q^4*t^2 + 
          10*Q^2*s*t^2 + 6*s^2*t^2 + 4*s*t^3))/(4*(Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-2 + D)*s*(-1 + SUNN)*(1 + SUNN)*
         (Q^2 + s + 2*t))/(4*(Q^2 + s)^2*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 1, 4}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^4*s + 3*Q^2*s^2 + s^3 + 
          6*Q^2*s*t + 4*s^2*t + 6*Q^2*t^2 + 6*s*t^2 + 4*t^3))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6*s + 3*Q^4*s^2 + 
          3*Q^2*s^3 + s^4 + 4*Q^4*s*t + 8*Q^2*s^2*t + 4*s^3*t + 2*Q^4*t^2 + 
          8*Q^2*s*t^2 + 6*s^2*t^2 + 4*s*t^3))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2*s + s^2 - Q^2*t + s*t)*
         (Q^2*s + s^2 + 2*Q^2*t + 2*s*t + 2*t^2))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^2*s + s^2 + 2*s*t + 
          2*t^2))/((Q^2 + s)*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^6*s + 5*Q^4*s^2 + 4*Q^2*s^3 + s^4 + 6*Q^4*s*t + 10*Q^2*s^2*t + 
          4*s^3*t + 4*Q^4*t^2 + 10*Q^2*s*t^2 + 6*s^2*t^2 + 4*s*t^3))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s + 2*Q^2*s^2 + s^3 + Q^4*t + 3*Q^2*s*t + 2*s^2*t + 2*s*t^2))/
        ((Q^2 + s)^2*SUNN*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 4, 1}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6*s + 5*Q^4*s^2 + 
          4*Q^2*s^3 + s^4 + 6*Q^4*s*t + 10*Q^2*s^2*t + 4*s^3*t + 6*Q^4*t^2 + 
          8*Q^2*s*t^2 + 4*s^2*t^2 + 4*Q^2*t^3))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6*s + 3*Q^4*s^2 + 
          3*Q^2*s^3 + s^4 + 4*Q^2*s^2*t + 4*s^3*t + 2*Q^4*t^2 - 2*Q^2*s*t^2 + 
          4*s^2*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^4*s^2 + 2*Q^2*s^3 + s^4 - 3*Q^4*s*t + 3*s^3*t - 2*Q^4*t^2 - 
          6*Q^2*s*t^2 + 2*s^2*t^2 - 2*Q^2*t^3))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4*s + 2*Q^2*s^2 + s^3 + 
          2*Q^2*s*t + 2*s^2*t + 2*Q^2*t^2))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(2*Q^6*s + 5*Q^4*s^2 + 
          4*Q^2*s^3 + s^4 + 2*Q^4*s*t + 6*Q^2*s^2*t + 4*s^3*t + 4*Q^4*t^2 - 
          2*Q^2*s*t^2 + 4*s^2*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^4*s - s^3 - Q^4*t + 
          Q^2*s*t - 2*s^2*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 4, 2}, "Coefficients" -> 
     <|GLI["V11", {0, 1, 0, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 + 5*Q^6*s + 4*Q^4*s^2 + Q^2*s^3 + 6*Q^6*t + 10*Q^4*s*t + 
          4*Q^2*s^2*t + 4*Q^4*t^2 + 10*Q^2*s*t^2 + 4*s^2*t^2 + 4*s*t^3))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + 
          Q^2*s^3 + 2*Q^6*t + 6*Q^4*s*t + 2*Q^2*s^2*t - 2*s^3*t + 
          6*Q^2*s*t^2 - 2*s^2*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (Q^6*s + 2*Q^4*s^2 + Q^2*s^3 - Q^6*t + 2*Q^4*s*t + Q^2*s^2*t - 
          2*s^3*t - 2*Q^4*t^2 - 4*s^2*t^2 - 2*s*t^3))/((Q^2 + s)^2*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(Q^6 + 2*Q^4*s + Q^2*s^2 + 
          2*Q^4*t + 2*Q^2*s*t + 2*s*t^2))/((Q^2 + s)^2*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (2*Q^8 + 5*Q^6*s + 4*Q^4*s^2 + Q^2*s^3 + 4*Q^6*t + 8*Q^4*s*t + 
          2*Q^2*s^2*t - 2*s^3*t + 8*Q^2*s*t^2 - 2*s^2*t^2))/
        ((Q^2 + s)^2*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*s*(-1 + SUNN)*
         (1 + SUNN)*(Q^4 - s^2 + 3*Q^2*t - s*t))/((Q^2 + s)^2*SUNN*
         (Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 4, 5}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-16*Q^6 + 4*D*Q^6 - 
          44*Q^4*s + 11*D*Q^4*s - 40*Q^2*s^2 + 10*D*Q^2*s^2 - 12*s^3 + 
          3*D*s^3 - 12*Q^4*t + 2*D*Q^4*t - 14*Q^2*s*t + 4*D*Q^2*s*t - 
          6*s^2*t + 2*D*s^2*t - 4*Q^2*t^2 + 4*s*t^2))/((Q^2 + s)^2*SUNN*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^6 + D*Q^6 - 8*Q^4*s + 
          3*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 8*s^3 + D*s^3 - 2*Q^4*t + 
          8*Q^2*s*t - 6*s^2*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)^2), 
      GLI["V11", {-1, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         (-8*Q^6 + 2*D*Q^6 - 24*Q^4*s + 5*D*Q^4*s - 16*Q^2*s^2 + 
          4*D*Q^2*s^2 + D*s^3 - 4*Q^4*t + D*Q^4*t - 14*Q^2*s*t + 
          2*D*Q^2*s*t + 2*s^2*t + D*s^2*t - 2*Q^2*t^2 + 2*s*t^2))/
        ((Q^2 + s)^2*SUNN*(Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 
          2*D*Q^2*s - 4*s^2 + D*s^2 - 2*Q^2*t + 2*s*t))/
        ((Q^2 + s)^2*SUNN*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^6 + 2*D*Q^6 - 16*Q^4*s + 
          5*D*Q^4*s - 16*Q^2*s^2 + 4*D*Q^2*s^2 - 8*s^3 + D*s^3 - 4*Q^4*t + 
          10*Q^2*s*t - 6*s^2*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-4*Q^6 + D*Q^6 - 10*Q^4*s + 
          3*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 6*s^3 + D*s^3 + 4*Q^2*s*t - 
          4*s^2*t))/((Q^2 + s)^2*SUNN*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonMetricD", "Index" -> {}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((16*I)*Q^6 - (4*I)*D*Q^6 - 
          (48*I)*eIn*Q^6 + (20*I)*D*eIn*Q^6 - (2*I)*D^2*eIn*Q^6 - 
          (16*I)*hIn*hOut*Q^6 + (4*I)*D*hIn*hOut*Q^6 + (32*I)*Q^4*s - 
          (6*I)*D*Q^4*s - (120*I)*eIn*Q^4*s + (50*I)*D*eIn*Q^4*s - 
          (5*I)*D^2*eIn*Q^4*s - (32*I)*hIn*hOut*Q^4*s + (6*I)*D*hIn*hOut*Q^4*
           s + (20*I)*Q^2*s^2 - (2*I)*D*Q^2*s^2 - (96*I)*eIn*Q^2*s^2 + 
          (40*I)*D*eIn*Q^2*s^2 - (4*I)*D^2*eIn*Q^2*s^2 - (20*I)*hIn*hOut*Q^2*
           s^2 + (2*I)*D*hIn*hOut*Q^2*s^2 + (4*I)*s^3 - (24*I)*eIn*s^3 + 
          (10*I)*D*eIn*s^3 - I*D^2*eIn*s^3 - (4*I)*hIn*hOut*s^3 - 
          (8*I)*Q^4*t + (4*I)*D*Q^4*t - (32*I)*eIn*Q^4*t + 
          (8*I)*D*eIn*Q^4*t + (8*I)*hIn*hOut*Q^4*t - (4*I)*D*hIn*hOut*Q^4*t + 
          (4*I)*Q^2*s*t - (2*I)*D*Q^2*s*t - (72*I)*eIn*Q^2*s*t + 
          (22*I)*D*eIn*Q^2*s*t + (12*I)*hIn*hOut*Q^2*s*t - 
          (6*I)*D*hIn*hOut*Q^2*s*t + (4*I)*s^2*t - (2*I)*D*s^2*t - 
          (32*I)*eIn*s^2*t + (10*I)*D*eIn*s^2*t + (4*I)*hIn*hOut*s^2*t - 
          (2*I)*D*hIn*hOut*s^2*t - (24*I)*Q^2*t^2 + (4*I)*D*Q^2*t^2 + 
          (8*I)*eIn*Q^2*t^2 + (24*I)*hIn*hOut*Q^2*t^2 - (4*I)*D*hIn*hOut*Q^2*
           t^2 - (4*I)*s*t^2 - (4*I)*D*s*t^2 - (12*I)*eIn*s*t^2 + 
          (8*I)*D*eIn*s*t^2 + (20*I)*hIn*hOut*s*t^2 - (4*I)*D*hIn*hOut*s*
           t^2 - (8*I)*t^3 + (8*I)*eIn*t^3 + (8*I)*hIn*hOut*t^3 - 
          (8*I)*Q^6*xIn - (28*I)*Q^4*s*xIn + (4*I)*D*Q^4*s*xIn - 
          (28*I)*Q^2*s^2*xIn + (6*I)*D*Q^2*s^2*xIn - (8*I)*s^3*xIn + 
          (2*I)*D*s^3*xIn - (32*I)*Q^4*t*xIn + (4*I)*D*Q^4*t*xIn - 
          (36*I)*Q^2*s*t*xIn - (2*I)*D*Q^2*s*t*xIn - (12*I)*s^2*t*xIn - 
          (2*I)*D*s^2*t*xIn - (32*I)*Q^2*t^2*xIn + (4*I)*D*Q^2*t^2*xIn - 
          (12*I)*s*t^2*xIn - (4*I)*D*s*t^2*xIn - (8*I)*t^3*xIn + 
          8*hOut*Q^6*yIn + 28*hOut*Q^4*s*yIn - 4*D*hOut*Q^4*s*yIn + 
          28*hOut*Q^2*s^2*yIn - 6*D*hOut*Q^2*s^2*yIn + 8*hOut*s^3*yIn - 
          2*D*hOut*s^3*yIn + 4*D*hOut*Q^4*t*yIn + 4*hOut*Q^2*s*t*yIn + 
          6*D*hOut*Q^2*s*t*yIn + 4*hOut*s^2*t*yIn + 2*D*hOut*s^2*t*yIn - 
          16*hOut*Q^2*t^2*yIn + 4*D*hOut*Q^2*t^2*yIn - 12*hOut*s*t^2*yIn + 
          4*D*hOut*s*t^2*yIn - 8*hOut*t^3*yIn))/(8*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((-8*I)*Q^6 + (2*I)*D*Q^6 + 
          (24*I)*eIn*Q^6 - (10*I)*D*eIn*Q^6 + I*D^2*eIn*Q^6 + 
          (8*I)*hIn*hOut*Q^6 - (2*I)*D*hIn*hOut*Q^6 - (20*I)*Q^4*s + 
          (4*I)*D*Q^4*s + (72*I)*eIn*Q^4*s - (30*I)*D*eIn*Q^4*s + 
          (3*I)*D^2*eIn*Q^4*s + (20*I)*hIn*hOut*Q^4*s - (4*I)*D*hIn*hOut*Q^4*
           s - (16*I)*Q^2*s^2 + (2*I)*D*Q^2*s^2 + (72*I)*eIn*Q^2*s^2 - 
          (30*I)*D*eIn*Q^2*s^2 + (3*I)*D^2*eIn*Q^2*s^2 + (16*I)*hIn*hOut*Q^2*
           s^2 - (2*I)*D*hIn*hOut*Q^2*s^2 - (4*I)*s^3 + (24*I)*eIn*s^3 - 
          (10*I)*D*eIn*s^3 + I*D^2*eIn*s^3 + (4*I)*hIn*hOut*s^3 + 
          (4*I)*Q^4*t - (2*I)*D*Q^4*t + (8*I)*eIn*Q^4*t - (2*I)*D*eIn*Q^4*t - 
          (4*I)*hIn*hOut*Q^4*t + (2*I)*D*hIn*hOut*Q^4*t - (8*I)*Q^2*s*t + 
          (4*I)*D*Q^2*s*t + (32*I)*eIn*Q^2*s*t - (12*I)*D*eIn*Q^2*s*t + 
          (16*I)*hIn*hOut*Q^2*s*t + (4*I)*s^2*t - (2*I)*D*s^2*t + 
          (8*I)*eIn*s^2*t - (2*I)*D*eIn*s^2*t + (20*I)*hIn*hOut*s^2*t - 
          (2*I)*D*hIn*hOut*s^2*t + (4*I)*Q^2*t^2 - (4*I)*eIn*Q^2*t^2 - 
          (4*I)*hIn*hOut*Q^2*t^2 + (4*I)*s*t^2 - (4*I)*eIn*s*t^2 + 
          (12*I)*hIn*hOut*s*t^2 + (4*I)*Q^6*xIn + (16*I)*Q^4*s*xIn - 
          (2*I)*D*Q^4*s*xIn + (20*I)*Q^2*s^2*xIn - (4*I)*D*Q^2*s^2*xIn + 
          (8*I)*s^3*xIn - (2*I)*D*s^3*xIn + (12*I)*Q^4*t*xIn - 
          (2*I)*D*Q^4*t*xIn + (8*I)*Q^2*s*t*xIn + (4*I)*D*Q^2*s*t*xIn + 
          (12*I)*s^2*t*xIn - (2*I)*D*s^2*t*xIn + (4*I)*Q^2*t^2*xIn + 
          (4*I)*s*t^2*xIn - 4*hOut*Q^6*yIn - 16*hOut*Q^4*s*yIn + 
          2*D*hOut*Q^4*s*yIn - 20*hOut*Q^2*s^2*yIn + 4*D*hOut*Q^2*s^2*yIn - 
          8*hOut*s^3*yIn + 2*D*hOut*s^3*yIn + 4*hOut*Q^4*t*yIn - 
          2*D*hOut*Q^4*t*yIn - 16*hOut*Q^2*s*t*yIn - 20*hOut*s^2*t*yIn + 
          2*D*hOut*s^2*t*yIn + 4*hOut*Q^2*t^2*yIn - 12*hOut*s*t^2*yIn))/
        (8*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((8*I)*Q^4*s - (2*I)*D*Q^4*s - 
          (24*I)*eIn*Q^4*s + (10*I)*D*eIn*Q^4*s - I*D^2*eIn*Q^4*s - 
          (8*I)*hIn*hOut*Q^4*s + (2*I)*D*hIn*hOut*Q^4*s + (12*I)*Q^2*s^2 - 
          (2*I)*D*Q^2*s^2 - (48*I)*eIn*Q^2*s^2 + (20*I)*D*eIn*Q^2*s^2 - 
          (2*I)*D^2*eIn*Q^2*s^2 - (12*I)*hIn*hOut*Q^2*s^2 + 
          (2*I)*D*hIn*hOut*Q^2*s^2 + (4*I)*s^3 - (24*I)*eIn*s^3 + 
          (10*I)*D*eIn*s^3 - I*D^2*eIn*s^3 - (4*I)*hIn*hOut*s^3 + 
          (8*I)*Q^4*t - (2*I)*D*Q^4*t - (8*I)*eIn*Q^4*t + (6*I)*D*eIn*Q^4*t - 
          I*D^2*eIn*Q^4*t - (8*I)*hIn*hOut*Q^4*t + (2*I)*D*hIn*hOut*Q^4*t + 
          (16*I)*Q^2*s*t - (4*I)*D*Q^2*s*t - (32*I)*eIn*Q^2*s*t + 
          (18*I)*D*eIn*Q^2*s*t - (2*I)*D^2*eIn*Q^2*s*t - (32*I)*hIn*hOut*Q^2*
           s*t + (4*I)*D*hIn*hOut*Q^2*s*t + (2*I)*D*s^2*t - 
          (16*I)*eIn*s^2*t + (8*I)*D*eIn*s^2*t - I*D^2*eIn*s^2*t - 
          (24*I)*hIn*hOut*s^2*t + (2*I)*D*hIn*hOut*s^2*t + (12*I)*Q^2*t^2 - 
          (2*I)*D*Q^2*t^2 - (8*I)*eIn*Q^2*t^2 + (2*I)*D*eIn*Q^2*t^2 - 
          (12*I)*hIn*hOut*Q^2*t^2 + (2*I)*D*hIn*hOut*Q^2*t^2 + 
          (2*I)*D*s*t^2 + (4*I)*eIn*s*t^2 - (2*I)*D*eIn*s*t^2 - 
          (24*I)*hIn*hOut*s*t^2 + (2*I)*D*hIn*hOut*s*t^2 + (4*I)*t^3 - 
          (4*I)*eIn*t^3 - (4*I)*hIn*hOut*t^3 - (4*I)*Q^4*s*xIn - 
          (12*I)*Q^2*s^2*xIn + (2*I)*D*Q^2*s^2*xIn - (8*I)*s^3*xIn + 
          (2*I)*D*s^3*xIn + (4*I)*Q^4*t*xIn - (12*I)*s^2*t*xIn + 
          (4*I)*D*s^2*t*xIn + (12*I)*Q^2*t^2*xIn - (2*I)*D*Q^2*t^2*xIn + 
          (2*I)*D*s*t^2*xIn + (4*I)*t^3*xIn + 4*hOut*Q^4*s*yIn + 
          12*hOut*Q^2*s^2*yIn - 2*D*hOut*Q^2*s^2*yIn + 8*hOut*s^3*yIn - 
          2*D*hOut*s^3*yIn - 4*hOut*Q^4*t*yIn + 16*hOut*Q^2*s*t*yIn - 
          4*D*hOut*Q^2*s*t*yIn + 20*hOut*s^2*t*yIn - 4*D*hOut*s^2*t*yIn + 
          4*hOut*Q^2*t^2*yIn - 2*D*hOut*Q^2*t^2*yIn + 16*hOut*s*t^2*yIn - 
          2*D*hOut*s*t^2*yIn + 4*hOut*t^3*yIn))/(8*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 1, -1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((-8*I)*Q^4 + (2*I)*D*Q^4 + 
          (24*I)*eIn*Q^4 - (10*I)*D*eIn*Q^4 + I*D^2*eIn*Q^4 + 
          (8*I)*hIn*hOut*Q^4 - (2*I)*D*hIn*hOut*Q^4 - (12*I)*Q^2*s + 
          (2*I)*D*Q^2*s + (48*I)*eIn*Q^2*s - (20*I)*D*eIn*Q^2*s + 
          (2*I)*D^2*eIn*Q^2*s + (12*I)*hIn*hOut*Q^2*s - (2*I)*D*hIn*hOut*Q^2*
           s - (4*I)*s^2 + (24*I)*eIn*s^2 - (10*I)*D*eIn*s^2 + 
          I*D^2*eIn*s^2 + (4*I)*hIn*hOut*s^2 + (4*I)*Q^2*t - (2*I)*D*Q^2*t + 
          (8*I)*eIn*Q^2*t - (2*I)*D*eIn*Q^2*t - (4*I)*hIn*hOut*Q^2*t + 
          (2*I)*D*hIn*hOut*Q^2*t - (4*I)*s*t + (2*I)*D*s*t + (16*I)*eIn*s*t - 
          (6*I)*D*eIn*s*t - (4*I)*hIn*hOut*s*t + (2*I)*D*hIn*hOut*s*t + 
          (4*I)*t^2 - (4*I)*eIn*t^2 - (4*I)*hIn*hOut*t^2 + (4*I)*Q^4*xIn + 
          (12*I)*Q^2*s*xIn - (2*I)*D*Q^2*s*xIn + (8*I)*s^2*xIn - 
          (2*I)*D*s^2*xIn + (12*I)*Q^2*t*xIn - (2*I)*D*Q^2*t*xIn + 
          (4*I)*s*t*xIn + (2*I)*D*s*t*xIn + (4*I)*t^2*xIn - 4*hOut*Q^4*yIn - 
          12*hOut*Q^2*s*yIn + 2*D*hOut*Q^2*s*yIn - 8*hOut*s^2*yIn + 
          2*D*hOut*s^2*yIn + 4*hOut*Q^2*t*yIn - 2*D*hOut*Q^2*t*yIn + 
          4*hOut*s*t*yIn - 2*D*hOut*s*t*yIn + 4*hOut*t^2*yIn))/
        (8*(Q^2 + s)*SUNN*t*(Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*((-16*I)*Q^6 + (4*I)*D*Q^6 + 
          (48*I)*eIn*Q^6 - (20*I)*D*eIn*Q^6 + (2*I)*D^2*eIn*Q^6 + 
          (16*I)*hIn*hOut*Q^6 - (4*I)*D*hIn*hOut*Q^6 - (32*I)*Q^4*s + 
          (6*I)*D*Q^4*s + (120*I)*eIn*Q^4*s - (50*I)*D*eIn*Q^4*s + 
          (5*I)*D^2*eIn*Q^4*s + (32*I)*hIn*hOut*Q^4*s - (6*I)*D*hIn*hOut*Q^4*
           s - (20*I)*Q^2*s^2 + (2*I)*D*Q^2*s^2 + (96*I)*eIn*Q^2*s^2 - 
          (40*I)*D*eIn*Q^2*s^2 + (4*I)*D^2*eIn*Q^2*s^2 + (20*I)*hIn*hOut*Q^2*
           s^2 - (2*I)*D*hIn*hOut*Q^2*s^2 - (4*I)*s^3 + (24*I)*eIn*s^3 - 
          (10*I)*D*eIn*s^3 + I*D^2*eIn*s^3 + (4*I)*hIn*hOut*s^3 + 
          (8*I)*Q^4*t - (4*I)*D*Q^4*t + (16*I)*eIn*Q^4*t - 
          (4*I)*D*eIn*Q^4*t - (8*I)*hIn*hOut*Q^4*t + (4*I)*D*hIn*hOut*Q^4*t - 
          (12*I)*Q^2*s*t + (6*I)*D*Q^2*s*t + (48*I)*eIn*Q^2*s*t - 
          (18*I)*D*eIn*Q^2*s*t + (12*I)*hIn*hOut*Q^2*s*t + 
          (2*I)*D*hIn*hOut*Q^2*s*t + (4*I)*s^2*t - (2*I)*D*s^2*t + 
          (8*I)*eIn*s^2*t - (2*I)*D*eIn*s^2*t + (20*I)*hIn*hOut*s^2*t - 
          (2*I)*D*hIn*hOut*s^2*t + (8*I)*Q^2*t^2 - (8*I)*eIn*Q^2*t^2 - 
          (8*I)*hIn*hOut*Q^2*t^2 + (4*I)*s*t^2 - (4*I)*eIn*s*t^2 + 
          (12*I)*hIn*hOut*s*t^2 + (8*I)*Q^6*xIn + (28*I)*Q^4*s*xIn - 
          (4*I)*D*Q^4*s*xIn + (28*I)*Q^2*s^2*xIn - (6*I)*D*Q^2*s^2*xIn + 
          (8*I)*s^3*xIn - (2*I)*D*s^3*xIn + (24*I)*Q^4*t*xIn - 
          (4*I)*D*Q^4*t*xIn + (12*I)*Q^2*s*t*xIn + (6*I)*D*Q^2*s*t*xIn + 
          (12*I)*s^2*t*xIn - (2*I)*D*s^2*t*xIn + (8*I)*Q^2*t^2*xIn + 
          (4*I)*s*t^2*xIn - 8*hOut*Q^6*yIn - 28*hOut*Q^4*s*yIn + 
          4*D*hOut*Q^4*s*yIn - 28*hOut*Q^2*s^2*yIn + 6*D*hOut*Q^2*s^2*yIn - 
          8*hOut*s^3*yIn + 2*D*hOut*s^3*yIn + 8*hOut*Q^4*t*yIn - 
          4*D*hOut*Q^4*t*yIn - 12*hOut*Q^2*s*t*yIn - 2*D*hOut*Q^2*s*t*yIn - 
          20*hOut*s^2*t*yIn + 2*D*hOut*s^2*t*yIn + 8*hOut*Q^2*t^2*yIn - 
          12*hOut*s*t^2*yIn))/(8*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*(-8*Q^4 + 2*D*Q^4 + 
          16*eIn*Q^4 - 8*D*eIn*Q^4 + D^2*eIn*Q^4 + 8*hIn*hOut*Q^4 - 
          2*D*hIn*hOut*Q^4 - 8*Q^2*s + 28*eIn*Q^2*s - 14*D*eIn*Q^2*s + 
          2*D^2*eIn*Q^2*s - 8*s^2 + 2*D*s^2 + 20*eIn*s^2 - 10*D*eIn*s^2 + 
          D^2*eIn*s^2 - 8*hIn*hOut*s^2 + 2*D*hIn*hOut*s^2 - 4*Q^2*t + 
          8*eIn*Q^2*t - 2*D*eIn*Q^2*t + 4*hIn*hOut*Q^2*t - 4*s*t + 
          8*eIn*s*t - 2*D*eIn*s*t - 4*hIn*hOut*s*t + 8*Q^2*s*xIn - 
          4*D*Q^2*s*xIn - (8*I)*hOut*Q^2*s*yIn - (8*I)*hOut*s^2*yIn - 
          (8*I)*hOut*s*t*yIn))/((Q^2 + s)*SUNN*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonWardLeft", "Index" -> {1}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*((-2*I)*Q^4 + (2*I)*hIn*hOut*Q^4 - 
          (9*I)*Q^2*s + (4*I)*eIn*Q^2*s + (5*I)*hIn*hOut*Q^2*s - (5*I)*s^2 + 
          (2*I)*eIn*s^2 + (3*I)*hIn*hOut*s^2 - (2*I)*Q^2*t + 
          (2*I)*hIn*hOut*Q^2*t - (6*I)*s*t + (4*I)*eIn*s*t + 
          (2*I)*hIn*hOut*s*t - (2*I)*Q^4*xIn - (9*I)*Q^2*s*xIn - 
          (5*I)*s^2*xIn - (2*I)*Q^2*t*xIn - (6*I)*s*t*xIn + 2*hOut*Q^4*yIn + 
          5*hOut*Q^2*s*yIn + 3*hOut*s^2*yIn + 2*hOut*Q^2*t*yIn + 
          2*hOut*s*t*yIn))/(2*(Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 0, 0, 1}] -> ((-1/2*I)*(-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*
         (-Q^4 + hIn*hOut*Q^4 - 4*Q^2*s + 2*eIn*Q^2*s + 2*hIn*hOut*Q^2*s - 
          3*s^2 + 2*eIn*s^2 + hIn*hOut*s^2 - 4*s*t + 4*eIn*s*t - Q^4*xIn - 
          4*Q^2*s*xIn - 3*s^2*xIn - 4*s*t*xIn - I*hOut*Q^4*yIn - 
          (2*I)*hOut*Q^2*s*yIn - I*hOut*s^2*yIn))/((Q^2 + s)^2*SUNN*
         (Q^2 + s + t)), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-1/2*I)*(-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*(s + t)*
         (-Q^2 + hIn*hOut*Q^2 + s - 2*eIn*s + hIn*hOut*s - Q^2*xIn + s*xIn - 
          I*hOut*Q^2*yIn - I*hOut*s*yIn))/((Q^2 + s)^2*SUNN*(Q^2 + s + t)), 
      GLI["V11", {0, 1, -1, 1}] -> ((-1/2*I)*(-2 + D)*Q*(-1 + SUNN)*
         (1 + SUNN)*(-Q^2 + hIn*hOut*Q^2 - 3*s + 2*eIn*s + hIn*hOut*s - 
          Q^2*xIn - 3*s*xIn - I*hOut*Q^2*yIn - I*hOut*s*yIn))/
        ((Q^2 + s)^2*SUNN), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/2*I)*(-2 + D)*Q*(-1 + SUNN)*(1 + SUNN)*(-2*Q^4 + 2*hIn*hOut*Q^4 - 
          7*Q^2*s + 4*eIn*Q^2*s + 3*hIn*hOut*Q^2*s - 3*s^2 + 2*eIn*s^2 + 
          hIn*hOut*s^2 - 4*s*t + 4*eIn*s*t - 2*Q^4*xIn - 7*Q^2*s*xIn - 
          3*s^2*xIn - 4*s*t*xIn - (2*I)*hOut*Q^4*yIn - (3*I)*hOut*Q^2*s*yIn - 
          I*hOut*s^2*yIn))/((Q^2 + s)^2*SUNN)|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/2*I)*(-2 + D)*Q*s*(-1 + SUNN)*
         (1 + SUNN)*(-Q^2 + hIn*hOut*Q^2 - s + hIn*hOut*s - 2*t + 2*eIn*t - 
          Q^2*xIn - s*xIn - 2*t*xIn - I*hOut*Q^2*yIn - I*hOut*s*yIn))/
        ((Q^2 + s)^2*SUNN)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonWardLeft", "Index" -> {2}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*((-8*I)*eIn*Q^8 + 
          (2*I)*D*eIn*Q^8 - (32*I)*eIn*Q^6*s + (9*I)*D*eIn*Q^6*s - 
          (8*I)*hIn*hOut*Q^6*s + (12*I)*Q^4*s^2 - (58*I)*eIn*Q^4*s^2 + 
          (15*I)*D*eIn*Q^4*s^2 - (24*I)*hIn*hOut*Q^4*s^2 + (20*I)*Q^2*s^3 - 
          (48*I)*eIn*Q^2*s^3 + (11*I)*D*eIn*Q^2*s^3 - (24*I)*hIn*hOut*Q^2*
           s^3 + (8*I)*s^4 - (14*I)*eIn*s^4 + (3*I)*D*eIn*s^4 - 
          (8*I)*hIn*hOut*s^4 - (4*I)*Q^6*t - (8*I)*eIn*Q^6*t + 
          (2*I)*D*eIn*Q^6*t + (4*I)*hIn*hOut*Q^6*t - (14*I)*Q^4*s*t - 
          (12*I)*eIn*Q^4*s*t + (6*I)*D*eIn*Q^4*s*t - (2*I)*hIn*hOut*Q^4*s*t + 
          (16*I)*Q^2*s^2*t - (28*I)*eIn*Q^2*s^2*t + (6*I)*D*eIn*Q^2*s^2*t - 
          (20*I)*hIn*hOut*Q^2*s^2*t + (18*I)*s^3*t - (16*I)*eIn*s^3*t + 
          (2*I)*D*eIn*s^3*t - (14*I)*hIn*hOut*s^3*t - (4*I)*Q^4*t^2 + 
          (4*I)*hIn*hOut*Q^4*t^2 - (8*I)*Q^2*s*t^2 + (8*I)*eIn*Q^2*s*t^2 + 
          (12*I)*s^2*t^2 - (8*I)*eIn*s^2*t^2 - (4*I)*hIn*hOut*s^2*t^2 - 
          (4*I)*Q^8*xIn - (18*I)*Q^6*s*xIn - (18*I)*Q^4*s^2*xIn - 
          (2*I)*Q^2*s^3*xIn + (2*I)*s^4*xIn - (8*I)*Q^6*t*xIn - 
          (26*I)*Q^4*s*t*xIn + (4*I)*Q^2*s^2*t*xIn + (14*I)*s^3*t*xIn - 
          (4*I)*Q^4*t^2*xIn - (8*I)*Q^2*s*t^2*xIn + (12*I)*s^2*t^2*xIn + 
          4*hOut*Q^8*yIn + 18*hOut*Q^6*s*yIn + 26*hOut*Q^4*s^2*yIn + 
          14*hOut*Q^2*s^3*yIn + 2*hOut*s^4*yIn + 8*hOut*Q^6*t*yIn + 
          18*hOut*Q^4*s*t*yIn + 8*hOut*Q^2*s^2*t*yIn - 2*hOut*s^3*t*yIn + 
          4*hOut*Q^4*t^2*yIn - 4*hOut*s^2*t^2*yIn))/(8*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*
         (-4*eIn*Q^8 + D*eIn*Q^8 - 14*eIn*Q^6*s + 4*D*eIn*Q^6*s - 
          4*hIn*hOut*Q^6*s + 4*Q^4*s^2 - 22*eIn*Q^4*s^2 + 6*D*eIn*Q^4*s^2 - 
          12*hIn*hOut*Q^4*s^2 + 8*Q^2*s^3 - 18*eIn*Q^2*s^3 + 
          4*D*eIn*Q^2*s^3 - 12*hIn*hOut*Q^2*s^3 + 4*s^4 - 6*eIn*s^4 + 
          D*eIn*s^4 - 4*hIn*hOut*s^4 - 2*Q^6*t + 2*hIn*hOut*Q^6*t - 
          10*Q^4*s*t + 8*eIn*Q^4*s*t - 2*hIn*hOut*Q^4*s*t + 2*Q^2*s^2*t - 
          10*hIn*hOut*Q^2*s^2*t + 10*s^3*t - 8*eIn*s^3*t - 6*hIn*hOut*s^3*t - 
          8*Q^2*s*t^2 + 8*eIn*Q^2*s*t^2 + 8*s^2*t^2 - 8*eIn*s^2*t^2 - 
          2*Q^8*xIn - 8*Q^6*s*xIn - 8*Q^4*s^2*xIn + 2*s^4*xIn - 2*Q^6*t*xIn - 
          10*Q^4*s*t*xIn + 2*Q^2*s^2*t*xIn + 10*s^3*t*xIn - 8*Q^2*s*t^2*xIn + 
          8*s^2*t^2*xIn - (2*I)*hOut*Q^8*yIn - (8*I)*hOut*Q^6*s*yIn - 
          (12*I)*hOut*Q^4*s^2*yIn - (8*I)*hOut*Q^2*s^3*yIn - 
          (2*I)*hOut*s^4*yIn - (2*I)*hOut*Q^6*t*yIn - (6*I)*hOut*Q^4*s*t*
           yIn - (6*I)*hOut*Q^2*s^2*t*yIn - (2*I)*hOut*s^3*t*yIn))/
        (s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(s + t)*transverseK*
         ((4*I)*eIn*Q^6 - I*D*eIn*Q^6 - (4*I)*Q^4*s + (14*I)*eIn*Q^4*s - 
          (3*I)*D*eIn*Q^4*s - (4*I)*Q^2*s^2 + (12*I)*eIn*Q^2*s^2 - 
          (3*I)*D*eIn*Q^2*s^2 + (2*I)*eIn*s^3 - I*D*eIn*s^3 + (2*I)*Q^4*t - 
          (2*I)*hIn*hOut*Q^4*t - (4*I)*Q^2*s*t + (4*I)*eIn*Q^2*s*t + 
          (2*I)*s^2*t - (4*I)*eIn*s^2*t + (2*I)*hIn*hOut*s^2*t + 
          (2*I)*Q^6*xIn + (2*I)*Q^4*s*xIn + (2*I)*Q^2*s^2*xIn + 
          (2*I)*s^3*xIn + (2*I)*Q^4*t*xIn - (4*I)*Q^2*s*t*xIn + 
          (2*I)*s^2*t*xIn - 2*hOut*Q^6*yIn - 2*hOut*Q^4*s*yIn + 
          2*hOut*Q^2*s^2*yIn + 2*hOut*s^3*yIn - 2*hOut*Q^4*t*yIn + 
          2*hOut*s^2*t*yIn))/(8*s*(Q^2 + s)*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         transverseK*((4*I)*eIn*Q^6 - I*D*eIn*Q^6 + (10*I)*eIn*Q^4*s - 
          (3*I)*D*eIn*Q^4*s + (4*I)*hIn*hOut*Q^4*s - (4*I)*Q^2*s^2 + 
          (12*I)*eIn*Q^2*s^2 - (3*I)*D*eIn*Q^2*s^2 + (8*I)*hIn*hOut*Q^2*s^2 - 
          (4*I)*s^3 + (6*I)*eIn*s^3 - I*D*eIn*s^3 + (4*I)*hIn*hOut*s^3 + 
          (2*I)*Q^4*t - (2*I)*hIn*hOut*Q^4*t + (4*I)*Q^2*s*t - 
          (4*I)*eIn*Q^2*s*t - (6*I)*s^2*t + (4*I)*eIn*s^2*t + 
          (2*I)*hIn*hOut*s^2*t + (2*I)*Q^6*xIn + (6*I)*Q^4*s*xIn + 
          (2*I)*Q^2*s^2*xIn - (2*I)*s^3*xIn + (2*I)*Q^4*t*xIn + 
          (4*I)*Q^2*s*t*xIn - (6*I)*s^2*t*xIn - 2*hOut*Q^6*yIn - 
          6*hOut*Q^4*s*yIn - 6*hOut*Q^2*s^2*yIn - 2*hOut*s^3*yIn - 
          2*hOut*Q^4*t*yIn + 2*hOut*s^2*t*yIn))/(8*s*(Q^2 + s)*SUNN*t*
         (Q^2 + s + t)), GLI["V11", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*
         (-8*eIn*Q^8 + 2*D*eIn*Q^8 - 24*eIn*Q^6*s + 7*D*eIn*Q^6*s - 
          8*hIn*hOut*Q^6*s + 8*Q^4*s^2 - 34*eIn*Q^4*s^2 + 9*D*eIn*Q^4*s^2 - 
          20*hIn*hOut*Q^4*s^2 + 12*Q^2*s^3 - 24*eIn*Q^2*s^3 + 
          5*D*eIn*Q^2*s^3 - 16*hIn*hOut*Q^2*s^3 + 4*s^4 - 6*eIn*s^4 + 
          D*eIn*s^4 - 4*hIn*hOut*s^4 - 4*Q^6*t + 4*hIn*hOut*Q^6*t - 
          14*Q^4*s*t + 12*eIn*Q^4*s*t - 2*hIn*hOut*Q^4*s*t + 8*Q^2*s^2*t - 
          4*eIn*Q^2*s^2*t - 12*hIn*hOut*Q^2*s^2*t + 10*s^3*t - 8*eIn*s^3*t - 
          6*hIn*hOut*s^3*t - 8*Q^2*s*t^2 + 8*eIn*Q^2*s*t^2 + 8*s^2*t^2 - 
          8*eIn*s^2*t^2 - 4*Q^8*xIn - 14*Q^6*s*xIn - 10*Q^4*s^2*xIn + 
          2*Q^2*s^3*xIn + 2*s^4*xIn - 4*Q^6*t*xIn - 14*Q^4*s*t*xIn + 
          8*Q^2*s^2*t*xIn + 10*s^3*t*xIn - 8*Q^2*s*t^2*xIn + 8*s^2*t^2*xIn - 
          (4*I)*hOut*Q^8*yIn - (14*I)*hOut*Q^6*s*yIn - (18*I)*hOut*Q^4*s^2*
           yIn - (10*I)*hOut*Q^2*s^3*yIn - (2*I)*hOut*s^4*yIn - 
          (4*I)*hOut*Q^6*t*yIn - (6*I)*hOut*Q^4*s*t*yIn - 
          (4*I)*hOut*Q^2*s^2*t*yIn - (2*I)*hOut*s^3*t*yIn))/
        (s*(Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V03", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)*(1 + SUNN)*
         transverseK*(-4*eIn*Q^6 + D*eIn*Q^6 + 2*Q^4*s - 12*eIn*Q^4*s + 
          3*D*eIn*Q^4*s - 2*hIn*hOut*Q^4*s + 4*Q^2*s^2 - 12*eIn*Q^2*s^2 + 
          3*D*eIn*Q^2*s^2 - 4*hIn*hOut*Q^2*s^2 + 2*s^3 - 4*eIn*s^3 + 
          D*eIn*s^3 - 2*hIn*hOut*s^3 - 4*Q^4*t + 2*eIn*Q^4*t - 
          4*hIn*hOut*Q^2*s*t + 4*s^2*t - 2*eIn*s^2*t - 4*hIn*hOut*s^2*t - 
          4*Q^2*t^2 + 4*eIn*Q^2*t^2 + 4*s*t^2 - 4*eIn*s*t^2 - 2*Q^6*xIn - 
          4*Q^4*s*xIn - 2*Q^2*s^2*xIn - 4*Q^4*t*xIn + 4*s^2*t*xIn - 
          4*Q^2*t^2*xIn + 4*s*t^2*xIn - (2*I)*hOut*Q^6*yIn - 
          (4*I)*hOut*Q^4*s*yIn - (2*I)*hOut*Q^2*s^2*yIn - 
          (4*I)*hOut*Q^4*t*yIn - (4*I)*hOut*Q^2*s*t*yIn))/
        ((Q^2 + s)*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonWardLeft", "Index" -> {3}, 
    "Coefficients" -> <|GLI["V11", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*(-8*eIn*hOut*Q^6 + 
          2*D*eIn*hOut*Q^6 - 8*hIn*Q^4*s - 24*eIn*hOut*Q^4*s + 
          7*D*eIn*hOut*Q^4*s - 16*hIn*Q^2*s^2 + 12*hOut*Q^2*s^2 - 
          34*eIn*hOut*Q^2*s^2 + 8*D*eIn*hOut*Q^2*s^2 - 8*hIn*s^3 + 
          8*hOut*s^3 - 14*eIn*hOut*s^3 + 3*D*eIn*hOut*s^3 - 4*hIn*Q^4*t + 
          4*hOut*Q^4*t - 8*eIn*hOut*Q^4*t + 2*D*eIn*hOut*Q^4*t - 
          26*hIn*Q^2*s*t + 10*hOut*Q^2*s*t - 12*eIn*hOut*Q^2*s*t + 
          4*D*eIn*hOut*Q^2*s*t - 18*hIn*s^2*t + 14*hOut*s^2*t - 
          12*eIn*hOut*s^2*t + 2*D*eIn*hOut*s^2*t - 4*hIn*Q^2*t^2 + 
          4*hOut*Q^2*t^2 - 12*hIn*s*t^2 + 4*hOut*s*t^2 - 4*hOut*Q^6*xIn - 
          14*hOut*Q^4*s*xIn - 4*hOut*Q^2*s^2*xIn + 2*hOut*s^3*xIn - 
          8*hOut*Q^4*t*xIn - 18*hOut*Q^2*s*t*xIn - 2*hOut*s^2*t*xIn - 
          4*hOut*Q^2*t^2*xIn - 4*hOut*s*t^2*xIn - (4*I)*Q^6*yIn - 
          (14*I)*Q^4*s*yIn - (12*I)*Q^2*s^2*yIn - (2*I)*s^3*yIn - 
          (8*I)*Q^4*t*yIn - (26*I)*Q^2*s*t*yIn - (14*I)*s^2*t*yIn - 
          (4*I)*Q^2*t^2*yIn - (12*I)*s*t^2*yIn))/(8*s*SUNN*t*
         (Q^2 + s + t)^2), GLI["V11", {0, 0, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*(-4*eIn*hOut*Q^6 + 
           D*eIn*hOut*Q^6 - 4*hIn*Q^4*s - 10*eIn*hOut*Q^4*s + 
           3*D*eIn*hOut*Q^4*s - 8*hIn*Q^2*s^2 + 4*hOut*Q^2*s^2 - 
           12*eIn*hOut*Q^2*s^2 + 3*D*eIn*hOut*Q^2*s^2 - 4*hIn*s^3 + 
           4*hOut*s^3 - 6*eIn*hOut*s^3 + D*eIn*hOut*s^3 - 2*hIn*Q^4*t + 
           2*hOut*Q^4*t - 12*hIn*Q^2*s*t + 4*eIn*hOut*Q^2*s*t - 
           10*hIn*s^2*t + 6*hOut*s^2*t - 4*eIn*hOut*s^2*t - 8*hIn*s*t^2 - 
           2*hOut*Q^6*xIn - 6*hOut*Q^4*s*xIn - 2*hOut*Q^2*s^2*xIn + 
           2*hOut*s^3*xIn - 2*hOut*Q^4*t*xIn - 8*hOut*Q^2*s*t*xIn + 
           2*hOut*s^2*t*xIn - (2*I)*Q^6*yIn - (6*I)*Q^4*s*yIn - 
           (6*I)*Q^2*s^2*yIn - (2*I)*s^3*yIn - (2*I)*Q^4*t*yIn - 
           (12*I)*Q^2*s*t*yIn - (10*I)*s^2*t*yIn - (8*I)*s*t^2*yIn))/
         (s*SUNN*t*(Q^2 + s + t)^2), GLI["V11", {-1, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*(s + t)*transverseK*
          (-4*eIn*hOut*Q^4 + D*eIn*hOut*Q^4 + 4*hOut*Q^2*s - 
           10*eIn*hOut*Q^2*s + 2*D*eIn*hOut*Q^2*s - 2*eIn*hOut*s^2 + 
           D*eIn*hOut*s^2 - 2*hIn*Q^2*t + 2*hOut*Q^2*t + 2*hIn*s*t + 
           2*hOut*s*t - 2*hOut*Q^4*xIn - 2*hOut*s^2*xIn - 2*hOut*Q^2*t*xIn - 
           2*hOut*s*t*xIn - (2*I)*Q^4*yIn + (2*I)*s^2*yIn - (2*I)*Q^2*t*yIn + 
           (2*I)*s*t*yIn))/(s*SUNN*t*(Q^2 + s + t)^2), 
      GLI["V11", {0, 1, -1, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          transverseK*(-4*eIn*hOut*Q^4 + D*eIn*hOut*Q^4 - 4*hIn*Q^2*s - 
           6*eIn*hOut*Q^2*s + 2*D*eIn*hOut*Q^2*s - 4*hIn*s^2 + 4*hOut*s^2 - 
           6*eIn*hOut*s^2 + D*eIn*hOut*s^2 - 2*hIn*Q^2*t + 2*hOut*Q^2*t - 
           6*hIn*s*t + 2*hOut*s*t - 2*hOut*Q^4*xIn - 4*hOut*Q^2*s*xIn + 
           2*hOut*s^2*xIn - 2*hOut*Q^2*t*xIn - 2*hOut*s*t*xIn - 
           (2*I)*Q^4*yIn - (4*I)*Q^2*s*yIn - (2*I)*s^2*yIn - 
           (2*I)*Q^2*t*yIn - (6*I)*s*t*yIn))/(s*SUNN*t*(Q^2 + s + t)), 
      GLI["V11", {0, 1, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)*(1 + SUNN)*
          transverseK*(-8*eIn*hOut*Q^6 + 2*D*eIn*hOut*Q^6 - 8*hIn*Q^4*s - 
           16*eIn*hOut*Q^4*s + 5*D*eIn*hOut*Q^4*s - 12*hIn*Q^2*s^2 + 
           8*hOut*Q^2*s^2 - 18*eIn*hOut*Q^2*s^2 + 4*D*eIn*hOut*Q^2*s^2 - 
           4*hIn*s^3 + 4*hOut*s^3 - 6*eIn*hOut*s^3 + D*eIn*hOut*s^3 - 
           4*hIn*Q^4*t + 4*hOut*Q^4*t - 18*hIn*Q^2*s*t + 2*hOut*Q^2*s*t + 
           4*eIn*hOut*Q^2*s*t - 10*hIn*s^2*t + 6*hOut*s^2*t - 
           4*eIn*hOut*s^2*t - 8*hIn*s*t^2 - 4*hOut*Q^6*xIn - 
           10*hOut*Q^4*s*xIn + 2*hOut*s^3*xIn - 4*hOut*Q^4*t*xIn - 
           10*hOut*Q^2*s*t*xIn + 2*hOut*s^2*t*xIn - (4*I)*Q^6*yIn - 
           (10*I)*Q^4*s*yIn - (8*I)*Q^2*s^2*yIn - (2*I)*s^3*yIn - 
           (4*I)*Q^4*t*yIn - (18*I)*Q^2*s*t*yIn - (10*I)*s^2*t*yIn - 
           (8*I)*s*t^2*yIn))/(s*SUNN*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V03", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)*(1 + SUNN)*transverseK*(4*eIn*hOut*Q^4 - 
          D*eIn*hOut*Q^4 + 2*hIn*Q^2*s - 2*hOut*Q^2*s + 8*eIn*hOut*Q^2*s - 
          2*D*eIn*hOut*Q^2*s + 2*hIn*s^2 - 2*hOut*s^2 + 4*eIn*hOut*s^2 - 
          D*eIn*hOut*s^2 + 4*hIn*Q^2*t - 2*eIn*hOut*Q^2*t + 4*hIn*s*t - 
          4*hOut*s*t + 2*eIn*hOut*s*t + 4*hIn*t^2 + 2*hOut*Q^4*xIn + 
          2*hOut*Q^2*s*xIn + 4*hOut*Q^2*t*xIn + (2*I)*Q^4*yIn + 
          (2*I)*Q^2*s*yIn + (4*I)*Q^2*t*yIn + (4*I)*s*t*yIn + (4*I)*t^2*yIn))/
        (8*SUNN*t*(Q^2 + s + t))|>, "MissingTargets" -> {}|>}, 
 "InputHash" -> 9393304692673827435719976734310224885410958034978155477851231\
7217311291292487, "ReconstructionPassed" -> True, 
 "ReducedReferenceChecksPassed" -> True|>
