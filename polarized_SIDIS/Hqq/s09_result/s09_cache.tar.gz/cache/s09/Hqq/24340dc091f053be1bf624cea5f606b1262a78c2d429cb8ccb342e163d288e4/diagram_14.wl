<|"Diagram" -> 14, "Components" -> {<|"Kind" -> "ExtendedResponse", 
    "Index" -> {1, 1, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 + 10*Q^2*s + 6*s^2 - 2*Q^2*t + 2*D*Q^2*t + 4*s*t + D*s*t - 
          2*t^2 + D*t^2))/(s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t)*
         (2*Q^2 + 2*s - 2*t + D*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 - 2*s - 6*t + D*t))/((Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 + 2*s - 2*t + D*t))/(s*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t)*(2*Q^2 + 2*s - 2*t + D*t))/((Q^2 + s)*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)^2*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        ((Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 2, 2}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 + 10*Q^2*s + 6*s^2 - 
          6*Q^2*t + 2*D*Q^2*t + 2*s*t + D*s*t - 4*t^2 + D*t^2))/
        (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t)*
         (2*Q^2 + 2*s - 4*t + D*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 - 2*s - 8*t + D*t))/((Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 + 2*s - 4*t + D*t))/(s*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t)*(2*Q^2 + 2*s - 4*t + D*t))/((Q^2 + s)*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/4)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        ((Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 3, 3}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^4 - 10*Q^2*s - 
          6*s^2 - 10*Q^2*t + 2*D*Q^2*t - 10*s*t + D*s*t - 4*t^2 + D*t^2))/
        (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t)*
         (-2*Q^2 - 2*s - 4*t + D*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 + 2*s + D*t))/((Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 - 2*s - 4*t + D*t))/(s*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t)*(-2*Q^2 - 2*s - 4*t + D*t))/
        ((Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/4*I)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t))/((Q^2 + s)*SUNN^2)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {1, 4, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^4 - 10*Q^2*s - 6*s^2 - 14*Q^2*t + 2*D*Q^2*t - 
          12*s*t + D*s*t - 6*t^2 + D*t^2))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t)*(-2*Q^2 - 2*s - 6*t + D*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 + 2*s - 2*t + D*t))/((Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 - 2*s - 6*t + D*t))/(s*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t)*(-2*Q^2 - 2*s - 6*t + D*t))/
        ((Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/4*I)*(-6 + D)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t))/((Q^2 + s)*SUNN^2)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 1, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 2*D*Q^4*s + 2*Q^2*s^2 + 
          5*D*Q^2*s^2 - 4*s^3 + 3*D*s^3 + 10*Q^4*t - 2*D*Q^4*t + 12*Q^2*s*t - 
          2*D*Q^2*s*t - 10*s^2*t + 2*D*s^2*t - 2*Q^2*t^2 + D*Q^2*t^2 + 
          2*s*t^2 - D*s*t^2))/(s^2*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (6*Q^6 + 12*Q^4*s + D*Q^4*s + 6*Q^2*s^2 + 2*D*Q^2*s^2 + D*s^3 + 
          8*Q^4*t - D*Q^4*t + 6*Q^2*s*t - D*Q^2*s*t - 2*s^2*t - 2*Q^2*t^2 + 
          D*Q^2*t^2 + 2*s*t^2 - D*s*t^2))/(s^2*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (6*Q^4 + 6*Q^2*s + D*Q^2*s + D*s^2 + 6*Q^2*t - D*Q^2*t - 6*s*t + 
          D*s*t))/(s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^4 - 6*Q^2*s + 
          D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - D*Q^2*t - 2*s*t + D*s*t))/
        (s^2*SUNN^2*t), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^6 + 12*Q^4*s + 
          D*Q^4*s + 6*Q^2*s^2 + 2*D*Q^2*s^2 + D*s^3 + 8*Q^4*t - D*Q^4*t + 
          6*Q^2*s*t - D*Q^2*s*t - 2*s^2*t - 2*Q^2*t^2 + D*Q^2*t^2 + 2*s*t^2 - 
          D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 4*Q^4*t - 6*Q^2*s*t + 
          D*Q^2*s*t - 2*s^2*t + D*s^2*t + 2*Q^2*t^2 - D*Q^2*t^2 - 2*s*t^2 + 
          D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 2, 2}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 6*Q^4*s + 
          2*D*Q^4*s - 8*Q^2*s^2 + 5*D*Q^2*s^2 - 10*s^3 + 3*D*s^3 + 14*Q^4*t - 
          2*D*Q^4*t + 16*Q^2*s*t - 2*D*Q^2*s*t - 14*s^2*t + 2*D*s^2*t - 
          4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/(s^2*(Q^2 + s)*SUNN^2*
         t), GLI["V09", {0, 0, 1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^6 + 10*Q^4*s + D*Q^4*s + 2*Q^2*s^2 + 2*D*Q^2*s^2 - 
          2*s^3 + D*s^3 + 10*Q^4*t - D*Q^4*t + 8*Q^2*s*t - D*Q^2*s*t - 
          2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/
        (s^2*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^4 + 4*Q^2*s + 
          D*Q^2*s - 2*s^2 + D*s^2 + 8*Q^2*t - D*Q^2*t - 8*s*t + D*s*t))/
        (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^4 - 8*Q^2*s + 
          D*Q^2*s - 6*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t))/
        (s^2*SUNN^2*t), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^6 + 10*Q^4*s + 
          D*Q^4*s + 2*Q^2*s^2 + 2*D*Q^2*s^2 - 2*s^3 + D*s^3 + 10*Q^4*t - 
          D*Q^4*t + 8*Q^2*s*t - D*Q^2*s*t - 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 
          4*s*t^2 - D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 4*Q^4*t - 8*Q^2*s*t + D*Q^2*s*t - 4*s^2*t + 
          D*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2 - 4*s*t^2 + D*s*t^2))/
        (s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 3, 3}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 22*Q^4*s + 
          2*D*Q^4*s - 32*Q^2*s^2 + 5*D*Q^2*s^2 - 14*s^3 + 3*D*s^3 + 2*Q^4*t - 
          2*D*Q^4*t - 2*D*Q^2*s*t - 2*s^2*t + 2*D*s^2*t - 4*Q^2*t^2 + 
          D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/(s^2*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^6 - 18*Q^4*s + D*Q^4*s - 18*Q^2*s^2 + 
          2*D*Q^2*s^2 - 6*s^3 + D*s^3 - 2*Q^4*t - D*Q^4*t - D*Q^2*s*t + 
          2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/
        (s^2*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^4 - 12*Q^2*s + 
          D*Q^2*s - 6*s^2 + D*s^2 - D*Q^2*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^4 + D*Q^2*s - 2*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 
          4*s*t + D*s*t))/(s^2*SUNN^2*t), GLI["V09", {0, 0, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^6 - 18*Q^4*s + 
          D*Q^4*s - 18*Q^2*s^2 + 2*D*Q^2*s^2 - 6*s^3 + D*s^3 - 2*Q^4*t - 
          D*Q^4*t - D*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - 
          D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 
          D*Q^2*s*t - 4*s^2*t + D*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2 - 4*s*t^2 + 
          D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 4, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 26*Q^4*s + 
          2*D*Q^4*s - 42*Q^2*s^2 + 5*D*Q^2*s^2 - 20*s^3 + 3*D*s^3 + 6*Q^4*t - 
          2*D*Q^4*t + 4*Q^2*s*t - 2*D*Q^2*s*t - 6*s^2*t + 2*D*s^2*t - 
          6*Q^2*t^2 + D*Q^2*t^2 + 6*s*t^2 - D*s*t^2))/(s^2*(Q^2 + s)*SUNN^2*
         t), GLI["V09", {0, 0, 1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^6 - 20*Q^4*s + D*Q^4*s - 22*Q^2*s^2 + 
          2*D*Q^2*s^2 - 8*s^3 + D*s^3 - D*Q^4*t + 2*Q^2*s*t - D*Q^2*s*t + 
          2*s^2*t - 6*Q^2*t^2 + D*Q^2*t^2 + 6*s*t^2 - D*s*t^2))/
        (s^2*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^4 - 14*Q^2*s + 
          D*Q^2*s - 8*s^2 + D*s^2 + 2*Q^2*t - D*Q^2*t - 2*s*t + D*s*t))/
        (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 - 2*Q^2*s + 
          D*Q^2*s - 4*s^2 + D*s^2 + 6*Q^2*t - D*Q^2*t - 6*s*t + D*s*t))/
        (s^2*SUNN^2*t), GLI["V09", {0, 0, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^6 - 20*Q^4*s + 
          D*Q^4*s - 22*Q^2*s^2 + 2*D*Q^2*s^2 - 8*s^3 + D*s^3 - D*Q^4*t + 
          2*Q^2*s*t - D*Q^2*s*t + 2*s^2*t - 6*Q^2*t^2 + D*Q^2*t^2 + 6*s*t^2 - 
          D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t - 
          2*Q^2*s*t + D*Q^2*s*t - 6*s^2*t + D*s^2*t + 6*Q^2*t^2 - D*Q^2*t^2 - 
          6*s*t^2 + D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 1, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^4 - 22*Q^2*s + 2*D*Q^2*s - 20*s^2 + 3*D*s^2 - 10*Q^2*t + 
          2*D*Q^2*t - 10*s*t + 2*D*s*t + 2*t^2 - D*t^2))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^4 - 14*Q^2*s + D*Q^2*s - 8*s^2 + D*s^2 - 
          8*Q^2*t + D*Q^2*t - 2*s*t + 2*t^2 - D*t^2))/(s^2*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^2 - 8*s + D*s - 6*t + D*t))/(s*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 - 4*s + D*s - 2*t + D*t))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-6*Q^4 - 14*Q^2*s + D*Q^2*s - 8*s^2 + D*s^2 - 8*Q^2*t + D*Q^2*t - 
          2*s*t + 2*t^2 - D*t^2))/(s*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^4 + 6*Q^2*s + 2*s^2 + 4*Q^2*t - 2*s*t + D*s*t - 
          2*t^2 + D*t^2))/(s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 2, 2}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^4 - 18*Q^2*s + 
          2*D*Q^2*s - 14*s^2 + 3*D*s^2 - 14*Q^2*t + 2*D*Q^2*t - 18*s*t + 
          2*D*s*t + 4*t^2 - D*t^2))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-6*Q^4 - 12*Q^2*s + D*Q^2*s - 6*s^2 + D*s^2 - 10*Q^2*t + D*Q^2*t - 
          6*s*t + 4*t^2 - D*t^2))/(s^2*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-6*Q^2 - 6*s + D*s - 8*t + D*t))/(s*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 - 2*s + D*s - 4*t + D*t))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^4 - 12*Q^2*s + D*Q^2*s - 6*s^2 + D*s^2 - 
          10*Q^2*t + D*Q^2*t - 6*s*t + 4*t^2 - D*t^2))/(s*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 + 6*Q^2*s + 2*s^2 + 
          4*Q^2*t + D*s*t - 4*t^2 + D*t^2))/(s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 3, 3}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 + 2*Q^2*s + 2*D*Q^2*s - 10*s^2 + 3*D*s^2 - 2*Q^2*t + 
          2*D*Q^2*t + 2*s*t + 2*D*s*t + 4*t^2 - D*t^2))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^4 + 4*Q^2*s + D*Q^2*s - 2*s^2 + D*s^2 + 2*Q^2*t + 
          D*Q^2*t + 6*s*t + 4*t^2 - D*t^2))/(s^2*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^2 - 2*s + D*s + D*t))/(s*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^2 - 6*s + D*s - 4*t + D*t))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (6*Q^4 + 4*Q^2*s + D*Q^2*s - 2*s^2 + D*s^2 + 2*Q^2*t + D*Q^2*t + 
          6*s*t + 4*t^2 - D*t^2))/(s*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^4 - 6*Q^2*s - 2*s^2 - 4*Q^2*t - 8*s*t + D*s*t - 
          4*t^2 + D*t^2))/(s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 4, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 + 6*Q^2*s + 
          2*D*Q^2*s - 4*s^2 + 3*D*s^2 - 6*Q^2*t + 2*D*Q^2*t - 6*s*t + 
          2*D*s*t + 6*t^2 - D*t^2))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (6*Q^4 + 6*Q^2*s + D*Q^2*s + D*s^2 + D*Q^2*t + 2*s*t + 6*t^2 - 
          D*t^2))/(s^2*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^2 + D*s - 2*t + D*t))/
        (s*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 - 4*s + D*s - 6*t + D*t))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^4 + 6*Q^2*s + D*Q^2*s + D*s^2 + D*Q^2*t + 2*s*t + 
          6*t^2 - D*t^2))/(s*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^4 - 6*Q^2*s - 2*s^2 - 4*Q^2*t - 6*s*t + D*s*t - 6*t^2 + 
          D*t^2))/(s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 1, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^8 - 32*Q^6*s - 
          46*Q^4*s^2 - 28*Q^2*s^3 - 6*s^4 - 28*Q^6*t + 4*D*Q^6*t - 
          82*Q^4*s*t + 12*D*Q^4*s*t - 58*Q^2*s^2*t + 9*D*Q^2*s^2*t - 
          4*s^3*t + D*s^3*t - 12*Q^4*t^2 - 36*Q^2*s*t^2 + 6*D*Q^2*s*t^2 + 
          2*D*s^2*t^2 + 6*Q^2*t^3 - 3*D*Q^2*t^3 - 2*s*t^3 + D*s*t^3)*
         transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 16*Q^4*t + 2*D*Q^4*t - 
          18*Q^2*s*t + 3*D*Q^2*s*t - 2*s^2*t + D*s^2*t + 6*Q^2*t^2 - 
          3*D*Q^2*t^2 - 2*s*t^2 + D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 20*Q^4*t + 
          2*D*Q^4*t - 18*Q^2*s*t + D*Q^2*s*t + 2*s^2*t - D*s^2*t - 
          18*Q^2*t^2 + 3*D*Q^2*t^2 + 6*s*t^2 - D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/16)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^4 - 6*Q^2*s - 2*s^2 - 8*Q^2*t + 2*D*Q^2*t - 2*s*t + D*s*t - 
          2*t^2 + D*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 16*Q^4*t + 
          2*D*Q^4*t - 18*Q^2*s*t + 3*D*Q^2*s*t - 2*s^2*t + D*s^2*t + 
          6*Q^2*t^2 - 3*D*Q^2*t^2 - 2*s*t^2 + D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^4 + 10*Q^2*s - D*Q^2*s + 4*s^2 - D*s^2 - 6*Q^2*t + 
          3*D*Q^2*t + 2*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 2, 2}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-8*Q^8 - 32*Q^6*s - 46*Q^4*s^2 - 28*Q^2*s^3 - 6*s^4 - 
          36*Q^6*t + 4*D*Q^6*t - 106*Q^4*s*t + 12*D*Q^4*s*t - 76*Q^2*s^2*t + 
          9*D*Q^2*s^2*t - 6*s^3*t + D*s^3*t - 12*Q^4*t^2 - 48*Q^2*s*t^2 + 
          6*D*Q^2*s*t^2 - 4*s^2*t^2 + 2*D*s^2*t^2 + 12*Q^2*t^3 - 
          3*D*Q^2*t^3 - 4*s*t^3 + D*s*t^3)*transverseK)/
        (Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 20*Q^4*t + 2*D*Q^4*t - 24*Q^2*s*t + 
          3*D*Q^2*s*t - 4*s^2*t + D*s^2*t + 12*Q^2*t^2 - 3*D*Q^2*t^2 - 
          4*s*t^2 + D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 24*Q^4*t + 
          2*D*Q^4*t - 20*Q^2*s*t + D*Q^2*s*t + 4*s^2*t - D*s^2*t - 
          24*Q^2*t^2 + 3*D*Q^2*t^2 + 8*s*t^2 - D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/16)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^4 - 6*Q^2*s - 2*s^2 - 12*Q^2*t + 2*D*Q^2*t - 4*s*t + D*s*t - 
          4*t^2 + D*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 20*Q^4*t + 
          2*D*Q^4*t - 24*Q^2*s*t + 3*D*Q^2*s*t - 4*s^2*t + D*s^2*t + 
          12*Q^2*t^2 - 3*D*Q^2*t^2 - 4*s*t^2 + D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^4 + 12*Q^2*s - D*Q^2*s + 6*s^2 - D*s^2 - 
          12*Q^2*t + 3*D*Q^2*t + 4*s*t - D*s*t)*transverseK)/
        (Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 3, 3}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^8 + 32*Q^6*s + 
          46*Q^4*s^2 + 28*Q^2*s^3 + 6*s^4 + 4*Q^6*t + 4*D*Q^6*t + 
          10*Q^4*s*t + 12*D*Q^4*s*t + 4*Q^2*s^2*t + 9*D*Q^2*s^2*t - 2*s^3*t + 
          D*s^3*t + 12*Q^4*t^2 + 6*D*Q^2*s*t^2 - 12*s^2*t^2 + 2*D*s^2*t^2 + 
          12*Q^2*t^3 - 3*D*Q^2*t^3 - 4*s*t^3 + D*s*t^3)*transverseK)/
        (Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 
          8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 2*D*Q^4*t + 3*D*Q^2*s*t - 4*s^2*t + 
          D*s^2*t + 12*Q^2*t^2 - 3*D*Q^2*t^2 - 4*s*t^2 + D*s*t^2)*
         transverseK)/(Q*s^2*SUNN^2*t^2), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 
          8*Q^2*s^2 + 2*s^3 + 8*Q^4*t + 2*D*Q^4*t + 12*Q^2*s*t + D*Q^2*s*t + 
          4*s^2*t - D*s^2*t + 3*D*Q^2*t^2 - D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-1/16*I)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 + 6*Q^2*s + 2*s^2 - 4*Q^2*t + 2*D*Q^2*t - 4*s*t + D*s*t - 
          4*t^2 + D*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 2*D*Q^4*t + 
          3*D*Q^2*s*t - 4*s^2*t + D*s^2*t + 12*Q^2*t^2 - 3*D*Q^2*t^2 - 
          4*s*t^2 + D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^4 + 4*Q^2*s + 
          D*Q^2*s - 2*s^2 + D*s^2 + 12*Q^2*t - 3*D*Q^2*t - 4*s*t + D*s*t)*
         transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 4, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^8 + 32*Q^6*s + 
          46*Q^4*s^2 + 28*Q^2*s^3 + 6*s^4 - 4*Q^6*t + 4*D*Q^6*t - 
          14*Q^4*s*t + 12*D*Q^4*s*t - 14*Q^2*s^2*t + 9*D*Q^2*s^2*t - 
          4*s^3*t + D*s^3*t + 12*Q^4*t^2 - 12*Q^2*s*t^2 + 6*D*Q^2*s*t^2 - 
          16*s^2*t^2 + 2*D*s^2*t^2 + 18*Q^2*t^3 - 3*D*Q^2*t^3 - 6*s*t^3 + 
          D*s*t^3)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 2*D*Q^4*t - 
          6*Q^2*s*t + 3*D*Q^2*s*t - 6*s^2*t + D*s^2*t + 18*Q^2*t^2 - 
          3*D*Q^2*t^2 - 6*s*t^2 + D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 
          2*D*Q^4*t + 10*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - D*s^2*t - 
          6*Q^2*t^2 + 3*D*Q^2*t^2 + 2*s*t^2 - D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-1/16*I)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 + 6*Q^2*s + 2*s^2 - 8*Q^2*t + 2*D*Q^2*t - 6*s*t + D*s*t - 
          6*t^2 + D*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 2*D*Q^4*t - 6*Q^2*s*t + 
          3*D*Q^2*s*t - 6*s^2*t + D*s^2*t + 18*Q^2*t^2 - 3*D*Q^2*t^2 - 
          6*s*t^2 + D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^4 + 2*Q^2*s + 
          D*Q^2*s - 4*s^2 + D*s^2 + 18*Q^2*t - 3*D*Q^2*t - 6*s*t + D*s*t)*
         transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 1, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^8 + 32*Q^6*s + 46*Q^4*s^2 + 
          28*Q^2*s^3 + 6*s^4 - 4*Q^6*t + 4*D*Q^6*t - 14*Q^4*s*t + 
          12*D*Q^4*s*t - 2*Q^2*s^2*t + 9*D*Q^2*s^2*t + 8*s^3*t + D*s^3*t - 
          12*Q^4*t^2 + 4*D*Q^4*t^2 - 24*Q^2*s*t^2 + 8*D*Q^2*s*t^2 + 
          2*D*s^2*t^2 + 2*Q^2*t^3 - D*Q^2*t^3 - 2*s*t^3 + D*s*t^3)*
         transverseK)/(16*Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 - 8*Q^4*t + 2*D*Q^4*t - 
           10*Q^2*s*t + 3*D*Q^2*s*t - 2*s^2*t + D*s^2*t + 2*Q^2*t^2 - 
           D*Q^2*t^2 - 2*s*t^2 + D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 - 4*Q^4*t + 2*D*Q^4*t + 
           6*Q^2*s*t + D*Q^2*s*t + 10*s^2*t - D*s^2*t - 6*Q^2*t^2 + 
           D*Q^2*t^2 + 6*s*t^2 - D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2*
          (Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 2*D*Q^4*t - 2*Q^2*s*t + 
           3*D*Q^2*s*t - 2*s^2*t + D*s^2*t - 6*Q^2*t^2 + 3*D*Q^2*t^2 - 
           2*s*t^2 + D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 - 8*Q^4*t + 2*D*Q^4*t - 
          10*Q^2*s*t + 3*D*Q^2*s*t - 2*s^2*t + D*s^2*t + 2*Q^2*t^2 - 
          D*Q^2*t^2 - 2*s*t^2 + D*s*t^2)*transverseK)/(16*Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + 6*Q^2*s - 
           D*Q^2*s + 4*s^2 - D*s^2 - 2*Q^2*t + D*Q^2*t + 2*s*t - D*s*t)*
          transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 2, 3}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^8 - 32*Q^6*s - 
          46*Q^4*s^2 - 28*Q^2*s^3 - 6*s^4 - 36*Q^6*t + 4*D*Q^6*t - 
          98*Q^4*s*t + 8*D*Q^4*s*t - 72*Q^2*s^2*t + 3*D*Q^2*s^2*t - 
          10*s^3*t - D*s^3*t - 12*Q^4*t^2 - 28*Q^2*s*t^2 - 2*D*s^2*t^2 + 
          12*Q^2*t^3 - 3*D*Q^2*t^3 + 4*s*t^3 - D*s*t^3)*transverseK)/
        (Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 20*Q^4*t + 2*D*Q^4*t - 20*Q^2*s*t + D*Q^2*s*t - 
          D*s^2*t + 12*Q^2*t^2 - 3*D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*
         transverseK)/(Q*s^2*SUNN^2*t^2), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 24*Q^4*t + 2*D*Q^4*t - 32*Q^2*s*t + 
          3*D*Q^2*s*t - 8*s^2*t + D*s^2*t - 24*Q^2*t^2 + 3*D*Q^2*t^2 - 
          8*s*t^2 + D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/16)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 12*Q^4*t + 
          2*D*Q^4*t - 12*Q^2*s*t + D*Q^2*s*t - D*s^2*t - 4*Q^2*t^2 + 
          D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 20*Q^4*t + 2*D*Q^4*t - 20*Q^2*s*t + D*Q^2*s*t - 
          D*s^2*t + 12*Q^2*t^2 - 3*D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*
         transverseK)/(Q*s*SUNN^2*t^2)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^4 + 4*Q^2*s + D*Q^2*s - 2*s^2 + D*s^2 - 12*Q^2*t + 
          3*D*Q^2*t - 4*s*t + D*s*t)*transverseK)/(Q*s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 3, 2}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(8*Q^8 + 32*Q^6*s + 46*Q^4*s^2 + 28*Q^2*s^3 + 6*s^4 + 
          4*Q^6*t + 4*D*Q^6*t + 34*Q^4*s*t + 8*D*Q^4*s*t + 48*Q^2*s^2*t + 
          3*D*Q^2*s^2*t + 18*s^3*t - D*s^3*t + 12*Q^4*t^2 + 28*Q^2*s*t^2 + 
          16*s^2*t^2 - 2*D*s^2*t^2 + 12*Q^2*t^3 - 3*D*Q^2*t^3 + 4*s*t^3 - 
          D*s*t^3)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 2*D*Q^4*t + 
          12*Q^2*s*t + D*Q^2*s*t + 8*s^2*t - D*s^2*t + 12*Q^2*t^2 - 
          3*D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 8*Q^4*t + 
          2*D*Q^4*t + 8*Q^2*s*t + 3*D*Q^2*s*t + D*s^2*t + 3*D*Q^2*t^2 + 
          D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/16)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 - 4*Q^4*t + 
          2*D*Q^4*t + 4*Q^2*s*t + D*Q^2*s*t + 8*s^2*t - D*s^2*t - 4*Q^2*t^2 + 
          D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 
          8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 2*D*Q^4*t + 12*Q^2*s*t + D*Q^2*s*t + 
          8*s^2*t - D*s^2*t + 12*Q^2*t^2 - 3*D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*
         transverseK)/(Q*s*SUNN^2*t^2)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^4 + 12*Q^2*s - D*Q^2*s + 6*s^2 - D*s^2 + 
          12*Q^2*t - 3*D*Q^2*t + 4*s*t - D*s*t)*transverseK)/
        (Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 4, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^8 - 32*Q^6*s - 
           46*Q^4*s^2 - 28*Q^2*s^3 - 6*s^4 - 28*Q^6*t + 4*D*Q^6*t - 
           82*Q^4*s*t + 12*D*Q^4*s*t - 70*Q^2*s^2*t + 9*D*Q^2*s^2*t - 
           16*s^3*t + D*s^3*t - 20*Q^4*t^2 + 4*D*Q^4*t^2 - 40*Q^2*s*t^2 + 
           8*D*Q^2*s*t^2 - 16*s^2*t^2 + 2*D*s^2*t^2 + 6*Q^2*t^3 - D*Q^2*t^3 - 
           6*s*t^3 + D*s*t^3)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 8*Q^4*t + 2*D*Q^4*t - 
          14*Q^2*s*t + 3*D*Q^2*s*t - 6*s^2*t + D*s^2*t + 6*Q^2*t^2 - 
          D*Q^2*t^2 - 6*s*t^2 + D*s*t^2)*transverseK)/(16*Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 12*Q^4*t + 2*D*Q^4*t - 
          14*Q^2*s*t + D*Q^2*s*t - 2*s^2*t - D*s^2*t - 2*Q^2*t^2 + 
          D*Q^2*t^2 + 2*s*t^2 - D*s*t^2)*transverseK)/(16*Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 16*Q^4*t + 2*D*Q^4*t - 22*Q^2*s*t + 
          3*D*Q^2*s*t - 6*s^2*t + D*s^2*t - 18*Q^2*t^2 + 3*D*Q^2*t^2 - 
          6*s*t^2 + D*s*t^2)*transverseK)/(16*Q*s^2*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
           8*Q^2*s^2 - 2*s^3 - 8*Q^4*t + 2*D*Q^4*t - 14*Q^2*s*t + 
           3*D*Q^2*s*t - 6*s^2*t + D*s^2*t + 6*Q^2*t^2 - D*Q^2*t^2 - 
           6*s*t^2 + D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 - 2*Q^2*s + 
           D*Q^2*s - 4*s^2 + D*s^2 + 6*Q^2*t - D*Q^2*t - 6*s*t + D*s*t)*
          transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 1, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^4 + 2*D*Q^4 - 20*Q^2*s + 
          5*D*Q^2*s - 12*s^2 + 3*D*s^2 - 4*Q^2*t + D*Q^2*t - 10*s*t + 
          2*D*s*t + 2*t^2 - D*t^2))/(8*s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^2 + s + t)*(-4*Q^2 + D*Q^2 - 4*s + D*s + 2*t - D*t))/
         (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^2 + D*Q^2 - 4*s + 
           D*s - 6*t + D*t))/((Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^2 + D*Q^2 - 4*s + D*s - 2*t + D*t))/(s*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t)*(-4*Q^2 + D*Q^2 - 4*s + D*s + 2*t - D*t))/
        (8*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> -1/8*((-2 + D)^2*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^2 + s + t))/((Q^2 + s)*SUNN^2)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {6, 2, 3}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 - 14*Q^4*s - 12*Q^2*s^2 - 2*s^3 - 14*Q^4*t + 2*D*Q^4*t - 
          24*Q^2*s*t + 3*D*Q^2*s*t - 2*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2))/
        (s^2*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^6 - 14*Q^4*s - 
          10*Q^2*s^2 - 2*s^3 - 10*Q^4*t + D*Q^4*t - 12*Q^2*s*t + D*Q^2*s*t - 
          2*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2))/(s^2*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^4 - 8*Q^2*s - 2*s^2 - 8*Q^2*t + D*Q^2*t))/
        (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + 4*Q^2*s + 
          2*s^2 - 4*Q^2*t + D*Q^2*t))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-6*Q^6 - 14*Q^4*s - 10*Q^2*s^2 - 2*s^3 - 10*Q^4*t + D*Q^4*t - 
          12*Q^2*s*t + D*Q^2*s*t - 2*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2))/
        (s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 
          6*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2))/
        (s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 3, 2}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 14*Q^4*s + 
          12*Q^2*s^2 + 2*s^3 - 2*Q^4*t + 2*D*Q^4*t + 3*D*Q^2*s*t + 2*s^2*t + 
          4*Q^2*t^2 - D*Q^2*t^2))/(s^2*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^6 + 14*Q^4*s + 10*Q^2*s^2 + 2*s^3 + 2*Q^4*t + 
          D*Q^4*t + 4*Q^2*s*t + D*Q^2*s*t + 2*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2))/
        (s^2*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^4 + 8*Q^2*s + 
          2*s^2 + D*Q^2*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^4 - 4*Q^2*s - 2*s^2 - 4*Q^2*t + D*Q^2*t))/
        (s^2*SUNN^2*t), GLI["V09", {0, 0, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^6 + 14*Q^4*s + 
          10*Q^2*s^2 + 2*s^3 + 2*Q^4*t + D*Q^4*t + 4*Q^2*s*t + D*Q^2*s*t + 
          2*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 
          8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 6*Q^2*s*t + 2*s^2*t + 4*Q^2*t^2 - 
          D*Q^2*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 4, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^4 + 2*D*Q^4 - 
           20*Q^2*s + 5*D*Q^2*s - 12*s^2 + 3*D*s^2 - 4*Q^2*t + D*Q^2*t - 
           6*s*t + 2*D*s*t + 6*t^2 - D*t^2))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t)*(-4*Q^2 + D*Q^2 - 4*s + D*s + 6*t - D*t))/
        (8*s*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^2 + D*Q^2 - 4*s + D*s - 
          2*t + D*t))/(8*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^2 + D*Q^2 - 4*s + D*s - 
          6*t + D*t))/(8*s*SUNN^2*t), GLI["V09", {0, 0, 1, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t)*
          (-4*Q^2 + D*Q^2 - 4*s + D*s + 6*t - D*t))/((Q^2 + s)*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-6 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        (8*(Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 1, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (8*Q^6 + 24*Q^4*s + 22*Q^2*s^2 + 6*s^3 - 4*Q^4*t + 4*D*Q^4*t - 
           2*Q^2*s*t + 4*D*Q^2*s*t + 4*s^2*t - D*s^2*t - 12*Q^2*t^2 + 
           4*D*Q^2*t^2 - 2*D*s*t^2 + 2*t^3 - D*t^3)*transverseK)/
         (Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 + 6*Q^2*s + 
          2*s^2 - 8*Q^2*t + 2*D*Q^2*t + 2*s*t - D*s*t + 2*t^2 - D*t^2)*
         transverseK)/(16*Q*s^2*SUNN^2*t^2), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 + 6*Q^2*s + 
          2*s^2 - 4*Q^2*t + 2*D*Q^2*t - 2*s*t + D*s*t - 6*t^2 + D*t^2)*
         transverseK)/(16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 2*D*Q^4*t + 
          2*Q^2*s*t + D*Q^2*s*t + 2*s^2*t - D*s^2*t - 6*Q^2*t^2 + 
          3*D*Q^2*t^2 + 2*s*t^2 - D*s*t^2)*transverseK)/
        (16*Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (4*Q^4 + 6*Q^2*s + 2*s^2 - 8*Q^2*t + 2*D*Q^2*t + 2*s*t - D*s*t + 
           2*t^2 - D*t^2)*transverseK)/(Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^2 - 4*s + D*s - 
          2*t + D*t)*transverseK)/(16*Q*s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 2, 2}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(8*Q^6 + 24*Q^4*s + 22*Q^2*s^2 + 6*s^3 - 12*Q^4*t + 
           4*D*Q^4*t - 10*Q^2*s*t + 4*D*Q^2*s*t + 6*s^2*t - D*s^2*t - 
           20*Q^2*t^2 + 4*D*Q^2*t^2 + 4*s*t^2 - 2*D*s*t^2 + 4*t^3 - D*t^3)*
          transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^4 + 6*Q^2*s + 2*s^2 - 12*Q^2*t + 2*D*Q^2*t + 
          4*s*t - D*s*t + 4*t^2 - D*t^2)*transverseK)/(16*Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^4 + 6*Q^2*s + 2*s^2 - 8*Q^2*t + 2*D*Q^2*t - 
          4*s*t + D*s*t - 8*t^2 + D*t^2)*transverseK)/(16*Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 
          8*Q^2*s^2 + 2*s^3 - 4*Q^4*t + 2*D*Q^4*t + D*Q^2*s*t + 4*s^2*t - 
          D*s^2*t - 12*Q^2*t^2 + 3*D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*
         transverseK)/(16*Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(4*Q^4 + 6*Q^2*s + 2*s^2 - 12*Q^2*t + 2*D*Q^2*t + 
           4*s*t - D*s*t + 4*t^2 - D*t^2)*transverseK)/(Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^2 - 6*s + D*s - 
          4*t + D*t)*transverseK)/(16*Q*s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 3, 3}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-8*Q^6 - 24*Q^4*s - 22*Q^2*s^2 - 6*s^3 - 20*Q^4*t + 
          4*D*Q^4*t - 22*Q^2*s*t + 4*D*Q^2*s*t + 2*s^2*t - D*s^2*t - 
          12*Q^2*t^2 + 4*D*Q^2*t^2 + 12*s*t^2 - 2*D*s*t^2 + 4*t^3 - D*t^3)*
         transverseK)/(16*Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(-4*Q^4 - 6*Q^2*s - 2*s^2 - 4*Q^2*t + 2*D*Q^2*t + 
           4*s*t - D*s*t + 4*t^2 - D*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(-4*Q^4 - 6*Q^2*s - 2*s^2 - 8*Q^2*t + 2*D*Q^2*t - 
           4*s*t + D*s*t + D*t^2)*transverseK)/(Q*s*SUNN^2*t^2*
          (Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 12*Q^4*t + 2*D*Q^4*t - 
           8*Q^2*s*t + D*Q^2*s*t + 4*s^2*t - D*s^2*t - 12*Q^2*t^2 + 
           3*D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*transverseK)/
         (Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^4 - 6*Q^2*s - 
          2*s^2 - 4*Q^2*t + 2*D*Q^2*t + 4*s*t - D*s*t + 4*t^2 - D*t^2)*
         transverseK)/(16*Q*s*SUNN^2*t^2)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 + 2*s - D*s + 4*t - D*t)*transverseK)/
        (16*Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 4, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^6 - 24*Q^4*s - 
          22*Q^2*s^2 - 6*s^3 - 28*Q^4*t + 4*D*Q^4*t - 30*Q^2*s*t + 
          4*D*Q^2*s*t + 4*s^2*t - D*s^2*t - 20*Q^2*t^2 + 4*D*Q^2*t^2 + 
          16*s*t^2 - 2*D*s*t^2 + 6*t^3 - D*t^3)*transverseK)/
        (16*Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^4 - 6*Q^2*s - 2*s^2 - 8*Q^2*t + 2*D*Q^2*t + 6*s*t - D*s*t + 
           6*t^2 - D*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(-4*Q^4 - 6*Q^2*s - 2*s^2 - 12*Q^2*t + 2*D*Q^2*t - 
           6*s*t + D*s*t - 2*t^2 + D*t^2)*transverseK)/(Q*s*SUNN^2*t^2*
          (Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 16*Q^4*t + 2*D*Q^4*t - 
           10*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - D*s^2*t - 18*Q^2*t^2 + 
           3*D*Q^2*t^2 + 6*s*t^2 - D*s*t^2)*transverseK)/
         (Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^4 - 6*Q^2*s - 
          2*s^2 - 8*Q^2*t + 2*D*Q^2*t + 6*s*t - D*s*t + 6*t^2 - D*t^2)*
         transverseK)/(16*Q*s*SUNN^2*t^2)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 + 4*s - D*s + 6*t - D*t)*transverseK)/
        (16*Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 1, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^8 - 32*Q^6*s - 
          46*Q^4*s^2 - 28*Q^2*s^3 - 6*s^4 - 28*Q^6*t + 4*D*Q^6*t - 
          74*Q^4*s*t + 8*D*Q^4*s*t - 54*Q^2*s^2*t + 3*D*Q^2*s^2*t - 8*s^3*t - 
          D*s^3*t - 12*Q^4*t^2 - 24*Q^2*s*t^2 - 2*D*s^2*t^2 + 6*Q^2*t^3 - 
          3*D*Q^2*t^3 + 2*s*t^3 - D*s*t^3)*transverseK)/
        (Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 16*Q^4*t + 2*D*Q^4*t - 14*Q^2*s*t + D*Q^2*s*t + 
          2*s^2*t - D*s^2*t + 6*Q^2*t^2 - 3*D*Q^2*t^2 + 2*s*t^2 - D*s*t^2)*
         transverseK)/(Q*s^2*SUNN^2*t^2), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 20*Q^4*t + 2*D*Q^4*t - 30*Q^2*s*t + 
          3*D*Q^2*s*t - 10*s^2*t + D*s^2*t - 18*Q^2*t^2 + 3*D*Q^2*t^2 - 
          6*s*t^2 + D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/16)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 8*Q^4*t + 
          2*D*Q^4*t - 6*Q^2*s*t + D*Q^2*s*t + 2*s^2*t - D*s^2*t - 2*Q^2*t^2 + 
          D*Q^2*t^2 + 2*s*t^2 - D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 16*Q^4*t + 2*D*Q^4*t - 14*Q^2*s*t + D*Q^2*s*t + 
          2*s^2*t - D*s^2*t + 6*Q^2*t^2 - 3*D*Q^2*t^2 + 2*s*t^2 - D*s*t^2)*
         transverseK)/(Q*s*SUNN^2*t^2)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(6*Q^4 + 2*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 - 6*Q^2*t + 
          3*D*Q^2*t - 2*s*t + D*s*t)*transverseK)/(Q*s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 2, 3}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (8*Q^8 + 32*Q^6*s + 46*Q^4*s^2 + 28*Q^2*s^3 + 6*s^4 - 12*Q^6*t + 
           4*D*Q^6*t - 30*Q^4*s*t + 12*D*Q^4*s*t - 8*Q^2*s^2*t + 
           9*D*Q^2*s^2*t + 10*s^3*t + D*s^3*t - 20*Q^4*t^2 + 4*D*Q^4*t^2 - 
           36*Q^2*s*t^2 + 8*D*Q^2*s*t^2 + 2*D*s^2*t^2 + 4*Q^2*t^3 - 
           D*Q^2*t^3 - 4*s*t^3 + D*s*t^3)*transverseK)/(Q*s^2*SUNN^2*t^2*
          (Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 
          2*s^3 - 12*Q^4*t + 2*D*Q^4*t - 12*Q^2*s*t + 3*D*Q^2*s*t + D*s^2*t + 
          4*Q^2*t^2 - D*Q^2*t^2 - 4*s*t^2 + D*s*t^2)*transverseK)/
        (16*Q*s^2*SUNN^2*t^2), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 
          2*s^3 - 8*Q^4*t + 2*D*Q^4*t + D*Q^2*s*t + 8*s^2*t - D*s^2*t - 
          8*Q^2*t^2 + D*Q^2*t^2 + 8*s*t^2 - D*s*t^2)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 
          8*Q^2*s^2 + 2*s^3 - 4*Q^4*t + 2*D*Q^4*t - 4*Q^2*s*t + 3*D*Q^2*s*t + 
          D*s^2*t - 12*Q^2*t^2 + 3*D*Q^2*t^2 - 4*s*t^2 + D*s*t^2)*
         transverseK)/(16*Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 - 12*Q^4*t + 2*D*Q^4*t - 
           12*Q^2*s*t + 3*D*Q^2*s*t + D*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2 - 
           4*s*t^2 + D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + 4*Q^2*s - D*Q^2*s + 
          2*s^2 - D*s^2 - 4*Q^2*t + D*Q^2*t + 4*s*t - D*s*t)*transverseK)/
        (16*Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 3, 2}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^8 - 32*Q^6*s - 
           46*Q^4*s^2 - 28*Q^2*s^3 - 6*s^4 - 20*Q^6*t + 4*D*Q^6*t - 
           66*Q^4*s*t + 12*D*Q^4*s*t - 64*Q^2*s^2*t + 9*D*Q^2*s^2*t - 
           18*s^3*t + D*s^3*t - 12*Q^4*t^2 + 4*D*Q^4*t^2 - 28*Q^2*s*t^2 + 
           8*D*Q^2*s*t^2 - 16*s^2*t^2 + 2*D*s^2*t^2 + 4*Q^2*t^3 - D*Q^2*t^3 - 
           4*s*t^3 + D*s*t^3)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 4*Q^4*t + 2*D*Q^4*t - 
          12*Q^2*s*t + 3*D*Q^2*s*t - 8*s^2*t + D*s^2*t + 4*Q^2*t^2 - 
          D*Q^2*t^2 - 4*s*t^2 + D*s*t^2)*transverseK)/(16*Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 - 10*Q^4*s - 8*Q^2*s^2 - 2*s^3 - 8*Q^4*t + 2*D*Q^4*t - 
          8*Q^2*s*t + D*Q^2*s*t - D*s^2*t + D*Q^2*t^2 - D*s*t^2)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
          8*Q^2*s^2 - 2*s^3 - 12*Q^4*t + 2*D*Q^4*t - 20*Q^2*s*t + 
          3*D*Q^2*s*t - 8*s^2*t + D*s^2*t - 12*Q^2*t^2 + 3*D*Q^2*t^2 - 
          4*s*t^2 + D*s*t^2)*transverseK)/(16*Q*s^2*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 10*Q^4*s - 
           8*Q^2*s^2 - 2*s^3 - 4*Q^4*t + 2*D*Q^4*t - 12*Q^2*s*t + 
           3*D*Q^2*s*t - 8*s^2*t + D*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2 - 
           4*s*t^2 + D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 - 4*Q^2*s + 
           D*Q^2*s - 6*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t)*
          transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 4, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^8 + 32*Q^6*s + 
          46*Q^4*s^2 + 28*Q^2*s^3 + 6*s^4 - 4*Q^6*t + 4*D*Q^6*t + 
          10*Q^4*s*t + 8*D*Q^4*s*t + 30*Q^2*s^2*t + 3*D*Q^2*s^2*t + 
          16*s^3*t - D*s^3*t + 12*Q^4*t^2 + 24*Q^2*s*t^2 + 16*s^2*t^2 - 
          2*D*s^2*t^2 + 18*Q^2*t^3 - 3*D*Q^2*t^3 + 6*s*t^3 - D*s*t^3)*
         transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 2*D*Q^4*t + 
          6*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - D*s^2*t + 18*Q^2*t^2 - 
          3*D*Q^2*t^2 + 6*s*t^2 - D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 
          2*D*Q^4*t + 6*Q^2*s*t + 3*D*Q^2*s*t + 2*s^2*t + D*s^2*t - 
          6*Q^2*t^2 + 3*D*Q^2*t^2 - 2*s*t^2 + D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-1/16*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 - 8*Q^4*t + 2*D*Q^4*t - 
          2*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - D*s^2*t - 6*Q^2*t^2 + D*Q^2*t^2 + 
          6*s*t^2 - D*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 2*D*Q^4*t + 6*Q^2*s*t + 
          D*Q^2*s*t + 6*s^2*t - D*s^2*t + 18*Q^2*t^2 - 3*D*Q^2*t^2 + 
          6*s*t^2 - D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^4 + 10*Q^2*s - 
          D*Q^2*s + 4*s^2 - D*s^2 + 18*Q^2*t - 3*D*Q^2*t + 6*s*t - D*s*t)*
         transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 1, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 - 18*Q^4*s - 
          22*Q^2*s^2 - 8*s^3 - 10*Q^4*t + 2*D*Q^4*t - 16*Q^2*s*t + 
          3*D*Q^2*s*t + 2*Q^2*t^2 - D*Q^2*t^2))/(s^2*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^6 - 16*Q^4*s - 14*Q^2*s^2 - 4*s^3 - 8*Q^4*t + 
          D*Q^4*t - 8*Q^2*s*t + D*Q^2*s*t + 2*Q^2*t^2 - D*Q^2*t^2))/
        (s^2*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^4 - 10*Q^2*s - 
          4*s^2 - 6*Q^2*t + D*Q^2*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/8*I)*(-2 + D)*Q^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 + 2*s - 2*t + D*t))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-6*Q^6 - 16*Q^4*s - 14*Q^2*s^2 - 4*s^3 - 8*Q^4*t + D*Q^4*t - 
          8*Q^2*s*t + D*Q^2*s*t + 2*Q^2*t^2 - D*Q^2*t^2))/
        (s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 
          4*Q^2*s*t - 2*Q^2*t^2 + D*Q^2*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 2, 3}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-8*Q^4 + 2*D*Q^4 - 20*Q^2*s + 5*D*Q^2*s - 12*s^2 + 3*D*s^2 - 
           8*Q^2*t + D*Q^2*t - 16*s*t + 2*D*s*t + 4*t^2 - D*t^2))/
         (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 
          2*D*Q^2*s - 4*s^2 + D*s^2 - 4*Q^2*t - 4*s*t + 4*t^2 - D*t^2))/
        (8*s*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^2 + D*Q^2 - 4*s + D*s - 
          8*t + D*t))/(8*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        (8*s*SUNN^2*t), GLI["V09", {0, 0, 1, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^4 + D*Q^4 - 8*Q^2*s + 
           2*D*Q^2*s - 4*s^2 + D*s^2 - 4*Q^2*t - 4*s*t + 4*t^2 - D*t^2))/
         ((Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 + D*Q^2 - 2*s + D*s - 4*t + D*t))/(8*(Q^2 + s)*SUNN^2)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 3, 2}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-8*Q^4 + 2*D*Q^4 - 20*Q^2*s + 5*D*Q^2*s - 12*s^2 + 3*D*s^2 + 
           D*Q^2*t + 2*D*s*t + 4*t^2 - D*t^2))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 4*Q^2*t + 
          4*s*t + 4*t^2 - D*t^2))/(8*s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^2 + D*Q^2 - 4*s + D*s + D*t))/(8*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((-4 + D)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t))/(8*s*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^4 + D*Q^4 - 8*Q^2*s + 2*D*Q^2*s - 4*s^2 + D*s^2 + 4*Q^2*t + 
           4*s*t + 4*t^2 - D*t^2))/((Q^2 + s)*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^2 + D*Q^2 - 6*s + D*s - 
          4*t + D*t))/(8*(Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 4, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 18*Q^4*s + 
          22*Q^2*s^2 + 8*s^3 - 6*Q^4*t + 2*D*Q^4*t - 8*Q^2*s*t + 
          3*D*Q^2*s*t + 6*Q^2*t^2 - D*Q^2*t^2))/(s^2*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (6*Q^6 + 16*Q^4*s + 14*Q^2*s^2 + 4*s^3 + D*Q^4*t + D*Q^2*s*t + 
          6*Q^2*t^2 - D*Q^2*t^2))/(s^2*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (6*Q^4 + 10*Q^2*s + 4*s^2 - 2*Q^2*t + D*Q^2*t))/
        (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*Q^2*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^2 - 2*s - 6*t + 
          D*t))/(s^2*SUNN^2*t), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(6*Q^6 + 16*Q^4*s + 
          14*Q^2*s^2 + 4*s^3 + D*Q^4*t + D*Q^2*s*t + 6*Q^2*t^2 - D*Q^2*t^2))/
        (s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^6 + 10*Q^4*s + 8*Q^2*s^2 + 2*s^3 + 4*Q^4*t + 
          4*Q^2*s*t + 6*Q^2*t^2 - D*Q^2*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonMetricD", "Index" -> {}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^4 - 4*D*Q^4 - 
          24*hIn*hOut*Q^4 + 4*D*hIn*hOut*Q^4 + 52*Q^2*s - 30*D*Q^2*s + 
          2*D^2*Q^2*s - 28*hIn*hOut*Q^2*s - 10*D*hIn*hOut*Q^2*s + 
          2*D^2*hIn*hOut*Q^2*s + 52*s^2 - 32*D*s^2 + 3*D^2*s^2 + 
          36*hIn*hOut*s^2 - 28*D*hIn*hOut*s^2 + 3*D^2*hIn*hOut*s^2 + 
          20*Q^2*t - 14*D*Q^2*t + 2*D^2*Q^2*t + 36*hIn*hOut*Q^2*t - 
          18*D*hIn*hOut*Q^2*t + 2*D^2*hIn*hOut*Q^2*t + 32*s*t - 20*D*s*t + 
          2*D^2*s*t - 16*hIn*hOut*s*t - 8*D*hIn*hOut*s*t + 
          2*D^2*hIn*hOut*s*t - 4*t^2 + 4*D*t^2 - D^2*t^2 - 36*hIn*hOut*t^2 + 
          12*D*hIn*hOut*t^2 - D^2*hIn*hOut*t^2 + 16*Q^4*xIn*xOut - 
          4*D*Q^4*xIn*xOut + 112*Q^2*s*xIn*xOut - 38*D*Q^2*s*xIn*xOut + 
          2*D^2*Q^2*s*xIn*xOut + 116*s^2*xIn*xOut - 44*D*s^2*xIn*xOut + 
          3*D^2*s^2*xIn*xOut + 56*Q^2*t*xIn*xOut - 22*D*Q^2*t*xIn*xOut + 
          2*D^2*Q^2*t*xIn*xOut + 84*s*t*xIn*xOut - 28*D*s*t*xIn*xOut + 
          2*D^2*s*t*xIn*xOut - 16*t^2*xIn*xOut + 8*D*t^2*xIn*xOut - 
          D^2*t^2*xIn*xOut - 16*Q^4*yIn*yOut + 4*D*Q^4*yIn*yOut - 
          32*Q^2*s*yIn*yOut - 2*D*Q^2*s*yIn*yOut + 2*D^2*Q^2*s*yIn*yOut + 
          4*s^2*yIn*yOut - 16*D*s^2*yIn*yOut + 3*D^2*s^2*yIn*yOut + 
          8*Q^2*t*yIn*yOut - 10*D*Q^2*t*yIn*yOut + 2*D^2*Q^2*t*yIn*yOut - 
          28*s*t*yIn*yOut + 2*D^2*s*t*yIn*yOut - 16*t^2*yIn*yOut + 
          8*D*t^2*yIn*yOut - D^2*t^2*yIn*yOut))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (12*Q^4 - 6*D*Q^4 - 36*hIn*hOut*Q^4 + 6*D*hIn*hOut*Q^4 + 32*Q^2*s - 
          18*D*Q^2*s + D^2*Q^2*s - 32*hIn*hOut*Q^2*s - 2*D*hIn*hOut*Q^2*s + 
          D^2*hIn*hOut*Q^2*s + 20*s^2 - 12*D*s^2 + D^2*s^2 + 4*hIn*hOut*s^2 - 
          8*D*hIn*hOut*s^2 + D^2*hIn*hOut*s^2 + 16*Q^2*t - 10*D*Q^2*t + 
          D^2*Q^2*t - 6*D*hIn*hOut*Q^2*t + D^2*hIn*hOut*Q^2*t + 8*s*t - 
          4*D*s*t - 40*hIn*hOut*s*t + 8*D*hIn*hOut*s*t - 4*t^2 + 4*D*t^2 - 
          D^2*t^2 - 36*hIn*hOut*t^2 + 12*D*hIn*hOut*t^2 - D^2*hIn*hOut*t^2 + 
          24*Q^4*xIn*xOut - 6*D*Q^4*xIn*xOut + 68*Q^2*s*xIn*xOut - 
          22*D*Q^2*s*xIn*xOut + D^2*Q^2*s*xIn*xOut + 44*s^2*xIn*xOut - 
          16*D*s^2*xIn*xOut + D^2*s^2*xIn*xOut + 40*Q^2*t*xIn*xOut - 
          14*D*Q^2*t*xIn*xOut + D^2*Q^2*t*xIn*xOut + 20*s*t*xIn*xOut - 
          4*D*s*t*xIn*xOut - 16*t^2*xIn*xOut + 8*D*t^2*xIn*xOut - 
          D^2*t^2*xIn*xOut - 24*Q^4*yIn*yOut + 6*D*Q^4*yIn*yOut - 
          28*Q^2*s*yIn*yOut + 2*D*Q^2*s*yIn*yOut + D^2*Q^2*s*yIn*yOut - 
          4*s^2*yIn*yOut - 4*D*s^2*yIn*yOut + D^2*s^2*yIn*yOut - 
          8*Q^2*t*yIn*yOut - 2*D*Q^2*t*yIn*yOut + D^2*Q^2*t*yIn*yOut - 
          28*s*t*yIn*yOut + 8*D*s*t*yIn*yOut - 16*t^2*yIn*yOut + 
          8*D*t^2*yIn*yOut - D^2*t^2*yIn*yOut))/(s^2*SUNN^2*t), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (12*Q^2 - 6*D*Q^2 - 36*hIn*hOut*Q^2 + 6*D*hIn*hOut*Q^2 + 20*s - 
          12*D*s + D^2*s + 4*hIn*hOut*s - 8*D*hIn*hOut*s + D^2*hIn*hOut*s + 
          12*t - 8*D*t + D^2*t + 12*hIn*hOut*t - 8*D*hIn*hOut*t + 
          D^2*hIn*hOut*t + 24*Q^2*xIn*xOut - 6*D*Q^2*xIn*xOut + 
          44*s*xIn*xOut - 16*D*s*xIn*xOut + D^2*s*xIn*xOut + 32*t*xIn*xOut - 
          12*D*t*xIn*xOut + D^2*t*xIn*xOut - 24*Q^2*yIn*yOut + 
          6*D*Q^2*yIn*yOut - 4*s*yIn*yOut - 4*D*s*yIn*yOut + D^2*s*yIn*yOut - 
          4*D*t*yIn*yOut + D^2*t*yIn*yOut))/(s*SUNN^2*t), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^4 + 2*D*Q^4 + 12*hIn*hOut*Q^4 - 2*D*hIn*hOut*Q^4 + 8*Q^2*s - 
          6*D*Q^2*s + D^2*Q^2*s + 40*hIn*hOut*Q^2*s - 14*D*hIn*hOut*Q^2*s + 
          D^2*hIn*hOut*Q^2*s + 12*s^2 - 8*D*s^2 + D^2*s^2 + 28*hIn*hOut*s^2 - 
          12*D*hIn*hOut*s^2 + D^2*hIn*hOut*s^2 + 4*Q^2*t - 4*D*Q^2*t + 
          D^2*Q^2*t + 36*hIn*hOut*Q^2*t - 12*D*hIn*hOut*Q^2*t + 
          D^2*hIn*hOut*Q^2*t + 12*s*t - 8*D*s*t + D^2*s*t + 12*hIn*hOut*s*t - 
          8*D*hIn*hOut*s*t + D^2*hIn*hOut*s*t - 8*Q^4*xIn*xOut + 
          2*D*Q^4*xIn*xOut + 20*Q^2*s*xIn*xOut - 10*D*Q^2*s*xIn*xOut + 
          D^2*Q^2*s*xIn*xOut + 28*s^2*xIn*xOut - 12*D*s^2*xIn*xOut + 
          D^2*s^2*xIn*xOut + 16*Q^2*t*xIn*xOut - 8*D*Q^2*t*xIn*xOut + 
          D^2*Q^2*t*xIn*xOut + 32*s*t*xIn*xOut - 12*D*s*t*xIn*xOut + 
          D^2*s*t*xIn*xOut + 8*Q^4*yIn*yOut - 2*D*Q^4*yIn*yOut + 
          20*Q^2*s*yIn*yOut - 10*D*Q^2*s*yIn*yOut + D^2*Q^2*s*yIn*yOut + 
          12*s^2*yIn*yOut - 8*D*s^2*yIn*yOut + D^2*s^2*yIn*yOut + 
          16*Q^2*t*yIn*yOut - 8*D*Q^2*t*yIn*yOut + D^2*Q^2*t*yIn*yOut - 
          4*D*s*t*yIn*yOut + D^2*s*t*yIn*yOut))/(s^2*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(12*Q^4 - 6*D*Q^4 - 36*hIn*hOut*Q^4 + 
          6*D*hIn*hOut*Q^4 + 32*Q^2*s - 18*D*Q^2*s + D^2*Q^2*s - 
          32*hIn*hOut*Q^2*s - 2*D*hIn*hOut*Q^2*s + D^2*hIn*hOut*Q^2*s + 
          20*s^2 - 12*D*s^2 + D^2*s^2 + 4*hIn*hOut*s^2 - 8*D*hIn*hOut*s^2 + 
          D^2*hIn*hOut*s^2 + 16*Q^2*t - 10*D*Q^2*t + D^2*Q^2*t - 
          6*D*hIn*hOut*Q^2*t + D^2*hIn*hOut*Q^2*t + 8*s*t - 4*D*s*t - 
          40*hIn*hOut*s*t + 8*D*hIn*hOut*s*t - 4*t^2 + 4*D*t^2 - D^2*t^2 - 
          36*hIn*hOut*t^2 + 12*D*hIn*hOut*t^2 - D^2*hIn*hOut*t^2 + 
          24*Q^4*xIn*xOut - 6*D*Q^4*xIn*xOut + 68*Q^2*s*xIn*xOut - 
          22*D*Q^2*s*xIn*xOut + D^2*Q^2*s*xIn*xOut + 44*s^2*xIn*xOut - 
          16*D*s^2*xIn*xOut + D^2*s^2*xIn*xOut + 40*Q^2*t*xIn*xOut - 
          14*D*Q^2*t*xIn*xOut + D^2*Q^2*t*xIn*xOut + 20*s*t*xIn*xOut - 
          4*D*s*t*xIn*xOut - 16*t^2*xIn*xOut + 8*D*t^2*xIn*xOut - 
          D^2*t^2*xIn*xOut - 24*Q^4*yIn*yOut + 6*D*Q^4*yIn*yOut - 
          28*Q^2*s*yIn*yOut + 2*D*Q^2*s*yIn*yOut + D^2*Q^2*s*yIn*yOut - 
          4*s^2*yIn*yOut - 4*D*s^2*yIn*yOut + D^2*s^2*yIn*yOut - 
          8*Q^2*t*yIn*yOut - 2*D*Q^2*t*yIn*yOut + D^2*Q^2*t*yIn*yOut - 
          28*s*t*yIn*yOut + 8*D*s*t*yIn*yOut - 16*t^2*yIn*yOut + 
          8*D*t^2*yIn*yOut - D^2*t^2*yIn*yOut))/(s*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^4 + 4*D*Q^4 + 
          24*hIn*hOut*Q^4 - 4*D*hIn*hOut*Q^4 - 12*Q^2*s + 6*D*Q^2*s + 
          36*hIn*hOut*Q^2*s - 6*D*hIn*hOut*Q^2*s - 4*s^2 + 2*D*s^2 + 
          12*hIn*hOut*s^2 - 2*D*hIn*hOut*s^2 - 8*Q^2*t + 4*D*Q^2*t + 
          24*hIn*hOut*Q^2*t - 4*D*hIn*hOut*Q^2*t + 4*s*t - 4*D*s*t + 
          D^2*s*t + 52*hIn*hOut*s*t - 16*D*hIn*hOut*s*t + D^2*hIn*hOut*s*t + 
          4*t^2 - 4*D*t^2 + D^2*t^2 + 36*hIn*hOut*t^2 - 12*D*hIn*hOut*t^2 + 
          D^2*hIn*hOut*t^2 - 16*Q^4*xIn*xOut + 4*D*Q^4*xIn*xOut - 
          24*Q^2*s*xIn*xOut + 6*D*Q^2*s*xIn*xOut - 8*s^2*xIn*xOut + 
          2*D*s^2*xIn*xOut - 16*Q^2*t*xIn*xOut + 4*D*Q^2*t*xIn*xOut + 
          12*s*t*xIn*xOut - 8*D*s*t*xIn*xOut + D^2*s*t*xIn*xOut + 
          16*t^2*xIn*xOut - 8*D*t^2*xIn*xOut + D^2*t^2*xIn*xOut + 
          16*Q^4*yIn*yOut - 4*D*Q^4*yIn*yOut + 24*Q^2*s*yIn*yOut - 
          6*D*Q^2*s*yIn*yOut + 8*s^2*yIn*yOut - 2*D*s^2*yIn*yOut + 
          16*Q^2*t*yIn*yOut - 4*D*Q^2*t*yIn*yOut + 28*s*t*yIn*yOut - 
          12*D*s*t*yIn*yOut + D^2*s*t*yIn*yOut + 16*t^2*yIn*yOut - 
          8*D*t^2*yIn*yOut + D^2*t^2*yIn*yOut))/(s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonWardLeft", "Index" -> {1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^4 - 4*hIn*hOut*Q^4 - 10*Q^2*s - 10*hIn*hOut*Q^2*s - 6*s^2 - 
          6*hIn*hOut*s^2 + 2*Q^2*t - 2*D*Q^2*t - 14*hIn*hOut*Q^2*t + 
          2*D*hIn*hOut*Q^2*t - 4*s*t - D*s*t - 12*hIn*hOut*s*t + 
          D*hIn*hOut*s*t + 2*t^2 - D*t^2 - 6*hIn*hOut*t^2 + D*hIn*hOut*t^2 - 
          4*Q^4*xIn*xOut - 10*Q^2*s*xIn*xOut - 6*s^2*xIn*xOut + 
          6*Q^2*t*xIn*xOut - 2*D*Q^2*t*xIn*xOut - 2*s*t*xIn*xOut - 
          D*s*t*xIn*xOut + 4*t^2*xIn*xOut - D*t^2*xIn*xOut - 4*Q^4*yIn*yOut - 
          10*Q^2*s*yIn*yOut - 6*s^2*yIn*yOut - 10*Q^2*t*yIn*yOut + 
          2*D*Q^2*t*yIn*yOut - 10*s*t*yIn*yOut + D*s*t*yIn*yOut - 
          4*t^2*yIn*yOut + D*t^2*yIn*yOut))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/4)*(-2 + D)*Q*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t)*(-2*Q^2 - 2*hIn*hOut*Q^2 - 2*s - 
          2*hIn*hOut*s + 2*t - D*t - 6*hIn*hOut*t + D*hIn*hOut*t - 
          2*Q^2*xIn*xOut - 2*s*xIn*xOut + 4*t*xIn*xOut - D*t*xIn*xOut - 
          2*Q^2*yIn*yOut - 2*s*yIn*yOut - 4*t*yIn*yOut + D*t*yIn*yOut))/
        (s*(Q^2 + s)*SUNN^2*t), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-1/4*I)*(-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^2 + 2*hIn*hOut*Q^2 + 2*s + 2*hIn*hOut*s + 6*t - D*t - 
          2*hIn*hOut*t + D*hIn*hOut*t + 2*Q^2*xIn*xOut + 2*s*xIn*xOut + 
          8*t*xIn*xOut - D*t*xIn*xOut + 2*Q^2*yIn*yOut + 2*s*yIn*yOut + 
          D*t*yIn*yOut))/((Q^2 + s)*SUNN^2*t), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/4)*(-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 - 2*hIn*hOut*Q^2 - 2*s - 2*hIn*hOut*s + 2*t - D*t - 
          6*hIn*hOut*t + D*hIn*hOut*t - 2*Q^2*xIn*xOut - 2*s*xIn*xOut + 
          4*t*xIn*xOut - D*t*xIn*xOut - 2*Q^2*yIn*yOut - 2*s*yIn*yOut - 
          4*t*yIn*yOut + D*t*yIn*yOut))/(s*SUNN^2*t), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*Q*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t)*(-2*Q^2 - 2*hIn*hOut*Q^2 - 2*s - 
          2*hIn*hOut*s + 2*t - D*t - 6*hIn*hOut*t + D*hIn*hOut*t - 
          2*Q^2*xIn*xOut - 2*s*xIn*xOut + 4*t*xIn*xOut - D*t*xIn*xOut - 
          2*Q^2*yIn*yOut - 2*s*yIn*yOut - 4*t*yIn*yOut + D*t*yIn*yOut))/
        ((Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*Q*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t)*(2 - D - 6*hIn*hOut + D*hIn*hOut + 
          4*xIn*xOut - D*xIn*xOut - 4*yIn*yOut + D*yIn*yOut))/
        ((Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonWardLeft", "Index" -> {2}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         (8*Q^8 + 8*hIn*hOut*Q^8 + 32*Q^6*s + 32*hIn*hOut*Q^6*s + 
          46*Q^4*s^2 + 46*hIn*hOut*Q^4*s^2 + 28*Q^2*s^3 + 
          28*hIn*hOut*Q^2*s^3 + 6*s^4 + 6*hIn*hOut*s^4 + 12*Q^6*t + 
          12*hIn*hOut*Q^6*t + 38*Q^4*s*t - 2*D*Q^4*s*t + 22*hIn*hOut*Q^4*s*
           t + 2*D*hIn*hOut*Q^4*s*t + 30*Q^2*s^2*t - 3*D*Q^2*s^2*t + 
          6*hIn*hOut*Q^2*s^2*t + 3*D*hIn*hOut*Q^2*s^2*t + 4*s^3*t - D*s^3*t - 
          4*hIn*hOut*s^3*t + D*hIn*hOut*s^3*t + 2*D*Q^4*t^2 + 
          16*hIn*hOut*Q^4*t^2 - 2*D*hIn*hOut*Q^4*t^2 + 12*Q^2*s*t^2 - 
          2*D*Q^2*s*t^2 - 4*hIn*hOut*Q^2*s*t^2 + 2*D*hIn*hOut*Q^2*s*t^2 - 
          2*D*s^2*t^2 - 16*hIn*hOut*s^2*t^2 + 2*D*hIn*hOut*s^2*t^2 - 
          2*Q^2*t^3 + D*Q^2*t^3 + 6*hIn*hOut*Q^2*t^3 - D*hIn*hOut*Q^2*t^3 + 
          2*s*t^3 - D*s*t^3 - 6*hIn*hOut*s*t^3 + D*hIn*hOut*s*t^3 + 
          8*Q^8*xIn*xOut + 32*Q^6*s*xIn*xOut + 46*Q^4*s^2*xIn*xOut + 
          28*Q^2*s^3*xIn*xOut + 6*s^4*xIn*xOut + 12*Q^6*t*xIn*xOut + 
          42*Q^4*s*t*xIn*xOut - 2*D*Q^4*s*t*xIn*xOut + 36*Q^2*s^2*t*xIn*
           xOut - 3*D*Q^2*s^2*t*xIn*xOut + 6*s^3*t*xIn*xOut - 
          D*s^3*t*xIn*xOut - 4*Q^4*t^2*xIn*xOut + 2*D*Q^4*t^2*xIn*xOut + 
          16*Q^2*s*t^2*xIn*xOut - 2*D*Q^2*s*t^2*xIn*xOut + 
          4*s^2*t^2*xIn*xOut - 2*D*s^2*t^2*xIn*xOut - 4*Q^2*t^3*xIn*xOut + 
          D*Q^2*t^3*xIn*xOut + 4*s*t^3*xIn*xOut - D*s*t^3*xIn*xOut + 
          8*Q^8*yIn*yOut + 32*Q^6*s*yIn*yOut + 46*Q^4*s^2*yIn*yOut + 
          28*Q^2*s^3*yIn*yOut + 6*s^4*yIn*yOut + 12*Q^6*t*yIn*yOut + 
          26*Q^4*s*t*yIn*yOut + 2*D*Q^4*s*t*yIn*yOut + 12*Q^2*s^2*t*yIn*
           yOut + 3*D*Q^2*s^2*t*yIn*yOut - 2*s^3*t*yIn*yOut + 
          D*s^3*t*yIn*yOut + 12*Q^4*t^2*yIn*yOut - 2*D*Q^4*t^2*yIn*yOut + 
          2*D*Q^2*s*t^2*yIn*yOut - 12*s^2*t^2*yIn*yOut + 
          2*D*s^2*t^2*yIn*yOut + 4*Q^2*t^3*yIn*yOut - D*Q^2*t^3*yIn*yOut - 
          4*s*t^3*yIn*yOut + D*s*t^3*yIn*yOut))/(s^2*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         (4*Q^6 + 4*hIn*hOut*Q^6 + 10*Q^4*s + 10*hIn*hOut*Q^4*s + 8*Q^2*s^2 + 
          8*hIn*hOut*Q^2*s^2 + 2*s^3 + 2*hIn*hOut*s^3 + 4*Q^4*t + 
          4*hIn*hOut*Q^4*t + 6*Q^2*s*t - D*Q^2*s*t - 2*hIn*hOut*Q^2*s*t + 
          D*hIn*hOut*Q^2*s*t + 2*s^2*t - D*s^2*t - 6*hIn*hOut*s^2*t + 
          D*hIn*hOut*s^2*t - 2*Q^2*t^2 + D*Q^2*t^2 + 6*hIn*hOut*Q^2*t^2 - 
          D*hIn*hOut*Q^2*t^2 + 2*s*t^2 - D*s*t^2 - 6*hIn*hOut*s*t^2 + 
          D*hIn*hOut*s*t^2 + 4*Q^6*xIn*xOut + 10*Q^4*s*xIn*xOut + 
          8*Q^2*s^2*xIn*xOut + 2*s^3*xIn*xOut + 4*Q^4*t*xIn*xOut + 
          8*Q^2*s*t*xIn*xOut - D*Q^2*s*t*xIn*xOut + 4*s^2*t*xIn*xOut - 
          D*s^2*t*xIn*xOut - 4*Q^2*t^2*xIn*xOut + D*Q^2*t^2*xIn*xOut + 
          4*s*t^2*xIn*xOut - D*s*t^2*xIn*xOut + 4*Q^6*yIn*yOut + 
          10*Q^4*s*yIn*yOut + 8*Q^2*s^2*yIn*yOut + 2*s^3*yIn*yOut + 
          4*Q^4*t*yIn*yOut + D*Q^2*s*t*yIn*yOut - 4*s^2*t*yIn*yOut + 
          D*s^2*t*yIn*yOut + 4*Q^2*t^2*yIn*yOut - D*Q^2*t^2*yIn*yOut - 
          4*s*t^2*yIn*yOut + D*s*t^2*yIn*yOut))/(s^2*SUNN^2*t^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         transverseK*(-4*Q^6 - 4*hIn*hOut*Q^6 - 10*Q^4*s - 
          10*hIn*hOut*Q^4*s - 8*Q^2*s^2 - 8*hIn*hOut*Q^2*s^2 - 2*s^3 - 
          2*hIn*hOut*s^3 - 8*Q^4*t - 8*hIn*hOut*Q^4*t - 6*Q^2*s*t - 
          D*Q^2*s*t - 14*hIn*hOut*Q^2*s*t + D*hIn*hOut*Q^2*s*t + 2*s^2*t - 
          D*s^2*t - 6*hIn*hOut*s^2*t + D*hIn*hOut*s^2*t - 6*Q^2*t^2 + 
          D*Q^2*t^2 + 2*hIn*hOut*Q^2*t^2 - D*hIn*hOut*Q^2*t^2 + 6*s*t^2 - 
          D*s*t^2 - 2*hIn*hOut*s*t^2 + D*hIn*hOut*s*t^2 - 4*Q^6*xIn*xOut - 
          10*Q^4*s*xIn*xOut - 8*Q^2*s^2*xIn*xOut - 2*s^3*xIn*xOut - 
          8*Q^4*t*xIn*xOut - 4*Q^2*s*t*xIn*xOut - D*Q^2*s*t*xIn*xOut + 
          4*s^2*t*xIn*xOut - D*s^2*t*xIn*xOut - 8*Q^2*t^2*xIn*xOut + 
          D*Q^2*t^2*xIn*xOut + 8*s*t^2*xIn*xOut - D*s*t^2*xIn*xOut - 
          4*Q^6*yIn*yOut - 10*Q^4*s*yIn*yOut - 8*Q^2*s^2*yIn*yOut - 
          2*s^3*yIn*yOut - 8*Q^4*t*yIn*yOut - 12*Q^2*s*t*yIn*yOut + 
          D*Q^2*s*t*yIn*yOut - 4*s^2*t*yIn*yOut + D*s^2*t*yIn*yOut - 
          D*Q^2*t^2*yIn*yOut + D*s*t^2*yIn*yOut))/(s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         (4*Q^6 + 4*hIn*hOut*Q^6 + 10*Q^4*s + 10*hIn*hOut*Q^4*s + 8*Q^2*s^2 + 
          8*hIn*hOut*Q^2*s^2 + 2*s^3 + 2*hIn*hOut*s^3 + 4*Q^4*t + 
          4*hIn*hOut*Q^4*t + 6*Q^2*s*t - D*Q^2*s*t - 2*hIn*hOut*Q^2*s*t + 
          D*hIn*hOut*Q^2*s*t + 2*s^2*t - D*s^2*t - 6*hIn*hOut*s^2*t + 
          D*hIn*hOut*s^2*t - 2*Q^2*t^2 + D*Q^2*t^2 + 6*hIn*hOut*Q^2*t^2 - 
          D*hIn*hOut*Q^2*t^2 + 2*s*t^2 - D*s*t^2 - 6*hIn*hOut*s*t^2 + 
          D*hIn*hOut*s*t^2 + 4*Q^6*xIn*xOut + 10*Q^4*s*xIn*xOut + 
          8*Q^2*s^2*xIn*xOut + 2*s^3*xIn*xOut + 4*Q^4*t*xIn*xOut + 
          8*Q^2*s*t*xIn*xOut - D*Q^2*s*t*xIn*xOut + 4*s^2*t*xIn*xOut - 
          D*s^2*t*xIn*xOut - 4*Q^2*t^2*xIn*xOut + D*Q^2*t^2*xIn*xOut + 
          4*s*t^2*xIn*xOut - D*s*t^2*xIn*xOut + 4*Q^6*yIn*yOut + 
          10*Q^4*s*yIn*yOut + 8*Q^2*s^2*yIn*yOut + 2*s^3*yIn*yOut + 
          4*Q^4*t*yIn*yOut + D*Q^2*s*t*yIn*yOut - 4*s^2*t*yIn*yOut + 
          D*s^2*t*yIn*yOut + 4*Q^2*t^2*yIn*yOut - D*Q^2*t^2*yIn*yOut - 
          4*s*t^2*yIn*yOut + D*s*t^2*yIn*yOut))/(s^2*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         (4*Q^6 + 4*hIn*hOut*Q^6 + 10*Q^4*s + 10*hIn*hOut*Q^4*s + 8*Q^2*s^2 + 
          8*hIn*hOut*Q^2*s^2 + 2*s^3 + 2*hIn*hOut*s^3 + 4*Q^4*t + 
          4*hIn*hOut*Q^4*t + 6*Q^2*s*t - D*Q^2*s*t - 2*hIn*hOut*Q^2*s*t + 
          D*hIn*hOut*Q^2*s*t + 2*s^2*t - D*s^2*t - 6*hIn*hOut*s^2*t + 
          D*hIn*hOut*s^2*t - 2*Q^2*t^2 + D*Q^2*t^2 + 6*hIn*hOut*Q^2*t^2 - 
          D*hIn*hOut*Q^2*t^2 + 2*s*t^2 - D*s*t^2 - 6*hIn*hOut*s*t^2 + 
          D*hIn*hOut*s*t^2 + 4*Q^6*xIn*xOut + 10*Q^4*s*xIn*xOut + 
          8*Q^2*s^2*xIn*xOut + 2*s^3*xIn*xOut + 4*Q^4*t*xIn*xOut + 
          8*Q^2*s*t*xIn*xOut - D*Q^2*s*t*xIn*xOut + 4*s^2*t*xIn*xOut - 
          D*s^2*t*xIn*xOut - 4*Q^2*t^2*xIn*xOut + D*Q^2*t^2*xIn*xOut + 
          4*s*t^2*xIn*xOut - D*s*t^2*xIn*xOut + 4*Q^6*yIn*yOut + 
          10*Q^4*s*yIn*yOut + 8*Q^2*s^2*yIn*yOut + 2*s^3*yIn*yOut + 
          4*Q^4*t*yIn*yOut + D*Q^2*s*t*yIn*yOut - 4*s^2*t*yIn*yOut + 
          D*s^2*t*yIn*yOut + 4*Q^2*t^2*yIn*yOut - D*Q^2*t^2*yIn*yOut - 
          4*s*t^2*yIn*yOut + D*s*t^2*yIn*yOut))/(s*SUNN^2*t^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         (2*Q^4 + 2*hIn*hOut*Q^4 + 6*Q^2*s - D*Q^2*s - 2*hIn*hOut*Q^2*s + 
          D*hIn*hOut*Q^2*s + 4*s^2 - D*s^2 - 4*hIn*hOut*s^2 + 
          D*hIn*hOut*s^2 - 2*Q^2*t + D*Q^2*t + 6*hIn*hOut*Q^2*t - 
          D*hIn*hOut*Q^2*t + 2*s*t - D*s*t - 6*hIn*hOut*s*t + 
          D*hIn*hOut*s*t + 2*Q^4*xIn*xOut + 8*Q^2*s*xIn*xOut - 
          D*Q^2*s*xIn*xOut + 6*s^2*xIn*xOut - D*s^2*xIn*xOut - 
          4*Q^2*t*xIn*xOut + D*Q^2*t*xIn*xOut + 4*s*t*xIn*xOut - 
          D*s*t*xIn*xOut + 2*Q^4*yIn*yOut + D*Q^2*s*yIn*yOut - 
          2*s^2*yIn*yOut + D*s^2*yIn*yOut + 4*Q^2*t*yIn*yOut - 
          D*Q^2*t*yIn*yOut - 4*s*t*yIn*yOut + D*s*t*yIn*yOut))/
        (s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonWardLeft", "Index" -> {3}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^2 + s + t)*
         transverseK*(4*hIn*Q^4 + 4*hOut*Q^4 + 10*hIn*Q^2*s + 10*hOut*Q^2*s + 
          6*hIn*s^2 + 6*hOut*s^2 + 4*hIn*Q^2*t + 4*hOut*Q^2*t + 2*hIn*s*t + 
          D*hIn*s*t + 10*hOut*s*t - D*hOut*s*t - 2*hIn*t^2 + D*hIn*t^2 + 
          6*hOut*t^2 - D*hOut*t^2 + (4*I)*Q^4*xOut*yIn + (10*I)*Q^2*s*xOut*
           yIn + (6*I)*s^2*xOut*yIn + (4*I)*Q^2*t*xOut*yIn + 
          (4*I)*s*t*xOut*yIn + I*D*s*t*xOut*yIn - (4*I)*t^2*xOut*yIn + 
          I*D*t^2*xOut*yIn - (4*I)*Q^4*xIn*yOut - (10*I)*Q^2*s*xIn*yOut - 
          (6*I)*s^2*xIn*yOut - (4*I)*Q^2*t*xIn*yOut - (12*I)*s*t*xIn*yOut + 
          I*D*s*t*xIn*yOut - (4*I)*t^2*xIn*yOut + I*D*t^2*xIn*yOut))/
        (8*s^2*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
          (4*hIn*Q^4 + 4*hOut*Q^4 + 6*hIn*Q^2*s + 6*hOut*Q^2*s + 2*hIn*s^2 + 
           2*hOut*s^2 + 4*hIn*Q^2*t + 4*hOut*Q^2*t - 2*hIn*s*t + D*hIn*s*t + 
           6*hOut*s*t - D*hOut*s*t - 2*hIn*t^2 + D*hIn*t^2 + 6*hOut*t^2 - 
           D*hOut*t^2 + (4*I)*Q^4*xOut*yIn + (6*I)*Q^2*s*xOut*yIn + 
           (2*I)*s^2*xOut*yIn + (4*I)*Q^2*t*xOut*yIn + I*D*s*t*xOut*yIn - 
           (4*I)*t^2*xOut*yIn + I*D*t^2*xOut*yIn - (4*I)*Q^4*xIn*yOut - 
           (6*I)*Q^2*s*xIn*yOut - (2*I)*s^2*xIn*yOut - (4*I)*Q^2*t*xIn*yOut - 
           (8*I)*s*t*xIn*yOut + I*D*s*t*xIn*yOut - (4*I)*t^2*xIn*yOut + 
           I*D*t^2*xIn*yOut))/(s^2*SUNN^2*t^2), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         (-4*hIn*Q^4 - 4*hOut*Q^4 - 6*hIn*Q^2*s - 6*hOut*Q^2*s - 2*hIn*s^2 - 
          2*hOut*s^2 - 8*hIn*Q^2*t - 8*hOut*Q^2*t - 10*hIn*s*t + D*hIn*s*t - 
          2*hOut*s*t - D*hOut*s*t - 6*hIn*t^2 + D*hIn*t^2 + 2*hOut*t^2 - 
          D*hOut*t^2 - (4*I)*Q^4*xOut*yIn - (6*I)*Q^2*s*xOut*yIn - 
          (2*I)*s^2*xOut*yIn - (8*I)*Q^2*t*xOut*yIn - (8*I)*s*t*xOut*yIn + 
          I*D*s*t*xOut*yIn - (8*I)*t^2*xOut*yIn + I*D*t^2*xOut*yIn + 
          (4*I)*Q^4*xIn*yOut + (6*I)*Q^2*s*xIn*yOut + (2*I)*s^2*xIn*yOut + 
          (8*I)*Q^2*t*xIn*yOut + I*D*s*t*xIn*yOut + I*D*t^2*xIn*yOut))/
        (8*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
          (4*hIn*Q^4 + 4*hOut*Q^4 + 6*hIn*Q^2*s + 6*hOut*Q^2*s + 2*hIn*s^2 + 
           2*hOut*s^2 + 4*hIn*Q^2*t + 4*hOut*Q^2*t - 2*hIn*s*t + D*hIn*s*t + 
           6*hOut*s*t - D*hOut*s*t - 2*hIn*t^2 + D*hIn*t^2 + 6*hOut*t^2 - 
           D*hOut*t^2 + (4*I)*Q^4*xOut*yIn + (6*I)*Q^2*s*xOut*yIn + 
           (2*I)*s^2*xOut*yIn + (4*I)*Q^2*t*xOut*yIn + I*D*s*t*xOut*yIn - 
           (4*I)*t^2*xOut*yIn + I*D*t^2*xOut*yIn - (4*I)*Q^4*xIn*yOut - 
           (6*I)*Q^2*s*xIn*yOut - (2*I)*s^2*xIn*yOut - (4*I)*Q^2*t*xIn*yOut - 
           (8*I)*s*t*xIn*yOut + I*D*s*t*xIn*yOut - (4*I)*t^2*xIn*yOut + 
           I*D*t^2*xIn*yOut))/(s^2*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*transverseK*(4*hIn*Q^4 + 4*hOut*Q^4 + 6*hIn*Q^2*s + 
          6*hOut*Q^2*s + 2*hIn*s^2 + 2*hOut*s^2 + 4*hIn*Q^2*t + 
          4*hOut*Q^2*t - 2*hIn*s*t + D*hIn*s*t + 6*hOut*s*t - D*hOut*s*t - 
          2*hIn*t^2 + D*hIn*t^2 + 6*hOut*t^2 - D*hOut*t^2 + 
          (4*I)*Q^4*xOut*yIn + (6*I)*Q^2*s*xOut*yIn + (2*I)*s^2*xOut*yIn + 
          (4*I)*Q^2*t*xOut*yIn + I*D*s*t*xOut*yIn - (4*I)*t^2*xOut*yIn + 
          I*D*t^2*xOut*yIn - (4*I)*Q^4*xIn*yOut - (6*I)*Q^2*s*xIn*yOut - 
          (2*I)*s^2*xIn*yOut - (4*I)*Q^2*t*xIn*yOut - (8*I)*s*t*xIn*yOut + 
          I*D*s*t*xIn*yOut - (4*I)*t^2*xIn*yOut + I*D*t^2*xIn*yOut))/
        (8*s*SUNN^2*t^2)|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*transverseK*(2*hIn*Q^2 + 2*hOut*Q^2 - 4*hIn*s + 
          D*hIn*s + 4*hOut*s - D*hOut*s - 2*hIn*t + D*hIn*t + 6*hOut*t - 
          D*hOut*t + (2*I)*Q^2*xOut*yIn - (2*I)*s*xOut*yIn + I*D*s*xOut*yIn - 
          (4*I)*t*xOut*yIn + I*D*t*xOut*yIn - (2*I)*Q^2*xIn*yOut - 
          (6*I)*s*xIn*yOut + I*D*s*xIn*yOut - (4*I)*t*xIn*yOut + 
          I*D*t*xIn*yOut))/(8*s*SUNN^2*t)|>, "MissingTargets" -> {}|>}, 
 "InputHash" -> 
  102345209442171759196267250512367977461018493736654285489431917341375899466\
0, "ReconstructionPassed" -> True, "ReducedReferenceChecksPassed" -> True|>
