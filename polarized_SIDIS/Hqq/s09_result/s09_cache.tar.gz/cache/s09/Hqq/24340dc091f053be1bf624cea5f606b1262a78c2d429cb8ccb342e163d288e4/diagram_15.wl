<|"Diagram" -> 15, "Components" -> {<|"Kind" -> "ExtendedResponse", 
    "Index" -> {1, 1, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/4*I)*(-2 + D)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(s + 2*t))/((Q^2 + s)*SUNN^2*t), 
      GLI["V10", {0, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(3*Q^4 + 2*Q^2*s - s^2 + 2*Q^2*t - 2*s*t))/
        ((Q^2 + s)^2*SUNN^2*t), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/4)*(-2 + D)^2*(-1 + SUNN)^2*(1 + SUNN)^2*(3*Q^4 + 3*Q^2*s + 
          3*Q^2*t - s*t))/((Q^2 + s)^2*SUNN^2*t), 
      GLI["V10", {1, 1, -1, 0}] -> ((I/4)*(-2 + D)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2)/((Q^2 + s)*SUNN^2), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)^2*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 + 3*Q^2*s - s^2 + 
          2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN^2)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/4)*(-2 + D)^2*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        ((Q^2 + s)^2*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 2, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/4*I)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t))/
        ((Q^2 + s)*SUNN^2*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/4*I)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (3*Q^4 + 2*Q^2*s - s^2 + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN^2*t), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/4)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(3*Q^4 + 3*Q^2*s + 3*Q^2*t - s*t))/
        ((Q^2 + s)^2*SUNN^2*t), GLI["V10", {1, 1, -1, 0}] -> 
       ((I/4)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2)/
        ((Q^2 + s)*SUNN^2), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/4)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 + 3*Q^2*s - s^2 + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN^2)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/4)*(-4 + D)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t))/((Q^2 + s)^2*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 3, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/4)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t))/
        ((Q^2 + s)*SUNN^2*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/4)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (3*Q^4 + 2*Q^2*s - s^2 + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN^2*t), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/4*I)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(3*Q^4 + 3*Q^2*s + 3*Q^2*t - s*t))/
        ((Q^2 + s)^2*SUNN^2*t), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2)/
        ((Q^2 + s)*SUNN^2), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-4 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 + 3*Q^2*s - s^2 + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN^2)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-4 + D)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t))/((Q^2 + s)^2*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 4, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/4)*(-6 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t))/
        ((Q^2 + s)*SUNN^2*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/4)*(-6 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (3*Q^4 + 2*Q^2*s - s^2 + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN^2*t), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/4*I)*(-6 + D)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(3*Q^4 + 3*Q^2*s + 3*Q^2*t - s*t))/
        ((Q^2 + s)^2*SUNN^2*t), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/4*I)*(-6 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2)/
        ((Q^2 + s)*SUNN^2), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-6 + D)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 + 3*Q^2*s - s^2 + 2*Q^2*t - 2*s*t))/((Q^2 + s)^2*SUNN^2)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/4*I)*(-6 + D)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t))/((Q^2 + s)^2*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 1, 1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-2*Q^4 - 6*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - D*Q^2*t - 
          2*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^4 + s^2 + 4*s*t)*(-2*Q^4 - 6*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 + 
          2*Q^2*t - D*Q^2*t - 2*s*t + D*s*t))/(s*(Q^2 + s)^2*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4 + Q^2*s + Q^2*t - 3*s*t)*(-2*Q^4 - 6*Q^2*s + D*Q^2*s - 4*s^2 + 
          D*s^2 + 2*Q^2*t - D*Q^2*t - 2*s*t + D*s*t))/(s*(Q^2 + s)^2*SUNN^2*
         t^2), GLI["V10", {1, 1, -1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^4 - 6*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - 
          D*Q^2*t - 2*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^4 - Q^2*s + s^2 + 4*s*t)*(-2*Q^4 - 6*Q^2*s + 
          D*Q^2*s - 4*s^2 + D*s^2 + 2*Q^2*t - D*Q^2*t - 2*s*t + D*s*t))/
        (s*(Q^2 + s)^2*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + 2*t)*(2*Q^4 + 6*Q^2*s - D*Q^2*s + 4*s^2 - D*s^2 - 
          2*Q^2*t + D*Q^2*t + 2*s*t - D*s*t))/((Q^2 + s)^2*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 2, 2}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(s + 2*t)*(-2*Q^4 - 8*Q^2*s + D*Q^2*s - 6*s^2 + D*s^2 + 
          4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^4 + s^2 + 4*s*t)*(-2*Q^4 - 8*Q^2*s + D*Q^2*s - 6*s^2 + D*s^2 + 
          4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t))/(s*(Q^2 + s)^2*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4 + Q^2*s + Q^2*t - 3*s*t)*(-2*Q^4 - 8*Q^2*s + D*Q^2*s - 6*s^2 + 
          D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t))/(s*(Q^2 + s)^2*SUNN^2*
         t^2), GLI["V10", {1, 1, -1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^4 - 8*Q^2*s + D*Q^2*s - 6*s^2 + D*s^2 + 4*Q^2*t - 
          D*Q^2*t - 4*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^4 - Q^2*s + s^2 + 4*s*t)*(-2*Q^4 - 8*Q^2*s + 
          D*Q^2*s - 6*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t))/
        (s*(Q^2 + s)^2*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + 2*t)*(2*Q^4 + 8*Q^2*s - D*Q^2*s + 6*s^2 - D*s^2 - 
          4*Q^2*t + D*Q^2*t + 4*s*t - D*s*t))/((Q^2 + s)^2*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 3, 3}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (s + 2*t)*(2*Q^4 + D*Q^2*s - 2*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 
          4*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-Q^4 + s^2 + 4*s*t)*(2*Q^4 + D*Q^2*s - 2*s^2 + D*s^2 + 
          4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t))/(s*(Q^2 + s)^2*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4 + Q^2*s + Q^2*t - 3*s*t)*(2*Q^4 + D*Q^2*s - 
          2*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t))/
        (s*(Q^2 + s)^2*SUNN^2*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + D*Q^2*s - 
          2*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t))/
        (s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^4 - Q^2*s + s^2 + 
          4*s*t)*(2*Q^4 + D*Q^2*s - 2*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 
          4*s*t + D*s*t))/(s*(Q^2 + s)^2*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + 2*t)*
         (2*Q^4 + D*Q^2*s - 2*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + 
          D*s*t))/((Q^2 + s)^2*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 4, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (2*Q^4 - 2*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 + 6*Q^2*t - D*Q^2*t - 
          6*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-Q^4 + s^2 + 4*s*t)*(2*Q^4 - 2*Q^2*s + D*Q^2*s - 
          4*s^2 + D*s^2 + 6*Q^2*t - D*Q^2*t - 6*s*t + D*s*t))/
        (s*(Q^2 + s)^2*SUNN^2*t^2), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^4 + Q^2*s + Q^2*t - 
          3*s*t)*(2*Q^4 - 2*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 + 6*Q^2*t - 
          D*Q^2*t - 6*s*t + D*s*t))/(s*(Q^2 + s)^2*SUNN^2*t^2), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^4 - 2*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 + 6*Q^2*t - 
          D*Q^2*t - 6*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V10", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^4 - Q^2*s + s^2 + 4*s*t)*(2*Q^4 - 2*Q^2*s + D*Q^2*s - 4*s^2 + 
          D*s^2 + 6*Q^2*t - D*Q^2*t - 6*s*t + D*s*t))/(s*(Q^2 + s)^2*SUNN^2*
         t)|>, "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + 2*t)*
         (2*Q^4 - 2*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 + 6*Q^2*t - D*Q^2*t - 
          6*s*t + D*s*t))/((Q^2 + s)^2*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 1, 1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-2*Q^2 - 4*s + D*s - 6*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^2 - 4*s + D*s - 6*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + t)*(-2*Q^2 - 4*s + D*s - 6*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {1, 1, -1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 - 4*s + D*s - 6*t + D*t))/(s*SUNN^2*t), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-2*Q^2 + s)*
         (-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^2 - 4*s + D*s - 6*t + D*t))/
        (s*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^2 - 4*s + D*s - 6*t + D*t))/(SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 2, 2}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (s + 2*t)*(-2*Q^2 - 6*s + D*s - 4*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^2 - 6*s + D*s - 4*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + t)*(-2*Q^2 - 6*s + D*s - 4*t + D*t))/
        (s*SUNN^2*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^2 - 6*s + D*s - 
          4*t + D*t))/(s*SUNN^2*t), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-2*Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^2 - 6*s + D*s - 4*t + D*t))/(s*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^2 - 6*s + D*s - 4*t + 
          D*t))/(SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 3, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (2*Q^2 - 2*s + D*s - 4*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 - 2*s + D*s - 4*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + t)*(2*Q^2 - 2*s + D*s - 4*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {1, 1, -1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^2 - 2*s + D*s - 4*t + D*t))/(s*SUNN^2*t), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-2*Q^2 + s)*
         (-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^2 - 2*s + D*s - 4*t + D*t))/
        (s*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 - 2*s + D*s - 4*t + D*t))/(SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 4, 4}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (s + 2*t)*(2*Q^2 - 4*s + D*s - 2*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2 - 4*s + D*s - 2*t + D*t))/(s*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + t)*(2*Q^2 - 4*s + D*s - 2*t + D*t))/
        (s*SUNN^2*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^2 - 4*s + D*s - 
          2*t + D*t))/(s*SUNN^2*t), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-2*Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^2 - 4*s + D*s - 2*t + D*t))/(s*SUNN^2*t)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^2 - 4*s + D*s - 2*t + 
          D*t))/(SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 1, 1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-2*Q^4 + 2*D*Q^4 + 2*Q^2*s + D*Q^2*s + 4*s^2 - D*s^2 - 6*Q^2*t + 
          3*D*Q^2*t + 2*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^8 + 2*D*Q^8 + 
          18*Q^6*s - D*Q^6*s + 26*Q^4*s^2 - 7*D*Q^4*s^2 + 6*Q^2*s^3 - 
          3*D*Q^2*s^3 - 4*s^4 + D*s^4 - 6*Q^6*t + 5*D*Q^6*t + 26*Q^4*s*t - 
          11*D*Q^4*s*t + 22*Q^2*s^2*t - 13*D*Q^2*s^2*t - 10*s^3*t + 
          3*D*s^3*t - 4*Q^4*t^2 + 2*D*Q^4*t^2 + 24*Q^2*s*t^2 - 
          12*D*Q^2*s*t^2 - 4*s^2*t^2 + 2*D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^8 + 2*D*Q^8 + 16*Q^6*s + D*Q^6*s + 26*Q^4*s^2 - 
          4*D*Q^4*s^2 + 12*Q^2*s^3 - 3*D*Q^2*s^3 - 8*Q^6*t + 7*D*Q^6*t + 
          20*Q^4*s*t - 5*D*Q^4*s*t + 24*Q^2*s^2*t - 11*D*Q^2*s^2*t - 
          4*s^3*t + D*s^3*t - 10*Q^4*t^2 + 5*D*Q^4*t^2 + 20*Q^2*s*t^2 - 
          10*D*Q^2*s*t^2 - 2*s^2*t^2 + D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^4 + 2*D*Q^4 + 2*Q^2*s + D*Q^2*s + 4*s^2 - D*s^2 - 
          6*Q^2*t + 3*D*Q^2*t + 2*s*t - D*s*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*D*Q^8 + 18*Q^6*s + 
          2*D*Q^6*s + 32*Q^4*s^2 - 7*D*Q^4*s^2 + 10*Q^2*s^3 - 4*D*Q^2*s^3 - 
          4*s^4 + D*s^4 - 12*Q^6*t + 8*D*Q^6*t + 22*Q^4*s*t - 9*D*Q^4*s*t + 
          24*Q^2*s^2*t - 14*D*Q^2*s^2*t - 10*s^3*t + 3*D*s^3*t - 4*Q^4*t^2 + 
          2*D*Q^4*t^2 + 24*Q^2*s*t^2 - 12*D*Q^2*s*t^2 - 4*s^2*t^2 + 
          2*D*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6 + 8*Q^4*s - 
          3*D*Q^4*s + 2*Q^2*s^2 - 2*D*Q^2*s^2 - 4*s^3 + D*s^3 - 2*Q^4*t + 
          D*Q^4*t + 12*Q^2*s*t - 6*D*Q^2*s*t - 2*s^2*t + D*s^2*t)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 2, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-6*Q^4 + 2*D*Q^4 + D*Q^2*s + 6*s^2 - D*s^2 - 12*Q^2*t + 3*D*Q^2*t + 
          4*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^8 + 2*D*Q^8 + 20*Q^6*s - D*Q^6*s + 40*Q^4*s^2 - 
          7*D*Q^4*s^2 + 12*Q^2*s^3 - 3*D*Q^2*s^3 - 6*s^4 + D*s^4 - 16*Q^6*t + 
          5*D*Q^6*t + 48*Q^4*s*t - 11*D*Q^4*s*t + 48*Q^2*s^2*t - 
          13*D*Q^2*s^2*t - 16*s^3*t + 3*D*s^3*t - 8*Q^4*t^2 + 2*D*Q^4*t^2 + 
          48*Q^2*s*t^2 - 12*D*Q^2*s*t^2 - 8*s^2*t^2 + 2*D*s^2*t^2)*
         transverseK)/(Q*s*(Q^2 + s)*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^8 + 2*D*Q^8 + 14*Q^6*s + D*Q^6*s + 34*Q^4*s^2 - 
          4*D*Q^4*s^2 + 18*Q^2*s^3 - 3*D*Q^2*s^3 - 22*Q^6*t + 7*D*Q^6*t + 
          30*Q^4*s*t - 5*D*Q^4*s*t + 46*Q^2*s^2*t - 11*D*Q^2*s^2*t - 
          6*s^3*t + D*s^3*t - 20*Q^4*t^2 + 5*D*Q^4*t^2 + 40*Q^2*s*t^2 - 
          10*D*Q^2*s*t^2 - 4*s^2*t^2 + D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^4 + 2*D*Q^4 + D*Q^2*s + 6*s^2 - D*s^2 - 
          12*Q^2*t + 3*D*Q^2*t + 4*s*t - D*s*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^8 + 4*D*Q^8 + 
          14*Q^6*s + 2*D*Q^6*s + 46*Q^4*s^2 - 7*D*Q^4*s^2 + 18*Q^2*s^3 - 
          4*D*Q^2*s^3 - 6*s^4 + D*s^4 - 28*Q^6*t + 8*D*Q^6*t + 40*Q^4*s*t - 
          9*D*Q^4*s*t + 52*Q^2*s^2*t - 14*D*Q^2*s^2*t - 16*s^3*t + 
          3*D*s^3*t - 8*Q^4*t^2 + 2*D*Q^4*t^2 + 48*Q^2*s*t^2 - 
          12*D*Q^2*s*t^2 - 8*s^2*t^2 + 2*D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^6 + 14*Q^4*s - 3*D*Q^4*s + 6*Q^2*s^2 - 
          2*D*Q^2*s^2 - 6*s^3 + D*s^3 - 4*Q^4*t + D*Q^4*t + 24*Q^2*s*t - 
          6*D*Q^2*s*t - 4*s^2*t + D*s^2*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 3, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-10*Q^4 + 2*D*Q^4 - 8*Q^2*s + D*Q^2*s + 2*s^2 - D*s^2 - 12*Q^2*t + 
          3*D*Q^2*t + 4*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-14*Q^8 + 2*D*Q^8 - 
          12*Q^6*s - D*Q^6*s + 16*Q^4*s^2 - 7*D*Q^4*s^2 + 12*Q^2*s^3 - 
          3*D*Q^2*s^3 - 2*s^4 + D*s^4 - 24*Q^6*t + 5*D*Q^6*t + 40*Q^4*s*t - 
          11*D*Q^4*s*t + 56*Q^2*s^2*t - 13*D*Q^2*s^2*t - 8*s^3*t + 
          3*D*s^3*t - 8*Q^4*t^2 + 2*D*Q^4*t^2 + 48*Q^2*s*t^2 - 
          12*D*Q^2*s*t^2 - 8*s^2*t^2 + 2*D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-14*Q^8 + 2*D*Q^8 - 22*Q^6*s + D*Q^6*s - 2*Q^4*s^2 - 
          4*D*Q^4*s^2 + 6*Q^2*s^3 - 3*D*Q^2*s^3 - 34*Q^6*t + 7*D*Q^6*t + 
          10*Q^4*s*t - 5*D*Q^4*s*t + 42*Q^2*s^2*t - 11*D*Q^2*s^2*t - 
          2*s^3*t + D*s^3*t - 20*Q^4*t^2 + 5*D*Q^4*t^2 + 40*Q^2*s*t^2 - 
          10*D*Q^2*s*t^2 - 4*s^2*t^2 + D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-10*Q^4 + 2*D*Q^4 - 8*Q^2*s + D*Q^2*s + 2*s^2 - 
          D*s^2 - 12*Q^2*t + 3*D*Q^2*t + 4*s*t - D*s*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-24*Q^8 + 4*D*Q^8 - 
          30*Q^6*s + 2*D*Q^6*s + 10*Q^4*s^2 - 7*D*Q^4*s^2 + 14*Q^2*s^3 - 
          4*D*Q^2*s^3 - 2*s^4 + D*s^4 - 36*Q^6*t + 8*D*Q^6*t + 32*Q^4*s*t - 
          9*D*Q^4*s*t + 60*Q^2*s^2*t - 14*D*Q^2*s^2*t - 8*s^3*t + 3*D*s^3*t - 
          8*Q^4*t^2 + 2*D*Q^4*t^2 + 48*Q^2*s*t^2 - 12*D*Q^2*s*t^2 - 
          8*s^2*t^2 + 2*D*s^2*t^2)*transverseK)/(Q*s*(Q^2 + s)*SUNN^2*t*
         (Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^6 - 10*Q^4*s + 3*D*Q^4*s - 10*Q^2*s^2 + 
          2*D*Q^2*s^2 + 2*s^3 - D*s^3 + 4*Q^4*t - D*Q^4*t - 24*Q^2*s*t + 
          6*D*Q^2*s*t + 4*s^2*t - D*s^2*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 4, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-14*Q^4 + 2*D*Q^4 - 10*Q^2*s + D*Q^2*s + 4*s^2 - D*s^2 - 18*Q^2*t + 
          3*D*Q^2*t + 6*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-18*Q^8 + 2*D*Q^8 - 
          10*Q^6*s - D*Q^6*s + 30*Q^4*s^2 - 7*D*Q^4*s^2 + 18*Q^2*s^3 - 
          3*D*Q^2*s^3 - 4*s^4 + D*s^4 - 34*Q^6*t + 5*D*Q^6*t + 62*Q^4*s*t - 
          11*D*Q^4*s*t + 82*Q^2*s^2*t - 13*D*Q^2*s^2*t - 14*s^3*t + 
          3*D*s^3*t - 12*Q^4*t^2 + 2*D*Q^4*t^2 + 72*Q^2*s*t^2 - 
          12*D*Q^2*s*t^2 - 12*s^2*t^2 + 2*D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-18*Q^8 + 2*D*Q^8 - 24*Q^6*s + D*Q^6*s + 6*Q^4*s^2 - 
          4*D*Q^4*s^2 + 12*Q^2*s^3 - 3*D*Q^2*s^3 - 48*Q^6*t + 7*D*Q^6*t + 
          20*Q^4*s*t - 5*D*Q^4*s*t + 64*Q^2*s^2*t - 11*D*Q^2*s^2*t - 
          4*s^3*t + D*s^3*t - 30*Q^4*t^2 + 5*D*Q^4*t^2 + 60*Q^2*s*t^2 - 
          10*D*Q^2*s*t^2 - 6*s^2*t^2 + D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-14*Q^4 + 2*D*Q^4 - 10*Q^2*s + D*Q^2*s + 4*s^2 - 
          D*s^2 - 18*Q^2*t + 3*D*Q^2*t + 6*s*t - D*s*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-32*Q^8 + 4*D*Q^8 - 
          34*Q^6*s + 2*D*Q^6*s + 24*Q^4*s^2 - 7*D*Q^4*s^2 + 22*Q^2*s^3 - 
          4*D*Q^2*s^3 - 4*s^4 + D*s^4 - 52*Q^6*t + 8*D*Q^6*t + 50*Q^4*s*t - 
          9*D*Q^4*s*t + 88*Q^2*s^2*t - 14*D*Q^2*s^2*t - 14*s^3*t + 
          3*D*s^3*t - 12*Q^4*t^2 + 2*D*Q^4*t^2 + 72*Q^2*s*t^2 - 
          12*D*Q^2*s*t^2 - 12*s^2*t^2 + 2*D*s^2*t^2)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^6 - 16*Q^4*s + 3*D*Q^4*s - 14*Q^2*s^2 + 
          2*D*Q^2*s^2 + 4*s^3 - D*s^3 + 6*Q^4*t - D*Q^4*t - 36*Q^2*s*t + 
          6*D*Q^2*s*t + 6*s^2*t - D*s^2*t)*transverseK)/
        (Q*s*(Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 1, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
          (-10*Q^4 + 2*D*Q^4 - 14*Q^2*s + 3*D*Q^2*s - 4*s^2 + D*s^2 - 
           14*Q^2*t + 3*D*Q^2*t - 2*s*t + D*s*t)*transverseK)/
         (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + 2*t)*
          (-6*Q^4 + 2*D*Q^4 - 2*Q^2*s + D*Q^2*s + 4*s^2 - D*s^2 - 2*Q^2*t + 
           D*Q^2*t + 2*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*
          (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^6 + 2*D*Q^6 - 18*Q^4*s + 
          5*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 24*Q^4*t + 7*D*Q^4*t - 
          32*Q^2*s*t + 8*D*Q^2*s*t + 4*s^2*t - D*s^2*t - 18*Q^2*t^2 + 
          5*D*Q^2*t^2 + 2*s*t^2 - D*s*t^2)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-10*Q^4 + 2*D*Q^4 - 14*Q^2*s + 
          3*D*Q^2*s - 4*s^2 + D*s^2 - 14*Q^2*t + 3*D*Q^2*t - 2*s*t + D*s*t)*
         transverseK)/(16*Q*s*SUNN^2*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-16*Q^6 + 4*D*Q^6 - 22*Q^4*s + 6*D*Q^4*s - 2*Q^2*s^2 + D*Q^2*s^2 + 
          4*s^3 - D*s^3 - 28*Q^4*t + 8*D*Q^4*t - 6*Q^2*s*t + 3*D*Q^2*s*t + 
          10*s^2*t - 3*D*s^2*t - 4*Q^2*t^2 + 2*D*Q^2*t^2 + 4*s*t^2 - 
          2*D*s*t^2)*transverseK)/(16*Q*s*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + 6*Q^2*s - D*Q^2*s + 
          4*s^2 - D*s^2 - 2*Q^2*t + D*Q^2*t + 2*s*t - D*s*t)*transverseK)/
        (16*Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 2, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-10*Q^4 + 2*D*Q^4 - 8*Q^2*s + D*Q^2*s + 2*s^2 - D*s^2 - 4*Q^2*t + 
          D*Q^2*t + 4*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-14*Q^6 + 2*D*Q^6 + 
          2*Q^4*s - 3*D*Q^4*s + 14*Q^2*s^2 - 4*D*Q^2*s^2 - 2*s^3 + D*s^3 - 
          D*Q^4*t + 24*Q^2*s*t - 6*D*Q^2*s*t - 8*s^2*t + 3*D*s^2*t + 
          8*Q^2*t^2 - 2*D*Q^2*t^2 - 8*s*t^2 + 2*D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-14*Q^6 + 2*D*Q^6 - 
          8*Q^4*s - D*Q^4*s + 6*Q^2*s^2 - 3*D*Q^2*s^2 - 10*Q^4*t + D*Q^4*t + 
          12*Q^2*s*t - 4*D*Q^2*s*t - 2*s^2*t + D*s^2*t + 4*Q^2*t^2 - 
          D*Q^2*t^2 - 4*s*t^2 + D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-10*Q^4 + 2*D*Q^4 - 
          8*Q^2*s + D*Q^2*s + 2*s^2 - D*s^2 - 4*Q^2*t + D*Q^2*t + 4*s*t - 
          D*s*t)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-24*Q^6 + 4*D*Q^6 - 6*Q^4*s - 2*D*Q^4*s + 16*Q^2*s^2 - 
          5*D*Q^2*s^2 - 2*s^3 + D*s^3 - 4*Q^4*t + 28*Q^2*s*t - 7*D*Q^2*s*t - 
          8*s^2*t + 3*D*s^2*t + 8*Q^2*t^2 - 2*D*Q^2*t^2 - 8*s*t^2 + 
          2*D*s*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 - 12*Q^2*s + 
          3*D*Q^2*s + 2*s^2 - D*s^2 - 4*Q^2*t + D*Q^2*t + 4*s*t - D*s*t)*
         transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 3, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-6*Q^4 + 2*D*Q^4 + D*Q^2*s + 6*s^2 - D*s^2 - 4*Q^2*t + D*Q^2*t + 
          4*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^6 + 2*D*Q^6 + 22*Q^4*s - 3*D*Q^4*s + 18*Q^2*s^2 - 
          4*D*Q^2*s^2 - 6*s^3 + D*s^3 + 8*Q^4*t - D*Q^4*t + 24*Q^2*s*t - 
          6*D*Q^2*s*t - 16*s^2*t + 3*D*s^2*t + 8*Q^2*t^2 - 2*D*Q^2*t^2 - 
          8*s*t^2 + 2*D*s*t^2)*transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^6 + 2*D*Q^6 + 16*Q^4*s - D*Q^4*s + 18*Q^2*s^2 - 
          3*D*Q^2*s^2 + 2*Q^4*t + D*Q^4*t + 20*Q^2*s*t - 4*D*Q^2*s*t - 
          6*s^2*t + D*s^2*t + 4*Q^2*t^2 - D*Q^2*t^2 - 4*s*t^2 + D*s*t^2)*
         transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-6*Q^4 + 2*D*Q^4 + D*Q^2*s + 6*s^2 - D*s^2 - 4*Q^2*t + 
          D*Q^2*t + 4*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-8*Q^6 + 4*D*Q^6 + 22*Q^4*s - 2*D*Q^4*s + 24*Q^2*s^2 - 
          5*D*Q^2*s^2 - 6*s^3 + D*s^3 + 4*Q^4*t + 28*Q^2*s*t - 7*D*Q^2*s*t - 
          16*s^2*t + 3*D*s^2*t + 8*Q^2*t^2 - 2*D*Q^2*t^2 - 8*s*t^2 + 
          2*D*s*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + 12*Q^2*s - 
          3*D*Q^2*s - 6*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t)*
         transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 4, 1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*(-6*Q^4 + 2*D*Q^4 - 
          10*Q^2*s + 3*D*Q^2*s - 4*s^2 + D*s^2 - 10*Q^2*t + 3*D*Q^2*t - 
          6*s*t + D*s*t)*transverseK)/(16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + 2*t)*(-10*Q^4 + 2*D*Q^4 - 6*Q^2*s + D*Q^2*s + 4*s^2 - 
          D*s^2 - 6*Q^2*t + D*Q^2*t + 6*s*t - D*s*t)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-10*Q^6 + 2*D*Q^6 - 
           22*Q^4*s + 5*D*Q^4*s - 12*Q^2*s^2 + 3*D*Q^2*s^2 - 32*Q^4*t + 
           7*D*Q^4*t - 32*Q^2*s*t + 8*D*Q^2*s*t + 4*s^2*t - D*s^2*t - 
           22*Q^2*t^2 + 5*D*Q^2*t^2 + 6*s*t^2 - D*s*t^2)*transverseK)/
         (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^4 + 2*D*Q^4 - 
           10*Q^2*s + 3*D*Q^2*s - 4*s^2 + D*s^2 - 10*Q^2*t + 3*D*Q^2*t - 
           6*s*t + D*s*t)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-16*Q^6 + 4*D*Q^6 - 26*Q^4*s + 6*D*Q^4*s - 6*Q^2*s^2 + D*Q^2*s^2 + 
           4*s^3 - D*s^3 - 36*Q^4*t + 8*D*Q^4*t - 18*Q^2*s*t + 3*D*Q^2*s*t + 
           14*s^2*t - 3*D*s^2*t - 12*Q^2*t^2 + 2*D*Q^2*t^2 + 12*s*t^2 - 
           2*D*s*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 - 2*Q^2*s + D*Q^2*s - 
          4*s^2 + D*s^2 + 6*Q^2*t - D*Q^2*t - 6*s*t + D*s*t)*transverseK)/
        (16*Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 1, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-4*Q^2 + D*Q^2 + 2*s)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t))/
        (8*s*(Q^2 + s)*SUNN^2*t), GLI["V10", {0, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 - D*Q^4 - 2*Q^2*s + 
           D*Q^2*s - 6*s^2 + 2*D*s^2 - 4*s*t + 2*D*s*t))/
         (s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, 0, -1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 - D*Q^4 + 2*Q^2*s - 
          8*s^2 + 2*D*s^2 + 4*Q^2*t - D*Q^2*t - 6*s*t + 2*D*s*t))/
        (8*s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, -1, 0}] -> 
       -1/8*((-2 + D)*(-4*Q^2 + D*Q^2 + 2*s)*(-1 + SUNN)^2*(1 + SUNN)^2)/
         (s*(Q^2 + s)*SUNN^2), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^4 - 2*D*Q^4 - 4*Q^2*s + 
          D*Q^2*s - 6*s^2 + 2*D*s^2 - 4*s*t + 2*D*s*t))/
        (8*s*(Q^2 + s)*SUNN^2)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-2 + D)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t))/(8*(Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 2, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (2*Q^4 + D*Q^2*s - 2*s^2 + D*s^2 - 4*s*t + D*s*t))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 + 2*Q^4*s - 
          D*Q^4*s + 2*Q^2*s^2 - 2*s^3 + D*s^3 + 8*Q^2*s*t - D*Q^2*s*t - 
          8*s^2*t + 3*D*s^2*t - 8*s*t^2 + 2*D*s*t^2))/(s*(Q^2 + s)*SUNN^2*
         t^2), GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^6 + D*Q^4*s - 2*Q^2*s^2 + D*Q^2*s^2 + 2*Q^4*t - 
          8*Q^2*s*t + 2*D*Q^2*s*t + 2*s^2*t - D*s^2*t + 4*s*t^2 - D*s*t^2))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + D*Q^2*s - 
          2*s^2 + D*s^2 - 4*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V10", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 + 2*Q^4*s - 2*D*Q^4*s + 4*Q^2*s^2 - D*Q^2*s^2 - 2*s^3 + 
          D*s^3 + 12*Q^2*s*t - 2*D*Q^2*s*t - 8*s^2*t + 3*D*s^2*t - 8*s*t^2 + 
          2*D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^4 + D*Q^2*s - 2*s^2 + D*s^2 + 2*Q^2*t - 6*s*t + 2*D*s*t - 
          4*t^2 + D*t^2))/((Q^2 + s)*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 3, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-2*Q^4 - 8*Q^2*s + D*Q^2*s - 6*s^2 + D*s^2 - 4*s*t + D*s*t))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6 + 6*Q^4*s - 
          D*Q^4*s - 2*Q^2*s^2 - 6*s^3 + D*s^3 - D*Q^2*s*t - 16*s^2*t + 
          3*D*s^2*t - 8*s*t^2 + 2*D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^6 - 8*Q^4*s + D*Q^4*s - 6*Q^2*s^2 + D*Q^2*s^2 - 
          2*Q^4*t - 8*Q^2*s*t + 2*D*Q^2*s*t + 6*s^2*t - D*s^2*t + 4*s*t^2 - 
          D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^4 - 8*Q^2*s + 
          D*Q^2*s - 6*s^2 + D*s^2 - 4*s*t + D*s*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V10", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^6 + 14*Q^4*s - 2*D*Q^4*s + 4*Q^2*s^2 - D*Q^2*s^2 - 6*s^3 + 
          D*s^3 + 4*Q^2*s*t - 2*D*Q^2*s*t - 16*s^2*t + 3*D*s^2*t - 8*s*t^2 + 
          2*D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^4 + 8*Q^2*s - D*Q^2*s + 6*s^2 - D*s^2 + 2*Q^2*t + 
          10*s*t - 2*D*s*t + 4*t^2 - D*t^2))/((Q^2 + s)*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {6, 4, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> -1/8*((-2 + D)*(-4*Q^2 + D*Q^2 - 2*s)*
          (-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 - D*Q^4 - 6*Q^2*s + D*Q^2*s - 10*s^2 + 2*D*s^2 - 12*s*t + 
          2*D*s*t))/(8*s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, 0, -1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 - D*Q^4 - 2*Q^2*s - 
           8*s^2 + 2*D*s^2 + 4*Q^2*t - D*Q^2*t - 10*s*t + 2*D*s*t))/
         (s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(-4*Q^2 + D*Q^2 - 2*s)*(-1 + SUNN)^2*(1 + SUNN)^2)/
        (8*s*(Q^2 + s)*SUNN^2), GLI["V10", {1, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^4 - 2*D*Q^4 - 4*Q^2*s + 
           D*Q^2*s - 10*s^2 + 2*D*s^2 - 12*s*t + 2*D*s*t))/
         (s*(Q^2 + s)*SUNN^2)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/8*((-6 + D)*(-2 + D)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^2 + s + t))/((Q^2 + s)*SUNN^2)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 1, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(s + 2*t)*(-6*Q^2 + 2*D*Q^2 - 4*s + D*s - 2*t + D*t)*
          transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(-10*Q^4 + 2*D*Q^4 - 6*Q^2*s + D*Q^2*s + 4*s^2 - 
           D*s^2 - 2*Q^2*t - D*Q^2*t + 10*s*t - 3*D*s*t + 4*t^2 - 2*D*t^2)*
          transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-10*Q^4 + 2*D*Q^4 - 12*Q^2*s + 3*D*Q^2*s - 8*Q^2*t + 
          D*Q^2*t + 4*s*t - D*s*t + 2*t^2 - D*t^2)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^2 + 2*D*Q^2 - 
          4*s + D*s - 2*t + D*t)*transverseK)/(16*Q*s*SUNN^2*t*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-16*Q^4 + 4*D*Q^4 - 
          10*Q^2*s + 2*D*Q^2*s + 4*s^2 - D*s^2 - 4*Q^2*t + 10*s*t - 3*D*s*t + 
          4*t^2 - 2*D*t^2)*transverseK)/(16*Q*s*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (2*Q^2 - 4*s + D*s - 2*t + D*t)*transverseK)/(Q*s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 2, 2}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(s + 2*t)*(-10*Q^2 + 2*D*Q^2 - 6*s + D*s - 4*t + D*t)*
          transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(-14*Q^4 + 2*D*Q^4 - 8*Q^2*s + D*Q^2*s + 6*s^2 - 
           D*s^2 - D*Q^2*t + 16*s*t - 3*D*s*t + 8*t^2 - 2*D*t^2)*transverseK)/
         (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-14*Q^4 + 2*D*Q^4 - 
          18*Q^2*s + 3*D*Q^2*s - 10*Q^2*t + D*Q^2*t + 6*s*t - D*s*t + 4*t^2 - 
          D*t^2)*transverseK)/(16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-10*Q^2 + 2*D*Q^2 - 6*s + D*s - 4*t + D*t)*
         transverseK)/(16*Q*s*SUNN^2*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-24*Q^4 + 4*D*Q^4 - 14*Q^2*s + 2*D*Q^2*s + 6*s^2 - 
          D*s^2 - 4*Q^2*t + 16*s*t - 3*D*s*t + 8*t^2 - 2*D*t^2)*transverseK)/
        (16*Q*s*SUNN^2*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(2*Q^2 - 6*s + D*s - 4*t + D*t)*transverseK)/
         (Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 3, 3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-6*Q^2 + 2*D*Q^2 - 2*s + D*s - 4*t + D*t)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^4 + 2*D*Q^4 + 
          D*Q^2*s + 2*s^2 - D*s^2 + 8*Q^2*t - D*Q^2*t + 8*s*t - 3*D*s*t + 
          8*t^2 - 2*D*t^2)*transverseK)/(16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(-2*Q^4 + 2*D*Q^4 - 6*Q^2*s + 3*D*Q^2*s + 2*Q^2*t + 
           D*Q^2*t + 2*s*t - D*s*t + 4*t^2 - D*t^2)*transverseK)/
         (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-6*Q^2 + 2*D*Q^2 - 2*s + D*s - 4*t + D*t)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-8*Q^4 + 4*D*Q^4 - 2*Q^2*s + 2*D*Q^2*s + 2*s^2 - D*s^2 + 4*Q^2*t + 
           8*s*t - 3*D*s*t + 8*t^2 - 2*D*t^2)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(2*Q^2 + 2*s - D*s + 4*t - D*t)*transverseK)/
         (Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 4, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-10*Q^2 + 2*D*Q^2 - 4*s + D*s - 6*t + D*t)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^4 + 2*D*Q^4 - 
          2*Q^2*s + D*Q^2*s + 4*s^2 - D*s^2 + 10*Q^2*t - D*Q^2*t + 14*s*t - 
          3*D*s*t + 12*t^2 - 2*D*t^2)*transverseK)/(16*Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-6*Q^4 + 2*D*Q^4 - 12*Q^2*s + 3*D*Q^2*s + D*Q^2*t + 4*s*t - 
           D*s*t + 6*t^2 - D*t^2)*transverseK)/(Q*s*SUNN^2*t^2*
          (Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-10*Q^2 + 2*D*Q^2 - 4*s + D*s - 6*t + D*t)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-16*Q^4 + 4*D*Q^4 - 6*Q^2*s + 2*D*Q^2*s + 4*s^2 - D*s^2 + 
           4*Q^2*t + 14*s*t - 3*D*s*t + 12*t^2 - 2*D*t^2)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(2*Q^2 + 4*s - D*s + 6*t - D*t)*transverseK)/
         (Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 1, 4}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-14*Q^4 + 2*D*Q^4 - 10*Q^2*s + D*Q^2*s + 4*s^2 - D*s^2 - 10*Q^2*t + 
          D*Q^2*t + 2*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-18*Q^6 + 2*D*Q^6 + 
          8*Q^4*s - 3*D*Q^4*s + 22*Q^2*s^2 - 4*D*Q^2*s^2 - 4*s^3 + D*s^3 - 
          10*Q^4*t - D*Q^4*t + 28*Q^2*s*t - 6*D*Q^2*s*t - 10*s^2*t + 
          3*D*s^2*t + 4*Q^2*t^2 - 2*D*Q^2*t^2 - 4*s*t^2 + 2*D*s*t^2)*
         transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-18*Q^6 + 2*D*Q^6 - 6*Q^4*s - D*Q^4*s + 12*Q^2*s^2 - 
          3*D*Q^2*s^2 - 24*Q^4*t + D*Q^4*t + 8*Q^2*s*t - 4*D*Q^2*s*t - 
          4*s^2*t + D*s^2*t - 6*Q^2*t^2 - D*Q^2*t^2 - 2*s*t^2 + D*s*t^2)*
         transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-14*Q^4 + 2*D*Q^4 - 10*Q^2*s + D*Q^2*s + 4*s^2 - 
          D*s^2 - 10*Q^2*t + D*Q^2*t + 2*s*t - D*s*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-32*Q^6 + 4*D*Q^6 - 
          2*Q^4*s - 2*D*Q^4*s + 26*Q^2*s^2 - 5*D*Q^2*s^2 - 4*s^3 + D*s^3 - 
          20*Q^4*t + 30*Q^2*s*t - 7*D*Q^2*s*t - 10*s^2*t + 3*D*s^2*t + 
          4*Q^2*t^2 - 2*D*Q^2*t^2 - 4*s*t^2 + 2*D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^4 - 18*Q^2*s + 3*D*Q^2*s + 4*s^2 - D*s^2 - 
          2*Q^2*t + D*Q^2*t + 2*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 2, 3}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (s + 2*t)*(-6*Q^4 + 2*D*Q^4 - 8*Q^2*s + 3*D*Q^2*s - 2*s^2 + D*s^2 - 
          12*Q^2*t + 3*D*Q^2*t - 4*s*t + D*s*t)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 + 2*D*Q^6 - 2*Q^4*s + 
          3*D*Q^4*s + 2*Q^2*s^2 + 2*s^3 - D*s^3 - 16*Q^4*t + 5*D*Q^4*t - 
          8*Q^2*s*t + 2*D*Q^2*s*t + 8*s^2*t - 3*D*s^2*t - 8*Q^2*t^2 + 
          2*D*Q^2*t^2 + 8*s*t^2 - 2*D*s*t^2)*transverseK)/
        (16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 + 2*D*Q^6 - 
           8*Q^4*s + 5*D*Q^4*s - 6*Q^2*s^2 + 3*D*Q^2*s^2 - 22*Q^4*t + 
           7*D*Q^4*t - 28*Q^2*s*t + 8*D*Q^2*s*t + 2*s^2*t - D*s^2*t - 
           20*Q^2*t^2 + 5*D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*transverseK)/
         (Q*s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-6*Q^4 + 2*D*Q^4 - 
           8*Q^2*s + 3*D*Q^2*s - 2*s^2 + D*s^2 - 12*Q^2*t + 3*D*Q^2*t - 
           4*s*t + D*s*t)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-8*Q^6 + 4*D*Q^6 - 10*Q^4*s + 6*D*Q^4*s + D*Q^2*s^2 + 2*s^3 - 
           D*s^3 - 28*Q^4*t + 8*D*Q^4*t - 12*Q^2*s*t + 3*D*Q^2*s*t + 
           8*s^2*t - 3*D*s^2*t - 8*Q^2*t^2 + 2*D*Q^2*t^2 + 8*s*t^2 - 
           2*D*s*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + 4*Q^2*s - 
           D*Q^2*s + 2*s^2 - D*s^2 - 4*Q^2*t + D*Q^2*t + 4*s*t - D*s*t)*
          transverseK)/(Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 3, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*(-10*Q^4 + 2*D*Q^4 - 
          16*Q^2*s + 3*D*Q^2*s - 6*s^2 + D*s^2 - 12*Q^2*t + 3*D*Q^2*t - 
          4*s*t + D*s*t)*transverseK)/(16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-14*Q^6 + 2*D*Q^6 - 22*Q^4*s + 3*D*Q^4*s - 2*Q^2*s^2 + 6*s^3 - 
          D*s^3 - 24*Q^4*t + 5*D*Q^4*t - 8*Q^2*s*t + 2*D*Q^2*s*t + 16*s^2*t - 
          3*D*s^2*t - 8*Q^2*t^2 + 2*D*Q^2*t^2 + 8*s*t^2 - 2*D*s*t^2)*
         transverseK)/(16*Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-14*Q^6 + 2*D*Q^6 - 32*Q^4*s + 5*D*Q^4*s - 18*Q^2*s^2 + 
           3*D*Q^2*s^2 - 34*Q^4*t + 7*D*Q^4*t - 36*Q^2*s*t + 8*D*Q^2*s*t + 
           6*s^2*t - D*s^2*t - 20*Q^2*t^2 + 5*D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*
          transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-10*Q^4 + 2*D*Q^4 - 16*Q^2*s + 3*D*Q^2*s - 6*s^2 + D*s^2 - 
           12*Q^2*t + 3*D*Q^2*t - 4*s*t + D*s*t)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-24*Q^6 + 4*D*Q^6 - 
           38*Q^4*s + 6*D*Q^4*s - 8*Q^2*s^2 + D*Q^2*s^2 + 6*s^3 - D*s^3 - 
           36*Q^4*t + 8*D*Q^4*t - 12*Q^2*s*t + 3*D*Q^2*s*t + 16*s^2*t - 
           3*D*s^2*t - 8*Q^2*t^2 + 2*D*Q^2*t^2 + 8*s*t^2 - 2*D*s*t^2)*
          transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 - 4*Q^2*s + D*Q^2*s - 
          6*s^2 + D*s^2 + 4*Q^2*t - D*Q^2*t - 4*s*t + D*s*t)*transverseK)/
        (16*Q*s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 4, 1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (-2*Q^4 + 2*D*Q^4 + 2*Q^2*s + D*Q^2*s + 4*s^2 - D*s^2 + 2*Q^2*t + 
          D*Q^2*t + 6*s*t - D*s*t)*transverseK)/(Q*s*SUNN^2*t^2*
         (Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6 + 2*D*Q^6 + 
          16*Q^4*s - 3*D*Q^4*s + 10*Q^2*s^2 - 4*D*Q^2*s^2 - 4*s^3 + D*s^3 + 
          18*Q^4*t - D*Q^4*t + 20*Q^2*s*t - 6*D*Q^2*s*t - 14*s^2*t + 
          3*D*s^2*t + 12*Q^2*t^2 - 2*D*Q^2*t^2 - 12*s*t^2 + 2*D*s*t^2)*
         transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^6 + 2*D*Q^6 + 14*Q^4*s - D*Q^4*s + 12*Q^2*s^2 - 
          3*D*Q^2*s^2 + 16*Q^4*t + D*Q^4*t + 24*Q^2*s*t - 4*D*Q^2*s*t - 
          4*s^2*t + D*s^2*t + 14*Q^2*t^2 - D*Q^2*t^2 - 6*s*t^2 + D*s*t^2)*
         transverseK)/(Q*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^4 + 2*D*Q^4 + 2*Q^2*s + D*Q^2*s + 4*s^2 - D*s^2 + 
          2*Q^2*t + D*Q^2*t + 6*s*t - D*s*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*D*Q^6 + 18*Q^4*s - 
          2*D*Q^4*s + 14*Q^2*s^2 - 5*D*Q^2*s^2 - 4*s^3 + D*s^3 + 20*Q^4*t + 
          26*Q^2*s*t - 7*D*Q^2*s*t - 14*s^2*t + 3*D*s^2*t + 12*Q^2*t^2 - 
          2*D*Q^2*t^2 - 12*s*t^2 + 2*D*s*t^2)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^4 + 6*Q^2*s - 3*D*Q^2*s - 4*s^2 + D*s^2 + 
          6*Q^2*t - D*Q^2*t - 6*s*t + D*s*t)*transverseK)/(Q*s*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 1, 4}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((I/8)*(-2 + D)*(2*Q^2 - 4*s + D*s)*
         (-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t)*(s + 2*t))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {0, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 + 4*Q^4*s - 
          D*Q^4*s + 2*Q^2*s^2 - 4*s^3 + D*s^3 - 2*Q^4*t + 10*Q^2*s*t - 
          D*Q^2*s*t - 12*s^2*t + 3*D*s^2*t - 4*s*t^2 + 2*D*s*t^2))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6 - 2*Q^4*s + 
          D*Q^4*s - 4*Q^2*s^2 + D*Q^2*s^2 + 4*Q^4*t - 10*Q^2*s*t + 
          2*D*Q^2*s*t + 4*s^2*t - D*s^2*t + 2*Q^2*t^2 - D*s*t^2))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(2*Q^2 - 4*s + D*s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t))/(s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 + 6*Q^4*s - 
          2*D*Q^4*s + 6*Q^2*s^2 - D*Q^2*s^2 - 4*s^3 + D*s^3 - 4*Q^4*t + 
          14*Q^2*s*t - 2*D*Q^2*s*t - 12*s^2*t + 3*D*s^2*t - 4*s*t^2 + 
          2*D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^4 - 2*Q^2*s + D*Q^2*s - 4*s^2 + D*s^2 + 4*Q^2*t - 8*s*t + 
          2*D*s*t - 2*t^2 + D*t^2))/((Q^2 + s)*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 2, 3}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> -1/8*((-4 + D)*(-2 + D)*Q^2*(-1 + SUNN)^2*
          (1 + SUNN)^2*(s + 2*t))/(s*(Q^2 + s)*SUNN^2*t), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^4 - D*Q^4 + D*Q^2*s - 4*s^2 + 2*D*s^2 - 8*s*t + 2*D*s*t))/
        (8*s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, 0, -1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 - D*Q^4 + 4*Q^2*s - 
           4*s^2 + 2*D*s^2 + 4*Q^2*t - D*Q^2*t - 8*s*t + 2*D*s*t))/
         (s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, -1, 0}] -> 
       ((-4 + D)*(-2 + D)*Q^2*(-1 + SUNN)^2*(1 + SUNN)^2)/
        (8*s*(Q^2 + s)*SUNN^2), GLI["V10", {1, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^4 - 2*D*Q^4 + D*Q^2*s - 
           4*s^2 + 2*D*s^2 - 8*s*t + 2*D*s*t))/(s*(Q^2 + s)*SUNN^2)|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^2 + D*Q^2 - 2*s + 
           D*s - 4*t + D*t))/((Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 3, 2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       -1/8*((-4 + D)*(-2 + D)*Q^2*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t))/
         (s*(Q^2 + s)*SUNN^2*t), GLI["V10", {0, 1, 0, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 - D*Q^4 - 8*Q^2*s + 
          D*Q^2*s - 12*s^2 + 2*D*s^2 - 8*s*t + 2*D*s*t))/
        (8*s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, 0, -1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^4 - D*Q^4 - 4*Q^2*s - 
           12*s^2 + 2*D*s^2 + 4*Q^2*t - D*Q^2*t - 8*s*t + 2*D*s*t))/
         (s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, -1, 0}] -> 
       ((-4 + D)*(-2 + D)*Q^2*(-1 + SUNN)^2*(1 + SUNN)^2)/
        (8*s*(Q^2 + s)*SUNN^2), GLI["V10", {1, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(8*Q^4 - 2*D*Q^4 - 8*Q^2*s + 
           D*Q^2*s - 12*s^2 + 2*D*s^2 - 8*s*t + 2*D*s*t))/
         (s*(Q^2 + s)*SUNN^2)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-6*Q^2 + D*Q^2 - 6*s + D*s - 4*t + D*t))/((Q^2 + s)*SUNN^2)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 4, 1}, "Coefficients" -> 
     <|GLI["V10", {1, 0, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-2*Q^2 - 4*s + D*s)*
         (-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t)*(s + 2*t))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6 + 4*Q^4*s - 
          D*Q^4*s - 2*Q^2*s^2 - 4*s^3 + D*s^3 + 2*Q^4*t - 2*Q^2*s*t - 
          D*Q^2*s*t - 12*s^2*t + 3*D*s^2*t - 12*s*t^2 + 2*D*s*t^2))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 - 6*Q^4*s + 
          D*Q^4*s - 4*Q^2*s^2 + D*Q^2*s^2 - 4*Q^4*t - 6*Q^2*s*t + 
          2*D*Q^2*s*t + 4*s^2*t - D*s^2*t - 2*Q^2*t^2 + 8*s*t^2 - D*s*t^2))/
        (s*(Q^2 + s)*SUNN^2*t^2), GLI["V10", {1, 1, -1, 0}] -> 
       ((I/8)*(-2 + D)*(-2*Q^2 - 4*s + D*s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^2 + s + t))/(s*(Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(4*Q^6 + 10*Q^4*s - 
          2*D*Q^4*s + 2*Q^2*s^2 - D*Q^2*s^2 - 4*s^3 + D*s^3 + 4*Q^4*t + 
          2*Q^2*s*t - 2*D*Q^2*s*t - 12*s^2*t + 3*D*s^2*t - 12*s*t^2 + 
          2*D*s*t^2))/(s*(Q^2 + s)*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^4 + 6*Q^2*s - D*Q^2*s + 4*s^2 - D*s^2 + 4*Q^2*t + 8*s*t - 
          2*D*s*t + 6*t^2 - D*t^2))/((Q^2 + s)*SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonMetricD", "Index" -> {}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (4*Q^2 - 2*D*Q^2 - 12*hIn*hOut*Q^2 + 2*D*hIn*hOut*Q^2 + 8*s - 
          6*D*s + D^2*s + 24*hIn*hOut*s - 10*D*hIn*hOut*s + D^2*hIn*hOut*s + 
          20*t - 10*D*t + D^2*t + 20*hIn*hOut*t - 10*D*hIn*hOut*t + 
          D^2*hIn*hOut*t + 8*Q^2*xIn*xOut - 2*D*Q^2*xIn*xOut + 
          24*s*xIn*xOut - 10*D*s*xIn*xOut + D^2*s*xIn*xOut + 40*t*xIn*xOut - 
          14*D*t*xIn*xOut + D^2*t*xIn*xOut - 8*Q^2*yIn*yOut + 
          2*D*Q^2*yIn*yOut + 8*s*yIn*yOut - 6*D*s*yIn*yOut + D^2*s*yIn*yOut + 
          8*t*yIn*yOut - 6*D*t*yIn*yOut + D^2*t*yIn*yOut))/(s*SUNN^2*t^2), 
      GLI["V10", {0, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^4 + 2*D*Q^4 + 12*hIn*hOut*Q^4 - 
          2*D*hIn*hOut*Q^4 - 4*Q^2*s + 4*D*Q^2*s - D^2*Q^2*s - 
          36*hIn*hOut*Q^2*s + 12*D*hIn*hOut*Q^2*s - D^2*hIn*hOut*Q^2*s + 
          8*s^2 - 6*D*s^2 + D^2*s^2 + 24*hIn*hOut*s^2 - 10*D*hIn*hOut*s^2 + 
          D^2*hIn*hOut*s^2 - 20*Q^2*t + 10*D*Q^2*t - D^2*Q^2*t - 
          20*hIn*hOut*Q^2*t + 10*D*hIn*hOut*Q^2*t - D^2*hIn*hOut*Q^2*t + 
          4*s*t - 6*D*s*t + D^2*s*t + 36*hIn*hOut*s*t - 14*D*hIn*hOut*s*t + 
          D^2*hIn*hOut*s*t - 8*Q^4*xIn*xOut + 2*D*Q^4*xIn*xOut - 
          16*Q^2*s*xIn*xOut + 8*D*Q^2*s*xIn*xOut - D^2*Q^2*s*xIn*xOut + 
          24*s^2*xIn*xOut - 10*D*s^2*xIn*xOut + D^2*s^2*xIn*xOut - 
          40*Q^2*t*xIn*xOut + 14*D*Q^2*t*xIn*xOut - D^2*Q^2*t*xIn*xOut + 
          16*s*t*xIn*xOut - 10*D*s*t*xIn*xOut + D^2*s*t*xIn*xOut + 
          8*Q^4*yIn*yOut - 2*D*Q^4*yIn*yOut - 16*Q^2*s*yIn*yOut + 
          8*D*Q^2*s*yIn*yOut - D^2*Q^2*s*yIn*yOut + 8*s^2*yIn*yOut - 
          6*D*s^2*yIn*yOut + D^2*s^2*yIn*yOut - 8*Q^2*t*yIn*yOut + 
          6*D*Q^2*t*yIn*yOut - D^2*Q^2*t*yIn*yOut + 16*s*t*yIn*yOut - 
          10*D*s*t*yIn*yOut + D^2*s*t*yIn*yOut))/(s*SUNN^2*t^2), 
      GLI["V10", {1, 1, 0, -1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^4 - 2*D*Q^4 - 12*hIn*hOut*Q^4 + 2*D*hIn*hOut*Q^4 + 
          8*Q^2*s - 6*D*Q^2*s + D^2*Q^2*s + 24*hIn*hOut*Q^2*s - 
          10*D*hIn*hOut*Q^2*s + D^2*hIn*hOut*Q^2*s + 24*Q^2*t - 12*D*Q^2*t + 
          D^2*Q^2*t + 8*hIn*hOut*Q^2*t - 8*D*hIn*hOut*Q^2*t + 
          D^2*hIn*hOut*Q^2*t + 24*s*t - 10*D*s*t + D^2*s*t + 8*hIn*hOut*s*t - 
          6*D*hIn*hOut*s*t + D^2*hIn*hOut*s*t + 20*t^2 - 10*D*t^2 + D^2*t^2 + 
          20*hIn*hOut*t^2 - 10*D*hIn*hOut*t^2 + D^2*hIn*hOut*t^2 + 
          8*Q^4*xIn*xOut - 2*D*Q^4*xIn*xOut + 24*Q^2*s*xIn*xOut - 
          10*D*Q^2*s*xIn*xOut + D^2*Q^2*s*xIn*xOut + 48*Q^2*t*xIn*xOut - 
          16*D*Q^2*t*xIn*xOut + D^2*Q^2*t*xIn*xOut + 48*s*t*xIn*xOut - 
          14*D*s*t*xIn*xOut + D^2*s*t*xIn*xOut + 40*t^2*xIn*xOut - 
          14*D*t^2*xIn*xOut + D^2*t^2*xIn*xOut - 8*Q^4*yIn*yOut + 
          2*D*Q^4*yIn*yOut + 8*Q^2*s*yIn*yOut - 6*D*Q^2*s*yIn*yOut + 
          D^2*Q^2*s*yIn*yOut - 4*D*Q^2*t*yIn*yOut + D^2*Q^2*t*yIn*yOut - 
          2*D*s*t*yIn*yOut + D^2*s*t*yIn*yOut + 8*t^2*yIn*yOut - 
          6*D*t^2*yIn*yOut + D^2*t^2*yIn*yOut))/(s*SUNN^2*t^2), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(4*Q^2 - 2*D*Q^2 - 12*hIn*hOut*Q^2 + 2*D*hIn*hOut*Q^2 + 
          8*s - 6*D*s + D^2*s + 24*hIn*hOut*s - 10*D*hIn*hOut*s + 
          D^2*hIn*hOut*s + 20*t - 10*D*t + D^2*t + 20*hIn*hOut*t - 
          10*D*hIn*hOut*t + D^2*hIn*hOut*t + 8*Q^2*xIn*xOut - 
          2*D*Q^2*xIn*xOut + 24*s*xIn*xOut - 10*D*s*xIn*xOut + 
          D^2*s*xIn*xOut + 40*t*xIn*xOut - 14*D*t*xIn*xOut + D^2*t*xIn*xOut - 
          8*Q^2*yIn*yOut + 2*D*Q^2*yIn*yOut + 8*s*yIn*yOut - 6*D*s*yIn*yOut + 
          D^2*s*yIn*yOut + 8*t*yIn*yOut - 6*D*t*yIn*yOut + D^2*t*yIn*yOut))/
        (s*SUNN^2*t), GLI["V10", {1, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^4 + 4*D*Q^4 + 
          24*hIn*hOut*Q^4 - 4*D*hIn*hOut*Q^4 - 12*Q^2*s + 10*D*Q^2*s - 
          2*D^2*Q^2*s - 60*hIn*hOut*Q^2*s + 22*D*hIn*hOut*Q^2*s - 
          2*D^2*hIn*hOut*Q^2*s + 8*s^2 - 6*D*s^2 + D^2*s^2 + 
          24*hIn*hOut*s^2 - 10*D*hIn*hOut*s^2 + D^2*hIn*hOut*s^2 - 40*Q^2*t + 
          20*D*Q^2*t - 2*D^2*Q^2*t - 40*hIn*hOut*Q^2*t + 20*D*hIn*hOut*Q^2*
           t - 2*D^2*hIn*hOut*Q^2*t + 4*s*t - 6*D*s*t + D^2*s*t + 
          36*hIn*hOut*s*t - 14*D*hIn*hOut*s*t + D^2*hIn*hOut*s*t - 
          16*Q^4*xIn*xOut + 4*D*Q^4*xIn*xOut - 40*Q^2*s*xIn*xOut + 
          18*D*Q^2*s*xIn*xOut - 2*D^2*Q^2*s*xIn*xOut + 24*s^2*xIn*xOut - 
          10*D*s^2*xIn*xOut + D^2*s^2*xIn*xOut - 80*Q^2*t*xIn*xOut + 
          28*D*Q^2*t*xIn*xOut - 2*D^2*Q^2*t*xIn*xOut + 16*s*t*xIn*xOut - 
          10*D*s*t*xIn*xOut + D^2*s*t*xIn*xOut + 16*Q^4*yIn*yOut - 
          4*D*Q^4*yIn*yOut - 24*Q^2*s*yIn*yOut + 14*D*Q^2*s*yIn*yOut - 
          2*D^2*Q^2*s*yIn*yOut + 8*s^2*yIn*yOut - 6*D*s^2*yIn*yOut + 
          D^2*s^2*yIn*yOut - 16*Q^2*t*yIn*yOut + 12*D*Q^2*t*yIn*yOut - 
          2*D^2*Q^2*t*yIn*yOut + 16*s*t*yIn*yOut - 10*D*s*t*yIn*yOut + 
          D^2*s*t*yIn*yOut))/(s*SUNN^2*t)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (4*Q^2 - 2*D*Q^2 - 12*hIn*hOut*Q^2 + 2*D*hIn*hOut*Q^2 + 8*s - 
          6*D*s + D^2*s + 24*hIn*hOut*s - 10*D*hIn*hOut*s + D^2*hIn*hOut*s + 
          12*t - 8*D*t + D^2*t + 28*hIn*hOut*t - 12*D*hIn*hOut*t + 
          D^2*hIn*hOut*t + 8*Q^2*xIn*xOut - 2*D*Q^2*xIn*xOut + 
          24*s*xIn*xOut - 10*D*s*xIn*xOut + D^2*s*xIn*xOut + 28*t*xIn*xOut - 
          12*D*t*xIn*xOut + D^2*t*xIn*xOut - 8*Q^2*yIn*yOut + 
          2*D*Q^2*yIn*yOut + 8*s*yIn*yOut - 6*D*s*yIn*yOut + D^2*s*yIn*yOut + 
          12*t*yIn*yOut - 8*D*t*yIn*yOut + D^2*t*yIn*yOut))/(SUNN^2*t)|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonWardLeft", "Index" -> {1}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((I/4)*(-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
         (2 - D - 6*hIn*hOut + D*hIn*hOut + 4*xIn*xOut - D*xIn*xOut - 
          4*yIn*yOut + D*yIn*yOut))/((Q^2 + s)*SUNN^2*t), 
      GLI["V10", {0, 1, 0, 0}] -> ((-1/4*I)*(-2 + D)*Q*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + 2*t)*(2 - D - 6*hIn*hOut + D*hIn*hOut + 
          4*xIn*xOut - D*xIn*xOut - 4*yIn*yOut + D*yIn*yOut))/
        ((Q^2 + s)*SUNN^2*t), GLI["V10", {1, 1, 0, -1}] -> 
       ((I/4)*(-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + t)*
         (2 - D - 6*hIn*hOut + D*hIn*hOut + 4*xIn*xOut - D*xIn*xOut - 
          4*yIn*yOut + D*yIn*yOut))/((Q^2 + s)*SUNN^2*t), 
      GLI["V10", {1, 1, -1, 0}] -> ((-1/4*I)*(-2 + D)*Q*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2 - D - 6*hIn*hOut + D*hIn*hOut + 4*xIn*xOut - 
          D*xIn*xOut - 4*yIn*yOut + D*yIn*yOut))/((Q^2 + s)*SUNN^2), 
      GLI["V10", {1, 1, 0, 0}] -> ((I/4)*(-2 + D)*Q*(-1 + SUNN)^2*
         (1 + SUNN)^2*(s + 2*t)*(2 - D - 6*hIn*hOut + D*hIn*hOut + 
          4*xIn*xOut - D*xIn*xOut - 4*yIn*yOut + D*yIn*yOut))/
        ((Q^2 + s)*SUNN^2)|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((I/4)*(-2 + D)*Q*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t)*(2 - D - 6*hIn*hOut + D*hIn*hOut + 
          4*xIn*xOut - D*xIn*xOut - 4*yIn*yOut + D*yIn*yOut))/
        ((Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonWardLeft", "Index" -> {2}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*transverseK*
         (2*Q^4 + 2*hIn*hOut*Q^4 + 6*Q^2*s - D*Q^2*s - 2*hIn*hOut*Q^2*s + 
          D*hIn*hOut*Q^2*s + 4*s^2 - D*s^2 - 4*hIn*hOut*s^2 + 
          D*hIn*hOut*s^2 - 2*Q^2*t + D*Q^2*t + 6*hIn*hOut*Q^2*t - 
          D*hIn*hOut*Q^2*t + 2*s*t - D*s*t - 6*hIn*hOut*s*t + 
          D*hIn*hOut*s*t + 2*Q^4*xIn*xOut + 8*Q^2*s*xIn*xOut - 
          D*Q^2*s*xIn*xOut + 6*s^2*xIn*xOut - D*s^2*xIn*xOut - 
          4*Q^2*t*xIn*xOut + D*Q^2*t*xIn*xOut + 4*s*t*xIn*xOut - 
          D*s*t*xIn*xOut + 2*Q^4*yIn*yOut + D*Q^2*s*yIn*yOut - 
          2*s^2*yIn*yOut + D*s^2*yIn*yOut + 4*Q^2*t*yIn*yOut - 
          D*Q^2*t*yIn*yOut - 4*s*t*yIn*yOut + D*s*t*yIn*yOut))/
        (s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {0, 1, 0, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + 2*t)*transverseK*
         (2*Q^4 + 2*hIn*hOut*Q^4 + 6*Q^2*s - D*Q^2*s - 2*hIn*hOut*Q^2*s + 
          D*hIn*hOut*Q^2*s + 4*s^2 - D*s^2 - 4*hIn*hOut*s^2 + 
          D*hIn*hOut*s^2 - 2*Q^2*t + D*Q^2*t + 6*hIn*hOut*Q^2*t - 
          D*hIn*hOut*Q^2*t + 2*s*t - D*s*t - 6*hIn*hOut*s*t + 
          D*hIn*hOut*s*t + 2*Q^4*xIn*xOut + 8*Q^2*s*xIn*xOut - 
          D*Q^2*s*xIn*xOut + 6*s^2*xIn*xOut - D*s^2*xIn*xOut - 
          4*Q^2*t*xIn*xOut + D*Q^2*t*xIn*xOut + 4*s*t*xIn*xOut - 
          D*s*t*xIn*xOut + 2*Q^4*yIn*yOut + D*Q^2*s*yIn*yOut - 
          2*s^2*yIn*yOut + D*s^2*yIn*yOut + 4*Q^2*t*yIn*yOut - 
          D*Q^2*t*yIn*yOut - 4*s*t*yIn*yOut + D*s*t*yIn*yOut))/
        (s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, 0, -1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + t)*transverseK*
         (2*Q^4 + 2*hIn*hOut*Q^4 + 6*Q^2*s - D*Q^2*s - 2*hIn*hOut*Q^2*s + 
          D*hIn*hOut*Q^2*s + 4*s^2 - D*s^2 - 4*hIn*hOut*s^2 + 
          D*hIn*hOut*s^2 - 2*Q^2*t + D*Q^2*t + 6*hIn*hOut*Q^2*t - 
          D*hIn*hOut*Q^2*t + 2*s*t - D*s*t - 6*hIn*hOut*s*t + 
          D*hIn*hOut*s*t + 2*Q^4*xIn*xOut + 8*Q^2*s*xIn*xOut - 
          D*Q^2*s*xIn*xOut + 6*s^2*xIn*xOut - D*s^2*xIn*xOut - 
          4*Q^2*t*xIn*xOut + D*Q^2*t*xIn*xOut + 4*s*t*xIn*xOut - 
          D*s*t*xIn*xOut + 2*Q^4*yIn*yOut + D*Q^2*s*yIn*yOut - 
          2*s^2*yIn*yOut + D*s^2*yIn*yOut + 4*Q^2*t*yIn*yOut - 
          D*Q^2*t*yIn*yOut - 4*s*t*yIn*yOut + D*s*t*yIn*yOut))/
        (s*SUNN^2*t^2*(Q^2 + s + t)), GLI["V10", {1, 1, -1, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         (2*Q^4 + 2*hIn*hOut*Q^4 + 6*Q^2*s - D*Q^2*s - 2*hIn*hOut*Q^2*s + 
          D*hIn*hOut*Q^2*s + 4*s^2 - D*s^2 - 4*hIn*hOut*s^2 + 
          D*hIn*hOut*s^2 - 2*Q^2*t + D*Q^2*t + 6*hIn*hOut*Q^2*t - 
          D*hIn*hOut*Q^2*t + 2*s*t - D*s*t - 6*hIn*hOut*s*t + 
          D*hIn*hOut*s*t + 2*Q^4*xIn*xOut + 8*Q^2*s*xIn*xOut - 
          D*Q^2*s*xIn*xOut + 6*s^2*xIn*xOut - D*s^2*xIn*xOut - 
          4*Q^2*t*xIn*xOut + D*Q^2*t*xIn*xOut + 4*s*t*xIn*xOut - 
          D*s*t*xIn*xOut + 2*Q^4*yIn*yOut + D*Q^2*s*yIn*yOut - 
          2*s^2*yIn*yOut + D*s^2*yIn*yOut + 4*Q^2*t*yIn*yOut - 
          D*Q^2*t*yIn*yOut - 4*s*t*yIn*yOut + D*s*t*yIn*yOut))/
        (s*SUNN^2*t*(Q^2 + s + t)), GLI["V10", {1, 1, 0, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*transverseK*
         (2*Q^4 + 2*hIn*hOut*Q^4 + 6*Q^2*s - D*Q^2*s - 2*hIn*hOut*Q^2*s + 
          D*hIn*hOut*Q^2*s + 4*s^2 - D*s^2 - 4*hIn*hOut*s^2 + 
          D*hIn*hOut*s^2 - 2*Q^2*t + D*Q^2*t + 6*hIn*hOut*Q^2*t - 
          D*hIn*hOut*Q^2*t + 2*s*t - D*s*t - 6*hIn*hOut*s*t + 
          D*hIn*hOut*s*t + 2*Q^4*xIn*xOut + 8*Q^2*s*xIn*xOut - 
          D*Q^2*s*xIn*xOut + 6*s^2*xIn*xOut - D*s^2*xIn*xOut - 
          4*Q^2*t*xIn*xOut + D*Q^2*t*xIn*xOut + 4*s*t*xIn*xOut - 
          D*s*t*xIn*xOut + 2*Q^4*yIn*yOut + D*Q^2*s*yIn*yOut - 
          2*s^2*yIn*yOut + D*s^2*yIn*yOut + 4*Q^2*t*yIn*yOut - 
          D*Q^2*t*yIn*yOut - 4*s*t*yIn*yOut + D*s*t*yIn*yOut))/
        (s*SUNN^2*t*(Q^2 + s + t))|>, "ReducedCoefficients" -> 
     <|GLI["V02", {1, 1, 0, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*transverseK*(2*Q^4 + 2*hIn*hOut*Q^4 + 6*Q^2*s - 
          D*Q^2*s - 2*hIn*hOut*Q^2*s + D*hIn*hOut*Q^2*s + 4*s^2 - D*s^2 - 
          4*hIn*hOut*s^2 + D*hIn*hOut*s^2 - 2*Q^2*t + D*Q^2*t + 
          6*hIn*hOut*Q^2*t - D*hIn*hOut*Q^2*t + 2*s*t - D*s*t - 
          6*hIn*hOut*s*t + D*hIn*hOut*s*t + 2*Q^4*xIn*xOut + 
          8*Q^2*s*xIn*xOut - D*Q^2*s*xIn*xOut + 6*s^2*xIn*xOut - 
          D*s^2*xIn*xOut - 4*Q^2*t*xIn*xOut + D*Q^2*t*xIn*xOut + 
          4*s*t*xIn*xOut - D*s*t*xIn*xOut + 2*Q^4*yIn*yOut + 
          D*Q^2*s*yIn*yOut - 2*s^2*yIn*yOut + D*s^2*yIn*yOut + 
          4*Q^2*t*yIn*yOut - D*Q^2*t*yIn*yOut - 4*s*t*yIn*yOut + 
          D*s*t*yIn*yOut))/(s*SUNN^2*t)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonWardLeft", "Index" -> {3}, 
    "Coefficients" -> <|GLI["V10", {1, 0, 0, 0}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(s + 2*t)*
          transverseK*(2*hIn*Q^2 + 2*hOut*Q^2 - 4*hIn*s + D*hIn*s + 
           4*hOut*s - D*hOut*s - 2*hIn*t + D*hIn*t + 6*hOut*t - D*hOut*t + 
           (2*I)*Q^2*xOut*yIn - (2*I)*s*xOut*yIn + I*D*s*xOut*yIn - 
           (4*I)*t*xOut*yIn + I*D*t*xOut*yIn - (2*I)*Q^2*xIn*yOut - 
           (6*I)*s*xIn*yOut + I*D*s*xIn*yOut - (4*I)*t*xIn*yOut + 
           I*D*t*xIn*yOut))/(s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {0, 1, 0, 0}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + 2*t)*transverseK*(2*hIn*Q^2 + 2*hOut*Q^2 - 
          4*hIn*s + D*hIn*s + 4*hOut*s - D*hOut*s - 2*hIn*t + D*hIn*t + 
          6*hOut*t - D*hOut*t + (2*I)*Q^2*xOut*yIn - (2*I)*s*xOut*yIn + 
          I*D*s*xOut*yIn - (4*I)*t*xOut*yIn + I*D*t*xOut*yIn - 
          (2*I)*Q^2*xIn*yOut - (6*I)*s*xIn*yOut + I*D*s*xIn*yOut - 
          (4*I)*t*xIn*yOut + I*D*t*xIn*yOut))/(8*s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, -1}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^2 + t)*transverseK*(2*hIn*Q^2 + 2*hOut*Q^2 - 
           4*hIn*s + D*hIn*s + 4*hOut*s - D*hOut*s - 2*hIn*t + D*hIn*t + 
           6*hOut*t - D*hOut*t + (2*I)*Q^2*xOut*yIn - (2*I)*s*xOut*yIn + 
           I*D*s*xOut*yIn - (4*I)*t*xOut*yIn + I*D*t*xOut*yIn - 
           (2*I)*Q^2*xIn*yOut - (6*I)*s*xIn*yOut + I*D*s*xIn*yOut - 
           (4*I)*t*xIn*yOut + I*D*t*xIn*yOut))/(s*SUNN^2*t^2*(Q^2 + s + t)), 
      GLI["V10", {1, 1, -1, 0}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*transverseK*(2*hIn*Q^2 + 2*hOut*Q^2 - 4*hIn*s + 
          D*hIn*s + 4*hOut*s - D*hOut*s - 2*hIn*t + D*hIn*t + 6*hOut*t - 
          D*hOut*t + (2*I)*Q^2*xOut*yIn - (2*I)*s*xOut*yIn + I*D*s*xOut*yIn - 
          (4*I)*t*xOut*yIn + I*D*t*xOut*yIn - (2*I)*Q^2*xIn*yOut - 
          (6*I)*s*xIn*yOut + I*D*s*xIn*yOut - (4*I)*t*xIn*yOut + 
          I*D*t*xIn*yOut))/(8*s*SUNN^2*t*(Q^2 + s + t)), 
      GLI["V10", {1, 1, 0, 0}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(s + 2*t)*transverseK*(2*hIn*Q^2 + 2*hOut*Q^2 - 
           4*hIn*s + D*hIn*s + 4*hOut*s - D*hOut*s - 2*hIn*t + D*hIn*t + 
           6*hOut*t - D*hOut*t + (2*I)*Q^2*xOut*yIn - (2*I)*s*xOut*yIn + 
           I*D*s*xOut*yIn - (4*I)*t*xOut*yIn + I*D*t*xOut*yIn - 
           (2*I)*Q^2*xIn*yOut - (6*I)*s*xIn*yOut + I*D*s*xIn*yOut - 
           (4*I)*t*xIn*yOut + I*D*t*xIn*yOut))/(s*SUNN^2*t*(Q^2 + s + t))|>, 
    "ReducedCoefficients" -> <|GLI["V02", {1, 1, 0, 0}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
          (2*hIn*Q^2 + 2*hOut*Q^2 - 4*hIn*s + D*hIn*s + 4*hOut*s - D*hOut*s - 
           2*hIn*t + D*hIn*t + 6*hOut*t - D*hOut*t + (2*I)*Q^2*xOut*yIn - 
           (2*I)*s*xOut*yIn + I*D*s*xOut*yIn - (4*I)*t*xOut*yIn + 
           I*D*t*xOut*yIn - (2*I)*Q^2*xIn*yOut - (6*I)*s*xIn*yOut + 
           I*D*s*xIn*yOut - (4*I)*t*xIn*yOut + I*D*t*xIn*yOut))/
         (s*SUNN^2*t)|>, "MissingTargets" -> {}|>}, 
 "InputHash" -> 
  102345209442171759196267250512367977461018493736654285489431917341375899466\
0, "ReconstructionPassed" -> True, "ReducedReferenceChecksPassed" -> True|>
