<|"Diagram" -> 14, "Components" -> {<|"Kind" -> "ExtendedResponse", 
    "Index" -> {1, 1, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/2)*(-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*t*(2*Q^2 + s + t))/(s*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/2*I)*(-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*t*
         (Q^2 + s + t))/(s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/2*I)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*t)/((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/2*I)*(-2 + D)*(-Q^2 + s)*
         (-1 + SUNN)^2*(1 + SUNN)^2*t)/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/2*I)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*t*
         (Q^2 + s + t))/((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/2*I)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*t*
         (Q^2 + s + t))/((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {1, 2, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/2)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^6 + 5*Q^4*s + 3*Q^2*s^2 + Q^4*t + 3*Q^2*s*t - 2*s^2*t))/
        (s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/2*I)*(-2 + D)*Q^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t))/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/2*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4 + Q^2*s + 2*Q^2*t - 2*s*t))/
        ((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/2*I)*(-2 + D)*Q^2*(Q^2 + s)*
         (-1 + SUNN)^2*(1 + SUNN)^2)/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/2)*(-2 + D)*Q^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t))/(SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/2)*(-2 + D)*s*(-1 + SUNN)^2*(1 + SUNN)^2*t)/
        (SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 3, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/2*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6 + 5*Q^4*s + 
           3*Q^2*s^2 + Q^4*t + 3*Q^2*s*t - 2*s^2*t))/(s*(Q^2 + s)*SUNN^2*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*Q^2*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        (2*s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4 + Q^2*s + 2*Q^2*t - 2*s*t))/(2*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*Q^2*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2)/
        (2*s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       -1/2*((-2 + D)*Q^2*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
         (SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> -1/2*((-2 + D)*s*(-1 + SUNN)^2*
          (1 + SUNN)^2*t)/(SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {1, 4, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/2*I)*(-2 + D)*(-Q^2 + s)*
         (-1 + SUNN)^2*(1 + SUNN)^2*t*(2*Q^2 + s + t))/(s*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/2)*(-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*t*(Q^2 + s + t))/
        (s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/2)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*t)/((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/2)*(-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*t)/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/2)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*t*(Q^2 + s + t))/((Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/2)*(-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*t*(Q^2 + s + t))/((Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {1, 5, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^8 + 2*D*Q^8 - 
          28*Q^6*s + 7*D*Q^6*s - 32*Q^4*s^2 + 8*D*Q^4*s^2 - 12*Q^2*s^3 + 
          3*D*Q^2*s^3 - 20*Q^6*t + 5*D*Q^6*t - 36*Q^4*s*t + 10*D*Q^4*s*t - 
          2*Q^2*s^2*t + 2*D*Q^2*s^2*t + 14*s^3*t - 3*D*s^3*t - 16*Q^4*t^2 + 
          4*D*Q^4*t^2 - 6*Q^2*s*t^2 + 2*D*Q^2*s*t^2 + 18*s^2*t^2 - 
          4*D*s^2*t^2 - 4*Q^2*t^3 + D*Q^2*t^3 + 4*s*t^3 - D*s*t^3))/
        (s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 + D*Q^6 - 8*Q^4*s + 2*D*Q^4*s - 4*Q^2*s^2 + D*Q^2*s^2 - 
          8*Q^4*t + 2*D*Q^4*t - 2*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - D*s^2*t - 
          4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/(s*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 + D*Q^6 - 8*Q^4*s + 
          2*D*Q^4*s - 4*Q^2*s^2 + D*Q^2*s^2 - 8*Q^4*t + 2*D*Q^4*t - 
          6*Q^2*s*t + D*Q^2*s*t + 2*s^2*t - D*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 
          4*s*t^2 - D*s*t^2))/((Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^6 + D*Q^6 - 8*Q^4*s + 
          2*D*Q^4*s - 4*Q^2*s^2 + D*Q^2*s^2 - 8*Q^4*t + 2*D*Q^4*t - 
          2*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - D*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 
          4*s*t^2 - D*s*t^2))/(s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^6 + D*Q^6 - 8*Q^4*s + 2*D*Q^4*s - 4*Q^2*s^2 + 
          D*Q^2*s^2 - 8*Q^4*t + 2*D*Q^4*t - 2*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - 
          D*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/
        ((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*t*(-4*Q^4 + D*Q^4 - 
          2*Q^2*s + D*Q^2*s + 2*s^2 - 4*Q^2*t + D*Q^2*t + 4*s*t - D*s*t))/
        ((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 1, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^10 - 10*Q^8*s - 14*Q^6*s^2 + 12*Q^2*s^4 + 6*s^5 - 
          7*Q^6*s*t - 12*Q^4*s^2*t + 3*Q^2*s^3*t + 8*s^4*t + Q^6*t^2 + 
          Q^4*s*t^2 - 3*Q^2*s^2*t^2 + s^3*t^2 - Q^4*t^3 + 2*Q^2*s*t^3 - 
          s^2*t^3))/(s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^8 - 6*Q^6*s - 
          4*Q^4*s^2 + 2*Q^2*s^3 + 2*s^4 + Q^6*t - Q^2*s^2*t - Q^4*t^2 + 
          2*Q^2*s*t^2 - s^2*t^2))/(s^2*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^8 - 6*Q^6*s - 
          4*Q^4*s^2 + 2*Q^2*s^3 + 2*s^4 - Q^6*t - 4*Q^4*s*t + Q^2*s^2*t + 
          4*s^3*t + Q^4*t^2 - 2*Q^2*s*t^2 + s^2*t^2))/(s*(Q^2 + s)*SUNN^2*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^4*s^2 + 4*Q^2*s^3 + 2*s^4 + Q^6*t - 2*Q^4*s*t - Q^2*s^2*t + 
          2*s^3*t + Q^4*t^2 - 2*Q^2*s*t^2 + s^2*t^2))/
        (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^8 - 6*Q^6*s - 4*Q^4*s^2 + 2*Q^2*s^3 + 2*s^4 + 
          Q^6*t - Q^2*s^2*t - Q^4*t^2 + 2*Q^2*s*t^2 - s^2*t^2))/
        (s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 
          3*Q^4*s^2 + Q^2*s^3 - Q^4*s*t + s^3*t + Q^4*t^2 - 2*Q^2*s*t^2 + 
          s^2*t^2))/(s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 2, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^10 - 9*Q^8*s - 12*Q^6*s^2 + Q^4*s^3 + 
          12*Q^2*s^4 + 6*s^5 + Q^8*t - 3*Q^6*s*t - 11*Q^4*s^2*t + Q^2*s^3*t + 
          8*s^4*t + 3*Q^6*t^2 + 2*Q^4*s*t^2 - 7*Q^2*s^2*t^2 + 2*s^3*t^2))/
        (s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^6 - 3*Q^4*s + 2*s^3 + 3*Q^4*t - 3*Q^2*s*t))/
        (s^2*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^8 - 4*Q^6*s - 3*Q^4*s^2 + 2*Q^2*s^3 + 2*s^4 + Q^6*t - 
          4*Q^4*s*t - Q^2*s^2*t + 4*s^3*t + 2*Q^4*t^2 - 4*Q^2*s*t^2 + 
          2*s^2*t^2))/(s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/4)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^6 - Q^4*s + 2*Q^2*s^2 + 2*s^3 - Q^4*t - Q^2*s*t + 2*s^2*t))/
        (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-Q^6 - 3*Q^4*s + 2*s^3 + 3*Q^4*t - 3*Q^2*s*t))/
        (s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4*s + Q^2*s^2 - 2*Q^4*t + Q^2*s*t + s^2*t))/
        (s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 3, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 - 3*Q^4*s + 
           3*Q^2*s^2 + 4*s^3 - Q^4*t - Q^2*s*t + 4*s^2*t))/
         (s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(-Q^2 + 2*s)*(-1 + SUNN)^2*(1 + SUNN)^2)/(4*s^2*SUNN^2), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^4 + Q^2*s + 2*s^2 - 2*Q^2*t + 2*s*t))/(4*s*(Q^2 + s)*SUNN^2*
         (Q^2 + s + t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/4*((-2 + D)*Q^2*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2)/
         (s^2*SUNN^2*(Q^2 + s + t)), GLI["V09", {0, 0, 1, 1}] -> 
       -1/4*((-2 + D)*(-Q^2 + 2*s)*(-1 + SUNN)^2*(1 + SUNN)^2)/(s*SUNN^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2)/SUNN^2|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {2, 4, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^6 - 4*Q^4*s + 2*s^3 - 2*Q^4*t - 3*Q^2*s*t + 
          s^2*t + Q^2*t^2 - s*t^2))/(s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^4 + 2*Q^2*s - Q^2*t + s*t))/
        (s^2*(Q^2 + s)*SUNN^2), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + 2*Q^2*s + 
          Q^2*t - s*t))/(s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^2*s + 2*s^2 - Q^2*t + s*t))/(s^2*SUNN^2*(Q^2 + s + t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^4 + 2*Q^2*s - Q^2*t + s*t))/(s*(Q^2 + s)*SUNN^2)|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^4 + 2*Q^2*s + s^2 - 
          Q^2*t + s*t))/(s*(Q^2 + s)*SUNN^2)|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {2, 5, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(D*Q^8*s + 14*Q^6*s^2 + 
          2*D*Q^6*s^2 + 40*Q^4*s^3 + D*Q^4*s^3 + 38*Q^2*s^4 + 12*s^5 - 
          4*Q^8*t + D*Q^8*t - 22*Q^6*s*t + 4*D*Q^6*s*t - 18*Q^4*s^2*t + 
          D*Q^4*s^2*t + 2*Q^2*s^3*t - 2*D*Q^2*s^3*t + 2*s^4*t - 8*Q^6*t^2 + 
          2*D*Q^6*t^2 - 2*Q^4*s*t^2 + D*Q^4*s*t^2 + 16*Q^2*s^2*t^2 - 
          4*D*Q^2*s^2*t^2 - 6*s^3*t^2 + D*s^3*t^2 - 4*Q^4*t^3 + D*Q^4*t^3 + 
          8*Q^2*s*t^3 - 2*D*Q^2*s*t^3 - 4*s^2*t^3 + D*s^2*t^3))/
        (s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^10 + D*Q^10 - 10*Q^8*s + 3*D*Q^8*s - 2*Q^6*s^2 + 
          3*D*Q^6*s^2 + 14*Q^4*s^3 + D*Q^4*s^3 + 14*Q^2*s^4 + 4*s^5 - 
          12*Q^8*t + 3*D*Q^8*t - 20*Q^6*s*t + 4*D*Q^6*s*t - 6*Q^4*s^2*t - 
          D*Q^4*s^2*t - 2*D*Q^2*s^3*t - 2*s^4*t - 12*Q^6*t^2 + 3*D*Q^6*t^2 + 
          6*Q^4*s*t^2 - D*Q^4*s*t^2 + 12*Q^2*s^2*t^2 - 3*D*Q^2*s^2*t^2 - 
          6*s^3*t^2 + D*s^3*t^2 - 4*Q^4*t^3 + D*Q^4*t^3 + 8*Q^2*s*t^3 - 
          2*D*Q^2*s*t^3 - 4*s^2*t^3 + D*s^2*t^3))/(s^2*(Q^2 + s)*SUNN^2*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^8 + D*Q^8 - 6*Q^6*s + 2*D*Q^6*s + 4*Q^4*s^2 + 
          D*Q^4*s^2 + 10*Q^2*s^3 + 4*s^4 - 8*Q^6*t + 2*D*Q^6*t - 2*Q^4*s*t + 
          8*Q^2*s^2*t - 2*D*Q^2*s^2*t + 2*s^3*t - 4*Q^4*t^2 + D*Q^4*t^2 + 
          8*Q^2*s*t^2 - 2*D*Q^2*s*t^2 - 4*s^2*t^2 + D*s^2*t^2))/
        (s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^8 + D*Q^8 - 10*Q^6*s + 2*D*Q^6*s - 12*Q^4*s^2 + D*Q^4*s^2 - 
          10*Q^2*s^3 - 4*s^4 - 8*Q^6*t + 2*D*Q^6*t + 2*Q^4*s*t + 
          8*Q^2*s^2*t - 2*D*Q^2*s^2*t - 2*s^3*t - 4*Q^4*t^2 + D*Q^4*t^2 + 
          8*Q^2*s*t^2 - 2*D*Q^2*s*t^2 - 4*s^2*t^2 + D*s^2*t^2))/
        (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^10 + D*Q^10 - 10*Q^8*s + 3*D*Q^8*s - 2*Q^6*s^2 + 3*D*Q^6*s^2 + 
          14*Q^4*s^3 + D*Q^4*s^3 + 14*Q^2*s^4 + 4*s^5 - 12*Q^8*t + 
          3*D*Q^8*t - 20*Q^6*s*t + 4*D*Q^6*s*t - 6*Q^4*s^2*t - D*Q^4*s^2*t - 
          2*D*Q^2*s^3*t - 2*s^4*t - 12*Q^6*t^2 + 3*D*Q^6*t^2 + 6*Q^4*s*t^2 - 
          D*Q^4*s*t^2 + 12*Q^2*s^2*t^2 - 3*D*Q^2*s^2*t^2 - 6*s^3*t^2 + 
          D*s^3*t^2 - 4*Q^4*t^3 + D*Q^4*t^3 + 8*Q^2*s*t^3 - 2*D*Q^2*s*t^3 - 
          4*s^2*t^3 + D*s^2*t^3))/(s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^10 + D*Q^10 - 12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 
          3*D*Q^6*s^2 - 4*Q^4*s^3 + D*Q^4*s^3 - 12*Q^8*t + 3*D*Q^8*t - 
          18*Q^6*s*t + 4*D*Q^6*s*t - 4*Q^4*s^2*t - D*Q^4*s^2*t - 
          2*Q^2*s^3*t - 2*D*Q^2*s^3*t - 4*s^4*t - 12*Q^6*t^2 + 3*D*Q^6*t^2 + 
          6*Q^4*s*t^2 - D*Q^4*s*t^2 + 12*Q^2*s^2*t^2 - 3*D*Q^2*s^2*t^2 - 
          6*s^3*t^2 + D*s^3*t^2 - 4*Q^4*t^3 + D*Q^4*t^3 + 8*Q^2*s*t^3 - 
          2*D*Q^2*s*t^3 - 4*s^2*t^3 + D*s^2*t^3))/(s*(Q^2 + s)*SUNN^2*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 1, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^8 - 4*Q^6*s + 2*Q^2*s^3 - Q^4*s*t - Q^2*s^2*t - 
          2*s^3*t + Q^4*t^2 - s^2*t^2 - Q^2*t^3 + s*t^3))/
        (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^6 + 2*Q^4*s - Q^4*t + Q^2*s*t + Q^2*t^2 - s*t^2))/
        (s^2*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^6 + 2*Q^4*s + Q^4*t - Q^2*s*t - Q^2*t^2 + s*t^2))/
        (s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/4)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^4*s + 2*Q^2*s^2 + Q^4*t + Q^2*s*t - 2*s^2*t + 
          Q^2*t^2 - s*t^2))/(s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6 + 2*Q^4*s - Q^4*t + 
          Q^2*s*t + Q^2*t^2 - s*t^2))/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - 
          s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^6 + 2*Q^4*s + Q^2*s^2 + Q^2*s*t - s^2*t + Q^2*t^2 - s*t^2))/
        (s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 2, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^8 - 3*Q^6*s + 
          3*Q^4*s^2 + 4*Q^2*s^3 + Q^6*t + 4*Q^4*s*t + 3*Q^2*s^2*t - 4*s^3*t + 
          3*Q^4*t^2 + 3*Q^2*s*t^2 - 4*s^2*t^2))/(s^2*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/4)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^4 + 2*Q^2*s + 3*Q^2*t - 2*s*t))/(s^2*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-Q^6 + Q^4*s + 2*Q^2*s^2 + 
          Q^4*t + 3*Q^2*s*t - 2*s^2*t + 2*Q^2*t^2 - 2*s*t^2))/
        (s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/4*I)*(-2 + D)*Q^2*(Q^2 + s)^2*
         (-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + t))/(s^2*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/4*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^4 + 2*Q^2*s + 3*Q^2*t - 2*s*t))/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - 
          s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2*s + 2*Q^2*t - s*t))/(s*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 3, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^8 - 7*Q^6*s - 
           5*Q^4*s^2 + 6*Q^2*s^3 + 6*s^4 - 3*Q^6*t - 8*Q^4*s*t - Q^2*s^2*t + 
           8*s^3*t - Q^4*t^2 - 3*Q^2*s*t^2 + 2*s^2*t^2))/
         (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-Q^4 - 2*Q^2*s + 2*s^2 - Q^2*t))/
        (4*s^2*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^6 - 3*Q^4*s + 2*s^3 - 3*Q^4*t - 3*Q^2*s*t + 4*s^2*t - 
          2*Q^2*t^2 + 2*s*t^2))/(4*s*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^4 + 2*s^2 - Q^2*t + 2*s*t))/(4*s^2*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       -1/4*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-Q^4 - 2*Q^2*s + 2*s^2 - Q^2*t))/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - 
           s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + t))/(4*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {3, 4, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^8 - 8*Q^6*s - 6*Q^4*s^2 + 6*Q^2*s^3 + 6*s^4 - 
          4*Q^6*t - 9*Q^4*s*t + Q^2*s^2*t + 8*s^3*t - Q^4*t^2 + s^2*t^2 + 
          Q^2*t^3 - s*t^3))/(s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 - 4*Q^4*s + 2*s^3 - 
          Q^4*t + Q^2*s*t + Q^2*t^2 - s*t^2))/(s^2*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 - 4*Q^4*s + 2*s^3 - 
          3*Q^4*t - Q^2*s*t + 4*s^2*t - Q^2*t^2 + s*t^2))/
        (s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/4)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^2*s^2 + 2*s^3 - Q^4*t - Q^2*s*t + 2*s^2*t - 
          Q^2*t^2 + s*t^2))/(s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^6 - 4*Q^4*s + 2*s^3 - Q^4*t + Q^2*s*t + Q^2*t^2 - 
          s*t^2))/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^6 + 2*Q^4*s + Q^2*s^2 - 
          Q^2*s*t + s^2*t - Q^2*t^2 + s*t^2))/(s*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {3, 5, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(D*Q^6*s + 6*Q^4*s^2 + 
          D*Q^4*s^2 + 6*Q^2*s^3 - 4*Q^6*t + D*Q^6*t - 18*Q^4*s*t + 
          3*D*Q^4*s*t - 12*Q^2*s^2*t - 6*s^3*t - 8*Q^4*t^2 + 2*D*Q^4*t^2 - 
          2*Q^2*s*t^2 + D*Q^2*s*t^2 + 6*s^2*t^2 - D*s^2*t^2 - 4*Q^2*t^3 + 
          D*Q^2*t^3 + 4*s*t^3 - D*s*t^3))/(s^2*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^8 + D*Q^8 - 
          6*Q^6*s + 2*D*Q^6*s + D*Q^4*s^2 + 2*Q^2*s^3 - 12*Q^6*t + 
          3*D*Q^6*t - 16*Q^4*s*t + 3*D*Q^4*s*t - 6*Q^2*s^2*t - 2*s^3*t - 
          12*Q^4*t^2 + 3*D*Q^4*t^2 + 2*Q^2*s*t^2 + 6*s^2*t^2 - D*s^2*t^2 - 
          4*Q^2*t^3 + D*Q^2*t^3 + 4*s*t^3 - D*s*t^3))/
        (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^6 + D*Q^6 - 2*Q^4*s + D*Q^4*s + 2*Q^2*s^2 - 
          8*Q^4*t + 2*D*Q^4*t - 2*Q^2*s*t - 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 
          4*s*t^2 - D*s*t^2))/(s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6 + D*Q^6 - 6*Q^4*s + D*Q^4*s - 2*Q^2*s^2 - 8*Q^4*t + 
          2*D*Q^4*t + 2*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - 
          D*s*t^2))/(s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^8 + D*Q^8 - 6*Q^6*s + 2*D*Q^6*s + D*Q^4*s^2 + 2*Q^2*s^3 - 
          12*Q^6*t + 3*D*Q^6*t - 16*Q^4*s*t + 3*D*Q^4*s*t - 6*Q^2*s^2*t - 
          2*s^3*t - 12*Q^4*t^2 + 3*D*Q^4*t^2 + 2*Q^2*s*t^2 + 6*s^2*t^2 - 
          D*s^2*t^2 - 4*Q^2*t^3 + D*Q^2*t^3 + 4*s*t^3 - D*s*t^3))/
        (s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^8 + D*Q^8 - 8*Q^6*s + 
          2*D*Q^6*s - 4*Q^4*s^2 + D*Q^4*s^2 - 12*Q^6*t + 3*D*Q^6*t - 
          14*Q^4*s*t + 3*D*Q^4*s*t - 2*Q^2*s^2*t - 12*Q^4*t^2 + 3*D*Q^4*t^2 + 
          2*Q^2*s*t^2 + 6*s^2*t^2 - D*s^2*t^2 - 4*Q^2*t^3 + D*Q^2*t^3 + 
          4*s*t^3 - D*s*t^3))/(s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t))|>, "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 1, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^10 + 9*Q^8*s + 15*Q^6*s^2 + 11*Q^4*s^3 + 
          3*Q^2*s^4 - 3*Q^8*t - 3*Q^6*s*t + 8*Q^4*s^2*t + 7*Q^2*s^3*t - 
          s^4*t - 6*Q^4*s*t^2 + 4*Q^2*s^2*t^2 + 2*s^3*t^2 + 3*Q^4*t^3 - 
          4*Q^2*s*t^3 + s^2*t^3)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 
          3*Q^4*s^2 + Q^2*s^3 - 2*Q^6*t - Q^4*s*t + 2*Q^2*s^2*t + s^3*t + 
          3*Q^4*t^2 - 4*Q^2*s*t^2 + s^2*t^2)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 3*Q^4*s*t - 3*s^3*t - 
          3*Q^4*t^2 + 4*Q^2*s*t^2 - s^2*t^2)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/8)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^6 + 2*Q^4*s + Q^2*s^2 - 2*Q^4*t + Q^2*s*t + s^2*t - 
          Q^2*t^2 + s*t^2)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 
          3*Q^4*s^2 + Q^2*s^3 - 2*Q^6*t - Q^4*s*t + 2*Q^2*s^2*t + s^3*t + 
          3*Q^4*t^2 - 4*Q^2*s*t^2 + s^2*t^2)*transverseK)/
        (Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4*s^2 + 4*Q^2*s^3 + 
          2*s^4 + 3*Q^6*t - 2*Q^4*s*t - 3*Q^2*s^2*t + 2*s^3*t + 3*Q^4*t^2 - 
          4*Q^2*s*t^2 + s^2*t^2)*transverseK)/(Q*s*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {4, 2, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^8*s + 7*Q^6*s^2 + 
          8*Q^4*s^3 + 3*Q^2*s^4 - 8*Q^8*t - 13*Q^6*s*t + 9*Q^4*s^2*t + 
          13*Q^2*s^3*t - s^4*t - 6*Q^6*t^2 - 9*Q^4*s*t^2 + 12*Q^2*s^2*t^2 - 
          s^3*t^2)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4*s + Q^2*s^2 - 6*Q^4*t + 3*Q^2*s*t + s^2*t)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^6*s + 2*Q^4*s^2 + Q^2*s^3 - 4*Q^6*t + Q^4*s*t + 2*Q^2*s^2*t - 
          3*s^3*t - 6*Q^4*t^2 + 8*Q^2*s*t^2 - 2*s^2*t^2)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/8)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4*s + Q^2*s^2 - 2*Q^4*t + 3*Q^2*s*t + s^2*t)*
         transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4*s + Q^2*s^2 - 6*Q^4*t + 3*Q^2*s*t + s^2*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (3*Q^4 - 2*s^2 + 3*Q^2*t - 2*s*t)*transverseK)/
        (Q*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 3, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^8*s + 7*Q^6*s^2 + 8*Q^4*s^3 + 3*Q^2*s^4 - 4*Q^8*t - 7*Q^6*s*t + 
          7*Q^4*s^2*t + 7*Q^2*s^3*t - 3*s^4*t - 4*Q^6*t^2 - 7*Q^4*s*t^2 + 
          10*Q^2*s^2*t^2 - 3*s^3*t^2)*transverseK)/(8*Q*s^2*SUNN^2*t*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^4*s + Q^2*s^2 - 4*Q^4*t + 3*Q^2*s*t - s^2*t)*
          transverseK)/(Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^6*s + 2*Q^4*s^2 + Q^2*s^3 - 6*Q^6*t - Q^4*s*t + 4*Q^2*s^2*t - 
           s^3*t - 6*Q^4*t^2 + 8*Q^2*s*t^2 - 2*s^2*t^2)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> -1/8*((-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^4 + Q^2*s + 3*Q^2*t - s*t)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4*s + Q^2*s^2 - 4*Q^4*t + 3*Q^2*s*t - s^2*t)*
         transverseK)/(8*Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/8*((-2 + D)*Q*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + t)*
          transverseK)/(s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
           s*t))|>, "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 4, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^10 + 9*Q^8*s + 15*Q^6*s^2 + 11*Q^4*s^3 + 
          3*Q^2*s^4 + 5*Q^8*t + 13*Q^6*s*t + 2*Q^4*s^2*t - 9*Q^2*s^3*t - 
          3*s^4*t + 6*Q^4*s*t^2 - 4*Q^2*s^2*t^2 - 2*s^3*t^2 - 3*Q^4*t^3 + 
          4*Q^2*s*t^3 - s^2*t^3)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 
          3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t + Q^4*s*t - 2*Q^2*s^2*t - s^3*t - 
          3*Q^4*t^2 + 4*Q^2*s*t^2 - s^2*t^2)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 4*Q^6*t + Q^4*s*t - 
          4*Q^2*s^2*t - s^3*t + 3*Q^4*t^2 - 4*Q^2*s*t^2 + s^2*t^2)*
         transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^6 + 2*Q^4*s + Q^2*s^2 + 2*Q^4*t - Q^2*s*t - s^2*t + Q^2*t^2 - 
          s*t^2)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 
          3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t + Q^4*s*t - 2*Q^2*s^2*t - s^3*t - 
          3*Q^4*t^2 + 4*Q^2*s*t^2 - s^2*t^2)*transverseK)/
        (Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6*s + 4*Q^4*s^2 + 
          2*Q^2*s^3 - 3*Q^6*t + 2*Q^4*s*t + 3*Q^2*s^2*t - 2*s^3*t - 
          3*Q^4*t^2 + 4*Q^2*s*t^2 - s^2*t^2)*transverseK)/
        (Q*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {4, 5, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-8*Q^12 + 2*D*Q^12 - 36*Q^10*s + 9*D*Q^10*s - 
          60*Q^8*s^2 + 15*D*Q^8*s^2 - 44*Q^6*s^3 + 11*D*Q^6*s^3 - 
          12*Q^4*s^4 + 3*D*Q^4*s^4 - 28*Q^10*t + 7*D*Q^10*t - 100*Q^8*s*t + 
          22*D*Q^8*s*t - 114*Q^6*s^2*t + 17*D*Q^6*s^2*t - 44*Q^4*s^3*t - 
          4*D*Q^4*s^3*t - 6*Q^2*s^4*t - 6*D*Q^2*s^4*t - 4*s^5*t - 
          44*Q^8*t^2 + 11*D*Q^8*t^2 - 78*Q^6*s*t^2 + 19*D*Q^6*s*t^2 + 
          6*Q^4*s^2*t^2 - 6*D*Q^4*s^2*t^2 + 22*Q^2*s^3*t^2 - 
          11*D*Q^2*s^3*t^2 - 18*s^4*t^2 + 3*D*s^4*t^2 - 36*Q^6*t^3 + 
          9*D*Q^6*t^3 - 2*Q^4*s*t^3 + 2*D*Q^4*s*t^3 + 48*Q^2*s^2*t^3 - 
          11*D*Q^2*s^2*t^3 - 18*s^3*t^3 + 4*D*s^3*t^3 - 12*Q^4*t^4 + 
          3*D*Q^4*t^4 + 16*Q^2*s*t^4 - 4*D*Q^2*s*t^4 - 4*s^2*t^4 + D*s^2*t^4)*
         transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^10 + D*Q^10 - 12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 
          3*D*Q^6*s^2 - 4*Q^4*s^3 + D*Q^4*s^3 - 20*Q^8*t + 5*D*Q^8*t - 
          38*Q^6*s*t + 8*D*Q^6*s*t - 20*Q^4*s^2*t + D*Q^4*s^2*t - 
          6*Q^2*s^3*t - 2*D*Q^2*s^3*t - 4*s^4*t - 28*Q^6*t^2 + 7*D*Q^6*t^2 + 
          2*Q^4*s*t^2 + D*Q^4*s*t^2 + 24*Q^2*s^2*t^2 - 5*D*Q^2*s^2*t^2 - 
          6*s^3*t^2 + D*s^3*t^2 - 12*Q^4*t^3 + 3*D*Q^4*t^3 + 16*Q^2*s*t^3 - 
          4*D*Q^2*s*t^3 - 4*s^2*t^3 + D*s^2*t^3)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^10 + D*Q^10 - 12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 
          3*D*Q^6*s^2 - 4*Q^4*s^3 + D*Q^4*s^3 - 20*Q^8*t + 5*D*Q^8*t - 
          34*Q^6*s*t + 8*D*Q^6*s*t - 4*Q^4*s^2*t + D*Q^4*s^2*t + 
          14*Q^2*s^3*t - 2*D*Q^2*s^3*t + 4*s^4*t - 28*Q^6*t^2 + 7*D*Q^6*t^2 - 
          10*Q^4*s*t^2 + D*Q^4*s*t^2 + 16*Q^2*s^2*t^2 - 5*D*Q^2*s^2*t^2 - 
          2*s^3*t^2 + D*s^3*t^2 - 12*Q^4*t^3 + 3*D*Q^4*t^3 + 16*Q^2*s*t^3 - 
          4*D*Q^2*s*t^3 - 4*s^2*t^3 + D*s^2*t^3)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/16)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^8 + D*Q^8 - 8*Q^6*s + 2*D*Q^6*s - 4*Q^4*s^2 + 
          D*Q^4*s^2 - 4*Q^6*t + D*Q^6*t - 2*Q^4*s*t - D*Q^4*s*t - 
          2*Q^2*s^2*t - 2*D*Q^2*s^2*t - 4*s^3*t + 4*Q^4*t^2 - D*Q^4*t^2 + 
          6*Q^2*s*t^2 - 2*D*Q^2*s*t^2 - 6*s^2*t^2 + D*s^2*t^2 + 4*Q^2*t^3 - 
          D*Q^2*t^3 - 4*s*t^3 + D*s*t^3)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^10 + D*Q^10 - 12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 
          3*D*Q^6*s^2 - 4*Q^4*s^3 + D*Q^4*s^3 - 20*Q^8*t + 5*D*Q^8*t - 
          38*Q^6*s*t + 8*D*Q^6*s*t - 20*Q^4*s^2*t + D*Q^4*s^2*t - 
          6*Q^2*s^3*t - 2*D*Q^2*s^3*t - 4*s^4*t - 28*Q^6*t^2 + 7*D*Q^6*t^2 + 
          2*Q^4*s*t^2 + D*Q^4*s*t^2 + 24*Q^2*s^2*t^2 - 5*D*Q^2*s^2*t^2 - 
          6*s^3*t^2 + D*s^3*t^2 - 12*Q^4*t^3 + 3*D*Q^4*t^3 + 16*Q^2*s*t^3 - 
          4*D*Q^2*s*t^3 - 4*s^2*t^3 + D*s^2*t^3)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-12*Q^8 + 3*D*Q^8 - 
          26*Q^6*s + 6*D*Q^6*s - 20*Q^4*s^2 + 3*D*Q^4*s^2 - 10*Q^2*s^3 - 
          4*s^4 - 24*Q^6*t + 6*D*Q^6*t - 2*Q^4*s*t + 2*D*Q^4*s*t + 
          20*Q^2*s^2*t - 4*D*Q^2*s^2*t - 2*s^3*t - 12*Q^4*t^2 + 3*D*Q^4*t^2 + 
          16*Q^2*s*t^2 - 4*D*Q^2*s*t^2 - 4*s^2*t^2 + D*s^2*t^2)*transverseK)/
        (Q*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 1, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (2*Q^10 + 9*Q^8*s + 15*Q^6*s^2 + 11*Q^4*s^3 + 3*Q^2*s^4 + 5*Q^8*t + 
           13*Q^6*s*t + 2*Q^4*s^2*t - 9*Q^2*s^3*t - 3*s^4*t + 4*Q^6*t^2 + 
           4*Q^4*s*t^2 - 6*Q^2*s^2*t^2 - 2*s^3*t^2 - Q^4*t^3 + 2*Q^2*s*t^3 - 
           s^2*t^3)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + 
          Q^2*s^3 + 2*Q^6*t + Q^4*s*t - 2*Q^2*s^2*t - s^3*t - Q^4*t^2 + 
          2*Q^2*s*t^2 - s^2*t^2)*transverseK)/(8*Q*s^2*SUNN^2*t*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + 
          Q^2*s^3 + 4*Q^6*t + Q^4*s*t - 4*Q^2*s^2*t - s^3*t + Q^4*t^2 - 
          2*Q^2*s*t^2 + s^2*t^2)*transverseK)/(8*Q*s*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 
          3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t + Q^4*s*t - 2*Q^2*s^2*t - s^3*t + 
          3*Q^4*t^2 - 2*Q^2*s*t^2 - s^2*t^2)*transverseK)/
        (8*Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t + Q^4*s*t - 
           2*Q^2*s^2*t - s^3*t - Q^4*t^2 + 2*Q^2*s*t^2 - s^2*t^2)*
          transverseK)/(Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^2*s + 2*s^2 - Q^2*t + 
           s*t)*transverseK)/(Q*s*SUNN^2*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 2, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^8*s + 7*Q^6*s^2 + 8*Q^4*s^3 + 3*Q^2*s^4 + 3*Q^6*s*t + 
          13*Q^4*s^2*t + 7*Q^2*s^3*t - 3*s^4*t - 2*Q^6*t^2 - Q^4*s*t^2 + 
          6*Q^2*s^2*t^2 - 3*s^3*t^2)*transverseK)/(8*Q*s^2*SUNN^2*t*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^4*s + Q^2*s^2 - 2*Q^4*t + 3*Q^2*s*t - s^2*t)*
          transverseK)/(Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^6*s + 2*Q^4*s^2 + Q^2*s^3 - 4*Q^6*t + Q^4*s*t + 4*Q^2*s^2*t - 
           s^3*t - 2*Q^4*t^2 + 4*Q^2*s*t^2 - 2*s^2*t^2)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> -1/8*((-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^4*s + Q^2*s^2 + 2*Q^4*t + 3*Q^2*s*t - s^2*t)*
          transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
           s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^4*s + Q^2*s^2 - 
          2*Q^4*t + 3*Q^2*s*t - s^2*t)*transverseK)/(8*Q*s*SUNN^2*t*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> -1/8*((-2 + D)*Q*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*transverseK)/(s*SUNN^2*(Q^2 + s + t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 3, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^8*s + 7*Q^6*s^2 + 8*Q^4*s^3 + 3*Q^2*s^4 - 4*Q^8*t - 3*Q^6*s*t + 
          15*Q^4*s^2*t + 13*Q^2*s^3*t - s^4*t - 4*Q^6*t^2 - 3*Q^4*s*t^2 + 
          8*Q^2*s^2*t^2 - s^3*t^2)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4*s + Q^2*s^2 - 4*Q^4*t + 3*Q^2*s*t + s^2*t)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^6*s + 2*Q^4*s^2 + Q^2*s^3 - 2*Q^6*t + 3*Q^4*s*t + 
          2*Q^2*s^2*t - 3*s^3*t - 2*Q^4*t^2 + 4*Q^2*s*t^2 - 2*s^2*t^2)*
         transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4 + Q^2*s + 3*Q^2*t + s*t)*transverseK)/(Q*s*SUNN^2*t*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4*s + Q^2*s^2 - 4*Q^4*t + 3*Q^2*s*t + s^2*t)*
         transverseK)/(Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (3*Q^6 + 3*Q^4*s - 2*Q^2*s^2 - 2*s^3 + 3*Q^4*t - Q^2*s*t - 2*s^2*t)*
         transverseK)/(Q*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t))|>, "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {5, 4, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (2*Q^10 + 9*Q^8*s + 15*Q^6*s^2 + 11*Q^4*s^3 + 3*Q^2*s^4 - 3*Q^8*t - 
           3*Q^6*s*t + 8*Q^4*s^2*t + 7*Q^2*s^3*t - s^4*t - 4*Q^6*t^2 - 
           4*Q^4*s*t^2 + 6*Q^2*s^2*t^2 + 2*s^3*t^2 + Q^4*t^3 - 2*Q^2*s*t^3 + 
           s^2*t^3)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^4 + Q^2*s - Q^2*t + s*t)*
         (Q^4 + 2*Q^2*s + s^2 - Q^2*t + s*t)*transverseK)/
        (8*Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 3*Q^4*s*t - 3*s^3*t - 
          Q^4*t^2 + 2*Q^2*s*t^2 - s^2*t^2)*transverseK)/
        (8*Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 - 2*Q^6*t - 
          Q^4*s*t + 2*Q^2*s^2*t + s^3*t - 3*Q^4*t^2 + 2*Q^2*s*t^2 + s^2*t^2)*
         transverseK)/(8*Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^4 + Q^2*s - Q^2*t + s*t)*
          (Q^4 + 2*Q^2*s + s^2 - Q^2*t + s*t)*transverseK)/
         (Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4*s^2 + 4*Q^2*s^3 + 
           2*s^4 + Q^6*t - 2*Q^4*s*t - Q^2*s^2*t + 2*s^3*t + Q^4*t^2 - 
           2*Q^2*s*t^2 + s^2*t^2)*transverseK)/(Q*s*SUNN^2*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {5, 5, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^12 + 2*D*Q^12 - 
           36*Q^10*s + 9*D*Q^10*s - 60*Q^8*s^2 + 15*D*Q^8*s^2 - 44*Q^6*s^3 + 
           11*D*Q^6*s^3 - 12*Q^4*s^4 + 3*D*Q^4*s^4 - 28*Q^10*t + 7*D*Q^10*t - 
           84*Q^8*s*t + 22*D*Q^8*s*t - 74*Q^6*s^2*t + 23*D*Q^6*s^2*t - 
           8*Q^4*s^3*t + 8*D*Q^4*s^3*t + 10*Q^2*s^4*t - 28*Q^8*t^2 + 
           7*D*Q^8*t^2 - 46*Q^6*s*t^2 + 13*D*Q^6*s*t^2 - 6*Q^4*s^2*t^2 + 
           6*D*Q^4*s^2*t^2 + 26*Q^2*s^3*t^2 - 3*D*Q^2*s^3*t^2 + 14*s^4*t^2 - 
           3*D*s^4*t^2 - 4*Q^6*t^3 + D*Q^6*t^3 - 10*Q^4*s*t^3 + 
           2*D*Q^4*s*t^3 - 4*Q^2*s^2*t^3 + D*Q^2*s^2*t^3 + 18*s^3*t^3 - 
           4*D*s^3*t^3 + 4*Q^4*t^4 - D*Q^4*t^4 - 8*Q^2*s*t^4 + 
           2*D*Q^2*s*t^4 + 4*s^2*t^4 - D*s^2*t^4)*transverseK)/
         (Q*s^2*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4 + Q^2*s - Q^2*t + s*t)*(-4*Q^6 + D*Q^6 - 8*Q^4*s + 2*D*Q^4*s - 
          4*Q^2*s^2 + D*Q^2*s^2 - 8*Q^4*t + 2*D*Q^4*t - 2*Q^2*s*t + 
          D*Q^2*s*t + 6*s^2*t - D*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - 
          D*s*t^2)*transverseK)/(16*Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^10 + D*Q^10 - 12*Q^8*s + 
          3*D*Q^8*s - 12*Q^6*s^2 + 3*D*Q^6*s^2 - 4*Q^4*s^3 + D*Q^4*s^3 - 
          4*Q^8*t + D*Q^8*t - 2*Q^6*s*t + 2*D*Q^6*s*t + 8*Q^4*s^2*t + 
          D*Q^4*s^2*t + 6*Q^2*s^3*t + 4*Q^6*t^2 - D*Q^6*t^2 - 2*Q^4*s*t^2 + 
          D*Q^4*s*t^2 - 4*Q^2*s^2*t^2 + D*Q^2*s^2*t^2 + 2*s^3*t^2 - 
          D*s^3*t^2 + 4*Q^4*t^3 - D*Q^4*t^3 - 8*Q^2*s*t^3 + 2*D*Q^2*s*t^3 + 
          4*s^2*t^3 - D*s^2*t^3)*transverseK)/(16*Q*s*SUNN^2*t*
         (Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4 + Q^2*s + 3*Q^2*t + s*t)*(-4*Q^6 + D*Q^6 - 
          8*Q^4*s + 2*D*Q^4*s - 4*Q^2*s^2 + D*Q^2*s^2 - 8*Q^4*t + 2*D*Q^4*t - 
          2*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - D*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 
          4*s*t^2 - D*s*t^2)*transverseK)/(16*Q*s^2*SUNN^2*t*(Q^2 + s + t)^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       -1/16*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^4 + Q^2*s - Q^2*t + s*t)*
          (-4*Q^6 + D*Q^6 - 8*Q^4*s + 2*D*Q^4*s - 4*Q^2*s^2 + D*Q^2*s^2 - 
           8*Q^4*t + 2*D*Q^4*t - 2*Q^2*s*t + D*Q^2*s*t + 6*s^2*t - D*s^2*t - 
           4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2)*transverseK)/
         (Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^4 + D*Q^4 - 2*Q^2*s + 
          D*Q^2*s + 2*s^2 - 4*Q^2*t + D*Q^2*t + 4*s*t - D*s*t)*transverseK)/
        (16*Q*s*SUNN^2*(Q^2 + s + t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 1, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^2 + 3*s - t)*
         (Q^2 + s + t))/(4*s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> -1/4*((-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^2 + s - t)*(Q^2 + s + t))/(s*(Q^2 + s)*SUNN^2*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        (4*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> -1/4*((-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^2 + s + t))/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> -1/4*((-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^2 + s - t)*(Q^2 + s + t))/((Q^2 + s)*SUNN^2*
          (Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*t*(Q^2 + s + t))/(4*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 2, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 - 4*Q^4*s + Q^2*s^2 + 
          3*s^3 - 2*Q^4*t - 3*Q^2*s*t + 3*s^2*t))/(4*s*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       -1/4*((-2 + D)*(-2*Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
         (s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + Q^2*s - s^2 + 2*Q^2*t - 
          2*s*t))/(4*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> -1/4*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2)/(SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> -1/4*((-2 + D)*(2*Q^2 - s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^2 + s + t))/(SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/4*((-2 + D)*Q^2*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
         (SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {6, 3, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^6 - 4*Q^4*s + 
          Q^2*s^2 + 3*s^3 - 2*Q^4*t - 3*Q^2*s*t + 3*s^2*t))/
        (s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/4*I)*(-2 + D)*(-2*Q^2 + s)*
         (-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        (s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4 + Q^2*s - s^2 + 
          2*Q^2*t - 2*s*t))/((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/4*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2)/(SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(2*Q^2 - s)*
         (-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        (SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/4*I)*(-2 + D)*Q^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^2 + s + t))/(SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {6, 4, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> -1/4*((-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(2*Q^2 + 3*s - t)*(Q^2 + s + t))/(s*(Q^2 + s)*SUNN^2*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s - t)*
         (Q^2 + s + t))/(4*s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> -1/4*((-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^2 + s + t))/((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + 
           Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(-Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s + t))/
        (4*s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 + s - t)*
         (Q^2 + s + t))/(4*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/4*((-2 + D)*(Q^2 - s)*(-1 + SUNN)^2*(1 + SUNN)^2*t*(Q^2 + s + t))/
         ((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {6, 5, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^6*s - 14*Q^4*s^2 - 16*Q^2*s^3 - 6*s^4 - 6*Q^4*s*t + 
          D*Q^4*s*t - 10*Q^2*s^2*t + D*Q^2*s^2*t - 4*s^3*t - 4*Q^4*t^2 + 
          D*Q^4*t^2 - 6*Q^2*s*t^2 + 2*D*Q^2*s*t^2 + 6*s^2*t^2 - D*s^2*t^2 - 
          4*Q^2*t^3 + D*Q^2*t^3 + 4*s*t^3 - D*s*t^3))/(8*s*(Q^2 + s)*SUNN^2*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-2*Q^4*s - 4*Q^2*s^2 - 2*s^3 - 4*Q^4*t + D*Q^4*t - 2*Q^2*s*t + 
           D*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/
         (s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-2*Q^4*s - 4*Q^2*s^2 - 2*s^3 - 4*Q^4*t + D*Q^4*t - 6*Q^2*s*t + 
           D*Q^2*s*t - 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/
         ((Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^4*s + 4*Q^2*s^2 + 2*s^3 - 4*Q^4*t + D*Q^4*t - 2*Q^2*s*t + 
          D*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/
        (8*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^4*s - 4*Q^2*s^2 - 2*s^3 - 4*Q^4*t + D*Q^4*t - 2*Q^2*s*t + 
          D*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 4*s*t^2 - D*s*t^2))/
        (8*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*t*(-4*Q^4 + D*Q^4 - 2*Q^2*s + 
          D*Q^2*s + 2*s^2 - 4*Q^2*t + D*Q^2*t + 4*s*t - D*s*t))/
        (8*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 1, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^8 + 7*Q^6*s + 8*Q^4*s^2 + 3*Q^2*s^3 + 5*Q^6*t + 
          4*Q^4*s*t - 4*Q^2*s^2*t - s^3*t + 4*Q^4*t^2 - 6*Q^2*s*t^2 + 
          2*s^2*t^2 - Q^2*t^3 + s*t^3)*transverseK)/(8*Q*s^2*SUNN^2*t*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^6 + 2*Q^4*s + Q^2*s^2 + 2*Q^4*t - 3*Q^2*s*t + 
           s^2*t - Q^2*t^2 + s*t^2)*transverseK)/(Q*s^2*SUNN^2*t*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^6 + 2*Q^4*s + Q^2*s^2 + 4*Q^4*t - Q^2*s*t - 3*s^2*t + Q^2*t^2 - 
           s*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t - Q^4*s*t - 
           2*Q^2*s^2*t + s^3*t + 3*Q^4*t^2 - 4*Q^2*s*t^2 + s^2*t^2)*
          transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
           s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^6 + 2*Q^4*s + 
          Q^2*s^2 + 2*Q^4*t - 3*Q^2*s*t + s^2*t - Q^2*t^2 + s*t^2)*
         transverseK)/(8*Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-2*Q^2*s^2 - 2*s^3 + Q^4*t + Q^2*s*t - 2*s^2*t + Q^2*t^2 - s*t^2)*
          transverseK)/(Q*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
           s*t))|>, "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 2, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^4*s + 3*Q^2*s^2 + 3*Q^2*s*t - s^2*t + 2*Q^2*t^2 - 
          s*t^2)*transverseK)/(8*Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^4*s + Q^2*s^2 + 2*Q^4*t - Q^2*s*t + s^2*t)*transverseK)/
         (Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^4*s + Q^2*s^2 + 4*Q^4*t + Q^2*s*t - 3*s^2*t + 
           2*Q^2*t^2 - 2*s*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)^3*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^2*s - 2*Q^2*t + s*t)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^4*s + Q^2*s^2 + 
          2*Q^4*t - Q^2*s*t + s^2*t)*transverseK)/(8*Q*s*SUNN^2*t*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^6 + Q^4*s + 2*Q^2*s^2 + 2*s^3 + Q^4*t - Q^2*s*t + 
          2*s^2*t)*transverseK)/(8*Q*s*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {7, 3, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^4*s + 3*Q^2*s^2 + 4*Q^4*t + Q^2*s*t - 3*s^2*t + 4*Q^2*t^2 - 
          3*s*t^2)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4*s + Q^2*s^2 + 4*Q^4*t - Q^2*s*t - s^2*t)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4*s + Q^2*s^2 + 2*Q^4*t + Q^2*s*t - s^2*t + 
          2*Q^2*t^2 - 2*s*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-1/8*I)*(-2 + D)*(Q^2 + s)^3*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^2 - t)*
         transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4*s + Q^2*s^2 + 4*Q^4*t - Q^2*s*t - s^2*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*Q*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (3*Q^4 + 3*Q^2*s + 3*Q^2*t - s*t)*transverseK)/
        (s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 4, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^8 + 7*Q^6*s + 8*Q^4*s^2 + 3*Q^2*s^3 - 3*Q^6*t + 
          4*Q^4*s*t + 6*Q^2*s^2*t - 3*s^3*t - 4*Q^4*t^2 + 6*Q^2*s*t^2 - 
          2*s^2*t^2 + Q^2*t^3 - s*t^3)*transverseK)/(8*Q*s^2*SUNN^2*t*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^6 + 2*Q^4*s + Q^2*s^2 - 2*Q^4*t + 3*Q^2*s*t - 
           s^2*t + Q^2*t^2 - s*t^2)*transverseK)/(Q*s^2*SUNN^2*t*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^6 + 2*Q^4*s + Q^2*s^2 + Q^2*s*t - s^2*t - Q^2*t^2 + s*t^2)*
          transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
           s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 - 2*Q^6*t + Q^4*s*t + 
           2*Q^2*s^2*t - s^3*t - 3*Q^4*t^2 + 4*Q^2*s*t^2 - s^2*t^2)*
          transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
           s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^6 + 2*Q^4*s + 
          Q^2*s^2 - 2*Q^4*t + 3*Q^2*s*t - s^2*t + Q^2*t^2 - s*t^2)*
         transverseK)/(8*Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^4*s + 2*Q^2*s^2 + 
          Q^4*t + Q^2*s*t - 2*s^2*t + Q^2*t^2 - s*t^2)*transverseK)/
        (8*Q*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {7, 5, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-8*Q^10 + 2*D*Q^10 - 28*Q^8*s + 7*D*Q^8*s - 
          32*Q^6*s^2 + 8*D*Q^6*s^2 - 12*Q^4*s^3 + 3*D*Q^4*s^3 - 28*Q^8*t + 
          7*D*Q^8*t - 40*Q^6*s*t + 11*D*Q^6*s*t + 14*Q^4*s^2*t - 
          2*D*Q^4*s^2*t + 22*Q^2*s^3*t - 6*D*Q^2*s^3*t - 4*s^4*t - 
          28*Q^6*t^2 + 7*D*Q^6*t^2 + 22*Q^4*s*t^2 - 4*D*Q^4*s*t^2 + 
          40*Q^2*s^2*t^2 - 10*D*Q^2*s^2*t^2 - 18*s^3*t^2 + 3*D*s^3*t^2 - 
          4*Q^4*t^3 + D*Q^4*t^3 + 26*Q^2*s*t^3 - 7*D*Q^2*s*t^3 - 18*s^2*t^3 + 
          4*D*s^2*t^3 + 4*Q^2*t^4 - D*Q^2*t^4 - 4*s*t^4 + D*s*t^4)*
         transverseK)/(16*Q*s^2*SUNN^2*t*(Q^2 + s + t)^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^8 + D*Q^8 - 8*Q^6*s + 2*D*Q^6*s - 4*Q^4*s^2 + D*Q^4*s^2 - 
           4*Q^6*t + D*Q^6*t + 6*Q^4*s*t - D*Q^4*s*t + 6*Q^2*s^2*t - 
           2*D*Q^2*s^2*t - 4*s^3*t + 4*Q^4*t^2 - D*Q^4*t^2 + 6*Q^2*s*t^2 - 
           2*D*Q^2*s*t^2 - 6*s^2*t^2 + D*s^2*t^2 + 4*Q^2*t^3 - D*Q^2*t^3 - 
           4*s*t^3 + D*s*t^3)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^8 + D*Q^8 - 8*Q^6*s + 2*D*Q^6*s - 4*Q^4*s^2 + D*Q^4*s^2 - 
           4*Q^6*t + D*Q^6*t + 10*Q^4*s*t - D*Q^4*s*t + 18*Q^2*s^2*t - 
           2*D*Q^2*s^2*t + 4*s^3*t + 4*Q^4*t^2 - D*Q^4*t^2 + 10*Q^2*s*t^2 - 
           2*D*Q^2*s*t^2 - 2*s^2*t^2 + D*s^2*t^2 + 4*Q^2*t^3 - D*Q^2*t^3 - 
           4*s*t^3 + D*s*t^3)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)^2*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^10 + D*Q^10 - 12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 
           3*D*Q^6*s^2 - 4*Q^4*s^3 + D*Q^4*s^3 - 20*Q^8*t + 5*D*Q^8*t - 
           30*Q^6*s*t + 8*D*Q^6*s*t - 4*Q^4*s^2*t + D*Q^4*s^2*t + 
           2*Q^2*s^3*t - 2*D*Q^2*s^3*t - 4*s^4*t - 28*Q^6*t^2 + 7*D*Q^6*t^2 + 
           2*Q^4*s*t^2 + D*Q^4*s*t^2 + 24*Q^2*s^2*t^2 - 5*D*Q^2*s^2*t^2 - 
           6*s^3*t^2 + D*s^3*t^2 - 12*Q^4*t^3 + 3*D*Q^4*t^3 + 16*Q^2*s*t^3 - 
           4*D*Q^2*s*t^3 - 4*s^2*t^3 + D*s^2*t^3)*transverseK)/
         (Q*s^2*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^8 + D*Q^8 - 8*Q^6*s + 2*D*Q^6*s - 4*Q^4*s^2 + 
          D*Q^4*s^2 - 4*Q^6*t + D*Q^6*t + 6*Q^4*s*t - D*Q^4*s*t + 
          6*Q^2*s^2*t - 2*D*Q^2*s^2*t - 4*s^3*t + 4*Q^4*t^2 - D*Q^4*t^2 + 
          6*Q^2*s*t^2 - 2*D*Q^2*s*t^2 - 6*s^2*t^2 + D*s^2*t^2 + 4*Q^2*t^3 - 
          D*Q^2*t^3 - 4*s*t^3 + D*s*t^3)*transverseK)/(16*Q*s*SUNN^2*t*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/16*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-4*Q^6 + D*Q^6 - 2*Q^4*s + D*Q^4*s + 6*Q^2*s^2 + 4*s^3 - 8*Q^4*t + 
           2*D*Q^4*t + 2*Q^2*s*t + 2*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 
           4*s*t^2 - D*s*t^2)*transverseK)/(Q*s*SUNN^2*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 1, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^10 + 9*Q^8*s + 
          15*Q^6*s^2 + 11*Q^4*s^3 + 3*Q^2*s^4 - 3*Q^8*t + Q^6*s*t + 
          10*Q^4*s^2*t + 3*Q^2*s^3*t - 3*s^4*t + 2*Q^2*s^2*t^2 - 2*s^3*t^2 + 
          3*Q^4*t^3 - 2*Q^2*s*t^3 - s^2*t^3)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 - 2*Q^6*t + Q^4*s*t + 
          2*Q^2*s^2*t - s^3*t + 3*Q^4*t^2 - 2*Q^2*s*t^2 - s^2*t^2)*
         transverseK)/(Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + Q^4*s*t - s^3*t - 3*Q^4*t^2 + 
          2*Q^2*s*t^2 + s^2*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 - 2*Q^6*t + Q^4*s*t + 
          2*Q^2*s^2*t - s^3*t - Q^4*t^2 + 2*Q^2*s*t^2 - s^2*t^2)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 - 2*Q^6*t + 
          Q^4*s*t + 2*Q^2*s^2*t - s^3*t + 3*Q^4*t^2 - 2*Q^2*s*t^2 - s^2*t^2)*
         transverseK)/(Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(2*Q^6*s + 4*Q^4*s^2 + 
          2*Q^2*s^3 + 3*Q^6*t + 2*Q^4*s*t - 3*Q^2*s^2*t - 2*s^3*t + 
          3*Q^4*t^2 - 2*Q^2*s*t^2 - s^2*t^2)*transverseK)/
        (Q*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 2, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (2*Q^8*s + 7*Q^6*s^2 + 8*Q^4*s^3 + 3*Q^2*s^4 + 8*Q^8*t + 
          19*Q^6*s*t + 9*Q^4*s^2*t - 5*Q^2*s^3*t - 3*s^4*t + 6*Q^6*t^2 + 
          11*Q^4*s*t^2 - 6*Q^2*s^2*t^2 - 3*s^3*t^2)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-1/8*I)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4*s + Q^2*s^2 + 6*Q^4*t - Q^2*s*t - s^2*t)*
         transverseK)/(Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^6*s + 2*Q^4*s^2 + Q^2*s^3 + 4*Q^6*t + 5*Q^4*s*t - 
          s^3*t + 6*Q^4*t^2 - 4*Q^2*s*t^2 - 2*s^2*t^2)*transverseK)/
        (Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-1/8*I)*(-2 + D)*(Q^2 + s)^2*
         (-1 + SUNN)^2*(1 + SUNN)^2*(Q^4*s + Q^2*s^2 + 2*Q^4*t - Q^2*s*t - 
          s^2*t)*transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^4*s + Q^2*s^2 + 6*Q^4*t - Q^2*s*t - s^2*t)*transverseK)/
        (Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*Q*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (3*Q^4 + 3*Q^2*s + 3*Q^2*t + s*t)*transverseK)/
        (s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 3, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> -1/8*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (2*Q^8*s + 7*Q^6*s^2 + 8*Q^4*s^3 + 3*Q^2*s^4 + 4*Q^8*t + 
           13*Q^6*s*t + 11*Q^4*s^2*t + Q^2*s^3*t - s^4*t + 4*Q^6*t^2 + 
           9*Q^4*s*t^2 - 4*Q^2*s^2*t^2 - s^3*t^2)*transverseK)/
         (Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4*s + Q^2*s^2 + 4*Q^4*t - Q^2*s*t + s^2*t)*
         transverseK)/(8*Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^6*s + 2*Q^4*s^2 + Q^2*s^3 + 6*Q^6*t + 7*Q^4*s*t - 2*Q^2*s^2*t - 
          3*s^3*t + 6*Q^4*t^2 - 4*Q^2*s*t^2 - 2*s^2*t^2)*transverseK)/
        (8*Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4 + Q^2*s - Q^2*t + s*t)*transverseK)/
        (8*Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*(Q^4*s + Q^2*s^2 + 4*Q^4*t - Q^2*s*t + s^2*t)*
          transverseK)/(Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (Q^6 + Q^4*s + 2*Q^2*s^2 + 2*s^3 + Q^4*t + Q^2*s*t + 2*s^2*t)*
          transverseK)/(Q*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
           s*t))|>, "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {8, 4, 1}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(2*Q^10 + 9*Q^8*s + 15*Q^6*s^2 + 11*Q^4*s^3 + 
          3*Q^2*s^4 + 5*Q^8*t + 9*Q^6*s*t - 5*Q^2*s^3*t - s^4*t - 
          2*Q^2*s^2*t^2 + 2*s^3*t^2 - 3*Q^4*t^3 + 2*Q^2*s*t^3 + s^2*t^3)*
         transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^8 + 3*Q^6*s + 
          3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t - Q^4*s*t - 2*Q^2*s^2*t + s^3*t - 
          3*Q^4*t^2 + 2*Q^2*s*t^2 + s^2*t^2)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 4*Q^6*t + 3*Q^4*s*t - 
          4*Q^2*s^2*t - 3*s^3*t + 3*Q^4*t^2 - 2*Q^2*s*t^2 - s^2*t^2)*
         transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t - Q^4*s*t - 
          2*Q^2*s^2*t + s^3*t + Q^4*t^2 - 2*Q^2*s*t^2 + s^2*t^2)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^8 + 3*Q^6*s + 3*Q^4*s^2 + Q^2*s^3 + 2*Q^6*t - 
          Q^4*s*t - 2*Q^2*s^2*t + s^3*t - 3*Q^4*t^2 + 2*Q^2*s*t^2 + s^2*t^2)*
         transverseK)/(Q*s*SUNN^2*t*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^4*s^2 - 4*Q^2*s^3 - 
          2*s^4 + 3*Q^6*t + 2*Q^4*s*t - 3*Q^2*s^2*t - 2*s^3*t + 3*Q^4*t^2 - 
          2*Q^2*s*t^2 - s^2*t^2)*transverseK)/(Q*s*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {8, 5, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-8*Q^12 + 2*D*Q^12 - 
          36*Q^10*s + 9*D*Q^10*s - 60*Q^8*s^2 + 15*D*Q^8*s^2 - 44*Q^6*s^3 + 
          11*D*Q^6*s^3 - 12*Q^4*s^4 + 3*D*Q^4*s^4 - 28*Q^10*t + 7*D*Q^10*t - 
          116*Q^8*s*t + 26*D*Q^8*s*t - 162*Q^6*s^2*t + 31*D*Q^6*s^2*t - 
          88*Q^4*s^3*t + 12*D*Q^4*s^3*t - 14*Q^2*s^4*t - 44*Q^8*t^2 + 
          11*D*Q^8*t^2 - 118*Q^6*s*t^2 + 29*D*Q^6*s*t^2 - 62*Q^4*s^2*t^2 + 
          14*D*Q^4*s^2*t^2 + 26*Q^2*s^3*t^2 - 7*D*Q^2*s^3*t^2 + 14*s^4*t^2 - 
          3*D*s^4*t^2 - 36*Q^6*t^3 + 9*D*Q^6*t^3 - 34*Q^4*s*t^3 + 
          10*D*Q^4*s*t^3 + 36*Q^2*s^2*t^3 - 7*D*Q^2*s^2*t^3 + 18*s^3*t^3 - 
          4*D*s^3*t^3 - 12*Q^4*t^4 + 3*D*Q^4*t^4 + 8*Q^2*s*t^4 - 
          2*D*Q^2*s*t^4 + 4*s^2*t^4 - D*s^2*t^4)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^10 + D*Q^10 - 12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 
          3*D*Q^6*s^2 - 4*Q^4*s^3 + D*Q^4*s^3 - 20*Q^8*t + 5*D*Q^8*t - 
          46*Q^6*s*t + 10*D*Q^6*s*t - 32*Q^4*s^2*t + 5*D*Q^4*s^2*t - 
          6*Q^2*s^3*t - 28*Q^6*t^2 + 7*D*Q^6*t^2 - 14*Q^4*s*t^2 + 
          5*D*Q^4*s*t^2 + 20*Q^2*s^2*t^2 - 3*D*Q^2*s^2*t^2 + 6*s^3*t^2 - 
          D*s^3*t^2 - 12*Q^4*t^3 + 3*D*Q^4*t^3 + 8*Q^2*s*t^3 - 
          2*D*Q^2*s*t^3 + 4*s^2*t^3 - D*s^2*t^3)*transverseK)/
        (Q*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/16)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^4 + Q^2*s + 3*Q^2*t + s*t)*(-4*Q^6 + D*Q^6 - 
          8*Q^4*s + 2*D*Q^4*s - 4*Q^2*s^2 + D*Q^2*s^2 - 8*Q^4*t + 2*D*Q^4*t - 
          6*Q^2*s*t + D*Q^2*s*t + 2*s^2*t - D*s^2*t - 4*Q^2*t^2 + D*Q^2*t^2 + 
          4*s*t^2 - D*s*t^2)*transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/16)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^10 + D*Q^10 - 12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 
          3*D*Q^6*s^2 - 4*Q^4*s^3 + D*Q^4*s^3 - 4*Q^8*t + D*Q^8*t - 
          14*Q^6*s*t + 2*D*Q^6*s*t - 16*Q^4*s^2*t + D*Q^4*s^2*t - 
          6*Q^2*s^3*t + 4*Q^6*t^2 - D*Q^6*t^2 - 6*Q^4*s*t^2 + D*Q^4*s*t^2 - 
          4*Q^2*s^2*t^2 + D*Q^2*s^2*t^2 + 6*s^3*t^2 - D*s^3*t^2 + 4*Q^4*t^3 - 
          D*Q^4*t^3 - 8*Q^2*s*t^3 + 2*D*Q^2*s*t^3 + 4*s^2*t^3 - D*s^2*t^3)*
         transverseK)/(Q*s^2*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^10 + D*Q^10 - 
          12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 3*D*Q^6*s^2 - 4*Q^4*s^3 + 
          D*Q^4*s^3 - 20*Q^8*t + 5*D*Q^8*t - 46*Q^6*s*t + 10*D*Q^6*s*t - 
          32*Q^4*s^2*t + 5*D*Q^4*s^2*t - 6*Q^2*s^3*t - 28*Q^6*t^2 + 
          7*D*Q^6*t^2 - 14*Q^4*s*t^2 + 5*D*Q^4*s*t^2 + 20*Q^2*s^2*t^2 - 
          3*D*Q^2*s^2*t^2 + 6*s^3*t^2 - D*s^3*t^2 - 12*Q^4*t^3 + 
          3*D*Q^4*t^3 + 8*Q^2*s*t^3 - 2*D*Q^2*s*t^3 + 4*s^2*t^3 - D*s^2*t^3)*
         transverseK)/(Q*s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - 
          s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-1/16*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-12*Q^8 + 3*D*Q^8 - 26*Q^6*s + 6*D*Q^6*s - 
          16*Q^4*s^2 + 3*D*Q^4*s^2 - 2*Q^2*s^3 - 24*Q^6*t + 6*D*Q^6*t - 
          10*Q^4*s*t + 4*D*Q^4*s*t + 16*Q^2*s^2*t - 2*D*Q^2*s^2*t + 2*s^3*t - 
          12*Q^4*t^2 + 3*D*Q^4*t^2 + 8*Q^2*s*t^2 - 2*D*Q^2*s*t^2 + 
          4*s^2*t^2 - D*s^2*t^2)*transverseK)/(Q*s*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 1, 4}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^10 - 8*Q^8*s - 
          9*Q^6*s^2 + Q^4*s^3 + 7*Q^2*s^4 + 3*s^5 - 4*Q^6*s*t - 7*Q^4*s^2*t + 
          3*s^4*t + Q^6*t^2 + Q^4*s*t^2 - 2*Q^2*s^2*t^2 - Q^4*t^3 + 
          Q^2*s*t^3))/(s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^8 - 5*Q^6*s - 
          3*Q^4*s^2 + Q^2*s^3 + s^4 + Q^6*t - Q^2*s^2*t - Q^4*t^2 + 
          Q^2*s*t^2))/(s^2*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^8 - 5*Q^6*s - 3*Q^4*s^2 + Q^2*s^3 + s^4 - Q^6*t - 2*Q^4*s*t + 
          Q^2*s^2*t + 2*s^3*t + Q^4*t^2 - Q^2*s*t^2))/(s*(Q^2 + s)*SUNN^2*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (Q^6*s + 3*Q^4*s^2 + 3*Q^2*s^3 + s^4 + Q^6*t - Q^2*s^2*t + Q^4*t^2 - 
          Q^2*s*t^2))/(s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^8 - 5*Q^6*s - 3*Q^4*s^2 + Q^2*s^3 + s^4 + Q^6*t - 
          Q^2*s^2*t - Q^4*t^2 + Q^2*s*t^2))/(s*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/4)*(-2 + D)*Q^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^6 + 3*Q^4*s + 3*Q^2*s^2 + s^3 + Q^2*t^2 - s*t^2))/
        (s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 2, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^10 - 7*Q^8*s - 6*Q^6*s^2 + 4*Q^4*s^3 + 
          8*Q^2*s^4 + 3*s^5 + Q^8*t + Q^6*s*t - 2*Q^4*s^2*t + 2*s^4*t + 
          3*Q^6*t^2 + 4*Q^4*s*t^2 - 4*Q^2*s^2*t^2 - s^3*t^2))/
        (s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^6 - Q^4*s + Q^2*s^2 + s^3 + 3*Q^4*t - Q^2*s*t - s^2*t))/
        (s^2*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^8 - 2*Q^6*s + 2*Q^2*s^3 + s^4 + Q^6*t + s^3*t + 2*Q^4*t^2 - 
          2*Q^2*s*t^2))/(s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/4)*(-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-Q^6 - Q^4*s + Q^2*s^2 + s^3 - Q^4*t - Q^2*s*t + s^2*t))/
        (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-Q^6 - Q^4*s + Q^2*s^2 + s^3 + 3*Q^4*t - Q^2*s*t - 
          s^2*t))/(s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(2*Q^4 - s^2)*(-1 + SUNN)^2*(1 + SUNN)^2*t)/
        (s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 3, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/4*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^10 - 7*Q^8*s - 
           6*Q^6*s^2 + 4*Q^4*s^3 + 8*Q^2*s^4 + 3*s^5 - 3*Q^8*t - 7*Q^6*s*t + 
           6*Q^2*s^3*t + 2*s^4*t - Q^6*t^2 - 2*Q^4*s*t^2 + 2*Q^2*s^2*t^2 - 
           s^3*t^2))/(s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-Q^6 - Q^4*s + Q^2*s^2 + s^3 - 
          Q^4*t + Q^2*s*t - s^2*t))/(4*s^2*SUNN^2*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-Q^8 - 2*Q^6*s + 2*Q^2*s^3 + 
          s^4 - 3*Q^6*t - 2*Q^4*s*t + 2*Q^2*s^2*t + s^3*t - 2*Q^4*t^2 + 
          2*Q^2*s*t^2))/(4*s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*(-Q^6 - Q^4*s + 
          Q^2*s^2 + s^3 - Q^4*t + Q^2*s*t + s^2*t))/(4*s^2*SUNN^2*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> -1/4*((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
          (-Q^6 - Q^4*s + Q^2*s^2 + s^3 - Q^4*t + Q^2*s*t - s^2*t))/
         (s*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-2 + D)*s*(-1 + SUNN)^2*(1 + SUNN)^2*t)/
        (4*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "ExtendedResponse", "Index" -> {9, 4, 1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^10 - 8*Q^8*s - 
          9*Q^6*s^2 + Q^4*s^3 + 7*Q^2*s^4 + 3*s^5 - 4*Q^8*t - 10*Q^6*s*t - 
          3*Q^4*s^2*t + 6*Q^2*s^3*t + 3*s^4*t - Q^6*t^2 - Q^4*s*t^2 + 
          2*Q^2*s^2*t^2 + Q^4*t^3 - Q^2*s*t^3))/(s^2*(Q^2 + s)*SUNN^2*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-2*Q^8 - 5*Q^6*s - 3*Q^4*s^2 + Q^2*s^3 + s^4 - Q^6*t + Q^2*s^2*t + 
          Q^4*t^2 - Q^2*s*t^2))/(s^2*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-2*Q^8 - 5*Q^6*s - 
          3*Q^4*s^2 + Q^2*s^3 + s^4 - 3*Q^6*t - 2*Q^4*s*t + 3*Q^2*s^2*t + 
          2*s^3*t - Q^4*t^2 + Q^2*s*t^2))/(s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/4)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(Q^6*s + 3*Q^4*s^2 + 
          3*Q^2*s^3 + s^4 - Q^6*t + Q^2*s^2*t - Q^4*t^2 + Q^2*s*t^2))/
        (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-1/4*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-2*Q^8 - 5*Q^6*s - 3*Q^4*s^2 + Q^2*s^3 + s^4 - Q^6*t + 
          Q^2*s^2*t + Q^4*t^2 - Q^2*s*t^2))/(s*(Q^2 + s)*SUNN^2*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((I/4)*(-2 + D)*Q^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*(Q^6 + 3*Q^4*s + 3*Q^2*s^2 + s^3 - Q^2*t^2 + s*t^2))/
        (s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "ExtendedResponse", 
    "Index" -> {9, 5, 4}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (D*Q^8*s + 10*Q^6*s^2 + 2*D*Q^6*s^2 + 26*Q^4*s^3 + D*Q^4*s^3 + 
          22*Q^2*s^4 + 6*s^5 - 4*Q^8*t + D*Q^8*t - 22*Q^6*s*t + 4*D*Q^6*s*t - 
          24*Q^4*s^2*t + 2*D*Q^4*s^2*t - 8*Q^2*s^3*t - D*Q^2*s^3*t - 
          2*s^4*t - 8*Q^6*t^2 + 2*D*Q^6*t^2 - 6*Q^4*s*t^2 + 2*D*Q^4*s*t^2 + 
          10*Q^2*s^2*t^2 - 2*D*Q^2*s^2*t^2 - 4*Q^4*t^3 + D*Q^4*t^3 + 
          4*Q^2*s*t^3 - D*Q^2*s*t^3))/(s^2*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^10 + D*Q^10 - 
          10*Q^8*s + 3*D*Q^8*s - 4*Q^6*s^2 + 3*D*Q^6*s^2 + 8*Q^4*s^3 + 
          D*Q^4*s^3 + 8*Q^2*s^4 + 2*s^5 - 12*Q^8*t + 3*D*Q^8*t - 24*Q^6*s*t + 
          5*D*Q^6*s*t - 14*Q^4*s^2*t + D*Q^4*s^2*t - 4*Q^2*s^3*t - 
          D*Q^2*s^3*t - 2*s^4*t - 12*Q^6*t^2 + 3*D*Q^6*t^2 - 2*Q^4*s*t^2 + 
          D*Q^4*s*t^2 + 10*Q^2*s^2*t^2 - 2*D*Q^2*s^2*t^2 - 4*Q^4*t^3 + 
          D*Q^4*t^3 + 4*Q^2*s*t^3 - D*Q^2*s*t^3))/(s^2*(Q^2 + s)*SUNN^2*
         (Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-1/8*I)*(-2 + D)*(-1 + SUNN)^2*
         (1 + SUNN)^2*(-4*Q^8 + D*Q^8 - 6*Q^6*s + 2*D*Q^6*s + 2*Q^4*s^2 + 
          D*Q^4*s^2 + 6*Q^2*s^3 + 2*s^4 - 8*Q^6*t + 2*D*Q^6*t - 6*Q^4*s*t + 
          D*Q^4*s*t + 2*Q^2*s^2*t - D*Q^2*s^2*t - 4*Q^4*t^2 + D*Q^4*t^2 + 
          4*Q^2*s*t^2 - D*Q^2*s*t^2))/(s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, -1, 1, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^8 + D*Q^8 - 
          10*Q^6*s + 2*D*Q^6*s - 10*Q^4*s^2 + D*Q^4*s^2 - 6*Q^2*s^3 - 2*s^4 - 
          8*Q^6*t + 2*D*Q^6*t - 2*Q^4*s*t + D*Q^4*s*t + 6*Q^2*s^2*t - 
          D*Q^2*s^2*t - 4*Q^4*t^2 + D*Q^4*t^2 + 4*Q^2*s*t^2 - D*Q^2*s*t^2))/
        (s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*Q^10 + D*Q^10 - 10*Q^8*s + 3*D*Q^8*s - 4*Q^6*s^2 + 3*D*Q^6*s^2 + 
          8*Q^4*s^3 + D*Q^4*s^3 + 8*Q^2*s^4 + 2*s^5 - 12*Q^8*t + 3*D*Q^8*t - 
          24*Q^6*s*t + 5*D*Q^6*s*t - 14*Q^4*s^2*t + D*Q^4*s^2*t - 
          4*Q^2*s^3*t - D*Q^2*s^3*t - 2*s^4*t - 12*Q^6*t^2 + 3*D*Q^6*t^2 - 
          2*Q^4*s*t^2 + D*Q^4*s*t^2 + 10*Q^2*s^2*t^2 - 2*D*Q^2*s^2*t^2 - 
          4*Q^4*t^3 + D*Q^4*t^3 + 4*Q^2*s*t^3 - D*Q^2*s*t^3))/
        (s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((I/8)*(-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*(-4*Q^10 + D*Q^10 - 
          12*Q^8*s + 3*D*Q^8*s - 12*Q^6*s^2 + 3*D*Q^6*s^2 - 4*Q^4*s^3 + 
          D*Q^4*s^3 - 12*Q^8*t + 3*D*Q^8*t - 22*Q^6*s*t + 5*D*Q^6*s*t - 
          10*Q^4*s^2*t + D*Q^4*s^2*t - 2*Q^2*s^3*t - D*Q^2*s^3*t - 2*s^4*t - 
          12*Q^6*t^2 + 3*D*Q^6*t^2 - 2*Q^4*s*t^2 + D*Q^4*s*t^2 + 
          10*Q^2*s^2*t^2 - 2*D*Q^2*s^2*t^2 - 4*Q^4*t^3 + D*Q^4*t^3 + 
          4*Q^2*s*t^3 - D*Q^2*s*t^3))/(s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonMetricD", "Index" -> {}, "Coefficients" -> 
     <|GLI["V09", {0, 0, 0, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         ((8*I)*Q^8 - (4*I)*D*Q^8 - (24*I)*hIn*hOut*Q^8 + 
          (4*I)*D*hIn*hOut*Q^8 + (8*I)*Q^6*s - (8*I)*D*Q^6*s + 
          (16*I)*eOut*Q^6*s - (2*I)*D*eOut*Q^6*s - I*D^2*eOut*Q^6*s - 
          (56*I)*hIn*hOut*Q^6*s + (8*I)*D*hIn*hOut*Q^6*s - (20*I)*Q^4*s^2 + 
          (2*I)*D*Q^4*s^2 + (52*I)*eOut*Q^4*s^2 - (16*I)*D*eOut*Q^4*s^2 - 
          I*D^2*eOut*Q^4*s^2 - (4*I)*hIn*hOut*Q^4*s^2 - (2*I)*D*hIn*hOut*Q^4*
           s^2 - (8*I)*Q^2*s^3 + (6*I)*D*Q^2*s^3 + (24*I)*eOut*Q^2*s^3 - 
          (14*I)*D*eOut*Q^2*s^3 + (40*I)*hIn*hOut*Q^2*s^3 - 
          (6*I)*D*hIn*hOut*Q^2*s^3 + (12*I)*s^4 - (12*I)*eOut*s^4 + 
          (12*I)*hIn*hOut*s^4 - (8*I)*eOut*Q^6*t + (6*I)*D*eOut*Q^6*t - 
          I*D^2*eOut*Q^6*t - (48*I)*hIn*hOut*Q^6*t + (8*I)*D*hIn*hOut*Q^6*t - 
          (24*I)*Q^4*s*t + (12*I)*eOut*Q^4*s*t + (12*I)*D*eOut*Q^4*s*t - 
          (3*I)*D^2*eOut*Q^4*s*t - (64*I)*hIn*hOut*Q^4*s*t + 
          (12*I)*D*hIn*hOut*Q^4*s*t - (16*I)*Q^2*s^2*t + (2*I)*D*Q^2*s^2*t + 
          (12*I)*eOut*Q^2*s^2*t + (48*I)*hIn*hOut*Q^2*s^2*t - 
          (10*I)*D*hIn*hOut*Q^2*s^2*t + (40*I)*s^3*t - (6*I)*D*s^3*t - 
          (56*I)*eOut*s^3*t + (14*I)*D*eOut*s^3*t + (32*I)*hIn*hOut*s^3*t - 
          (6*I)*D*hIn*hOut*s^3*t - (4*I)*Q^4*t^2 + (2*I)*D*Q^4*t^2 - 
          (16*I)*eOut*Q^4*t^2 + (12*I)*D*eOut*Q^4*t^2 - (2*I)*D^2*eOut*Q^4*
           t^2 - (12*I)*hIn*hOut*Q^4*t^2 + (2*I)*D*hIn*hOut*Q^4*t^2 - 
          (20*I)*Q^2*s*t^2 + (2*I)*D*Q^2*s*t^2 + (28*I)*eOut*Q^2*s*t^2 - 
          (4*I)*D*eOut*Q^2*s*t^2 - I*D^2*eOut*Q^2*s*t^2 + 
          (4*I)*hIn*hOut*Q^2*s*t^2 + (2*I)*D*hIn*hOut*Q^2*s*t^2 + 
          (24*I)*s^2*t^2 - (4*I)*D*s^2*t^2 - (20*I)*eOut*s^2*t^2 + 
          I*D^2*eOut*s^2*t^2 + (8*I)*hIn*hOut*s^2*t^2 - (4*I)*D*hIn*hOut*s^2*
           t^2 + (4*I)*Q^2*t^3 - (2*I)*D*Q^2*t^3 - (8*I)*eOut*Q^2*t^3 + 
          (6*I)*D*eOut*Q^2*t^3 - I*D^2*eOut*Q^2*t^3 + (12*I)*hIn*hOut*Q^2*
           t^3 - (2*I)*D*hIn*hOut*Q^2*t^3 - (4*I)*s*t^3 + (2*I)*D*s*t^3 + 
          (8*I)*eOut*s*t^3 - (6*I)*D*eOut*s*t^3 + I*D^2*eOut*s*t^3 - 
          (12*I)*hIn*hOut*s*t^3 + (2*I)*D*hIn*hOut*s*t^3 + (8*I)*Q^8*xOut - 
          (4*I)*D*Q^8*xOut + (12*I)*Q^6*s*xOut - (6*I)*D*Q^6*s*xOut + 
          (4*I)*D*Q^4*s^2*xOut + (8*I)*Q^2*s^3*xOut + (6*I)*D*Q^2*s^3*xOut + 
          (12*I)*s^4*xOut - (4*I)*Q^6*t*xOut + (2*I)*D*Q^6*t*xOut - 
          (12*I)*Q^4*s*t*xOut + (6*I)*D*Q^4*s*t*xOut + (8*I)*Q^2*s^2*t*xOut + 
          (2*I)*D*Q^2*s^2*t*xOut + (24*I)*s^3*t*xOut - (6*I)*D*s^3*t*xOut - 
          (12*I)*Q^4*t^2*xOut + (6*I)*D*Q^4*t^2*xOut - (8*I)*Q^2*s*t^2*xOut + 
          (4*I)*D*Q^2*s*t^2*xOut + (12*I)*s^2*t^2*xOut - 
          (6*I)*D*s^2*t^2*xOut - 24*hIn*Q^8*yOut + 4*D*hIn*Q^8*yOut - 
          52*hIn*Q^6*s*yOut + 6*D*hIn*Q^6*s*yOut - 8*hIn*Q^4*s^2*yOut - 
          4*D*hIn*Q^4*s^2*yOut + 32*hIn*Q^2*s^3*yOut - 6*D*hIn*Q^2*s^3*yOut + 
          12*hIn*s^4*yOut - 36*hIn*Q^6*t*yOut + 6*D*hIn*Q^6*t*yOut - 
          68*hIn*Q^4*s*t*yOut + 10*D*hIn*Q^4*s*t*yOut + 16*hIn*Q^2*s^2*t*
           yOut - 6*D*hIn*Q^2*s^2*t*yOut + 40*hIn*s^3*t*yOut - 
          6*D*hIn*s^3*t*yOut - 12*hIn*Q^4*t^2*yOut + 2*D*hIn*Q^4*t^2*yOut - 
          40*hIn*Q^2*s*t^2*yOut + 8*D*hIn*Q^2*s*t^2*yOut + 
          28*hIn*s^2*t^2*yOut - 6*D*hIn*s^2*t^2*yOut))/
        (8*s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         ((-8*I)*Q^8 + (4*I)*D*Q^8 + (8*I)*eOut*Q^8 - (6*I)*D*eOut*Q^8 + 
          I*D^2*eOut*Q^8 + (24*I)*hIn*hOut*Q^8 - (4*I)*D*hIn*hOut*Q^8 - 
          (4*I)*Q^6*s + (6*I)*D*Q^6*s - (4*I)*eOut*Q^6*s - 
          (6*I)*D*eOut*Q^6*s + (2*I)*D^2*eOut*Q^6*s + (44*I)*hIn*hOut*Q^6*s - 
          (6*I)*D*hIn*hOut*Q^6*s + (12*I)*Q^4*s^2 - (28*I)*eOut*Q^4*s^2 + 
          (6*I)*D*eOut*Q^4*s^2 + I*D^2*eOut*Q^4*s^2 + (12*I)*hIn*hOut*Q^4*
           s^2 + (4*I)*Q^2*s^3 - (2*I)*D*Q^2*s^3 - (12*I)*eOut*Q^2*s^3 + 
          (6*I)*D*eOut*Q^2*s^3 - (12*I)*hIn*hOut*Q^2*s^3 + 
          (2*I)*D*hIn*hOut*Q^2*s^3 - (4*I)*s^4 + (4*I)*eOut*s^4 - 
          (4*I)*hIn*hOut*s^4 - (4*I)*Q^6*t + (2*I)*D*Q^6*t + 
          (24*I)*eOut*Q^6*t - (18*I)*D*eOut*Q^6*t + (3*I)*D^2*eOut*Q^6*t + 
          (36*I)*hIn*hOut*Q^6*t - (6*I)*D*hIn*hOut*Q^6*t + (16*I)*Q^4*s*t - 
          (14*I)*D*eOut*Q^4*s*t + (3*I)*D^2*eOut*Q^4*s*t + 
          (24*I)*hIn*hOut*Q^4*s*t - (4*I)*D*hIn*hOut*Q^4*s*t + 
          (4*I)*Q^2*s^2*t - (2*I)*D*eOut*Q^2*s^2*t - (20*I)*hIn*hOut*Q^2*s^2*
           t + (4*I)*D*hIn*hOut*Q^2*s^2*t - (16*I)*s^3*t + (2*I)*D*s^3*t + 
          (24*I)*eOut*s^3*t - (6*I)*D*eOut*s^3*t - (8*I)*hIn*hOut*s^3*t + 
          (2*I)*D*hIn*hOut*s^3*t + (24*I)*eOut*Q^4*t^2 - (18*I)*D*eOut*Q^4*
           t^2 + (3*I)*D^2*eOut*Q^4*t^2 + (8*I)*Q^2*s*t^2 - 
          (20*I)*eOut*Q^2*s*t^2 + (6*I)*D*eOut*Q^2*s*t^2 - 
          (8*I)*hIn*hOut*Q^2*s*t^2 - (8*I)*s^2*t^2 + (4*I)*eOut*s^2*t^2 + 
          (4*I)*D*eOut*s^2*t^2 - I*D^2*eOut*s^2*t^2 + (8*I)*hIn*hOut*s^2*
           t^2 - (4*I)*Q^2*t^3 + (2*I)*D*Q^2*t^3 + (8*I)*eOut*Q^2*t^3 - 
          (6*I)*D*eOut*Q^2*t^3 + I*D^2*eOut*Q^2*t^3 - (12*I)*hIn*hOut*Q^2*
           t^3 + (2*I)*D*hIn*hOut*Q^2*t^3 + (4*I)*s*t^3 - (2*I)*D*s*t^3 - 
          (8*I)*eOut*s*t^3 + (6*I)*D*eOut*s*t^3 - I*D^2*eOut*s*t^3 + 
          (12*I)*hIn*hOut*s*t^3 - (2*I)*D*hIn*hOut*s*t^3 - (4*I)*Q^8*xOut + 
          (2*I)*D*Q^8*xOut - (4*I)*Q^6*s*xOut + (2*I)*D*Q^6*s*xOut - 
          (2*I)*D*Q^4*s^2*xOut - (4*I)*Q^2*s^3*xOut - (2*I)*D*Q^2*s^3*xOut - 
          (4*I)*s^4*xOut + (8*I)*Q^6*t*xOut - (4*I)*D*Q^6*t*xOut + 
          (12*I)*Q^4*s*t*xOut - (6*I)*D*Q^4*s*t*xOut - (4*I)*Q^2*s^2*t*xOut - 
          (8*I)*s^3*t*xOut + (2*I)*D*s^3*t*xOut + (12*I)*Q^4*t^2*xOut - 
          (6*I)*D*Q^4*t^2*xOut - (4*I)*s^2*t^2*xOut + (2*I)*D*s^2*t^2*xOut + 
          12*hIn*Q^8*yOut - 2*D*hIn*Q^8*yOut + 20*hIn*Q^6*s*yOut - 
          2*D*hIn*Q^6*s*yOut + 2*D*hIn*Q^4*s^2*yOut - 12*hIn*Q^2*s^3*yOut + 
          2*D*hIn*Q^2*s^3*yOut - 4*hIn*s^4*yOut + 24*hIn*Q^6*t*yOut - 
          4*D*hIn*Q^6*t*yOut + 36*hIn*Q^4*s*t*yOut - 6*D*hIn*Q^4*s*t*yOut + 
          4*hIn*Q^2*s^2*t*yOut - 8*hIn*s^3*t*yOut + 2*D*hIn*s^3*t*yOut + 
          12*hIn*Q^4*t^2*yOut - 2*D*hIn*Q^4*t^2*yOut + 16*hIn*Q^2*s*t^2*
           yOut - 4*D*hIn*Q^2*s*t^2*yOut - 4*hIn*s^2*t^2*yOut + 
          2*D*hIn*s^2*t^2*yOut))/(8*s^2*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*((-8*I)*Q^6 + (4*I)*D*Q^6 + 
          (8*I)*eOut*Q^6 - (6*I)*D*eOut*Q^6 + I*D^2*eOut*Q^6 + 
          (24*I)*hIn*hOut*Q^6 - (4*I)*D*hIn*hOut*Q^6 + (4*I)*Q^4*s + 
          (2*I)*D*Q^4*s - (12*I)*eOut*Q^4*s + I*D^2*eOut*Q^4*s + 
          (20*I)*hIn*hOut*Q^4*s - (2*I)*D*hIn*hOut*Q^4*s + (8*I)*Q^2*s^2 - 
          (2*I)*D*Q^2*s^2 - (16*I)*eOut*Q^2*s^2 + (6*I)*D*eOut*Q^2*s^2 - 
          (8*I)*hIn*hOut*Q^2*s^2 + (2*I)*D*hIn*hOut*Q^2*s^2 - (4*I)*s^3 + 
          (4*I)*eOut*s^3 - (4*I)*hIn*hOut*s^3 - (4*I)*Q^4*t + (2*I)*D*Q^4*t + 
          (16*I)*eOut*Q^4*t - (12*I)*D*eOut*Q^4*t + (2*I)*D^2*eOut*Q^4*t + 
          (36*I)*hIn*hOut*Q^4*t - (6*I)*D*hIn*hOut*Q^4*t + (16*I)*Q^2*s*t - 
          (4*I)*D*Q^2*s*t - (12*I)*eOut*Q^2*s*t + (2*I)*D*eOut*Q^2*s*t - 
          (16*I)*hIn*hOut*Q^2*s*t + (4*I)*D*hIn*hOut*Q^2*s*t - (12*I)*s^2*t + 
          (2*I)*D*s^2*t + (20*I)*eOut*s^2*t - (6*I)*D*eOut*s^2*t - 
          (20*I)*hIn*hOut*s^2*t + (2*I)*D*hIn*hOut*s^2*t + (4*I)*Q^2*t^2 - 
          (2*I)*D*Q^2*t^2 + (8*I)*eOut*Q^2*t^2 - (6*I)*D*eOut*Q^2*t^2 + 
          I*D^2*eOut*Q^2*t^2 + (12*I)*hIn*hOut*Q^2*t^2 - (2*I)*D*hIn*hOut*Q^2*
           t^2 - (4*I)*s*t^2 + (2*I)*D*s*t^2 - (8*I)*eOut*s*t^2 + 
          (6*I)*D*eOut*s*t^2 - I*D^2*eOut*s*t^2 - (12*I)*hIn*hOut*s*t^2 + 
          (2*I)*D*hIn*hOut*s*t^2 - (4*I)*Q^6*xOut + (2*I)*D*Q^6*xOut - 
          (2*I)*D*Q^2*s^2*xOut - (4*I)*s^3*xOut + (4*I)*Q^4*t*xOut - 
          (2*I)*D*Q^4*t*xOut + (8*I)*Q^2*s*t*xOut - (4*I)*D*Q^2*s*t*xOut - 
          (4*I)*s^2*t*xOut + (2*I)*D*s^2*t*xOut + (8*I)*Q^2*t^2*xOut - 
          (4*I)*D*Q^2*t^2*xOut - (8*I)*s*t^2*xOut + (4*I)*D*s*t^2*xOut + 
          12*hIn*Q^6*yOut - 2*D*hIn*Q^6*yOut + 8*hIn*Q^4*s*yOut - 
          8*hIn*Q^2*s^2*yOut + 2*D*hIn*Q^2*s^2*yOut - 4*hIn*s^3*yOut + 
          36*hIn*Q^4*t*yOut - 6*D*hIn*Q^4*t*yOut + 8*hIn*Q^2*s*t*yOut - 
          20*hIn*s^2*t*yOut + 2*D*hIn*s^2*t*yOut + 24*hIn*Q^2*t^2*yOut - 
          4*D*hIn*Q^2*t^2*yOut - 24*hIn*s*t^2*yOut + 4*D*hIn*s*t^2*yOut))/
        (8*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         ((-8*I)*eOut*Q^8 + (6*I)*D*eOut*Q^8 - I*D^2*eOut*Q^8 + (4*I)*Q^6*s - 
          (2*I)*D*Q^6*s - (20*I)*eOut*Q^6*s + (14*I)*D*eOut*Q^6*s - 
          (2*I)*D^2*eOut*Q^6*s - (12*I)*hIn*hOut*Q^6*s + (2*I)*D*hIn*hOut*Q^6*
           s + (4*I)*Q^4*s^2 - (4*I)*D*Q^4*s^2 - (12*I)*eOut*Q^4*s^2 + 
          (10*I)*D*eOut*Q^4*s^2 - I*D^2*eOut*Q^4*s^2 - (28*I)*hIn*hOut*Q^4*
           s^2 + (4*I)*D*hIn*hOut*Q^4*s^2 - (4*I)*Q^2*s^3 - (2*I)*D*Q^2*s^3 + 
          (4*I)*eOut*Q^2*s^3 + (2*I)*D*eOut*Q^2*s^3 - (20*I)*hIn*hOut*Q^2*
           s^3 + (2*I)*D*hIn*hOut*Q^2*s^3 - (4*I)*s^4 + (4*I)*eOut*s^4 - 
          (4*I)*hIn*hOut*s^4 + (4*I)*Q^6*t - (2*I)*D*Q^6*t - 
          (16*I)*eOut*Q^6*t + (12*I)*D*eOut*Q^6*t - (2*I)*D^2*eOut*Q^6*t + 
          (12*I)*hIn*hOut*Q^6*t - (2*I)*D*hIn*hOut*Q^6*t + (12*I)*Q^4*s*t - 
          (2*I)*D*Q^4*s*t - (28*I)*eOut*Q^4*s*t + (14*I)*D*eOut*Q^4*s*t - 
          (2*I)*D^2*eOut*Q^4*s*t + (4*I)*hIn*hOut*Q^4*s*t - 
          (2*I)*D*hIn*hOut*Q^4*s*t - (4*I)*Q^2*s^2*t + (2*I)*D*Q^2*s^2*t - 
          (12*I)*hIn*hOut*Q^2*s^2*t + (2*I)*D*hIn*hOut*Q^2*s^2*t - 
          (12*I)*s^3*t + (2*I)*D*s^3*t + (12*I)*eOut*s^3*t - 
          (2*I)*D*eOut*s^3*t - (4*I)*hIn*hOut*s^3*t + (2*I)*D*hIn*hOut*s^3*
           t + (4*I)*Q^4*t^2 - (2*I)*D*Q^4*t^2 - (8*I)*eOut*Q^4*t^2 + 
          (6*I)*D*eOut*Q^4*t^2 - I*D^2*eOut*Q^4*t^2 + (12*I)*hIn*hOut*Q^4*
           t^2 - (2*I)*D*hIn*hOut*Q^4*t^2 + (8*I)*Q^2*s*t^2 - 
          (16*I)*eOut*Q^2*s*t^2 + (4*I)*D*eOut*Q^2*s*t^2 - 
          (8*I)*hIn*hOut*Q^2*s*t^2 - (12*I)*s^2*t^2 + (2*I)*D*s^2*t^2 + 
          (24*I)*eOut*s^2*t^2 - (10*I)*D*eOut*s^2*t^2 + I*D^2*eOut*s^2*t^2 - 
          (4*I)*hIn*hOut*s^2*t^2 + (2*I)*D*hIn*hOut*s^2*t^2 - 
          (4*I)*Q^8*xOut + (2*I)*D*Q^8*xOut - (4*I)*Q^6*s*xOut + 
          (2*I)*D*Q^6*s*xOut - (2*I)*D*Q^4*s^2*xOut - (4*I)*Q^2*s^3*xOut - 
          (2*I)*D*Q^2*s^3*xOut - (4*I)*s^4*xOut - (4*I)*Q^6*t*xOut + 
          (2*I)*D*Q^6*t*xOut - (4*I)*Q^4*s*t*xOut + (2*I)*D*Q^4*s*t*xOut - 
          (12*I)*Q^2*s^2*t*xOut + (2*I)*D*Q^2*s^2*t*xOut - 
          (12*I)*s^3*t*xOut + (2*I)*D*s^3*t*xOut + 12*hIn*Q^8*yOut - 
          2*D*hIn*Q^8*yOut + 20*hIn*Q^6*s*yOut - 2*D*hIn*Q^6*s*yOut + 
          2*D*hIn*Q^4*s^2*yOut - 12*hIn*Q^2*s^3*yOut + 2*D*hIn*Q^2*s^3*yOut - 
          4*hIn*s^4*yOut + 12*hIn*Q^6*t*yOut - 2*D*hIn*Q^6*t*yOut - 
          4*hIn*Q^4*s*t*yOut + 2*D*hIn*Q^4*s*t*yOut - 28*hIn*Q^2*s^2*t*yOut + 
          6*D*hIn*Q^2*s^2*t*yOut - 12*hIn*s^3*t*yOut + 2*D*hIn*s^3*t*yOut))/
        (8*s^2*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         ((8*I)*Q^8 - (4*I)*D*Q^8 - (8*I)*eOut*Q^8 + (6*I)*D*eOut*Q^8 - 
          I*D^2*eOut*Q^8 - (24*I)*hIn*hOut*Q^8 + (4*I)*D*hIn*hOut*Q^8 + 
          (4*I)*Q^6*s - (6*I)*D*Q^6*s + (4*I)*eOut*Q^6*s + 
          (6*I)*D*eOut*Q^6*s - (2*I)*D^2*eOut*Q^6*s - (44*I)*hIn*hOut*Q^6*s + 
          (6*I)*D*hIn*hOut*Q^6*s - (12*I)*Q^4*s^2 + (28*I)*eOut*Q^4*s^2 - 
          (6*I)*D*eOut*Q^4*s^2 - I*D^2*eOut*Q^4*s^2 - (12*I)*hIn*hOut*Q^4*
           s^2 - (4*I)*Q^2*s^3 + (2*I)*D*Q^2*s^3 + (12*I)*eOut*Q^2*s^3 - 
          (6*I)*D*eOut*Q^2*s^3 + (12*I)*hIn*hOut*Q^2*s^3 - 
          (2*I)*D*hIn*hOut*Q^2*s^3 + (4*I)*s^4 - (4*I)*eOut*s^4 + 
          (4*I)*hIn*hOut*s^4 + (4*I)*Q^6*t - (2*I)*D*Q^6*t - 
          (24*I)*eOut*Q^6*t + (18*I)*D*eOut*Q^6*t - (3*I)*D^2*eOut*Q^6*t - 
          (36*I)*hIn*hOut*Q^6*t + (6*I)*D*hIn*hOut*Q^6*t - (16*I)*Q^4*s*t + 
          (14*I)*D*eOut*Q^4*s*t - (3*I)*D^2*eOut*Q^4*s*t - 
          (24*I)*hIn*hOut*Q^4*s*t + (4*I)*D*hIn*hOut*Q^4*s*t - 
          (4*I)*Q^2*s^2*t + (2*I)*D*eOut*Q^2*s^2*t + (20*I)*hIn*hOut*Q^2*s^2*
           t - (4*I)*D*hIn*hOut*Q^2*s^2*t + (16*I)*s^3*t - (2*I)*D*s^3*t - 
          (24*I)*eOut*s^3*t + (6*I)*D*eOut*s^3*t + (8*I)*hIn*hOut*s^3*t - 
          (2*I)*D*hIn*hOut*s^3*t - (24*I)*eOut*Q^4*t^2 + (18*I)*D*eOut*Q^4*
           t^2 - (3*I)*D^2*eOut*Q^4*t^2 - (8*I)*Q^2*s*t^2 + 
          (20*I)*eOut*Q^2*s*t^2 - (6*I)*D*eOut*Q^2*s*t^2 + 
          (8*I)*hIn*hOut*Q^2*s*t^2 + (8*I)*s^2*t^2 - (4*I)*eOut*s^2*t^2 - 
          (4*I)*D*eOut*s^2*t^2 + I*D^2*eOut*s^2*t^2 - (8*I)*hIn*hOut*s^2*
           t^2 + (4*I)*Q^2*t^3 - (2*I)*D*Q^2*t^3 - (8*I)*eOut*Q^2*t^3 + 
          (6*I)*D*eOut*Q^2*t^3 - I*D^2*eOut*Q^2*t^3 + (12*I)*hIn*hOut*Q^2*
           t^3 - (2*I)*D*hIn*hOut*Q^2*t^3 - (4*I)*s*t^3 + (2*I)*D*s*t^3 + 
          (8*I)*eOut*s*t^3 - (6*I)*D*eOut*s*t^3 + I*D^2*eOut*s*t^3 - 
          (12*I)*hIn*hOut*s*t^3 + (2*I)*D*hIn*hOut*s*t^3 + (4*I)*Q^8*xOut - 
          (2*I)*D*Q^8*xOut + (4*I)*Q^6*s*xOut - (2*I)*D*Q^6*s*xOut + 
          (2*I)*D*Q^4*s^2*xOut + (4*I)*Q^2*s^3*xOut + (2*I)*D*Q^2*s^3*xOut + 
          (4*I)*s^4*xOut - (8*I)*Q^6*t*xOut + (4*I)*D*Q^6*t*xOut - 
          (12*I)*Q^4*s*t*xOut + (6*I)*D*Q^4*s*t*xOut + (4*I)*Q^2*s^2*t*xOut + 
          (8*I)*s^3*t*xOut - (2*I)*D*s^3*t*xOut - (12*I)*Q^4*t^2*xOut + 
          (6*I)*D*Q^4*t^2*xOut + (4*I)*s^2*t^2*xOut - (2*I)*D*s^2*t^2*xOut - 
          12*hIn*Q^8*yOut + 2*D*hIn*Q^8*yOut - 20*hIn*Q^6*s*yOut + 
          2*D*hIn*Q^6*s*yOut - 2*D*hIn*Q^4*s^2*yOut + 12*hIn*Q^2*s^3*yOut - 
          2*D*hIn*Q^2*s^3*yOut + 4*hIn*s^4*yOut - 24*hIn*Q^6*t*yOut + 
          4*D*hIn*Q^6*t*yOut - 36*hIn*Q^4*s*t*yOut + 6*D*hIn*Q^4*s*t*yOut - 
          4*hIn*Q^2*s^2*t*yOut + 8*hIn*s^3*t*yOut - 2*D*hIn*s^3*t*yOut - 
          12*hIn*Q^4*t^2*yOut + 2*D*hIn*Q^4*t^2*yOut - 16*hIn*Q^2*s*t^2*
           yOut + 4*D*hIn*Q^2*s*t^2*yOut + 4*hIn*s^2*t^2*yOut - 
          2*D*hIn*s^2*t^2*yOut))/(8*s*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         ((4*I)*Q^8 - (2*I)*D*Q^8 - (8*I)*eOut*Q^8 + (6*I)*D*eOut*Q^8 - 
          I*D^2*eOut*Q^8 - (12*I)*hIn*hOut*Q^8 + (2*I)*D*hIn*hOut*Q^8 + 
          (4*I)*Q^6*s - (4*I)*D*Q^6*s - (8*I)*eOut*Q^6*s + 
          (10*I)*D*eOut*Q^6*s - (2*I)*D^2*eOut*Q^6*s - (28*I)*hIn*hOut*Q^6*
           s + (4*I)*D*hIn*hOut*Q^6*s - (4*I)*Q^4*s^2 - (2*I)*D*Q^4*s^2 + 
          (8*I)*eOut*Q^4*s^2 + (2*I)*D*eOut*Q^4*s^2 - I*D^2*eOut*Q^4*s^2 - 
          (20*I)*hIn*hOut*Q^4*s^2 + (2*I)*D*hIn*hOut*Q^4*s^2 - 
          (4*I)*Q^2*s^3 + (8*I)*eOut*Q^2*s^3 - (2*I)*D*eOut*Q^2*s^3 - 
          (4*I)*hIn*hOut*Q^2*s^3 + (4*I)*Q^6*t - (2*I)*D*Q^6*t - 
          (24*I)*eOut*Q^6*t + (18*I)*D*eOut*Q^6*t - (3*I)*D^2*eOut*Q^6*t - 
          (12*I)*hIn*hOut*Q^6*t + (2*I)*D*hIn*hOut*Q^6*t - (4*I)*Q^4*s*t - 
          (2*I)*D*Q^4*s*t - (12*I)*eOut*Q^4*s*t + (16*I)*D*eOut*Q^4*s*t - 
          (3*I)*D^2*eOut*Q^4*s*t - (12*I)*hIn*hOut*Q^4*s*t + 
          (2*I)*D*hIn*hOut*Q^4*s*t - (4*I)*Q^2*s^2*t + (4*I)*eOut*Q^2*s^2*t - 
          (4*I)*hIn*hOut*Q^2*s^2*t + (4*I)*s^3*t - (8*I)*eOut*s^3*t + 
          (2*I)*D*eOut*s^3*t - (4*I)*hIn*hOut*s^3*t + (4*I)*Q^4*t^2 - 
          (2*I)*D*Q^4*t^2 - (24*I)*eOut*Q^4*t^2 + (18*I)*D*eOut*Q^4*t^2 - 
          (3*I)*D^2*eOut*Q^4*t^2 + (12*I)*hIn*hOut*Q^4*t^2 - 
          (2*I)*D*hIn*hOut*Q^4*t^2 - (4*I)*Q^2*s*t^2 + (12*I)*eOut*Q^2*s*
           t^2 - (4*I)*D*eOut*Q^2*s*t^2 + (4*I)*hIn*hOut*Q^2*s*t^2 + 
          (2*I)*D*s^2*t^2 + (4*I)*eOut*s^2*t^2 - (6*I)*D*eOut*s^2*t^2 + 
          I*D^2*eOut*s^2*t^2 - (16*I)*hIn*hOut*s^2*t^2 + (2*I)*D*hIn*hOut*s^2*
           t^2 + (4*I)*Q^2*t^3 - (2*I)*D*Q^2*t^3 - (8*I)*eOut*Q^2*t^3 + 
          (6*I)*D*eOut*Q^2*t^3 - I*D^2*eOut*Q^2*t^3 + (12*I)*hIn*hOut*Q^2*
           t^3 - (2*I)*D*hIn*hOut*Q^2*t^3 - (4*I)*s*t^3 + (2*I)*D*s*t^3 + 
          (8*I)*eOut*s*t^3 - (6*I)*D*eOut*s*t^3 + I*D^2*eOut*s*t^3 - 
          (12*I)*hIn*hOut*s*t^3 + (2*I)*D*hIn*hOut*s*t^3 - (8*I)*Q^6*t*xOut + 
          (4*I)*D*Q^6*t*xOut - (8*I)*Q^4*s*t*xOut + (4*I)*D*Q^4*s*t*xOut - 
          (8*I)*Q^4*t^2*xOut + (4*I)*D*Q^4*t^2*xOut - 16*hIn*Q^4*s*t*yOut + 
          4*D*hIn*Q^4*s*t*yOut - 24*hIn*Q^2*s^2*t*yOut + 4*D*hIn*Q^2*s^2*t*
           yOut - 8*hIn*s^3*t*yOut - 16*hIn*Q^2*s*t^2*yOut + 
          4*D*hIn*Q^2*s*t^2*yOut - 8*hIn*s^2*t^2*yOut))/
        (8*s*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonWardLeft", "Index" -> {1}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*((8*I)*eOut*Q^8 - 
          (2*I)*D*eOut*Q^8 + (28*I)*eOut*Q^6*s - (7*I)*D*eOut*Q^6*s + 
          (32*I)*eOut*Q^4*s^2 - (8*I)*D*eOut*Q^4*s^2 + (12*I)*eOut*Q^2*s^3 - 
          (3*I)*D*eOut*Q^2*s^3 - (4*I)*Q^6*t + (20*I)*eOut*Q^6*t - 
          (5*I)*D*eOut*Q^6*t + (4*I)*hIn*hOut*Q^6*t - (2*I)*Q^4*s*t + 
          (36*I)*eOut*Q^4*s*t - (10*I)*D*eOut*Q^4*s*t + (2*I)*hIn*hOut*Q^4*s*
           t + (4*I)*Q^2*s^2*t + (2*I)*eOut*Q^2*s^2*t - (2*I)*D*eOut*Q^2*s^2*
           t - (4*I)*hIn*hOut*Q^2*s^2*t + (2*I)*s^3*t - (14*I)*eOut*s^3*t + 
          (3*I)*D*eOut*s^3*t - (2*I)*hIn*hOut*s^3*t - (6*I)*Q^4*t^2 + 
          (16*I)*eOut*Q^4*t^2 - (4*I)*D*eOut*Q^4*t^2 + (6*I)*hIn*hOut*Q^4*
           t^2 + (2*I)*Q^2*s*t^2 + (6*I)*eOut*Q^2*s*t^2 - 
          (2*I)*D*eOut*Q^2*s*t^2 - (2*I)*hIn*hOut*Q^2*s*t^2 + (4*I)*s^2*t^2 - 
          (18*I)*eOut*s^2*t^2 + (4*I)*D*eOut*s^2*t^2 - (4*I)*hIn*hOut*s^2*
           t^2 - (2*I)*Q^2*t^3 + (4*I)*eOut*Q^2*t^3 - I*D*eOut*Q^2*t^3 + 
          (2*I)*hIn*hOut*Q^2*t^3 + (2*I)*s*t^3 - (4*I)*eOut*s*t^3 + 
          I*D*eOut*s*t^3 - (2*I)*hIn*hOut*s*t^3 + (4*I)*Q^8*xOut + 
          (14*I)*Q^6*s*xOut + (16*I)*Q^4*s^2*xOut + (6*I)*Q^2*s^3*xOut + 
          (6*I)*Q^6*t*xOut + (18*I)*Q^4*s*t*xOut + (8*I)*Q^2*s^2*t*xOut - 
          (4*I)*s^3*t*xOut + (2*I)*Q^4*t^2*xOut + (6*I)*Q^2*s*t^2*xOut - 
          (4*I)*s^2*t^2*xOut - 4*hIn*Q^8*yOut - 14*hIn*Q^6*s*yOut - 
          16*hIn*Q^4*s^2*yOut - 6*hIn*Q^2*s^3*yOut - 6*hIn*Q^6*t*yOut - 
          18*hIn*Q^4*s*t*yOut - 8*hIn*Q^2*s^2*t*yOut + 4*hIn*s^3*t*yOut - 
          2*hIn*Q^4*t^2*yOut - 6*hIn*Q^2*s*t^2*yOut + 4*hIn*s^2*t^2*yOut))/
        (4*s*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*
         ((-4*I)*eOut*Q^6 + I*D*eOut*Q^6 - (8*I)*eOut*Q^4*s + 
          (2*I)*D*eOut*Q^4*s - (4*I)*eOut*Q^2*s^2 + I*D*eOut*Q^2*s^2 + 
          (2*I)*Q^4*t - (8*I)*eOut*Q^4*t + (2*I)*D*eOut*Q^4*t - 
          (2*I)*hIn*hOut*Q^4*t - (2*I)*eOut*Q^2*s*t + I*D*eOut*Q^2*s*t - 
          (2*I)*s^2*t + (6*I)*eOut*s^2*t - I*D*eOut*s^2*t + 
          (2*I)*hIn*hOut*s^2*t + (2*I)*Q^2*t^2 - (4*I)*eOut*Q^2*t^2 + 
          I*D*eOut*Q^2*t^2 - (2*I)*hIn*hOut*Q^2*t^2 - (2*I)*s*t^2 + 
          (4*I)*eOut*s*t^2 - I*D*eOut*s*t^2 + (2*I)*hIn*hOut*s*t^2 - 
          (2*I)*Q^6*xOut - (4*I)*Q^4*s*xOut - (2*I)*Q^2*s^2*xOut - 
          (2*I)*Q^4*t*xOut - (2*I)*Q^2*s*t*xOut + 2*hIn*Q^6*yOut + 
          4*hIn*Q^4*s*yOut + 2*hIn*Q^2*s^2*yOut + 2*hIn*Q^4*t*yOut + 
          2*hIn*Q^2*s*t*yOut))/(4*s*(Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - 
          s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*((-4*I)*eOut*Q^6 + 
          I*D*eOut*Q^6 - (8*I)*eOut*Q^4*s + (2*I)*D*eOut*Q^4*s - 
          (4*I)*eOut*Q^2*s^2 + I*D*eOut*Q^2*s^2 - (2*I)*Q^4*t - 
          (8*I)*eOut*Q^4*t + (2*I)*D*eOut*Q^4*t + (2*I)*hIn*hOut*Q^4*t - 
          (6*I)*eOut*Q^2*s*t + I*D*eOut*Q^2*s*t + (2*I)*s^2*t + 
          (2*I)*eOut*s^2*t - I*D*eOut*s^2*t - (2*I)*hIn*hOut*s^2*t - 
          (2*I)*Q^2*t^2 - (4*I)*eOut*Q^2*t^2 + I*D*eOut*Q^2*t^2 + 
          (2*I)*hIn*hOut*Q^2*t^2 + (2*I)*s*t^2 + (4*I)*eOut*s*t^2 - 
          I*D*eOut*s*t^2 - (2*I)*hIn*hOut*s*t^2 - (2*I)*Q^6*xOut - 
          (4*I)*Q^4*s*xOut - (2*I)*Q^2*s^2*xOut - (6*I)*Q^4*t*xOut - 
          (2*I)*Q^2*s*t*xOut + (4*I)*s^2*t*xOut - (4*I)*Q^2*t^2*xOut + 
          (4*I)*s*t^2*xOut + 2*hIn*Q^6*yOut + 4*hIn*Q^4*s*yOut + 
          2*hIn*Q^2*s^2*yOut + 6*hIn*Q^4*t*yOut + 2*hIn*Q^2*s*t*yOut - 
          4*hIn*s^2*t*yOut + 4*hIn*Q^2*t^2*yOut - 4*hIn*s*t^2*yOut))/
        (4*(Q^2 + s)*SUNN^2*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*
         ((-4*I)*eOut*Q^6 + I*D*eOut*Q^6 - (8*I)*eOut*Q^4*s + 
          (2*I)*D*eOut*Q^4*s - (4*I)*eOut*Q^2*s^2 + I*D*eOut*Q^2*s^2 + 
          (2*I)*Q^4*t - (8*I)*eOut*Q^4*t + (2*I)*D*eOut*Q^4*t - 
          (2*I)*hIn*hOut*Q^4*t - (2*I)*eOut*Q^2*s*t + I*D*eOut*Q^2*s*t - 
          (2*I)*s^2*t + (6*I)*eOut*s^2*t - I*D*eOut*s^2*t + 
          (2*I)*hIn*hOut*s^2*t + (2*I)*Q^2*t^2 - (4*I)*eOut*Q^2*t^2 + 
          I*D*eOut*Q^2*t^2 - (2*I)*hIn*hOut*Q^2*t^2 - (2*I)*s*t^2 + 
          (4*I)*eOut*s*t^2 - I*D*eOut*s*t^2 + (2*I)*hIn*hOut*s*t^2 - 
          (2*I)*Q^6*xOut - (4*I)*Q^4*s*xOut - (2*I)*Q^2*s^2*xOut - 
          (2*I)*Q^4*t*xOut - (2*I)*Q^2*s*t*xOut + 2*hIn*Q^6*yOut + 
          4*hIn*Q^4*s*yOut + 2*hIn*Q^2*s^2*yOut + 2*hIn*Q^4*t*yOut + 
          2*hIn*Q^2*s*t*yOut))/(4*s*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-1/4*I)*(-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*
         (-4*eOut*Q^6 + D*eOut*Q^6 - 8*eOut*Q^4*s + 2*D*eOut*Q^4*s - 
          4*eOut*Q^2*s^2 + D*eOut*Q^2*s^2 + 2*Q^4*t - 8*eOut*Q^4*t + 
          2*D*eOut*Q^4*t - 2*hIn*hOut*Q^4*t - 2*eOut*Q^2*s*t + 
          D*eOut*Q^2*s*t - 2*s^2*t + 6*eOut*s^2*t - D*eOut*s^2*t + 
          2*hIn*hOut*s^2*t + 2*Q^2*t^2 - 4*eOut*Q^2*t^2 + D*eOut*Q^2*t^2 - 
          2*hIn*hOut*Q^2*t^2 - 2*s*t^2 + 4*eOut*s*t^2 - D*eOut*s*t^2 + 
          2*hIn*hOut*s*t^2 - 2*Q^6*xOut - 4*Q^4*s*xOut - 2*Q^2*s^2*xOut - 
          2*Q^4*t*xOut - 2*Q^2*s*t*xOut - (2*I)*hIn*Q^6*yOut - 
          (4*I)*hIn*Q^4*s*yOut - (2*I)*hIn*Q^2*s^2*yOut - 
          (2*I)*hIn*Q^4*t*yOut - (2*I)*hIn*Q^2*s*t*yOut))/
        ((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       ((-1/4*I)*(-2 + D)*Q*(-1 + SUNN)^2*(1 + SUNN)^2*t*
         (2*Q^4 - 4*eOut*Q^4 + D*eOut*Q^4 - 2*hIn*hOut*Q^4 - 2*eOut*Q^2*s + 
          D*eOut*Q^2*s - 2*s^2 + 2*eOut*s^2 + 2*hIn*hOut*s^2 + 2*Q^2*t - 
          4*eOut*Q^2*t + D*eOut*Q^2*t - 2*hIn*hOut*Q^2*t - 2*s*t + 
          4*eOut*s*t - D*eOut*s*t + 2*hIn*hOut*s*t - 2*Q^2*s*xOut - 
          2*s^2*xOut - (2*I)*hIn*Q^2*s*yOut - (2*I)*hIn*s^2*yOut))/
        ((Q^2 + s)*SUNN^2*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "MissingTargets" -> {}|>, <|"Kind" -> "PhotonWardLeft", "Index" -> {2}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         ((4*I)*Q^12 - (8*I)*eOut*Q^12 + (2*I)*D*eOut*Q^12 + 
          (4*I)*hIn*hOut*Q^12 + (22*I)*Q^10*s - (36*I)*eOut*Q^10*s + 
          (9*I)*D*eOut*Q^10*s + (22*I)*hIn*hOut*Q^10*s + (48*I)*Q^8*s^2 - 
          (60*I)*eOut*Q^8*s^2 + (15*I)*D*eOut*Q^8*s^2 + (48*I)*hIn*hOut*Q^8*
           s^2 + (52*I)*Q^6*s^3 - (44*I)*eOut*Q^6*s^3 + (11*I)*D*eOut*Q^6*
           s^3 + (52*I)*hIn*hOut*Q^6*s^3 + (28*I)*Q^4*s^4 - 
          (12*I)*eOut*Q^4*s^4 + (3*I)*D*eOut*Q^4*s^4 + (28*I)*hIn*hOut*Q^4*
           s^4 + (6*I)*Q^2*s^5 + (6*I)*hIn*hOut*Q^2*s^5 + (6*I)*Q^10*t - 
          (28*I)*eOut*Q^10*t + (7*I)*D*eOut*Q^10*t + (6*I)*hIn*hOut*Q^10*t + 
          (26*I)*Q^8*s*t - (84*I)*eOut*Q^8*s*t + (20*I)*D*eOut*Q^8*s*t + 
          (34*I)*hIn*hOut*Q^8*s*t + (44*I)*Q^6*s^2*t - (70*I)*eOut*Q^6*s^2*
           t + (13*I)*D*eOut*Q^6*s^2*t + (56*I)*hIn*hOut*Q^6*s^2*t + 
          (32*I)*Q^4*s^3*t - (4*I)*eOut*Q^4*s^3*t - (6*I)*D*eOut*Q^4*s^3*t + 
          (28*I)*hIn*hOut*Q^4*s^3*t + (6*I)*Q^2*s^4*t + (6*I)*eOut*Q^2*s^4*
           t - (6*I)*D*eOut*Q^2*s^4*t - (6*I)*hIn*hOut*Q^2*s^4*t - 
          (2*I)*s^5*t - (4*I)*eOut*s^5*t - (6*I)*hIn*hOut*s^5*t + 
          (6*I)*Q^8*t^2 - (36*I)*eOut*Q^8*t^2 + (9*I)*D*eOut*Q^8*t^2 - 
          (2*I)*hIn*hOut*Q^8*t^2 + (2*I)*Q^6*s*t^2 - (42*I)*eOut*Q^6*s*t^2 + 
          (11*I)*D*eOut*Q^6*s*t^2 + (18*I)*hIn*hOut*Q^6*s*t^2 + 
          (34*I)*eOut*Q^4*s^2*t^2 - (10*I)*D*eOut*Q^4*s^2*t^2 + 
          (20*I)*hIn*hOut*Q^4*s^2*t^2 + (6*I)*Q^2*s^3*t^2 + 
          (22*I)*eOut*Q^2*s^3*t^2 - (9*I)*D*eOut*Q^2*s^3*t^2 - 
          (10*I)*hIn*hOut*Q^2*s^3*t^2 + (2*I)*s^4*t^2 - (18*I)*eOut*s^4*t^2 + 
          (3*I)*D*eOut*s^4*t^2 - (10*I)*hIn*hOut*s^4*t^2 + (6*I)*Q^6*t^3 - 
          (20*I)*eOut*Q^6*t^3 + (5*I)*D*eOut*Q^6*t^3 - (6*I)*hIn*hOut*Q^6*
           t^3 - (10*I)*Q^4*s*t^3 + (10*I)*eOut*Q^4*s*t^3 - 
          (2*I)*D*eOut*Q^4*s*t^3 + (10*I)*hIn*hOut*Q^4*s*t^3 - 
          (2*I)*Q^2*s^2*t^3 + (28*I)*eOut*Q^2*s^2*t^3 - (7*I)*D*eOut*Q^2*s^2*
           t^3 + (2*I)*hIn*hOut*Q^2*s^2*t^3 + (6*I)*s^3*t^3 - 
          (18*I)*eOut*s^3*t^3 + (4*I)*D*eOut*s^3*t^3 - (6*I)*hIn*hOut*s^3*
           t^3 + (2*I)*Q^4*t^4 - (4*I)*eOut*Q^4*t^4 + I*D*eOut*Q^4*t^4 - 
          (2*I)*hIn*hOut*Q^4*t^4 - (4*I)*Q^2*s*t^4 + (8*I)*eOut*Q^2*s*t^4 - 
          (2*I)*D*eOut*Q^2*s*t^4 + (4*I)*hIn*hOut*Q^2*s*t^4 + (2*I)*s^2*t^4 - 
          (4*I)*eOut*s^2*t^4 + I*D*eOut*s^2*t^4 - (2*I)*hIn*hOut*s^2*t^4 + 
          (4*I)*Q^10*s*xOut + (18*I)*Q^8*s^2*xOut + (30*I)*Q^6*s^3*xOut + 
          (22*I)*Q^4*s^4*xOut + (6*I)*Q^2*s^5*xOut - (8*I)*Q^10*t*xOut - 
          (14*I)*Q^8*s*t*xOut + (18*I)*Q^6*s^2*t*xOut + (44*I)*Q^4*s^3*t*
           xOut + (18*I)*Q^2*s^4*t*xOut - (2*I)*s^5*t*xOut - 
          (12*I)*Q^8*t^2*xOut - (20*I)*Q^6*s*t^2*xOut + (20*I)*Q^4*s^2*t^2*
           xOut + (24*I)*Q^2*s^3*t^2*xOut - (4*I)*s^4*t^2*xOut - 
          (4*I)*Q^6*t^3*xOut - (6*I)*Q^4*s*t^3*xOut + (12*I)*Q^2*s^2*t^3*
           xOut - (2*I)*s^3*t^3*xOut - 4*hIn*Q^10*s*yOut - 
          18*hIn*Q^8*s^2*yOut - 30*hIn*Q^6*s^3*yOut - 22*hIn*Q^4*s^4*yOut - 
          6*hIn*Q^2*s^5*yOut - 6*hIn*Q^8*s*t*yOut - 26*hIn*Q^6*s^2*t*yOut - 
          28*hIn*Q^4*s^3*t*yOut - 2*hIn*Q^2*s^4*t*yOut + 6*hIn*s^5*t*yOut - 
          16*hIn*Q^4*s^2*t^2*yOut - 4*hIn*Q^2*s^3*t^2*yOut + 
          12*hIn*s^4*t^2*yOut + 2*hIn*Q^4*s*t^3*yOut - 8*hIn*Q^2*s^2*t^3*
           yOut + 6*hIn*s^3*t^3*yOut))/(8*s^2*SUNN^2*t*(Q^2 + s + t)^2*
         (-Q^4 - Q^2*s - Q^2*t + s*t)), GLI["V09", {0, 0, 1, 0}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         ((-2*I)*Q^10 + (4*I)*eOut*Q^10 - I*D*eOut*Q^10 - 
          (2*I)*hIn*hOut*Q^10 - (8*I)*Q^8*s + (12*I)*eOut*Q^8*s - 
          (3*I)*D*eOut*Q^8*s - (8*I)*hIn*hOut*Q^8*s - (12*I)*Q^6*s^2 + 
          (12*I)*eOut*Q^6*s^2 - (3*I)*D*eOut*Q^6*s^2 - (12*I)*hIn*hOut*Q^6*
           s^2 - (8*I)*Q^4*s^3 + (4*I)*eOut*Q^4*s^3 - I*D*eOut*Q^4*s^3 - 
          (8*I)*hIn*hOut*Q^4*s^3 - (2*I)*Q^2*s^4 - (2*I)*hIn*hOut*Q^2*s^4 - 
          (2*I)*Q^8*t + (12*I)*eOut*Q^8*t - (3*I)*D*eOut*Q^8*t - 
          (2*I)*hIn*hOut*Q^8*t - (4*I)*Q^6*s*t + (18*I)*eOut*Q^6*s*t - 
          (4*I)*D*eOut*Q^6*s*t - (8*I)*hIn*hOut*Q^6*s*t - (4*I)*Q^4*s^2*t + 
          (4*I)*eOut*Q^4*s^2*t + I*D*eOut*Q^4*s^2*t - (8*I)*hIn*hOut*Q^4*s^2*
           t - (4*I)*Q^2*s^3*t + (2*I)*eOut*Q^2*s^3*t + (2*I)*D*eOut*Q^2*s^3*
           t - (2*I)*s^4*t + (4*I)*eOut*s^4*t + (2*I)*hIn*hOut*s^4*t - 
          (2*I)*Q^6*t^2 + (12*I)*eOut*Q^6*t^2 - (3*I)*D*eOut*Q^6*t^2 + 
          (2*I)*hIn*hOut*Q^6*t^2 + (4*I)*Q^4*s*t^2 - (6*I)*eOut*Q^4*s*t^2 + 
          I*D*eOut*Q^4*s*t^2 - (4*I)*hIn*hOut*Q^4*s*t^2 + (2*I)*Q^2*s^2*t^2 - 
          (12*I)*eOut*Q^2*s^2*t^2 + (3*I)*D*eOut*Q^2*s^2*t^2 - 
          (2*I)*hIn*hOut*Q^2*s^2*t^2 - (4*I)*s^3*t^2 + (6*I)*eOut*s^3*t^2 - 
          I*D*eOut*s^3*t^2 + (4*I)*hIn*hOut*s^3*t^2 - (2*I)*Q^4*t^3 + 
          (4*I)*eOut*Q^4*t^3 - I*D*eOut*Q^4*t^3 + (2*I)*hIn*hOut*Q^4*t^3 + 
          (4*I)*Q^2*s*t^3 - (8*I)*eOut*Q^2*s*t^3 + (2*I)*D*eOut*Q^2*s*t^3 - 
          (4*I)*hIn*hOut*Q^2*s*t^3 - (2*I)*s^2*t^3 + (4*I)*eOut*s^2*t^3 - 
          I*D*eOut*s^2*t^3 + (2*I)*hIn*hOut*s^2*t^3 - (2*I)*Q^8*s*xOut - 
          (6*I)*Q^6*s^2*xOut - (6*I)*Q^4*s^3*xOut - (2*I)*Q^2*s^4*xOut + 
          (4*I)*Q^8*t*xOut + (4*I)*Q^6*s*t*xOut - (6*I)*Q^4*s^2*t*xOut - 
          (8*I)*Q^2*s^3*t*xOut - (2*I)*s^4*t*xOut + (4*I)*Q^6*t^2*xOut + 
          (2*I)*Q^4*s*t^2*xOut - (4*I)*Q^2*s^2*t^2*xOut - 
          (2*I)*s^3*t^2*xOut + 2*hIn*Q^8*s*yOut + 6*hIn*Q^6*s^2*yOut + 
          6*hIn*Q^4*s^3*yOut + 2*hIn*Q^2*s^4*yOut + 4*hIn*Q^6*s*t*yOut + 
          6*hIn*Q^4*s^2*t*yOut - 2*hIn*s^4*t*yOut + 2*hIn*Q^4*s*t^2*yOut - 
          2*hIn*s^3*t^2*yOut))/(8*s^2*SUNN^2*t*(Q^2 + s + t)*
         (-Q^4 - Q^2*s - Q^2*t + s*t)), GLI["V09", {-1, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         ((-2*I)*Q^10 + (4*I)*eOut*Q^10 - I*D*eOut*Q^10 - 
          (2*I)*hIn*hOut*Q^10 - (8*I)*Q^8*s + (12*I)*eOut*Q^8*s - 
          (3*I)*D*eOut*Q^8*s - (8*I)*hIn*hOut*Q^8*s - (12*I)*Q^6*s^2 + 
          (12*I)*eOut*Q^6*s^2 - (3*I)*D*eOut*Q^6*s^2 - (12*I)*hIn*hOut*Q^6*
           s^2 - (8*I)*Q^4*s^3 + (4*I)*eOut*Q^4*s^3 - I*D*eOut*Q^4*s^3 - 
          (8*I)*hIn*hOut*Q^4*s^3 - (2*I)*Q^2*s^4 - (2*I)*hIn*hOut*Q^2*s^4 - 
          (6*I)*Q^8*t + (12*I)*eOut*Q^8*t - (3*I)*D*eOut*Q^8*t - 
          (6*I)*hIn*hOut*Q^8*t - (16*I)*Q^6*s*t + (14*I)*eOut*Q^6*s*t - 
          (4*I)*D*eOut*Q^6*s*t - (12*I)*hIn*hOut*Q^6*s*t - (8*I)*Q^4*s^2*t - 
          (12*I)*eOut*Q^4*s^2*t + I*D*eOut*Q^4*s^2*t - (4*I)*hIn*hOut*Q^4*s^2*
           t + (8*I)*Q^2*s^3*t - (18*I)*eOut*Q^2*s^3*t + (2*I)*D*eOut*Q^2*s^3*
           t + (4*I)*hIn*hOut*Q^2*s^3*t + (6*I)*s^4*t - (4*I)*eOut*s^4*t + 
          (2*I)*hIn*hOut*s^4*t - (2*I)*Q^6*t^2 + (12*I)*eOut*Q^6*t^2 - 
          (3*I)*D*eOut*Q^6*t^2 - (6*I)*hIn*hOut*Q^6*t^2 - (8*I)*Q^4*s*t^2 - 
          (2*I)*eOut*Q^4*s*t^2 + I*D*eOut*Q^4*s*t^2 + (2*I)*Q^2*s^2*t^2 - 
          (12*I)*eOut*Q^2*s^2*t^2 + (3*I)*D*eOut*Q^2*s^2*t^2 + 
          (6*I)*hIn*hOut*Q^2*s^2*t^2 + (8*I)*s^3*t^2 + (2*I)*eOut*s^3*t^2 - 
          I*D*eOut*s^3*t^2 + (2*I)*Q^4*t^3 + (4*I)*eOut*Q^4*t^3 - 
          I*D*eOut*Q^4*t^3 - (2*I)*hIn*hOut*Q^4*t^3 - (4*I)*Q^2*s*t^3 - 
          (8*I)*eOut*Q^2*s*t^3 + (2*I)*D*eOut*Q^2*s*t^3 + 
          (4*I)*hIn*hOut*Q^2*s*t^3 + (2*I)*s^2*t^3 + (4*I)*eOut*s^2*t^3 - 
          I*D*eOut*s^2*t^3 - (2*I)*hIn*hOut*s^2*t^3 - (2*I)*Q^8*s*xOut - 
          (6*I)*Q^6*s^2*xOut - (6*I)*Q^4*s^3*xOut - (2*I)*Q^2*s^4*xOut - 
          (8*I)*Q^6*s*t*xOut - (10*I)*Q^4*s^2*t*xOut + (4*I)*Q^2*s^3*t*xOut + 
          (6*I)*s^4*t*xOut + (4*I)*Q^6*t^2*xOut - (10*I)*Q^4*s*t^2*xOut - 
          (4*I)*Q^2*s^2*t^2*xOut + (10*I)*s^3*t^2*xOut + (4*I)*Q^4*t^3*xOut - 
          (8*I)*Q^2*s*t^3*xOut + (4*I)*s^2*t^3*xOut + 2*hIn*Q^8*s*yOut + 
          6*hIn*Q^6*s^2*yOut + 6*hIn*Q^4*s^3*yOut + 2*hIn*Q^2*s^4*yOut - 
          4*hIn*Q^8*t*yOut + 10*hIn*Q^4*s^2*t*yOut + 4*hIn*Q^2*s^3*t*yOut - 
          2*hIn*s^4*t*yOut - 8*hIn*Q^6*t^2*yOut + 6*hIn*Q^4*s*t^2*yOut + 
          8*hIn*Q^2*s^2*t^2*yOut - 6*hIn*s^3*t^2*yOut - 4*hIn*Q^4*t^3*yOut + 
          8*hIn*Q^2*s*t^3*yOut - 4*hIn*s^2*t^3*yOut))/
        (8*s*SUNN^2*t*(Q^2 + s + t)^2*(-Q^4 - Q^2*s - Q^2*t + s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*transverseK*((2*I)*Q^10 - (4*I)*eOut*Q^10 + 
          I*D*eOut*Q^10 + (2*I)*hIn*hOut*Q^10 + (8*I)*Q^8*s - 
          (12*I)*eOut*Q^8*s + (3*I)*D*eOut*Q^8*s + (8*I)*hIn*hOut*Q^8*s + 
          (12*I)*Q^6*s^2 - (12*I)*eOut*Q^6*s^2 + (3*I)*D*eOut*Q^6*s^2 + 
          (12*I)*hIn*hOut*Q^6*s^2 + (8*I)*Q^4*s^3 - (4*I)*eOut*Q^4*s^3 + 
          I*D*eOut*Q^4*s^3 + (8*I)*hIn*hOut*Q^4*s^3 + (2*I)*Q^2*s^4 + 
          (2*I)*hIn*hOut*Q^2*s^4 + (2*I)*Q^8*t - (12*I)*eOut*Q^8*t + 
          (3*I)*D*eOut*Q^8*t + (2*I)*hIn*hOut*Q^8*t + (4*I)*Q^6*s*t - 
          (18*I)*eOut*Q^6*s*t + (4*I)*D*eOut*Q^6*s*t + (8*I)*hIn*hOut*Q^6*s*
           t + (4*I)*Q^4*s^2*t - (4*I)*eOut*Q^4*s^2*t - I*D*eOut*Q^4*s^2*t + 
          (8*I)*hIn*hOut*Q^4*s^2*t + (4*I)*Q^2*s^3*t - (2*I)*eOut*Q^2*s^3*t - 
          (2*I)*D*eOut*Q^2*s^3*t + (2*I)*s^4*t - (4*I)*eOut*s^4*t - 
          (2*I)*hIn*hOut*s^4*t + (2*I)*Q^6*t^2 - (12*I)*eOut*Q^6*t^2 + 
          (3*I)*D*eOut*Q^6*t^2 - (2*I)*hIn*hOut*Q^6*t^2 - (4*I)*Q^4*s*t^2 + 
          (6*I)*eOut*Q^4*s*t^2 - I*D*eOut*Q^4*s*t^2 + (4*I)*hIn*hOut*Q^4*s*
           t^2 - (2*I)*Q^2*s^2*t^2 + (12*I)*eOut*Q^2*s^2*t^2 - 
          (3*I)*D*eOut*Q^2*s^2*t^2 + (2*I)*hIn*hOut*Q^2*s^2*t^2 + 
          (4*I)*s^3*t^2 - (6*I)*eOut*s^3*t^2 + I*D*eOut*s^3*t^2 - 
          (4*I)*hIn*hOut*s^3*t^2 + (2*I)*Q^4*t^3 - (4*I)*eOut*Q^4*t^3 + 
          I*D*eOut*Q^4*t^3 - (2*I)*hIn*hOut*Q^4*t^3 - (4*I)*Q^2*s*t^3 + 
          (8*I)*eOut*Q^2*s*t^3 - (2*I)*D*eOut*Q^2*s*t^3 + 
          (4*I)*hIn*hOut*Q^2*s*t^3 + (2*I)*s^2*t^3 - (4*I)*eOut*s^2*t^3 + 
          I*D*eOut*s^2*t^3 - (2*I)*hIn*hOut*s^2*t^3 + (2*I)*Q^8*s*xOut + 
          (6*I)*Q^6*s^2*xOut + (6*I)*Q^4*s^3*xOut + (2*I)*Q^2*s^4*xOut - 
          (4*I)*Q^8*t*xOut - (4*I)*Q^6*s*t*xOut + (6*I)*Q^4*s^2*t*xOut + 
          (8*I)*Q^2*s^3*t*xOut + (2*I)*s^4*t*xOut - (4*I)*Q^6*t^2*xOut - 
          (2*I)*Q^4*s*t^2*xOut + (4*I)*Q^2*s^2*t^2*xOut + 
          (2*I)*s^3*t^2*xOut - 2*hIn*Q^8*s*yOut - 6*hIn*Q^6*s^2*yOut - 
          6*hIn*Q^4*s^3*yOut - 2*hIn*Q^2*s^4*yOut - 4*hIn*Q^6*s*t*yOut - 
          6*hIn*Q^4*s^2*t*yOut + 2*hIn*s^4*t*yOut - 2*hIn*Q^4*s*t^2*yOut + 
          2*hIn*s^3*t^2*yOut))/(8*s^2*SUNN^2*t*(Q^2 + s + t)^2*
         (Q^4 + Q^2*s + Q^2*t - s*t)), GLI["V09", {0, 0, 1, 1}] -> 
       ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
         ((2*I)*Q^10 - (4*I)*eOut*Q^10 + I*D*eOut*Q^10 + 
          (2*I)*hIn*hOut*Q^10 + (8*I)*Q^8*s - (12*I)*eOut*Q^8*s + 
          (3*I)*D*eOut*Q^8*s + (8*I)*hIn*hOut*Q^8*s + (12*I)*Q^6*s^2 - 
          (12*I)*eOut*Q^6*s^2 + (3*I)*D*eOut*Q^6*s^2 + (12*I)*hIn*hOut*Q^6*
           s^2 + (8*I)*Q^4*s^3 - (4*I)*eOut*Q^4*s^3 + I*D*eOut*Q^4*s^3 + 
          (8*I)*hIn*hOut*Q^4*s^3 + (2*I)*Q^2*s^4 + (2*I)*hIn*hOut*Q^2*s^4 + 
          (2*I)*Q^8*t - (12*I)*eOut*Q^8*t + (3*I)*D*eOut*Q^8*t + 
          (2*I)*hIn*hOut*Q^8*t + (4*I)*Q^6*s*t - (18*I)*eOut*Q^6*s*t + 
          (4*I)*D*eOut*Q^6*s*t + (8*I)*hIn*hOut*Q^6*s*t + (4*I)*Q^4*s^2*t - 
          (4*I)*eOut*Q^4*s^2*t - I*D*eOut*Q^4*s^2*t + (8*I)*hIn*hOut*Q^4*s^2*
           t + (4*I)*Q^2*s^3*t - (2*I)*eOut*Q^2*s^3*t - (2*I)*D*eOut*Q^2*s^3*
           t + (2*I)*s^4*t - (4*I)*eOut*s^4*t - (2*I)*hIn*hOut*s^4*t + 
          (2*I)*Q^6*t^2 - (12*I)*eOut*Q^6*t^2 + (3*I)*D*eOut*Q^6*t^2 - 
          (2*I)*hIn*hOut*Q^6*t^2 - (4*I)*Q^4*s*t^2 + (6*I)*eOut*Q^4*s*t^2 - 
          I*D*eOut*Q^4*s*t^2 + (4*I)*hIn*hOut*Q^4*s*t^2 - (2*I)*Q^2*s^2*t^2 + 
          (12*I)*eOut*Q^2*s^2*t^2 - (3*I)*D*eOut*Q^2*s^2*t^2 + 
          (2*I)*hIn*hOut*Q^2*s^2*t^2 + (4*I)*s^3*t^2 - (6*I)*eOut*s^3*t^2 + 
          I*D*eOut*s^3*t^2 - (4*I)*hIn*hOut*s^3*t^2 + (2*I)*Q^4*t^3 - 
          (4*I)*eOut*Q^4*t^3 + I*D*eOut*Q^4*t^3 - (2*I)*hIn*hOut*Q^4*t^3 - 
          (4*I)*Q^2*s*t^3 + (8*I)*eOut*Q^2*s*t^3 - (2*I)*D*eOut*Q^2*s*t^3 + 
          (4*I)*hIn*hOut*Q^2*s*t^3 + (2*I)*s^2*t^3 - (4*I)*eOut*s^2*t^3 + 
          I*D*eOut*s^2*t^3 - (2*I)*hIn*hOut*s^2*t^3 + (2*I)*Q^8*s*xOut + 
          (6*I)*Q^6*s^2*xOut + (6*I)*Q^4*s^3*xOut + (2*I)*Q^2*s^4*xOut - 
          (4*I)*Q^8*t*xOut - (4*I)*Q^6*s*t*xOut + (6*I)*Q^4*s^2*t*xOut + 
          (8*I)*Q^2*s^3*t*xOut + (2*I)*s^4*t*xOut - (4*I)*Q^6*t^2*xOut - 
          (2*I)*Q^4*s*t^2*xOut + (4*I)*Q^2*s^2*t^2*xOut + 
          (2*I)*s^3*t^2*xOut - 2*hIn*Q^8*s*yOut - 6*hIn*Q^6*s^2*yOut - 
          6*hIn*Q^4*s^3*yOut - 2*hIn*Q^2*s^4*yOut - 4*hIn*Q^6*s*t*yOut - 
          6*hIn*Q^4*s^2*t*yOut + 2*hIn*s^4*t*yOut - 2*hIn*Q^4*s*t^2*yOut + 
          2*hIn*s^3*t^2*yOut))/(8*s*SUNN^2*t*(Q^2 + s + t)*
         (-Q^4 - Q^2*s - Q^2*t + s*t))|>, "ReducedCoefficients" -> 
     <|GLI["V01", {0, 1, 0, 1}] -> ((-2 + D)*(-1 + SUNN)^2*(1 + SUNN)^2*
         transverseK*((4*I)*eOut*Q^8 - I*D*eOut*Q^8 + (10*I)*eOut*Q^6*s - 
          (2*I)*D*eOut*Q^6*s - (4*I)*hIn*hOut*Q^6*s - (4*I)*Q^4*s^2 + 
          (12*I)*eOut*Q^4*s^2 - I*D*eOut*Q^4*s^2 - (8*I)*hIn*hOut*Q^4*s^2 - 
          (8*I)*Q^2*s^3 + (10*I)*eOut*Q^2*s^3 - (4*I)*hIn*hOut*Q^2*s^3 - 
          (4*I)*s^4 + (4*I)*eOut*s^4 - (2*I)*Q^6*t + (8*I)*eOut*Q^6*t - 
          (2*I)*D*eOut*Q^6*t + (2*I)*hIn*hOut*Q^6*t + (4*I)*Q^4*s*t - 
          (2*I)*eOut*Q^4*s*t - (4*I)*hIn*hOut*Q^4*s*t + (2*I)*Q^2*s^2*t - 
          (8*I)*eOut*Q^2*s^2*t + (2*I)*D*eOut*Q^2*s^2*t - 
          (2*I)*hIn*hOut*Q^2*s^2*t - (4*I)*s^3*t + (2*I)*eOut*s^3*t + 
          (4*I)*hIn*hOut*s^3*t - (2*I)*Q^4*t^2 + (4*I)*eOut*Q^4*t^2 - 
          I*D*eOut*Q^4*t^2 + (2*I)*hIn*hOut*Q^4*t^2 + (4*I)*Q^2*s*t^2 - 
          (8*I)*eOut*Q^2*s*t^2 + (2*I)*D*eOut*Q^2*s*t^2 - 
          (4*I)*hIn*hOut*Q^2*s*t^2 - (2*I)*s^2*t^2 + (4*I)*eOut*s^2*t^2 - 
          I*D*eOut*s^2*t^2 + (2*I)*hIn*hOut*s^2*t^2 + (2*I)*Q^8*xOut + 
          (4*I)*Q^6*s*xOut - (2*I)*Q^4*s^2*xOut - (8*I)*Q^2*s^3*xOut - 
          (4*I)*s^4*xOut + (2*I)*Q^6*t*xOut + (4*I)*Q^4*s*t*xOut - 
          (2*I)*Q^2*s^2*t*xOut - (4*I)*s^3*t*xOut + 2*hIn*Q^8*yOut + 
          4*hIn*Q^6*s*yOut + 2*hIn*Q^4*s^2*yOut + 2*hIn*Q^6*t*yOut - 
          2*hIn*Q^2*s^2*t*yOut))/(8*s*SUNN^2*(Q^2 + s + t)*
         (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>, 
   <|"Kind" -> "PhotonWardLeft", "Index" -> {3}, 
    "Coefficients" -> <|GLI["V09", {0, 0, 0, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
          (4*hIn*Q^10 - 8*eOut*hIn*Q^10 + 2*D*eOut*hIn*Q^10 + 4*hOut*Q^10 + 
           18*hIn*Q^8*s - 28*eOut*hIn*Q^8*s + 7*D*eOut*hIn*Q^8*s + 
           18*hOut*Q^8*s + 30*hIn*Q^6*s^2 - 32*eOut*hIn*Q^6*s^2 + 
           8*D*eOut*hIn*Q^6*s^2 + 30*hOut*Q^6*s^2 + 22*hIn*Q^4*s^3 - 
           12*eOut*hIn*Q^4*s^3 + 3*D*eOut*hIn*Q^4*s^3 + 22*hOut*Q^4*s^3 + 
           6*hIn*Q^2*s^4 + 6*hOut*Q^2*s^4 + 6*hIn*Q^8*t - 28*eOut*hIn*Q^8*t + 
           7*D*eOut*hIn*Q^8*t + 6*hOut*Q^8*t + 28*hIn*Q^6*s*t - 
           72*eOut*hIn*Q^6*s*t + 17*D*eOut*hIn*Q^6*s*t + 20*hOut*Q^6*s*t + 
           28*hIn*Q^4*s^2*t - 46*eOut*hIn*Q^4*s^2*t + 10*D*eOut*hIn*Q^4*s^2*
            t + 24*hOut*Q^4*s^2*t - 2*eOut*hIn*Q^2*s^3*t + 8*hOut*Q^2*s^3*t - 
           6*hIn*s^4*t - 2*hOut*s^4*t + 6*hIn*Q^6*t^2 - 36*eOut*hIn*Q^6*t^2 + 
           9*D*eOut*hIn*Q^6*t^2 - 2*hOut*Q^6*t^2 + 16*hIn*Q^4*s*t^2 - 
           46*eOut*hIn*Q^4*s*t^2 + 12*D*eOut*hIn*Q^4*s*t^2 - 
           4*hIn*Q^2*s^2*t^2 + 12*eOut*hIn*Q^2*s^2*t^2 - 2*D*eOut*hIn*Q^2*s^2*
            t^2 + 8*hOut*Q^2*s^2*t^2 - 10*hIn*s^3*t^2 + 14*eOut*hIn*s^3*t^2 - 
           3*D*eOut*hIn*s^3*t^2 + 2*hOut*s^3*t^2 + 6*hIn*Q^4*t^3 - 
           20*eOut*hIn*Q^4*t^3 + 5*D*eOut*hIn*Q^4*t^3 - 6*hOut*Q^4*t^3 - 
           2*eOut*hIn*Q^2*s*t^3 + D*eOut*hIn*Q^2*s*t^3 - 6*hIn*s^2*t^3 + 
           18*eOut*hIn*s^2*t^3 - 4*D*eOut*hIn*s^2*t^3 + 6*hOut*s^2*t^3 + 
           2*hIn*Q^2*t^4 - 4*eOut*hIn*Q^2*t^4 + D*eOut*hIn*Q^2*t^4 - 
           2*hOut*Q^2*t^4 - 2*hIn*s*t^4 + 4*eOut*hIn*s*t^4 - 
           D*eOut*hIn*s*t^4 + 2*hOut*s*t^4 - 4*hIn*Q^8*s*xOut - 
           14*hIn*Q^6*s^2*xOut - 16*hIn*Q^4*s^3*xOut - 6*hIn*Q^2*s^4*xOut - 
           8*hIn*Q^8*t*xOut - 26*hIn*Q^6*s*t*xOut - 32*hIn*Q^4*s^2*t*xOut - 
           8*hIn*Q^2*s^3*t*xOut + 6*hIn*s^4*t*xOut - 12*hIn*Q^6*t^2*xOut - 
           24*hIn*Q^4*s*t^2*xOut - 8*hIn*Q^2*s^2*t^2*xOut + 
           12*hIn*s^3*t^2*xOut - 4*hIn*Q^4*t^3*xOut - 6*hIn*Q^2*s*t^3*xOut + 
           6*hIn*s^2*t^3*xOut - (4*I)*Q^8*s*yOut - (14*I)*Q^6*s^2*yOut - 
           (16*I)*Q^4*s^3*yOut - (6*I)*Q^2*s^4*yOut - (14*I)*Q^6*s*t*yOut - 
           (36*I)*Q^4*s^2*t*yOut - (20*I)*Q^2*s^3*t*yOut + (2*I)*s^4*t*yOut - 
           (16*I)*Q^4*s*t^2*yOut - (20*I)*Q^2*s^2*t^2*yOut + 
           (4*I)*s^3*t^2*yOut - (6*I)*Q^2*s*t^3*yOut + (2*I)*s^2*t^3*yOut))/
         (s^2*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 0}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*transverseK*(2*hIn*Q^8 - 4*eOut*hIn*Q^8 + 
          D*eOut*hIn*Q^8 + 2*hOut*Q^8 + 6*hIn*Q^6*s - 8*eOut*hIn*Q^6*s + 
          2*D*eOut*hIn*Q^6*s + 6*hOut*Q^6*s + 6*hIn*Q^4*s^2 - 
          4*eOut*hIn*Q^4*s^2 + D*eOut*hIn*Q^4*s^2 + 6*hOut*Q^4*s^2 + 
          2*hIn*Q^2*s^3 + 2*hOut*Q^2*s^3 + 2*hIn*Q^6*t - 12*eOut*hIn*Q^6*t + 
          3*D*eOut*hIn*Q^6*t + 2*hOut*Q^6*t + 6*hIn*Q^4*s*t - 
          14*eOut*hIn*Q^4*s*t + 3*D*eOut*hIn*Q^4*s*t + 2*hOut*Q^4*s*t + 
          2*hIn*Q^2*s^2*t - 2*eOut*hIn*Q^2*s^2*t + 2*hOut*Q^2*s^2*t - 
          2*hIn*s^3*t + 2*hOut*s^3*t + 2*hIn*Q^4*t^2 - 12*eOut*hIn*Q^4*t^2 + 
          3*D*eOut*hIn*Q^4*t^2 - 2*hOut*Q^4*t^2 + 2*hIn*Q^2*s*t^2 + 
          2*eOut*hIn*Q^2*s*t^2 - 2*hOut*Q^2*s*t^2 - 4*hIn*s^2*t^2 + 
          6*eOut*hIn*s^2*t^2 - D*eOut*hIn*s^2*t^2 + 4*hOut*s^2*t^2 + 
          2*hIn*Q^2*t^3 - 4*eOut*hIn*Q^2*t^3 + D*eOut*hIn*Q^2*t^3 - 
          2*hOut*Q^2*t^3 - 2*hIn*s*t^3 + 4*eOut*hIn*s*t^3 - 
          D*eOut*hIn*s*t^3 + 2*hOut*s*t^3 - 2*hIn*Q^6*s*xOut - 
          4*hIn*Q^4*s^2*xOut - 2*hIn*Q^2*s^3*xOut - 4*hIn*Q^6*t*xOut - 
          8*hIn*Q^4*s*t*xOut - 2*hIn*Q^2*s^2*t*xOut + 2*hIn*s^3*t*xOut - 
          4*hIn*Q^4*t^2*xOut - 2*hIn*Q^2*s*t^2*xOut + 2*hIn*s^2*t^2*xOut - 
          (2*I)*Q^6*s*yOut - (4*I)*Q^4*s^2*yOut - (2*I)*Q^2*s^3*yOut - 
          (4*I)*Q^4*s*t*yOut - (6*I)*Q^2*s^2*t*yOut - (2*I)*s^3*t*yOut - 
          (2*I)*Q^2*s*t^2*yOut - (2*I)*s^2*t^2*yOut))/
        (8*s^2*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {-1, 0, 1, 1}] -> ((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
         (1 + SUNN)^2*transverseK*(2*hIn*Q^8 - 4*eOut*hIn*Q^8 + 
          D*eOut*hIn*Q^8 + 2*hOut*Q^8 + 6*hIn*Q^6*s - 8*eOut*hIn*Q^6*s + 
          2*D*eOut*hIn*Q^6*s + 6*hOut*Q^6*s + 6*hIn*Q^4*s^2 - 
          4*eOut*hIn*Q^4*s^2 + D*eOut*hIn*Q^4*s^2 + 6*hOut*Q^4*s^2 + 
          2*hIn*Q^2*s^3 + 2*hOut*Q^2*s^3 + 6*hIn*Q^6*t - 12*eOut*hIn*Q^6*t + 
          3*D*eOut*hIn*Q^6*t + 6*hOut*Q^6*t + 6*hIn*Q^4*s*t - 
          10*eOut*hIn*Q^4*s*t + 3*D*eOut*hIn*Q^4*s*t + 10*hOut*Q^4*s*t - 
          2*hIn*Q^2*s^2*t + 2*eOut*hIn*Q^2*s^2*t - 2*hOut*Q^2*s^2*t - 
          2*hIn*s^3*t - 6*hOut*s^3*t + 2*hIn*Q^4*t^2 - 12*eOut*hIn*Q^4*t^2 + 
          3*D*eOut*hIn*Q^4*t^2 + 6*hOut*Q^4*t^2 - 2*hIn*Q^2*s*t^2 - 
          2*eOut*hIn*Q^2*s*t^2 + 2*hOut*Q^2*s*t^2 + 2*eOut*hIn*s^2*t^2 - 
          D*eOut*hIn*s^2*t^2 - 8*hOut*s^2*t^2 - 2*hIn*Q^2*t^3 - 
          4*eOut*hIn*Q^2*t^3 + D*eOut*hIn*Q^2*t^3 + 2*hOut*Q^2*t^3 + 
          2*hIn*s*t^3 + 4*eOut*hIn*s*t^3 - D*eOut*hIn*s*t^3 - 2*hOut*s*t^3 - 
          2*hIn*Q^6*s*xOut - 4*hIn*Q^4*s^2*xOut - 2*hIn*Q^2*s^3*xOut - 
          8*hIn*Q^4*s*t*xOut - 6*hIn*Q^2*s^2*t*xOut + 2*hIn*s^3*t*xOut - 
          4*hIn*Q^4*t^2*xOut - 6*hIn*Q^2*s*t^2*xOut + 6*hIn*s^2*t^2*xOut - 
          4*hIn*Q^2*t^3*xOut + 4*hIn*s*t^3*xOut - (2*I)*Q^6*s*yOut - 
          (4*I)*Q^4*s^2*yOut - (2*I)*Q^2*s^3*yOut - (4*I)*Q^6*t*yOut - 
          (12*I)*Q^4*s*t*yOut - (2*I)*Q^2*s^2*t*yOut + (6*I)*s^3*t*yOut - 
          (8*I)*Q^4*t^2*yOut - (6*I)*Q^2*s*t^2*yOut + (10*I)*s^2*t^2*yOut - 
          (4*I)*Q^2*t^3*yOut + (4*I)*s*t^3*yOut))/(8*s*SUNN^2*t*
         (Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, -1, 1, 1}] -> ((-2 + D)*(Q^2 + s)^2*(-1 + SUNN)^2*
         (1 + SUNN)^2*transverseK*(2*hIn*Q^8 - 4*eOut*hIn*Q^8 + 
          D*eOut*hIn*Q^8 + 2*hOut*Q^8 + 6*hIn*Q^6*s - 8*eOut*hIn*Q^6*s + 
          2*D*eOut*hIn*Q^6*s + 6*hOut*Q^6*s + 6*hIn*Q^4*s^2 - 
          4*eOut*hIn*Q^4*s^2 + D*eOut*hIn*Q^4*s^2 + 6*hOut*Q^4*s^2 + 
          2*hIn*Q^2*s^3 + 2*hOut*Q^2*s^3 + 2*hIn*Q^6*t - 12*eOut*hIn*Q^6*t + 
          3*D*eOut*hIn*Q^6*t + 2*hOut*Q^6*t + 6*hIn*Q^4*s*t - 
          14*eOut*hIn*Q^4*s*t + 3*D*eOut*hIn*Q^4*s*t + 2*hOut*Q^4*s*t + 
          2*hIn*Q^2*s^2*t - 2*eOut*hIn*Q^2*s^2*t + 2*hOut*Q^2*s^2*t - 
          2*hIn*s^3*t + 2*hOut*s^3*t + 2*hIn*Q^4*t^2 - 12*eOut*hIn*Q^4*t^2 + 
          3*D*eOut*hIn*Q^4*t^2 - 2*hOut*Q^4*t^2 + 2*hIn*Q^2*s*t^2 + 
          2*eOut*hIn*Q^2*s*t^2 - 2*hOut*Q^2*s*t^2 - 4*hIn*s^2*t^2 + 
          6*eOut*hIn*s^2*t^2 - D*eOut*hIn*s^2*t^2 + 4*hOut*s^2*t^2 + 
          2*hIn*Q^2*t^3 - 4*eOut*hIn*Q^2*t^3 + D*eOut*hIn*Q^2*t^3 - 
          2*hOut*Q^2*t^3 - 2*hIn*s*t^3 + 4*eOut*hIn*s*t^3 - 
          D*eOut*hIn*s*t^3 + 2*hOut*s*t^3 - 2*hIn*Q^6*s*xOut - 
          4*hIn*Q^4*s^2*xOut - 2*hIn*Q^2*s^3*xOut - 4*hIn*Q^6*t*xOut - 
          8*hIn*Q^4*s*t*xOut - 2*hIn*Q^2*s^2*t*xOut + 2*hIn*s^3*t*xOut - 
          4*hIn*Q^4*t^2*xOut - 2*hIn*Q^2*s*t^2*xOut + 2*hIn*s^2*t^2*xOut - 
          (2*I)*Q^6*s*yOut - (4*I)*Q^4*s^2*yOut - (2*I)*Q^2*s^3*yOut - 
          (4*I)*Q^4*s*t*yOut - (6*I)*Q^2*s^2*t*yOut - (2*I)*s^3*t*yOut - 
          (2*I)*Q^2*s*t^2*yOut - (2*I)*s^2*t^2*yOut))/
        (8*s^2*SUNN^2*t*(Q^2 + s + t)^2*(Q^4 + Q^2*s + Q^2*t - s*t)), 
      GLI["V09", {0, 0, 1, 1}] -> -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*
          (1 + SUNN)^2*transverseK*(2*hIn*Q^8 - 4*eOut*hIn*Q^8 + 
           D*eOut*hIn*Q^8 + 2*hOut*Q^8 + 6*hIn*Q^6*s - 8*eOut*hIn*Q^6*s + 
           2*D*eOut*hIn*Q^6*s + 6*hOut*Q^6*s + 6*hIn*Q^4*s^2 - 
           4*eOut*hIn*Q^4*s^2 + D*eOut*hIn*Q^4*s^2 + 6*hOut*Q^4*s^2 + 
           2*hIn*Q^2*s^3 + 2*hOut*Q^2*s^3 + 2*hIn*Q^6*t - 12*eOut*hIn*Q^6*t + 
           3*D*eOut*hIn*Q^6*t + 2*hOut*Q^6*t + 6*hIn*Q^4*s*t - 
           14*eOut*hIn*Q^4*s*t + 3*D*eOut*hIn*Q^4*s*t + 2*hOut*Q^4*s*t + 
           2*hIn*Q^2*s^2*t - 2*eOut*hIn*Q^2*s^2*t + 2*hOut*Q^2*s^2*t - 
           2*hIn*s^3*t + 2*hOut*s^3*t + 2*hIn*Q^4*t^2 - 12*eOut*hIn*Q^4*t^2 + 
           3*D*eOut*hIn*Q^4*t^2 - 2*hOut*Q^4*t^2 + 2*hIn*Q^2*s*t^2 + 
           2*eOut*hIn*Q^2*s*t^2 - 2*hOut*Q^2*s*t^2 - 4*hIn*s^2*t^2 + 
           6*eOut*hIn*s^2*t^2 - D*eOut*hIn*s^2*t^2 + 4*hOut*s^2*t^2 + 
           2*hIn*Q^2*t^3 - 4*eOut*hIn*Q^2*t^3 + D*eOut*hIn*Q^2*t^3 - 
           2*hOut*Q^2*t^3 - 2*hIn*s*t^3 + 4*eOut*hIn*s*t^3 - 
           D*eOut*hIn*s*t^3 + 2*hOut*s*t^3 - 2*hIn*Q^6*s*xOut - 
           4*hIn*Q^4*s^2*xOut - 2*hIn*Q^2*s^3*xOut - 4*hIn*Q^6*t*xOut - 
           8*hIn*Q^4*s*t*xOut - 2*hIn*Q^2*s^2*t*xOut + 2*hIn*s^3*t*xOut - 
           4*hIn*Q^4*t^2*xOut - 2*hIn*Q^2*s*t^2*xOut + 2*hIn*s^2*t^2*xOut - 
           (2*I)*Q^6*s*yOut - (4*I)*Q^4*s^2*yOut - (2*I)*Q^2*s^3*yOut - 
           (4*I)*Q^4*s*t*yOut - (6*I)*Q^2*s^2*t*yOut - (2*I)*s^3*t*yOut - 
           (2*I)*Q^2*s*t^2*yOut - (2*I)*s^2*t^2*yOut))/
         (s*SUNN^2*t*(Q^2 + s + t)*(Q^4 + Q^2*s + Q^2*t - s*t))|>, 
    "ReducedCoefficients" -> <|GLI["V01", {0, 1, 0, 1}] -> 
       -1/8*((-2 + D)*(Q^2 + s)*(-1 + SUNN)^2*(1 + SUNN)^2*transverseK*
          (-4*eOut*hIn*Q^6 + D*eOut*hIn*Q^6 + 4*hIn*Q^4*s - 
           6*eOut*hIn*Q^4*s + D*eOut*hIn*Q^4*s + 4*hIn*Q^2*s^2 - 
           2*eOut*hIn*Q^2*s^2 + 4*hOut*Q^2*s^2 + 4*hOut*s^3 + 2*hIn*Q^4*t - 
           8*eOut*hIn*Q^4*t + 2*D*eOut*hIn*Q^4*t - 2*hOut*Q^4*t + 
           2*hIn*Q^2*s*t + 2*eOut*hIn*Q^2*s*t - 2*hOut*Q^2*s*t - 
           4*hIn*s^2*t + 2*eOut*hIn*s^2*t + 4*hOut*s^2*t + 2*hIn*Q^2*t^2 - 
           4*eOut*hIn*Q^2*t^2 + D*eOut*hIn*Q^2*t^2 - 2*hOut*Q^2*t^2 - 
           2*hIn*s*t^2 + 4*eOut*hIn*s*t^2 - D*eOut*hIn*s*t^2 + 2*hOut*s*t^2 - 
           2*hIn*Q^6*xOut - 2*hIn*Q^4*s*xOut - 2*hIn*Q^4*t*xOut - 
           2*hIn*Q^2*s*t*xOut + (2*I)*Q^6*yOut + (2*I)*Q^4*s*yOut - 
           (4*I)*Q^2*s^2*yOut - (4*I)*s^3*yOut + (2*I)*Q^4*t*yOut - 
           (2*I)*Q^2*s*t*yOut - (4*I)*s^2*t*yOut))/(s*SUNN^2*(Q^2 + s + t)*
          (Q^4 + Q^2*s + Q^2*t - s*t))|>, "MissingTargets" -> {}|>}, 
 "InputHash" -> 9790999558967801146749399391199556252505347639496559566042219\
1892328298741711, "ReconstructionPassed" -> True, 
 "ReducedReferenceChecksPassed" -> True|>
