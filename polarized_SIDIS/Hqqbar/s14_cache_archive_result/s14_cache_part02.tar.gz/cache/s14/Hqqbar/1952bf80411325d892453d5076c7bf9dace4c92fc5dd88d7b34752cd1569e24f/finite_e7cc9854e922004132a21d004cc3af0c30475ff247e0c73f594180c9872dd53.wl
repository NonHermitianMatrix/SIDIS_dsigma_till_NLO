<|"Label" -> {{1, 3, 3}, 1, "Regular"}, "PoleResiduals" -> <|-1 -> 0|>, 
 "Finite" -> 
  (((4*eq^2*gs^4*omega*Pi*Q^4)/((omega + 2*Q^2)*(omega - s)*
        ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^4*s)/
       ((omega + 2*Q^2)*(omega - s)*((omega - s)*s + Q^2*s23)) + 
      (8*eq^2*gs^4*omega^3*Pi*Q^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*omega^2*Pi*Q^4)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
      (20*eq^2*gs^4*omega*Pi*Q^6)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*Pi*Q^8)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) - 
      (12*eq^2*gs^4*omega^2*Pi*Q^2*s)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) - (28*eq^2*gs^4*omega*Pi*Q^4*s)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) - 
      (8*eq^2*gs^4*Pi*Q^6*s)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega*Pi*Q^2*s^2)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
      (16*eq^2*gs^4*Pi*Q^4*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*omega^2*Pi*Q^4)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)) + 
      (4*eq^2*gs^4*omega*Pi*Q^6)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*
        ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega^2*Pi*Q^2*s)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)) + 
      (8*eq^2*gs^4*omega*Pi*Q^4*s)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*
        ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^6*s)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)) - 
      (8*eq^2*gs^4*omega*Pi*Q^2*s^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*
        ((omega - s)*s + Q^2*s23)) - (12*eq^2*gs^4*Pi*Q^4*s^2)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)) - 
      (8*eq^2*gs^4*Pi*Q^4*s23)/((omega + 2*Q^2)*(omega - s)*
        ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^2*s*s23)/
       ((omega + 2*Q^2)*(omega - s)*((omega - s)*s + Q^2*s23)) - 
      (16*eq^2*gs^4*omega^2*Pi*Q^2*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) - (36*eq^2*gs^4*omega*Pi*Q^4*s23)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) - 
      (8*eq^2*gs^4*Pi*Q^6*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega*Pi*Q^2*s*s23)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
      (16*eq^2*gs^4*Pi*Q^4*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*Pi*Q^6*s23)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)) + 
      (12*eq^2*gs^4*Pi*Q^4*s*s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*
        ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*Pi*Q^2*s^2*s23)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)) + 
      (12*eq^2*gs^4*omega*Pi*Q^2*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*Pi*Q^4*s23^2)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
      (8*eq^2*gs^4*omega*Pi*Q^2*s23^2)/((omega - s)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*Pi*Q^2*s*s23^2)/
       ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) - 
      (8*eq^2*gs^4*Pi*Q^2*s23^3)/((omega - s)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega^8*Pi*Q^2*s^2)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (8*eq^2*gs^4*omega^7*Pi*Q^4*s^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) - (8*eq^2*gs^4*omega^6*Pi*Q^6*s^2)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (28*eq^2*gs^4*omega^7*Pi*Q^2*s^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (8*eq^2*gs^4*omega^6*Pi*Q^4*s^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) + (16*eq^2*gs^4*omega^5*Pi*Q^6*s^3)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (48*eq^2*gs^4*omega^6*Pi*Q^2*s^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (8*eq^2*gs^4*omega^5*Pi*Q^4*s^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) - (8*eq^2*gs^4*omega^4*Pi*Q^6*s^4)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (44*eq^2*gs^4*omega^5*Pi*Q^2*s^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (8*eq^2*gs^4*omega^4*Pi*Q^4*s^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) - (16*eq^2*gs^4*omega^4*Pi*Q^2*s^6)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (16*eq^2*gs^4*omega^8*Pi*Q^2*s*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (16*eq^2*gs^4*omega^7*Pi*Q^4*s*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (16*eq^2*gs^4*omega^6*Pi*Q^6*s*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (40*eq^2*gs^4*omega^7*Pi*Q^2*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (76*eq^2*gs^4*omega^6*Pi*Q^4*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (96*eq^2*gs^4*omega^5*Pi*Q^6*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (64*eq^2*gs^4*omega^4*Pi*Q^8*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (56*eq^2*gs^4*omega^6*Pi*Q^2*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (200*eq^2*gs^4*omega^5*Pi*Q^4*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (80*eq^2*gs^4*omega^4*Pi*Q^6*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (128*eq^2*gs^4*omega^3*Pi*Q^8*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (56*eq^2*gs^4*omega^5*Pi*Q^2*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (364*eq^2*gs^4*omega^4*Pi*Q^4*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (64*eq^2*gs^4*omega^3*Pi*Q^6*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (64*eq^2*gs^4*omega^2*Pi*Q^8*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (24*eq^2*gs^4*omega^4*Pi*Q^2*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (352*eq^2*gs^4*omega^3*Pi*Q^4*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (64*eq^2*gs^4*omega^2*Pi*Q^6*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*omega^2*Pi*Q^4*s^6*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (8*eq^2*gs^4*omega^8*Pi*Q^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (8*eq^2*gs^4*omega^7*Pi*Q^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (8*eq^2*gs^4*omega^6*Pi*Q^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (4*eq^2*gs^4*omega^7*Pi*Q^2*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (128*eq^2*gs^4*omega^6*Pi*Q^4*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (144*eq^2*gs^4*omega^5*Pi*Q^6*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (128*eq^2*gs^4*omega^4*Pi*Q^8*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (12*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (296*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (232*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (384*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*omega^2*Pi*Q^10*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (20*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (432*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (256*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (256*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (256*eq^2*gs^4*omega*Pi*Q^10*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (20*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (448*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (608*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (128*eq^2*gs^4*omega*Pi*Q^8*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*Pi*Q^10*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (192*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (704*eq^2*gs^4*omega*Pi*Q^6*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*Pi*Q^8*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) - (256*eq^2*gs^4*Pi*Q^6*s^6*s23^2)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (16*eq^2*gs^4*omega^7*Pi*Q^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (60*eq^2*gs^4*omega^6*Pi*Q^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (64*eq^2*gs^4*omega^5*Pi*Q^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (64*eq^2*gs^4*omega^4*Pi*Q^8*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (40*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (256*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (384*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (256*eq^2*gs^4*omega^2*Pi*Q^10*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (40*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (100*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (448*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (256*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (512*eq^2*gs^4*omega*Pi*Q^10*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (24*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (160*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (768*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (384*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (256*eq^2*gs^4*Pi*Q^10*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (160*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (896*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (320*eq^2*gs^4*Pi*Q^8*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) + (384*eq^2*gs^4*Pi*Q^6*s^5*s23^3)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (20*eq^2*gs^4*omega^6*Pi*Q^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (128*eq^2*gs^4*omega^5*Pi*Q^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (96*eq^2*gs^4*omega^4*Pi*Q^6*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*omega^3*Pi*Q^8*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*omega^2*Pi*Q^10*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (24*eq^2*gs^4*omega^5*Pi*Q^2*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (256*eq^2*gs^4*omega*Pi*Q^10*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (4*eq^2*gs^4*omega^4*Pi*Q^2*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (320*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (224*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (384*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*Pi*Q^10*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (192*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (320*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (256*eq^2*gs^4*Pi*Q^8*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) - (320*eq^2*gs^4*Pi*Q^6*s^4*s23^4)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (8*eq^2*gs^4*omega^5*Pi*Q^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (160*eq^2*gs^4*omega^4*Pi*Q^4*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (256*eq^2*gs^4*omega^3*Pi*Q^6*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (64*eq^2*gs^4*omega^2*Pi*Q^8*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (192*eq^2*gs^4*omega^3*Pi*Q^4*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*omega*Pi*Q^8*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (32*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (640*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (64*eq^2*gs^4*Pi*Q^8*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) + (384*eq^2*gs^4*Pi*Q^6*s^3*s23^5)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (64*eq^2*gs^4*omega^3*Pi*Q^4*s23^6)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (320*eq^2*gs^4*omega^2*Pi*Q^6*s23^6)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (64*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^6)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
      (384*eq^2*gs^4*omega*Pi*Q^6*s*s23^6)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (64*eq^2*gs^4*Pi*Q^6*s^2*s23^6)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) + (128*eq^2*gs^4*omega*Pi*Q^6*s23^7)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
      (128*eq^2*gs^4*Pi*Q^6*s*s23^7)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2) - (4*eq^2*gs^4*omega*Pi*Q^4)/
       ((omega + 2*Q^2)*(omega - s)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
      (4*eq^2*gs^4*Pi*Q^4*s)/((omega + 2*Q^2)*(omega - s)*
        ((omega - s)*s + Q^2*s23)*SUNN^2) - (8*eq^2*gs^4*omega^3*Pi*Q^2)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (24*eq^2*gs^4*omega^2*Pi*Q^4)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) - (20*eq^2*gs^4*omega*Pi*Q^6)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (8*eq^2*gs^4*Pi*Q^8)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) + (12*eq^2*gs^4*omega^2*Pi*Q^2*s)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) + 
      (28*eq^2*gs^4*omega*Pi*Q^4*s)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^6*s)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (8*eq^2*gs^4*omega*Pi*Q^2*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) - (16*eq^2*gs^4*Pi*Q^4*s^2)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (4*eq^2*gs^4*omega^2*Pi*Q^4)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*
        ((omega - s)*s + Q^2*s23)*SUNN^2) - (4*eq^2*gs^4*omega*Pi*Q^6)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)*
        SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^2*s)/((omega + 2*Q^2)*(omega - s)*
        (Q^2 + s)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (8*eq^2*gs^4*omega*Pi*Q^4*s)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*
        ((omega - s)*s + Q^2*s23)*SUNN^2) + (4*eq^2*gs^4*Pi*Q^6*s)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)*
        SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^2*s^2)/((omega + 2*Q^2)*(omega - s)*
        (Q^2 + s)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
      (12*eq^2*gs^4*Pi*Q^4*s^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*
        ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^4*s23)/
       ((omega + 2*Q^2)*(omega - s)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
      (4*eq^2*gs^4*Pi*Q^2*s*s23)/((omega + 2*Q^2)*(omega - s)*
        ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*omega^2*Pi*Q^2*s23)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) + 
      (36*eq^2*gs^4*omega*Pi*Q^4*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^6*s23)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (8*eq^2*gs^4*omega*Pi*Q^2*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) - (16*eq^2*gs^4*Pi*Q^4*s*s23)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (8*eq^2*gs^4*Pi*Q^6*s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*
        ((omega - s)*s + Q^2*s23)*SUNN^2) - (12*eq^2*gs^4*Pi*Q^4*s*s23)/
       ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)*((omega - s)*s + Q^2*s23)*
        SUNN^2) - (4*eq^2*gs^4*Pi*Q^2*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
        (Q^2 + s)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (12*eq^2*gs^4*omega*Pi*Q^2*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) - (24*eq^2*gs^4*Pi*Q^4*s23^2)/
       ((omega + 2*Q^2)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
      (8*eq^2*gs^4*omega*Pi*Q^2*s23^2)/((omega - s)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^2*s*s23^2)/
       ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) + 
      (8*eq^2*gs^4*Pi*Q^2*s23^3)/((omega - s)*(Q^2 + s)^2*
        ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*omega^8*Pi*Q^2*s^2)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (8*eq^2*gs^4*omega^7*Pi*Q^4*s^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) + (8*eq^2*gs^4*omega^6*Pi*Q^6*s^2)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (28*eq^2*gs^4*omega^7*Pi*Q^2*s^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (8*eq^2*gs^4*omega^6*Pi*Q^4*s^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) - (16*eq^2*gs^4*omega^5*Pi*Q^6*s^3)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (48*eq^2*gs^4*omega^6*Pi*Q^2*s^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (8*eq^2*gs^4*omega^5*Pi*Q^4*s^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) + (8*eq^2*gs^4*omega^4*Pi*Q^6*s^4)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (44*eq^2*gs^4*omega^5*Pi*Q^2*s^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (8*eq^2*gs^4*omega^4*Pi*Q^4*s^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) + (16*eq^2*gs^4*omega^4*Pi*Q^2*s^6)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (16*eq^2*gs^4*omega^8*Pi*Q^2*s*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (16*eq^2*gs^4*omega^7*Pi*Q^4*s*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (16*eq^2*gs^4*omega^6*Pi*Q^6*s*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (40*eq^2*gs^4*omega^7*Pi*Q^2*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (76*eq^2*gs^4*omega^6*Pi*Q^4*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (96*eq^2*gs^4*omega^5*Pi*Q^6*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (64*eq^2*gs^4*omega^4*Pi*Q^8*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (56*eq^2*gs^4*omega^6*Pi*Q^2*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (200*eq^2*gs^4*omega^5*Pi*Q^4*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (80*eq^2*gs^4*omega^4*Pi*Q^6*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (128*eq^2*gs^4*omega^3*Pi*Q^8*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (56*eq^2*gs^4*omega^5*Pi*Q^2*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (364*eq^2*gs^4*omega^4*Pi*Q^4*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (64*eq^2*gs^4*omega^3*Pi*Q^6*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (64*eq^2*gs^4*omega^2*Pi*Q^8*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (24*eq^2*gs^4*omega^4*Pi*Q^2*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (352*eq^2*gs^4*omega^3*Pi*Q^4*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (64*eq^2*gs^4*omega^2*Pi*Q^6*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*omega^2*Pi*Q^4*s^6*s23)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (8*eq^2*gs^4*omega^8*Pi*Q^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (8*eq^2*gs^4*omega^7*Pi*Q^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (8*eq^2*gs^4*omega^6*Pi*Q^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (4*eq^2*gs^4*omega^7*Pi*Q^2*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (128*eq^2*gs^4*omega^6*Pi*Q^4*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (144*eq^2*gs^4*omega^5*Pi*Q^6*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (128*eq^2*gs^4*omega^4*Pi*Q^8*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (12*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (296*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (232*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (384*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*omega^2*Pi*Q^10*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (20*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (432*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (256*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (256*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (256*eq^2*gs^4*omega*Pi*Q^10*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (20*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (448*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (608*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (128*eq^2*gs^4*omega*Pi*Q^8*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*Pi*Q^10*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (192*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (704*eq^2*gs^4*omega*Pi*Q^6*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*Pi*Q^8*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) + (256*eq^2*gs^4*Pi*Q^6*s^6*s23^2)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (16*eq^2*gs^4*omega^7*Pi*Q^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (60*eq^2*gs^4*omega^6*Pi*Q^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (64*eq^2*gs^4*omega^5*Pi*Q^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (64*eq^2*gs^4*omega^4*Pi*Q^8*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (40*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (256*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (384*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (256*eq^2*gs^4*omega^2*Pi*Q^10*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (40*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (100*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (448*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (256*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (512*eq^2*gs^4*omega*Pi*Q^10*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (24*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (160*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (768*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (384*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (256*eq^2*gs^4*Pi*Q^10*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (160*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (896*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (320*eq^2*gs^4*Pi*Q^8*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) - (384*eq^2*gs^4*Pi*Q^6*s^5*s23^3)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (20*eq^2*gs^4*omega^6*Pi*Q^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (128*eq^2*gs^4*omega^5*Pi*Q^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (96*eq^2*gs^4*omega^4*Pi*Q^6*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*omega^3*Pi*Q^8*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*omega^2*Pi*Q^10*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (24*eq^2*gs^4*omega^5*Pi*Q^2*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (256*eq^2*gs^4*omega*Pi*Q^10*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (4*eq^2*gs^4*omega^4*Pi*Q^2*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (320*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (224*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (384*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*Pi*Q^10*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (192*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (320*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (256*eq^2*gs^4*Pi*Q^8*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) + (320*eq^2*gs^4*Pi*Q^6*s^4*s23^4)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (8*eq^2*gs^4*omega^5*Pi*Q^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (160*eq^2*gs^4*omega^4*Pi*Q^4*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (256*eq^2*gs^4*omega^3*Pi*Q^6*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (64*eq^2*gs^4*omega^2*Pi*Q^8*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (192*eq^2*gs^4*omega^3*Pi*Q^4*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*omega*Pi*Q^8*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (32*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (640*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (64*eq^2*gs^4*Pi*Q^8*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) - (384*eq^2*gs^4*Pi*Q^6*s^3*s23^5)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (64*eq^2*gs^4*omega^3*Pi*Q^4*s23^6)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (320*eq^2*gs^4*omega^2*Pi*Q^6*s23^6)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (64*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^6)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
      (384*eq^2*gs^4*omega*Pi*Q^6*s*s23^6)/((omega - s)^2*(Q^2 + s)^2*
        (s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (64*eq^2*gs^4*Pi*Q^6*s^2*s23^6)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2) - (128*eq^2*gs^4*omega*Pi*Q^6*s23^7)/
       ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
        ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
      (128*eq^2*gs^4*Pi*Q^6*s*s23^7)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
        ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
          4*Q^2*s23)^2*SUNN^2))*(Log[2] + Log[mu2] + Log[Pi]))/(64*Pi^6) + 
   ((8*eq^2*gs^4*omega^2*Pi*Q^2*s)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*omega*Pi*Q^2*s^2)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*Pi*Q^2*s^3)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*omega^6*Pi*Q^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (56*eq^2*gs^4*omega^5*Pi*Q^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (28*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (56*eq^2*gs^4*omega^4*Pi*Q^6)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (32*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*omega^3*Pi*Q^8)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (60*eq^2*gs^4*omega^5*Pi*Q^2*s)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (28*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*
       s)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (204*eq^2*gs^4*omega^4*Pi*Q^4*s)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (88*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*
       s)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (200*eq^2*gs^4*omega^3*Pi*Q^6*s)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (84*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*
       s)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (56*eq^2*gs^4*omega^2*Pi*Q^8*s)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*
       s)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (80*eq^2*gs^4*omega^4*Pi*Q^2*s^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (40*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*
       s^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (260*eq^2*gs^4*omega^3*Pi*Q^4*s^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (112*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*
       s^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (244*eq^2*gs^4*omega^2*Pi*Q^6*s^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (84*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*
       s^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (64*eq^2*gs^4*omega*Pi*Q^8*s^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*
       s^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (44*eq^2*gs^4*omega^3*Pi*Q^2*s^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (28*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*
       s^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (132*eq^2*gs^4*omega^2*Pi*Q^4*s^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (72*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*
       s^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (112*eq^2*gs^4*omega*Pi*Q^6*s^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (44*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*
       s^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*Pi*Q^8*s^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*
       s^4)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (20*eq^2*gs^4*omega*Pi*Q^4*s^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*
       s^4)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*gs^4*Pi*Q^6*s^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*omega^5*Pi*Q^2*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*gs^4*omega^4*Pi*Q^4*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (20*eq^2*gs^4*omega^3*Pi*Q^6*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega^2*Pi*Q^8*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega^4*Pi*Q^2*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (44*eq^2*gs^4*omega^3*Pi*Q^4*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*
       s^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - 
     (68*eq^2*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (32*eq^2*gs^4*omega*Pi*Q^8*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*omega^3*Pi*Q^2*s^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*
       s^3)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^4*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (36*eq^2*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (24*eq^2*gs^4*Pi*Q^8*s^3)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^8*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*omega*Pi*Q^4*s23)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^4*s*s23)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
     (52*eq^2*gs^4*omega^5*Pi*Q^2*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (28*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s23)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (160*eq^2*gs^4*omega^4*Pi*Q^4*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (84*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*
       s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (124*eq^2*gs^4*omega^3*Pi*Q^6*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (68*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*
       s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*gs^4*omega^2*Pi*Q^8*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*
       s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega*Pi*Q^10*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (172*eq^2*gs^4*omega^4*Pi*Q^2*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (84*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s*
       s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (500*eq^2*gs^4*omega^3*Pi*Q^4*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (228*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*
       s*s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (352*eq^2*gs^4*omega^2*Pi*Q^6*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (160*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*
       s*s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (60*eq^2*gs^4*omega*Pi*Q^8*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (32*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*
       s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*Pi*Q^10*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (192*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (96*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*
       s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (508*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (220*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (308*eq^2*gs^4*omega*Pi*Q^6*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (116*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*
       s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (28*eq^2*gs^4*Pi*Q^8*s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (84*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (52*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (184*eq^2*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (92*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^3*
       s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (80*eq^2*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (24*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^4*
       s23)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*EulerGamma*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*omega^4*Pi*Q^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*gs^4*omega^3*Pi*Q^6*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*
       s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (20*eq^2*gs^4*omega^2*Pi*Q^8*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^10*s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*omega^3*Pi*Q^4*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*gs^4*omega^2*Pi*Q^6*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (28*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s*
       s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - 
     (20*eq^2*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*Pi*Q^10*s*s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*EulerGamma*gs^4*Pi*Q^10*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (24*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (72*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (20*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*
       s^2*s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (20*eq^2*gs^4*Pi*Q^8*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (40*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (48*eq^2*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (36*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^3*
       s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - (52*eq^2*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (44*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^4*
       s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*EulerGamma*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega*Pi*Q^2*s23^2)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s23^2)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^4*s23^2)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^2*s*s23^2)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) - (56*eq^2*gs^4*omega^4*Pi*Q^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (32*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*
       s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (156*eq^2*gs^4*omega^3*Pi*Q^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (80*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*
       s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (100*eq^2*gs^4*omega^2*Pi*Q^6*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (36*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*
       s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (48*eq^2*gs^4*omega*Pi*Q^8*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^10*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (160*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (80*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s*
       s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (396*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (184*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*
       s*s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (156*eq^2*gs^4*omega*Pi*Q^6*s*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (72*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (140*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (68*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*
       s^2*s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (304*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (128*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (88*eq^2*gs^4*Pi*Q^6*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (36*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*
       s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (40*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^3*
       s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (56*eq^2*gs^4*Pi*Q^4*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*EulerGamma*gs^4*Pi*Q^4*s^3*
       s23^2)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega^3*Pi*Q^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*omega^2*Pi*Q^6*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*
       s23^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*Pi*Q^10*s23^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^10*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*omega*Pi*Q^6*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s*
       s23^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + (36*eq^2*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*EulerGamma*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (20*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*
       s^2*s23^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*gs^4*Pi*Q^6*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (52*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*
       s23^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*gs^4*Pi*Q^4*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*EulerGamma*gs^4*Pi*Q^4*s^3*
       s23^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*Pi*Q^2*s23^3)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^2*s23^3)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) + (20*eq^2*gs^4*omega^3*Pi*Q^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (12*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*
       s23^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (60*eq^2*gs^4*omega^2*Pi*Q^4*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*
       s23^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (48*eq^2*gs^4*omega*Pi*Q^6*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (48*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (24*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s*
       s23^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (104*eq^2*gs^4*omega*Pi*Q^4*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (48*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s*
       s23^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (28*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^2*
       s23^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (60*eq^2*gs^4*Pi*Q^4*s^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*EulerGamma*gs^4*Pi*Q^4*s^2*
       s23^3)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*omega^2*Pi*Q^4*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega*Pi*Q^6*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*EulerGamma*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*omega*Pi*Q^4*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (24*eq^2*gs^4*Pi*Q^6*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (20*eq^2*EulerGamma*gs^4*Pi*Q^6*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*gs^4*Pi*Q^4*s^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*EulerGamma*gs^4*Pi*Q^4*s^2*
       s23^3)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^3*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega*Pi*Q^4*s23^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^6*s23^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*Pi*Q^6*s23^4)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*Pi*Q^4*s*s23^4)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (12*eq^2*gs^4*omega^8*Pi*Q^2*s^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^8*Pi*Q^2*s^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (8*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^4*s^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^6*s^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (36*eq^2*gs^4*omega^7*Pi*Q^2*s^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (28*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^2*s^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^6*Pi*Q^4*s^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (8*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^4*s^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^6*s^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (48*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2*s^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (24*eq^2*gs^4*omega^5*Pi*Q^4*s^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (8*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (124*eq^2*gs^4*omega^5*Pi*Q^2*s^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (44*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^4*s^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (8*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (188*eq^2*gs^4*omega^4*Pi*Q^2*s^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (112*eq^2*gs^4*omega^3*Pi*Q^2*s^7)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^2*s^8)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (32*eq^2*gs^4*omega^8*Pi*Q^2*s*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*EulerGamma*gs^4*omega^8*Pi*Q^2*s*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^7*Pi*Q^4*s*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^4*s*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^6*s*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (80*eq^2*gs^4*omega^7*Pi*Q^2*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^2*s^2*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (172*eq^2*gs^4*omega^6*Pi*Q^4*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (76*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^4*s^2*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^5*Pi*Q^6*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (96*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^6*s^2*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^8*s^2*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*gs^4*omega^6*Pi*Q^2*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (56*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2*s^3*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (440*eq^2*gs^4*omega^5*Pi*Q^4*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (200*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s^3*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*gs^4*omega^4*Pi*Q^6*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (80*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s^3*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8*s^3*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (176*eq^2*gs^4*omega^5*Pi*Q^2*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (56*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s^4*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (532*eq^2*gs^4*omega^4*Pi*Q^4*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (364*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s^4*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (192*eq^2*gs^4*omega^3*Pi*Q^6*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s^4*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s^4*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^5*Pi*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (176*eq^2*gs^4*omega^4*Pi*Q^2*s^5*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^5*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (336*eq^2*gs^4*omega^3*Pi*Q^4*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (352*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^5*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^6*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^5*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (24*eq^2*gs^4*omega^4*Pi*s^6*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (664*eq^2*gs^4*omega^3*Pi*Q^2*s^6*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (176*eq^2*gs^4*omega^2*Pi*Q^4*s^6*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^6*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^3*Pi*s^7*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (544*eq^2*gs^4*omega^2*Pi*Q^2*s^7*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^4*s^7*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^2*Pi*s^8*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (144*eq^2*gs^4*omega*Pi*Q^2*s^8*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (48*eq^2*gs^4*Pi*Q^4*s^8*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (16*eq^2*gs^4*omega^8*Pi*Q^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^8*Pi*Q^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (4*eq^2*gs^4*omega^6*Pi*Q^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (4*eq^2*gs^4*omega^7*Pi*Q^2*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (4*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^2*s*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (272*eq^2*gs^4*omega^6*Pi*Q^4*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^4*s*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (176*eq^2*gs^4*omega^5*Pi*Q^6*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (144*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^6*s*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^8*s*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (148*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (12*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (832*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (296*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (756*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (232*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (384*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (20*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (472*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (432*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (1120*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (16*eq^2*gs^4*omega^5*Pi*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (860*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (20*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^4*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (680*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (448*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^4*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (744*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (608*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^4*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^4*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*EulerGamma*gs^4*Pi*Q^10*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (48*eq^2*gs^4*omega^4*Pi*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (1208*eq^2*gs^4*omega^3*Pi*Q^2*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (688*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^5*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (160*eq^2*gs^4*omega*Pi*Q^6*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (704*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^5*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*Pi*Q^8*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (128*eq^2*EulerGamma*gs^4*Pi*Q^8*s^5*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (48*eq^2*gs^4*omega^3*Pi*s^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (424*eq^2*gs^4*omega^2*Pi*Q^2*s^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega*Pi*Q^4*s^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (32*eq^2*gs^4*Pi*Q^6*s^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (256*eq^2*EulerGamma*gs^4*Pi*Q^6*s^6*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^2*Pi*s^7*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (192*eq^2*gs^4*omega*Pi*Q^2*s^7*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (160*eq^2*gs^4*Pi*Q^4*s^7*s23^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (112*eq^2*gs^4*Pi*Q^2*s^8*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (32*eq^2*gs^4*omega^7*Pi*Q^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (116*eq^2*gs^4*omega^6*Pi*Q^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (60*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^4*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (56*eq^2*gs^4*omega^5*Pi*Q^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^6*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (32*eq^2*gs^4*omega^4*Pi*Q^8*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^8*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (56*eq^2*gs^4*omega^6*Pi*Q^2*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (96*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (568*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8*s*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10*s*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (168*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (1156*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (100*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (1584*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (448*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (1168*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (256*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (512*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^5*Pi*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (456*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^3*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (2176*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (160*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^3*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (1072*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (768*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^3*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (1184*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (384*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^3*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*EulerGamma*gs^4*Pi*Q^10*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (24*eq^2*gs^4*omega^4*Pi*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^3*Pi*Q^2*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (696*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (160*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^4*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (336*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (896*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^4*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (368*eq^2*gs^4*Pi*Q^8*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (320*eq^2*EulerGamma*gs^4*Pi*Q^8*s^4*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^3*Pi*s^5*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (880*eq^2*gs^4*omega^2*Pi*Q^2*s^5*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (960*eq^2*gs^4*omega*Pi*Q^4*s^5*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (384*eq^2*gs^4*Pi*Q^6*s^5*s23^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (384*eq^2*EulerGamma*gs^4*Pi*Q^6*s^5*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^2*Pi*s^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (816*eq^2*gs^4*omega*Pi*Q^2*s^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (592*eq^2*gs^4*Pi*Q^4*s^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (224*eq^2*gs^4*Pi*Q^2*s^7*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (28*eq^2*gs^4*omega^6*Pi*Q^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (20*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (216*eq^2*gs^4*omega^5*Pi*Q^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^4*Pi*Q^6*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (96*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^3*Pi*Q^8*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^10*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^5*Pi*Q^2*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (728*eq^2*gs^4*omega^4*Pi*Q^4*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (512*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (288*eq^2*gs^4*omega^2*Pi*Q^8*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (256*eq^2*gs^4*omega*Pi*Q^10*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (52*eq^2*gs^4*omega^4*Pi*Q^2*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (4*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (328*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (320*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (904*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (224*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (448*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*Pi*Q^10*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (128*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (456*eq^2*gs^4*omega^3*Pi*Q^2*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (1504*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^3*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (1952*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (320*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (224*eq^2*gs^4*Pi*Q^8*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (256*eq^2*EulerGamma*gs^4*Pi*Q^8*s^3*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (736*eq^2*gs^4*omega^2*Pi*Q^2*s^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (2240*eq^2*gs^4*omega*Pi*Q^4*s^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (848*eq^2*gs^4*Pi*Q^6*s^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (320*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (480*eq^2*gs^4*omega*Pi*Q^2*s^5*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (896*eq^2*gs^4*Pi*Q^4*s^5*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (112*eq^2*gs^4*Pi*Q^2*s^6*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^5*Pi*Q^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (192*eq^2*gs^4*omega^4*Pi*Q^4*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (160*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (80*eq^2*gs^4*omega^3*Pi*Q^6*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (144*eq^2*gs^4*omega^2*Pi*Q^8*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^10*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (640*eq^2*gs^4*omega^3*Pi*Q^4*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (832*eq^2*gs^4*omega^2*Pi*Q^6*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (544*eq^2*gs^4*omega*Pi*Q^8*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*Pi*Q^10*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (1240*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (32*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^2*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (976*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (640*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (368*eq^2*gs^4*Pi*Q^8*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (64*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (1216*eq^2*gs^4*omega*Pi*Q^4*s^3*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (416*eq^2*gs^4*Pi*Q^6*s^3*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (384*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (416*eq^2*gs^4*Pi*Q^4*s^4*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (64*eq^2*gs^4*omega^3*Pi*Q^4*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (144*eq^2*gs^4*omega^2*Pi*Q^6*s23^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (320*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (512*eq^2*gs^4*omega*Pi*Q^8*s23^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^10*s23^6)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (64*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (96*eq^2*gs^4*omega*Pi*Q^6*s*s23^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*Pi*Q^8*s*s23^6)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) - (112*eq^2*gs^4*Pi*Q^6*s^2*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*s23^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^6*s23^7)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s23^7)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*Pi*Q^8*s23^7)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2) + (128*eq^2*gs^4*Pi*Q^6*s*s23^7)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*EulerGamma*gs^4*Pi*Q^6*s*s23^7)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*omega*Pi*Q^8*s^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (4*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^4*s^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (20*eq^2*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (16*eq^2*gs^4*Pi*Q^8*s^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^8*s^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (4*eq^2*gs^4*Pi*Q^6*s^4)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*gs^4*omega^4*Pi*Q^2*s*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (20*eq^2*gs^4*omega^3*Pi*Q^4*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (28*eq^2*gs^4*omega^2*Pi*Q^6*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (20*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (28*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - (8*eq^2*gs^4*Pi*Q^10*s*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (12*eq^2*EulerGamma*gs^4*Pi*Q^10*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (40*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (16*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (80*eq^2*gs^4*omega*Pi*Q^6*s^2*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (48*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - (52*eq^2*gs^4*Pi*Q^8*s^2*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (32*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (28*eq^2*gs^4*omega*Pi*Q^4*s^3*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + (28*eq^2*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (28*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^4*s^4*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*gs^4*omega^3*Pi*Q^4*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s23^2)/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (20*eq^2*gs^4*omega^2*Pi*Q^6*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (16*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (32*eq^2*gs^4*omega*Pi*Q^8*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s23^2)/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + (16*eq^2*gs^4*Pi*Q^10*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^10*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (32*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (60*eq^2*gs^4*omega*Pi*Q^6*s*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (60*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + (52*eq^2*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (32*eq^2*EulerGamma*gs^4*Pi*Q^8*s*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (4*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (36*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (52*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^2*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (32*eq^2*gs^4*Pi*Q^6*s^2*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (44*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (8*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^3*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (16*eq^2*gs^4*Pi*Q^4*s^3*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (24*eq^2*EulerGamma*gs^4*Pi*Q^4*s^3*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^4*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (4*eq^2*gs^4*omega^3*Pi*Q^2*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s23^3)/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (28*eq^2*gs^4*omega^2*Pi*Q^4*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (16*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (60*eq^2*gs^4*omega*Pi*Q^6*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s23^3)/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - (40*eq^2*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^8*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (12*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (12*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (40*eq^2*gs^4*omega*Pi*Q^4*s*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (32*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + (24*eq^2*gs^4*Pi*Q^6*s*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (20*eq^2*EulerGamma*gs^4*Pi*Q^6*s*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^2*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*gs^4*Pi*Q^4*s^2*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^4*s^2*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^3*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*gs^4*omega*Pi*Q^4*s23^4)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + (8*eq^2*gs^4*Pi*Q^6*s23^4)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - (4*eq^2*gs^4*Pi*Q^4*s*s23^4)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (4*eq^2*gs^4*omega^3*Pi*Q^6*s)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (12*eq^2*gs^4*omega^2*Pi*Q^6*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (12*eq^2*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*EulerGamma*gs^4*Pi*Q^8*s^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - (4*eq^2*gs^4*Pi*Q^6*s^4)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (4*eq^2*gs^4*omega^2*Pi*Q^8*s23)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (16*eq^2*gs^4*omega^2*Pi*Q^6*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (40*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^10*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (32*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + (4*eq^2*gs^4*Pi*Q^8*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (40*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (16*eq^2*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^3*s23)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - (16*eq^2*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (32*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*gs^4*Pi*Q^4*s^4*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*EulerGamma*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (16*eq^2*gs^4*omega*Pi*Q^8*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (16*eq^2*EulerGamma*gs^4*Pi*Q^10*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^6*s*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (16*eq^2*gs^4*Pi*Q^8*s*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (48*eq^2*EulerGamma*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (16*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*gs^4*Pi*Q^6*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (52*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (4*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (16*eq^2*gs^4*Pi*Q^4*s^3*s23^2)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (24*eq^2*EulerGamma*gs^4*Pi*Q^4*s^3*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + (16*eq^2*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + (16*eq^2*gs^4*Pi*Q^6*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (4*eq^2*gs^4*Pi*Q^4*s^2*s23^3)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*omega*Pi*Q^2*s^2)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^2*s^3)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*omega^6*Pi*Q^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (56*eq^2*gs^4*omega^5*Pi*Q^4)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (28*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (56*eq^2*gs^4*omega^4*Pi*Q^6)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega^3*Pi*Q^8)/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (60*eq^2*gs^4*omega^5*Pi*Q^2*s)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (204*eq^2*gs^4*omega^4*Pi*Q^4*s)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (88*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (200*eq^2*gs^4*omega^3*Pi*Q^6*s)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (84*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (56*eq^2*gs^4*omega^2*Pi*Q^8*s)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (80*eq^2*gs^4*omega^4*Pi*Q^2*s^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (40*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^2)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (260*eq^2*gs^4*omega^3*Pi*Q^4*s^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (112*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^2)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (244*eq^2*gs^4*omega^2*Pi*Q^6*s^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (64*eq^2*gs^4*omega*Pi*Q^8*s^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (44*eq^2*gs^4*omega^3*Pi*Q^2*s^3)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s^3)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (132*eq^2*gs^4*omega^2*Pi*Q^4*s^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (72*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^3)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (112*eq^2*gs^4*omega*Pi*Q^6*s^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (44*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (24*eq^2*gs^4*Pi*Q^8*s^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s^4)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (20*eq^2*gs^4*omega*Pi*Q^4*s^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^4)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (12*eq^2*gs^4*Pi*Q^6*s^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^5*Pi*Q^2*s)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega^4*Pi*Q^4*s)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (20*eq^2*gs^4*omega^3*Pi*Q^6*s)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       (omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^8*s)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega^4*Pi*Q^2*s^2)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (44*eq^2*gs^4*omega^3*Pi*Q^4*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^2)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (68*eq^2*gs^4*omega^2*Pi*Q^6*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (32*eq^2*gs^4*omega*Pi*Q^8*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (4*eq^2*gs^4*omega^3*Pi*Q^2*s^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^4*s^3)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (36*eq^2*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (24*eq^2*gs^4*Pi*Q^8*s^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^8*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (20*eq^2*gs^4*omega*Pi*Q^4*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^4)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (12*eq^2*gs^4*Pi*Q^6*s^4)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (16*eq^2*gs^4*omega*Pi*Q^4*s23)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*Pi*Q^4*s*s23)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (52*eq^2*gs^4*omega^5*Pi*Q^2*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s23)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (160*eq^2*gs^4*omega^4*Pi*Q^4*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (84*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s23)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (124*eq^2*gs^4*omega^3*Pi*Q^6*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (68*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s23)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (32*eq^2*gs^4*omega^2*Pi*Q^8*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s23)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^10*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (172*eq^2*gs^4*omega^4*Pi*Q^2*s*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (500*eq^2*gs^4*omega^3*Pi*Q^4*s*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (228*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (352*eq^2*gs^4*omega^2*Pi*Q^6*s*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (160*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (60*eq^2*gs^4*omega*Pi*Q^8*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^10*s*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (192*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (96*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (508*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (220*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (308*eq^2*gs^4*omega*Pi*Q^6*s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (116*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (28*eq^2*gs^4*Pi*Q^8*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (52*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (184*eq^2*gs^4*omega*Pi*Q^4*s^3*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (92*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (80*eq^2*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (16*eq^2*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^4*s^4*s23)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^4*Pi*Q^4*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (16*eq^2*gs^4*omega^3*Pi*Q^6*s23)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (20*eq^2*gs^4*omega^2*Pi*Q^8*s23)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^10*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega^3*Pi*Q^4*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega^2*Pi*Q^6*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (28*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (20*eq^2*gs^4*omega*Pi*Q^8*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (16*eq^2*gs^4*Pi*Q^10*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*EulerGamma*gs^4*Pi*Q^10*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (72*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (20*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (24*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (20*eq^2*gs^4*Pi*Q^8*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (40*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (48*eq^2*gs^4*omega*Pi*Q^4*s^3*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (36*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (52*eq^2*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (44*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^4*s^4*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^2*s23^2)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s23^2)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*Pi*Q^4*s23^2)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^2*s*s23^2)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (56*eq^2*gs^4*omega^4*Pi*Q^2*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (156*eq^2*gs^4*omega^3*Pi*Q^4*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (80*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (100*eq^2*gs^4*omega^2*Pi*Q^6*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (36*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (48*eq^2*gs^4*omega*Pi*Q^8*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*Pi*Q^10*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (160*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (80*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (396*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (184*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (156*eq^2*gs^4*omega*Pi*Q^6*s*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (72*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (8*eq^2*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (140*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (68*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (304*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (128*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (88*eq^2*gs^4*Pi*Q^6*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (36*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*s23^2)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (40*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (56*eq^2*gs^4*Pi*Q^4*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*EulerGamma*gs^4*Pi*Q^4*s^3*s23^2)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^4*s23^2)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^3*Pi*Q^4*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (16*eq^2*gs^4*omega^2*Pi*Q^6*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s23^2)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*Pi*Q^10*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*EulerGamma*gs^4*Pi*Q^10*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*omega*Pi*Q^6*s*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (36*eq^2*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*EulerGamma*gs^4*Pi*Q^8*s*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (20*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (32*eq^2*gs^4*Pi*Q^6*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (52*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (32*eq^2*gs^4*Pi*Q^4*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*EulerGamma*gs^4*Pi*Q^4*s^3*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (8*eq^2*gs^4*Pi*Q^2*s23^3)/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^2*s23^3)/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (20*eq^2*gs^4*omega^3*Pi*Q^2*s23^3)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (60*eq^2*gs^4*omega^2*Pi*Q^4*s23^3)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (48*eq^2*gs^4*omega*Pi*Q^6*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (32*eq^2*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (48*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (104*eq^2*gs^4*omega*Pi*Q^4*s*s23^3)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (48*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3)/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (60*eq^2*gs^4*Pi*Q^4*s^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*EulerGamma*gs^4*Pi*Q^4*s^2*s23^3)/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (4*eq^2*gs^4*omega^2*Pi*Q^4*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^6*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^8*s23^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*omega*Pi*Q^4*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (24*eq^2*gs^4*Pi*Q^6*s*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (20*eq^2*EulerGamma*gs^4*Pi*Q^6*s*s23^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (12*eq^2*gs^4*Pi*Q^4*s^2*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^4*s^2*s23^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^3*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^4*s23^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + (16*eq^2*gs^4*Pi*Q^6*s23^4)/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (8*eq^2*gs^4*Pi*Q^6*s23^4)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (4*eq^2*gs^4*Pi*Q^4*s*s23^4)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (12*eq^2*gs^4*omega^8*Pi*Q^2*s^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^8*Pi*Q^2*s^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (8*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^4*s^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^6*s^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (36*eq^2*gs^4*omega^7*Pi*Q^2*s^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (28*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^2*s^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^6*Pi*Q^4*s^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (8*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^4*s^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^6*s^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (48*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2*s^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (24*eq^2*gs^4*omega^5*Pi*Q^4*s^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (8*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (124*eq^2*gs^4*omega^5*Pi*Q^2*s^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (44*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^4*s^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (8*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (188*eq^2*gs^4*omega^4*Pi*Q^2*s^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (16*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (112*eq^2*gs^4*omega^3*Pi*Q^2*s^7)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^2*Pi*Q^2*s^8)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (32*eq^2*gs^4*omega^8*Pi*Q^2*s*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^8*Pi*Q^2*s*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^7*Pi*Q^4*s*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^4*s*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^6*s*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (80*eq^2*gs^4*omega^7*Pi*Q^2*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^2*s^2*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (172*eq^2*gs^4*omega^6*Pi*Q^4*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (76*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^4*s^2*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^5*Pi*Q^6*s^2*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (96*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^6*s^2*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^8*s^2*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*gs^4*omega^6*Pi*Q^2*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (56*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2*s^3*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (440*eq^2*gs^4*omega^5*Pi*Q^4*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (200*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s^3*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*gs^4*omega^4*Pi*Q^6*s^3*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (80*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s^3*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8*s^3*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (176*eq^2*gs^4*omega^5*Pi*Q^2*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (56*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s^4*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (532*eq^2*gs^4*omega^4*Pi*Q^4*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (364*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s^4*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (192*eq^2*gs^4*omega^3*Pi*Q^6*s^4*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s^4*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s^4*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^5*Pi*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (176*eq^2*gs^4*omega^4*Pi*Q^2*s^5*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^5*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (336*eq^2*gs^4*omega^3*Pi*Q^4*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (352*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^5*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^6*s^5*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^5*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (24*eq^2*gs^4*omega^4*Pi*s^6*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (664*eq^2*gs^4*omega^3*Pi*Q^2*s^6*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (176*eq^2*gs^4*omega^2*Pi*Q^4*s^6*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^6*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^3*Pi*s^7*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (544*eq^2*gs^4*omega^2*Pi*Q^2*s^7*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^4*s^7*s23)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^2*Pi*s^8*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (144*eq^2*gs^4*omega*Pi*Q^2*s^8*s23)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (48*eq^2*gs^4*Pi*Q^4*s^8*s23)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (16*eq^2*gs^4*omega^8*Pi*Q^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^8*Pi*Q^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (4*eq^2*gs^4*omega^6*Pi*Q^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (4*eq^2*gs^4*omega^7*Pi*Q^2*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (4*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^2*s*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (272*eq^2*gs^4*omega^6*Pi*Q^4*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^4*s*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (176*eq^2*gs^4*omega^5*Pi*Q^6*s*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (144*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^6*s*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^8*s*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (148*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (12*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (832*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (296*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (756*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (232*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (384*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10*s^2*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (20*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (472*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (432*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (1120*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s^3*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (16*eq^2*gs^4*omega^5*Pi*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (860*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (20*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^4*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (680*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (448*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^4*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (744*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (608*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^4*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^4*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*EulerGamma*gs^4*Pi*Q^10*s^4*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (48*eq^2*gs^4*omega^4*Pi*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (1208*eq^2*gs^4*omega^3*Pi*Q^2*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (688*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^5*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (160*eq^2*gs^4*omega*Pi*Q^6*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (704*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^5*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*Pi*Q^8*s^5*s23^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (128*eq^2*EulerGamma*gs^4*Pi*Q^8*s^5*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (48*eq^2*gs^4*omega^3*Pi*s^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (424*eq^2*gs^4*omega^2*Pi*Q^2*s^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega*Pi*Q^4*s^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^6*s^6*s23^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (256*eq^2*EulerGamma*gs^4*Pi*Q^6*s^6*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^2*Pi*s^7*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (192*eq^2*gs^4*omega*Pi*Q^2*s^7*s23^2)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (160*eq^2*gs^4*Pi*Q^4*s^7*s23^2)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (112*eq^2*gs^4*Pi*Q^2*s^8*s23^2)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (32*eq^2*gs^4*omega^7*Pi*Q^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^7*Pi*Q^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (116*eq^2*gs^4*omega^6*Pi*Q^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (60*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^4*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (56*eq^2*gs^4*omega^5*Pi*Q^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^6*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (32*eq^2*gs^4*omega^4*Pi*Q^8*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^8*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (56*eq^2*gs^4*omega^6*Pi*Q^2*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (96*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (568*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8*s*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10*s*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (168*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (1156*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (100*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (1584*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (448*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (1168*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (256*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (512*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s^2*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^5*Pi*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (456*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^3*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (2176*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (160*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^3*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (1072*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (768*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^3*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (1184*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (384*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^3*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*EulerGamma*gs^4*Pi*Q^10*s^3*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (24*eq^2*gs^4*omega^4*Pi*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^3*Pi*Q^2*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (696*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (160*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^4*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (336*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (896*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^4*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (368*eq^2*gs^4*Pi*Q^8*s^4*s23^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (320*eq^2*EulerGamma*gs^4*Pi*Q^8*s^4*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^3*Pi*s^5*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (880*eq^2*gs^4*omega^2*Pi*Q^2*s^5*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (960*eq^2*gs^4*omega*Pi*Q^4*s^5*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (384*eq^2*gs^4*Pi*Q^6*s^5*s23^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (384*eq^2*EulerGamma*gs^4*Pi*Q^6*s^5*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^2*Pi*s^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (816*eq^2*gs^4*omega*Pi*Q^2*s^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (592*eq^2*gs^4*Pi*Q^4*s^6*s23^3)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (224*eq^2*gs^4*Pi*Q^2*s^7*s23^3)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (28*eq^2*gs^4*omega^6*Pi*Q^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (20*eq^2*EulerGamma*gs^4*omega^6*Pi*Q^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (216*eq^2*gs^4*omega^5*Pi*Q^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^4*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^4*Pi*Q^6*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (96*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^6*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^3*Pi*Q^8*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^8*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^10*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^5*Pi*Q^2*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (728*eq^2*gs^4*omega^4*Pi*Q^4*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (512*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (288*eq^2*gs^4*omega^2*Pi*Q^8*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (256*eq^2*gs^4*omega*Pi*Q^10*s*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (52*eq^2*gs^4*omega^4*Pi*Q^2*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (4*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (328*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (320*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (904*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (224*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (448*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*Pi*Q^10*s^2*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (128*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (456*eq^2*gs^4*omega^3*Pi*Q^2*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (1504*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^3*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (1952*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (320*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (224*eq^2*gs^4*Pi*Q^8*s^3*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (256*eq^2*EulerGamma*gs^4*Pi*Q^8*s^3*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (736*eq^2*gs^4*omega^2*Pi*Q^2*s^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (2240*eq^2*gs^4*omega*Pi*Q^4*s^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (848*eq^2*gs^4*Pi*Q^6*s^4*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (320*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (480*eq^2*gs^4*omega*Pi*Q^2*s^5*s23^4)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (896*eq^2*gs^4*Pi*Q^4*s^5*s23^4)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (112*eq^2*gs^4*Pi*Q^2*s^6*s23^4)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^5*Pi*Q^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^5*Pi*Q^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (192*eq^2*gs^4*omega^4*Pi*Q^4*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (160*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^4*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (80*eq^2*gs^4*omega^3*Pi*Q^6*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^6*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (144*eq^2*gs^4*omega^2*Pi*Q^8*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^10*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*EulerGamma*gs^4*omega^4*Pi*Q^2*s*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (640*eq^2*gs^4*omega^3*Pi*Q^4*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (832*eq^2*gs^4*omega^2*Pi*Q^6*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (544*eq^2*gs^4*omega*Pi*Q^8*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*Pi*Q^10*s*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (1240*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (32*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^2*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (976*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (640*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (368*eq^2*gs^4*Pi*Q^8*s^2*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (64*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (1216*eq^2*gs^4*omega*Pi*Q^4*s^3*s23^5)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (416*eq^2*gs^4*Pi*Q^6*s^3*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (384*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23^5)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (416*eq^2*gs^4*Pi*Q^4*s^4*s23^5)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (64*eq^2*gs^4*omega^3*Pi*Q^4*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (144*eq^2*gs^4*omega^2*Pi*Q^6*s23^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (320*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (512*eq^2*gs^4*omega*Pi*Q^8*s23^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^10*s23^6)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (64*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (96*eq^2*gs^4*omega*Pi*Q^6*s*s23^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*Pi*Q^8*s*s23^6)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) + (112*eq^2*gs^4*Pi*Q^6*s^2*s23^6)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*s23^6)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^6*s23^7)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s23^7)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*Pi*Q^8*s23^7)/((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*
       ((omega - s)*s + Q^2*s23)*((omega - s)^2 + 2*(omega - s)*s + s^2 + 
         4*Q^2*s23)^2*SUNN^2) - (128*eq^2*gs^4*Pi*Q^6*s*s23^7)/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*EulerGamma*gs^4*Pi*Q^6*s*s23^7)/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^8*s^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^4*s^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (20*eq^2*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^8*s^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (8*eq^2*EulerGamma*gs^4*Pi*Q^8*s^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (4*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^4*Pi*Q^2*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (20*eq^2*gs^4*omega^3*Pi*Q^4*s*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*s*s23)/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^2*Pi*Q^6*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (20*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s*
       s23)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (28*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^10*s*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (12*eq^2*EulerGamma*gs^4*Pi*Q^10*s*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (40*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (80*eq^2*gs^4*omega*Pi*Q^6*s^2*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (48*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*
       s23)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (52*eq^2*gs^4*Pi*Q^8*s^2*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (32*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (28*eq^2*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (28*eq^2*gs^4*Pi*Q^6*s^3*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (28*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (8*eq^2*EulerGamma*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^4*
       s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (20*eq^2*gs^4*omega^2*Pi*Q^6*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega*Pi*Q^8*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^10*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (8*eq^2*EulerGamma*gs^4*Pi*Q^10*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*s*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (32*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s*
       s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (60*eq^2*gs^4*omega*Pi*Q^6*s*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (60*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (52*eq^2*gs^4*Pi*Q^8*s*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (32*eq^2*EulerGamma*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (12*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*
       s^2*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (36*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (52*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^2*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^6*s^2*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (44*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^3*
       s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (16*eq^2*gs^4*Pi*Q^4*s^3*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (24*eq^2*EulerGamma*gs^4*Pi*Q^4*s^3*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*EulerGamma*gs^4*omega^3*Pi*Q^2*
       s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (28*eq^2*gs^4*omega^2*Pi*Q^4*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^4*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (60*eq^2*gs^4*omega*Pi*Q^6*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (20*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (40*eq^2*gs^4*Pi*Q^8*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (8*eq^2*EulerGamma*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (12*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^2*s*
       s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (40*eq^2*gs^4*omega*Pi*Q^4*s*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (32*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (24*eq^2*gs^4*Pi*Q^6*s*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (20*eq^2*EulerGamma*gs^4*Pi*Q^6*s*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (12*eq^2*EulerGamma*gs^4*omega*Pi*Q^2*s^2*
       s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (12*eq^2*gs^4*Pi*Q^4*s^2*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (16*eq^2*EulerGamma*gs^4*Pi*Q^4*s^2*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^3*s23^3)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega*Pi*Q^4*s23^4)/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (8*eq^2*gs^4*Pi*Q^6*s23^4)/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*gs^4*Pi*Q^4*s*s23^4)/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^10)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (4*eq^2*gs^4*omega^3*Pi*Q^6*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^8*s)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega^2*Pi*Q^6*s^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (4*eq^2*EulerGamma*gs^4*omega^2*Pi*Q^6*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (4*eq^2*EulerGamma*gs^4*Pi*Q^10*s^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega*Pi*Q^6*s^3)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*
       SUNN^2) - (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*EulerGamma*gs^4*Pi*Q^8*s^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (4*eq^2*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^6*s^4)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (4*eq^2*gs^4*omega^2*Pi*Q^8*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (16*eq^2*EulerGamma*gs^4*omega*Pi*Q^10*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (16*eq^2*gs^4*omega^2*Pi*Q^6*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega*Pi*Q^8*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (40*eq^2*EulerGamma*gs^4*omega*Pi*Q^8*s*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*EulerGamma*gs^4*Pi*Q^10*s*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (8*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (32*eq^2*EulerGamma*gs^4*omega*Pi*Q^6*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^8*s^2*s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*
       SUNN^2) + (40*eq^2*EulerGamma*gs^4*Pi*Q^8*s^2*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega*Pi*Q^4*s^3*s23)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*EulerGamma*gs^4*omega*Pi*Q^4*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^6*s^3*s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*
       SUNN^2) + (32*eq^2*EulerGamma*gs^4*Pi*Q^6*s^3*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*
       SUNN^2) + (8*eq^2*EulerGamma*gs^4*Pi*Q^4*s^4*s23)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega*Pi*Q^8*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (16*eq^2*EulerGamma*gs^4*Pi*Q^10*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega*Pi*Q^6*s*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (16*eq^2*gs^4*Pi*Q^8*s*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (48*eq^2*EulerGamma*gs^4*Pi*Q^8*s*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (16*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^6*s^2*s23^2)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*
       SUNN^2) + (52*eq^2*EulerGamma*gs^4*Pi*Q^6*s^2*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (16*eq^2*gs^4*Pi*Q^4*s^3*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (24*eq^2*EulerGamma*gs^4*Pi*Q^4*s^3*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (4*eq^2*EulerGamma*gs^4*Pi*Q^2*s^4*s23^2)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (16*eq^2*gs^4*Pi*Q^8*s23^3)/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^6*s*s23^3)/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*
       SUNN^2) - (4*eq^2*gs^4*Pi*Q^4*s^2*s23^3)/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*gs^4*omega^6*Pi*Q^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (28*eq^2*gs^4*omega^5*Pi*Q^4*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (32*eq^2*gs^4*omega^4*Pi*Q^6*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*omega^3*Pi*Q^8*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (28*eq^2*gs^4*omega^5*Pi*Q^2*s*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (88*eq^2*gs^4*omega^4*Pi*Q^4*s*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (84*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (40*eq^2*gs^4*omega^4*Pi*Q^2*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (112*eq^2*gs^4*omega^3*Pi*Q^4*s^2*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (84*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (28*eq^2*gs^4*omega^3*Pi*Q^2*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (72*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (44*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*Pi*Q^6*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega*Pi*Q^10*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega^3*Pi*Q^4*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*Pi*Q^8*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*Pi*Q^6*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (84*eq^2*gs^4*omega^4*Pi*Q^4*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (68*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*omega^2*Pi*Q^8*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (84*eq^2*gs^4*omega^4*Pi*Q^2*s*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (228*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (160*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (32*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (96*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (220*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (116*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (52*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (92*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega^2*Pi*Q^8*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*omega*Pi*Q^10*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (12*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (28*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (20*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (36*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (44*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^2*s23^2*Log[Pi])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*Pi*Q^2*s*s23^2*Log[Pi])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) - 
     (32*eq^2*gs^4*omega^4*Pi*Q^2*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (80*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (36*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (80*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (184*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (72*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (68*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (128*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (36*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (24*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*Pi*Q^2*s23^3*Log[Pi])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (48*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*
       Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega^8*Pi*Q^2*s^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^6*Pi*Q^6*s^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (28*eq^2*gs^4*omega^7*Pi*Q^2*s^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^6*Pi*Q^4*s^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^5*Pi*Q^6*s^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (48*eq^2*gs^4*omega^6*Pi*Q^2*s^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^5*Pi*Q^4*s^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^6*s^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (44*eq^2*gs^4*omega^5*Pi*Q^2*s^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^4*s^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (16*eq^2*gs^4*omega^4*Pi*Q^2*s^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^8*Pi*Q^2*s*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^7*Pi*Q^4*s*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^6*Pi*Q^6*s*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*gs^4*omega^7*Pi*Q^2*s^2*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (76*eq^2*gs^4*omega^6*Pi*Q^4*s^2*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (96*eq^2*gs^4*omega^5*Pi*Q^6*s^2*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^4*Pi*Q^8*s^2*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (56*eq^2*gs^4*omega^6*Pi*Q^2*s^3*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (200*eq^2*gs^4*omega^5*Pi*Q^4*s^3*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (80*eq^2*gs^4*omega^4*Pi*Q^6*s^3*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s^3*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (56*eq^2*gs^4*omega^5*Pi*Q^2*s^4*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (364*eq^2*gs^4*omega^4*Pi*Q^4*s^4*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^3*Pi*Q^6*s^4*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^8*s^4*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^4*Pi*Q^2*s^5*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (352*eq^2*gs^4*omega^3*Pi*Q^4*s^5*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^6*s^5*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^2*Pi*Q^4*s^6*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^8*Pi*Q^2*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^6*Pi*Q^6*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (4*eq^2*gs^4*omega^7*Pi*Q^2*s*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega^6*Pi*Q^4*s*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (144*eq^2*gs^4*omega^5*Pi*Q^6*s*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega^4*Pi*Q^8*s*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (12*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (296*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (232*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (384*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^2*Pi*Q^10*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (20*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (432*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega*Pi*Q^10*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (20*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (448*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (608*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^8*s^4*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^10*s^4*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (704*eq^2*gs^4*omega*Pi*Q^6*s^5*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^8*s^5*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (256*eq^2*gs^4*Pi*Q^6*s^6*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^7*Pi*Q^2*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (60*eq^2*gs^4*omega^6*Pi*Q^4*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^5*Pi*Q^6*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^4*Pi*Q^8*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^2*Pi*Q^10*s*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (100*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (448*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (256*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (512*eq^2*gs^4*omega*Pi*Q^10*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (160*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (768*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*Pi*Q^10*s^3*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (160*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (896*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (320*eq^2*gs^4*Pi*Q^8*s^4*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*Pi*Q^6*s^5*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (20*eq^2*gs^4*omega^6*Pi*Q^2*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega^5*Pi*Q^4*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (96*eq^2*gs^4*omega^4*Pi*Q^6*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^2*Pi*Q^10*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^5*Pi*Q^2*s*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega*Pi*Q^10*s*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (4*eq^2*gs^4*omega^4*Pi*Q^2*s^2*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (320*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (224*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^10*s^2*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (320*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (256*eq^2*gs^4*Pi*Q^8*s^3*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (320*eq^2*gs^4*Pi*Q^6*s^4*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^5*Pi*Q^2*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (160*eq^2*gs^4*omega^4*Pi*Q^4*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^3*Pi*Q^6*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^8*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*gs^4*omega^3*Pi*Q^4*s*s23^5*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^8*s*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23^5*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (640*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^5*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*Pi*Q^8*s^2*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*Pi*Q^6*s^3*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^3*Pi*Q^4*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (320*eq^2*gs^4*omega^2*Pi*Q^6*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*omega*Pi*Q^6*s*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*Pi*Q^6*s^2*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^6*s23^7*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^6*s*s23^7*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (8*eq^2*gs^4*Pi*Q^8*s^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*Pi*Q^6*s^4*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (20*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (28*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*Log[Pi])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (48*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (32*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (28*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (4*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (20*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (60*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (52*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (44*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (16*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (20*eq^2*gs^4*omega*Pi*Q^6*s23^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (32*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (4*eq^2*gs^4*Pi*Q^10*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*gs^4*Pi*Q^8*s^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (4*eq^2*gs^4*Pi*Q^6*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (16*eq^2*gs^4*omega*Pi*Q^10*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (40*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (16*eq^2*gs^4*Pi*Q^10*s*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (32*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (16*eq^2*gs^4*Pi*Q^10*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (48*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*omega^6*Pi*Q^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega^4*Pi*Q^6*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega^3*Pi*Q^8*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (88*eq^2*gs^4*omega^4*Pi*Q^4*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (84*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (40*eq^2*gs^4*omega^4*Pi*Q^2*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (112*eq^2*gs^4*omega^3*Pi*Q^4*s^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^3*Pi*Q^2*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (72*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (44*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*Pi*Q^6*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega*Pi*Q^10*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega^3*Pi*Q^4*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (4*eq^2*gs^4*Pi*Q^10*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (16*eq^2*gs^4*Pi*Q^8*s^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (12*eq^2*gs^4*Pi*Q^6*s^4*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (84*eq^2*gs^4*omega^4*Pi*Q^4*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (68*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^8*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*gs^4*omega^4*Pi*Q^2*s*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (228*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (160*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (96*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (220*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (116*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (52*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (92*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^8*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega*Pi*Q^10*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (20*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (36*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (44*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega*Pi*Q^2*s23^2*Log[Pi])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^2*s*s23^2*Log[Pi])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega^4*Pi*Q^2*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (80*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (36*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (80*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (184*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (72*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (68*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (36*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (8*eq^2*gs^4*Pi*Q^2*s23^3*Log[Pi])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (48*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*Log[Pi])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega^8*Pi*Q^2*s^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^6*Pi*Q^6*s^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (28*eq^2*gs^4*omega^7*Pi*Q^2*s^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^6*Pi*Q^4*s^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^5*Pi*Q^6*s^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (48*eq^2*gs^4*omega^6*Pi*Q^2*s^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^5*Pi*Q^4*s^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^6*s^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (44*eq^2*gs^4*omega^5*Pi*Q^2*s^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^4*s^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (16*eq^2*gs^4*omega^4*Pi*Q^2*s^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^8*Pi*Q^2*s*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^7*Pi*Q^4*s*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^6*Pi*Q^6*s*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*gs^4*omega^7*Pi*Q^2*s^2*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (76*eq^2*gs^4*omega^6*Pi*Q^4*s^2*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (96*eq^2*gs^4*omega^5*Pi*Q^6*s^2*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^4*Pi*Q^8*s^2*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (56*eq^2*gs^4*omega^6*Pi*Q^2*s^3*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (200*eq^2*gs^4*omega^5*Pi*Q^4*s^3*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (80*eq^2*gs^4*omega^4*Pi*Q^6*s^3*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s^3*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (56*eq^2*gs^4*omega^5*Pi*Q^2*s^4*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (364*eq^2*gs^4*omega^4*Pi*Q^4*s^4*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^3*Pi*Q^6*s^4*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^8*s^4*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^4*Pi*Q^2*s^5*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (352*eq^2*gs^4*omega^3*Pi*Q^4*s^5*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^6*s^5*s23*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^2*Pi*Q^4*s^6*s23*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^8*Pi*Q^2*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^6*Pi*Q^6*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (4*eq^2*gs^4*omega^7*Pi*Q^2*s*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega^6*Pi*Q^4*s*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (144*eq^2*gs^4*omega^5*Pi*Q^6*s*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega^4*Pi*Q^8*s*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (12*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (296*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (232*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (384*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^2*Pi*Q^10*s^2*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (20*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (432*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega*Pi*Q^10*s^3*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (20*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (448*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (608*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^8*s^4*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^10*s^4*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (704*eq^2*gs^4*omega*Pi*Q^6*s^5*s23^2*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^8*s^5*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (256*eq^2*gs^4*Pi*Q^6*s^6*s23^2*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^7*Pi*Q^2*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (60*eq^2*gs^4*omega^6*Pi*Q^4*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^5*Pi*Q^6*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^4*Pi*Q^8*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^2*Pi*Q^10*s*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (100*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (448*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (256*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (512*eq^2*gs^4*omega*Pi*Q^10*s^2*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (160*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (768*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*Pi*Q^10*s^3*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (160*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (896*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^3*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (320*eq^2*gs^4*Pi*Q^8*s^4*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*Pi*Q^6*s^5*s23^3*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (20*eq^2*gs^4*omega^6*Pi*Q^2*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega^5*Pi*Q^4*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (96*eq^2*gs^4*omega^4*Pi*Q^6*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^2*Pi*Q^10*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^5*Pi*Q^2*s*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega*Pi*Q^10*s*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (4*eq^2*gs^4*omega^4*Pi*Q^2*s^2*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (320*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (224*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^10*s^2*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (320*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^4*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (256*eq^2*gs^4*Pi*Q^8*s^3*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (320*eq^2*gs^4*Pi*Q^6*s^4*s23^4*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^5*Pi*Q^2*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (160*eq^2*gs^4*omega^4*Pi*Q^4*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^3*Pi*Q^6*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^8*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*gs^4*omega^3*Pi*Q^4*s*s23^5*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^8*s*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23^5*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (640*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^5*Log[Pi])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*Pi*Q^8*s^2*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*Pi*Q^6*s^3*s23^5*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^3*Pi*Q^4*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (320*eq^2*gs^4*omega^2*Pi*Q^6*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*omega*Pi*Q^6*s*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*Pi*Q^6*s^2*s23^6*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^6*s23^7*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^6*s*s23^7*Log[Pi])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (4*eq^2*gs^4*Pi*Q^6*s^4*Log[Pi])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (20*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (28*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (16*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (48*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (20*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (28*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (20*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (4*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (32*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (60*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (52*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (44*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (20*eq^2*gs^4*omega*Pi*Q^6*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (12*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*
       Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (32*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*
       Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[Pi])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[Pi])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (16*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (4*eq^2*gs^4*Pi*Q^6*s^4*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega*Pi*Q^10*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (40*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^10*s*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^10*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (48*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[Pi])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[Pi])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*gs^4*omega^9*Pi*Q^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (24*eq^2*gs^4*omega^8*Pi*Q^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (16*eq^2*gs^4*omega^7*Pi*Q^6*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (20*eq^2*gs^4*omega^8*Pi*Q^2*s*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (64*eq^2*gs^4*omega^7*Pi*Q^4*s*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (48*eq^2*gs^4*omega^6*Pi*Q^6*s*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (36*eq^2*gs^4*omega^7*Pi*Q^2*s^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (152*eq^2*gs^4*omega^6*Pi*Q^4*s^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (144*eq^2*gs^4*omega^5*Pi*Q^6*s^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (48*eq^2*gs^4*omega^6*Pi*Q^2*s^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (240*eq^2*gs^4*omega^5*Pi*Q^4*s^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (240*eq^2*gs^4*omega^4*Pi*Q^6*s^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (32*eq^2*gs^4*omega^5*Pi*Q^2*s^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (176*eq^2*gs^4*omega^4*Pi*Q^4*s^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (176*eq^2*gs^4*omega^3*Pi*Q^6*s^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (48*eq^2*gs^4*omega^3*Pi*Q^4*s^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (48*eq^2*gs^4*omega^2*Pi*Q^6*s^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (16*eq^2*gs^4*omega^8*Pi*Q^2*s23*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (44*eq^2*gs^4*omega^7*Pi*Q^4*s23*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (232*eq^2*gs^4*omega^6*Pi*Q^6*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (160*eq^2*gs^4*omega^5*Pi*Q^8*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (24*eq^2*gs^4*omega^7*Pi*Q^2*s*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (100*eq^2*gs^4*omega^6*Pi*Q^4*s*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (408*eq^2*gs^4*omega^5*Pi*Q^6*s*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (256*eq^2*gs^4*omega^4*Pi*Q^8*s*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (56*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (160*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (96*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (288*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (176*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (872*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (752*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (128*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (192*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (992*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1056*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (160*eq^2*gs^4*omega*Pi*Q^8*s^4*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (64*eq^2*gs^4*omega^3*Pi*Q^2*s^5*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (336*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (384*eq^2*gs^4*omega*Pi*Q^6*s^5*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (96*eq^2*gs^4*Pi*Q^8*s^5*s23*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (12*eq^2*gs^4*omega^7*Pi*Q^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (136*eq^2*gs^4*omega^6*Pi*Q^4*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (96*eq^2*gs^4*omega^5*Pi*Q^6*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (752*eq^2*gs^4*omega^4*Pi*Q^8*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (592*eq^2*gs^4*omega^3*Pi*Q^10*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (12*eq^2*gs^4*omega^6*Pi*Q^2*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (120*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (512*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1952*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1008*eq^2*gs^4*omega^2*Pi*Q^10*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (24*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (416*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (1776*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (2592*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (1152*eq^2*gs^4*omega*Pi*Q^10*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (136*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1008*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1600*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1216*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (704*eq^2*gs^4*Pi*Q^10*s^3*s23^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (176*eq^2*gs^4*omega^3*Pi*Q^2*s^4*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (928*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (704*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (128*eq^2*gs^4*Pi*Q^8*s^4*s23^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^2*s^5*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (320*eq^2*gs^4*omega*Pi*Q^4*s^5*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (256*eq^2*gs^4*Pi*Q^6*s^5*s23^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (120*eq^2*gs^4*omega^5*Pi*Q^4*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (288*eq^2*gs^4*omega^4*Pi*Q^6*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1136*eq^2*gs^4*omega^3*Pi*Q^8*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (192*eq^2*gs^4*omega^2*Pi*Q^10*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (544*eq^2*gs^4*omega*Pi*Q^12*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (72*eq^2*gs^4*omega^4*Pi*Q^4*s*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (1040*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (2160*eq^2*gs^4*omega^2*Pi*Q^8*s*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (192*eq^2*gs^4*omega*Pi*Q^10*s*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (416*eq^2*gs^4*Pi*Q^12*s*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (368*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1888*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1856*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (128*eq^2*gs^4*Pi*Q^10*s^2*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (448*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (1216*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (768*eq^2*gs^4*Pi*Q^8*s^3*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (160*eq^2*gs^4*omega*Pi*Q^4*s^4*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (128*eq^2*gs^4*Pi*Q^6*s^4*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (32*eq^2*gs^4*Pi*Q^4*s^5*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (384*eq^2*gs^4*omega^3*Pi*Q^6*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (640*eq^2*gs^4*omega^2*Pi*Q^8*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (512*eq^2*gs^4*omega*Pi*Q^10*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (256*eq^2*gs^4*Pi*Q^12*s23^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (736*eq^2*gs^4*omega^2*Pi*Q^6*s*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (1408*eq^2*gs^4*omega*Pi*Q^8*s*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (448*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (640*eq^2*gs^4*Pi*Q^8*s^2*s23^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (64*eq^2*gs^4*Pi*Q^6*s^3*s23^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (96*eq^2*gs^4*omega*Pi*Q^8*s23^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (256*eq^2*gs^4*Pi*Q^10*s23^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) - 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3) + 
     (8*eq^2*gs^4*omega^9*Pi*Q^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (24*eq^2*gs^4*omega^8*Pi*Q^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (16*eq^2*gs^4*omega^7*Pi*Q^6*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (20*eq^2*gs^4*omega^8*Pi*Q^2*s*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (64*eq^2*gs^4*omega^7*Pi*Q^4*s*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (48*eq^2*gs^4*omega^6*Pi*Q^6*s*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (36*eq^2*gs^4*omega^7*Pi*Q^2*s^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (152*eq^2*gs^4*omega^6*Pi*Q^4*s^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (144*eq^2*gs^4*omega^5*Pi*Q^6*s^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (48*eq^2*gs^4*omega^6*Pi*Q^2*s^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (240*eq^2*gs^4*omega^5*Pi*Q^4*s^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (240*eq^2*gs^4*omega^4*Pi*Q^6*s^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (32*eq^2*gs^4*omega^5*Pi*Q^2*s^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (176*eq^2*gs^4*omega^4*Pi*Q^4*s^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (176*eq^2*gs^4*omega^3*Pi*Q^6*s^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (48*eq^2*gs^4*omega^3*Pi*Q^4*s^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (48*eq^2*gs^4*omega^2*Pi*Q^6*s^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (16*eq^2*gs^4*omega^8*Pi*Q^2*s23*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (44*eq^2*gs^4*omega^7*Pi*Q^4*s23*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (232*eq^2*gs^4*omega^6*Pi*Q^6*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (160*eq^2*gs^4*omega^5*Pi*Q^8*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (24*eq^2*gs^4*omega^7*Pi*Q^2*s*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (100*eq^2*gs^4*omega^6*Pi*Q^4*s*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (408*eq^2*gs^4*omega^5*Pi*Q^6*s*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (256*eq^2*gs^4*omega^4*Pi*Q^8*s*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (56*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (160*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (96*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (288*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (176*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (872*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (752*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (128*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (192*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (992*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1056*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (160*eq^2*gs^4*omega*Pi*Q^8*s^4*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (64*eq^2*gs^4*omega^3*Pi*Q^2*s^5*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (336*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (384*eq^2*gs^4*omega*Pi*Q^6*s^5*s23*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (96*eq^2*gs^4*Pi*Q^8*s^5*s23*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (12*eq^2*gs^4*omega^7*Pi*Q^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (136*eq^2*gs^4*omega^6*Pi*Q^4*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (96*eq^2*gs^4*omega^5*Pi*Q^6*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (752*eq^2*gs^4*omega^4*Pi*Q^8*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (592*eq^2*gs^4*omega^3*Pi*Q^10*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (12*eq^2*gs^4*omega^6*Pi*Q^2*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (120*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (512*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1952*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1008*eq^2*gs^4*omega^2*Pi*Q^10*s*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (24*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (416*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (1776*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (2592*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (1152*eq^2*gs^4*omega*Pi*Q^10*s^2*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (136*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1008*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1600*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1216*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (704*eq^2*gs^4*Pi*Q^10*s^3*s23^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (176*eq^2*gs^4*omega^3*Pi*Q^2*s^4*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (928*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (704*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^8*s^4*s23^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^2*s^5*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (320*eq^2*gs^4*omega*Pi*Q^4*s^5*s23^2*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (256*eq^2*gs^4*Pi*Q^6*s^5*s23^2*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (120*eq^2*gs^4*omega^5*Pi*Q^4*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (288*eq^2*gs^4*omega^4*Pi*Q^6*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1136*eq^2*gs^4*omega^3*Pi*Q^8*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (192*eq^2*gs^4*omega^2*Pi*Q^10*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (544*eq^2*gs^4*omega*Pi*Q^12*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (72*eq^2*gs^4*omega^4*Pi*Q^4*s*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (1040*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (2160*eq^2*gs^4*omega^2*Pi*Q^8*s*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (192*eq^2*gs^4*omega*Pi*Q^10*s*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (416*eq^2*gs^4*Pi*Q^12*s*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (368*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1888*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1856*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (128*eq^2*gs^4*Pi*Q^10*s^2*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (448*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (1216*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (768*eq^2*gs^4*Pi*Q^8*s^3*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (160*eq^2*gs^4*omega*Pi*Q^4*s^4*s23^3*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^6*s^4*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^4*s^5*s23^3*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (384*eq^2*gs^4*omega^3*Pi*Q^6*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (640*eq^2*gs^4*omega^2*Pi*Q^8*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (512*eq^2*gs^4*omega*Pi*Q^10*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (256*eq^2*gs^4*Pi*Q^12*s23^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (736*eq^2*gs^4*omega^2*Pi*Q^6*s*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (1408*eq^2*gs^4*omega*Pi*Q^8*s*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (448*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^4*
       Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
         (omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (640*eq^2*gs^4*Pi*Q^8*s^2*s23^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (64*eq^2*gs^4*Pi*Q^6*s^3*s23^4*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (96*eq^2*gs^4*omega*Pi*Q^8*s23^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (256*eq^2*gs^4*Pi*Q^10*s23^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^5*Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
          s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]*
       Log[(1 - Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])/
         (1 + Sqrt[1 - (4*Q^2*(omega + Q^2 - s23))/(omega + 2*Q^2)^2])])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^3*SUNN^2) - 
     (8*eq^2*gs^4*omega^6*Pi*Q^2*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^4*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (32*eq^2*gs^4*omega^4*Pi*Q^6*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*omega^3*Pi*Q^8*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (88*eq^2*gs^4*omega^4*Pi*Q^4*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (84*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (32*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (40*eq^2*gs^4*omega^4*Pi*Q^2*s^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (112*eq^2*gs^4*omega^3*Pi*Q^4*s^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (84*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^10*s^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (28*eq^2*gs^4*omega^3*Pi*Q^2*s^3*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (72*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (44*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*gs^4*Pi*Q^6*s^4*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*omega*Pi*Q^10*s*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (12*eq^2*gs^4*omega^3*Pi*Q^4*s^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*Pi*Q^8*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*Pi*Q^6*s^4*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (84*eq^2*gs^4*omega^4*Pi*Q^4*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (68*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*gs^4*omega^2*Pi*Q^8*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (84*eq^2*gs^4*omega^4*Pi*Q^2*s*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (228*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (160*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (32*eq^2*gs^4*omega*Pi*Q^8*s*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (96*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (220*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (116*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (52*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (92*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (24*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^8*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega*Pi*Q^10*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (28*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (20*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (36*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[s23])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) - 
     (44*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*omega*Pi*Q^2*s23^2*Log[s23])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*Pi*Q^2*s*s23^2*Log[s23])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) - (32*eq^2*gs^4*omega^4*Pi*Q^2*s23^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (80*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (36*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (80*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (184*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (72*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (68*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (128*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (36*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (16*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[s23])/((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*
       (s - s23)*((omega - s)*s + Q^2*s23)) + 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (32*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*Pi*Q^2*s23^3*Log[s23])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (48*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*
       Log[s23])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) + (24*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)) + (8*eq^2*gs^4*omega^8*Pi*Q^2*s^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^6*Pi*Q^6*s^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (28*eq^2*gs^4*omega^7*Pi*Q^2*s^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^6*Pi*Q^4*s^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^5*Pi*Q^6*s^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (48*eq^2*gs^4*omega^6*Pi*Q^2*s^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^5*Pi*Q^4*s^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^6*s^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (44*eq^2*gs^4*omega^5*Pi*Q^2*s^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^4*s^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (16*eq^2*gs^4*omega^4*Pi*Q^2*s^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^8*Pi*Q^2*s*s23*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^7*Pi*Q^4*s*s23*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^6*Pi*Q^6*s*s23*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*gs^4*omega^7*Pi*Q^2*s^2*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (76*eq^2*gs^4*omega^6*Pi*Q^4*s^2*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (96*eq^2*gs^4*omega^5*Pi*Q^6*s^2*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^4*Pi*Q^8*s^2*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (56*eq^2*gs^4*omega^6*Pi*Q^2*s^3*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (200*eq^2*gs^4*omega^5*Pi*Q^4*s^3*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (80*eq^2*gs^4*omega^4*Pi*Q^6*s^3*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s^3*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (56*eq^2*gs^4*omega^5*Pi*Q^2*s^4*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (364*eq^2*gs^4*omega^4*Pi*Q^4*s^4*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^3*Pi*Q^6*s^4*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^8*s^4*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^4*Pi*Q^2*s^5*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (352*eq^2*gs^4*omega^3*Pi*Q^4*s^5*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^6*s^5*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^2*Pi*Q^4*s^6*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^8*Pi*Q^2*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^6*Pi*Q^6*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (4*eq^2*gs^4*omega^7*Pi*Q^2*s*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega^6*Pi*Q^4*s*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (144*eq^2*gs^4*omega^5*Pi*Q^6*s*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega^4*Pi*Q^8*s*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (12*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (296*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (232*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (384*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^2*Pi*Q^10*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (20*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (432*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega*Pi*Q^10*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (20*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (448*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (608*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^8*s^4*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^10*s^4*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (704*eq^2*gs^4*omega*Pi*Q^6*s^5*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^8*s^5*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (256*eq^2*gs^4*Pi*Q^6*s^6*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (16*eq^2*gs^4*omega^7*Pi*Q^2*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (60*eq^2*gs^4*omega^6*Pi*Q^4*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^5*Pi*Q^6*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^4*Pi*Q^8*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^2*Pi*Q^10*s*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (40*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (100*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (448*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (256*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (512*eq^2*gs^4*omega*Pi*Q^10*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (160*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (768*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*Pi*Q^10*s^3*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (160*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (896*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (320*eq^2*gs^4*Pi*Q^8*s^4*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*Pi*Q^6*s^5*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (20*eq^2*gs^4*omega^6*Pi*Q^2*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega^5*Pi*Q^4*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (96*eq^2*gs^4*omega^4*Pi*Q^6*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^2*Pi*Q^10*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (24*eq^2*gs^4*omega^5*Pi*Q^2*s*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega*Pi*Q^10*s*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (4*eq^2*gs^4*omega^4*Pi*Q^2*s^2*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (320*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (224*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^10*s^2*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (320*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (256*eq^2*gs^4*Pi*Q^8*s^3*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (320*eq^2*gs^4*Pi*Q^6*s^4*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (8*eq^2*gs^4*omega^5*Pi*Q^2*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (160*eq^2*gs^4*omega^4*Pi*Q^4*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (256*eq^2*gs^4*omega^3*Pi*Q^6*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^8*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (192*eq^2*gs^4*omega^3*Pi*Q^4*s*s23^5*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^8*s*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23^5*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (640*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^5*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*Pi*Q^8*s^2*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*Pi*Q^6*s^3*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (64*eq^2*gs^4*omega^3*Pi*Q^4*s23^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (320*eq^2*gs^4*omega^2*Pi*Q^6*s23^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^6*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (384*eq^2*gs^4*omega*Pi*Q^6*s*s23^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (64*eq^2*gs^4*Pi*Q^6*s^2*s23^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^6*s23^7*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) + 
     (128*eq^2*gs^4*Pi*Q^6*s*s23^7*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*Pi*Q^6*s^4*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (20*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (28*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (48*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[s23])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (32*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (20*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (28*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (16*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (20*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*Log[s23])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (60*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[s23])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (12*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (52*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (44*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (16*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (20*eq^2*gs^4*omega*Pi*Q^6*s23^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (32*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*Log[s23])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) - (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)) + (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (4*eq^2*gs^4*Pi*Q^10*s^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*gs^4*Pi*Q^8*s^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (4*eq^2*gs^4*Pi*Q^6*s^4*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (16*eq^2*gs^4*omega*Pi*Q^10*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (40*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (16*eq^2*gs^4*Pi*Q^10*s*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (8*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (32*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (16*eq^2*gs^4*Pi*Q^10*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (48*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) - (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)) + (8*eq^2*gs^4*omega^6*Pi*Q^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^4*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega^4*Pi*Q^6*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega^3*Pi*Q^8*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (88*eq^2*gs^4*omega^4*Pi*Q^4*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (84*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (40*eq^2*gs^4*omega^4*Pi*Q^2*s^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (112*eq^2*gs^4*omega^3*Pi*Q^4*s^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^3*Pi*Q^2*s^3*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (72*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (44*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*Pi*Q^6*s^4*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega*Pi*Q^10*s*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega^3*Pi*Q^4*s^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (4*eq^2*gs^4*Pi*Q^10*s^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (16*eq^2*gs^4*Pi*Q^8*s^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - (12*eq^2*gs^4*Pi*Q^6*s^4*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (84*eq^2*gs^4*omega^4*Pi*Q^4*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (68*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^8*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*gs^4*omega^4*Pi*Q^2*s*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (228*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (160*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (96*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (220*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (116*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (52*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (92*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^8*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega*Pi*Q^10*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (20*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[s23])/((omega + 2*Q^2)*
       (omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (36*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (44*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^2*s23^2*Log[s23])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^2*s*s23^2*Log[s23])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega^4*Pi*Q^2*s23^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (80*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (36*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (80*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (184*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (72*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (68*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (36*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^2*s23^3*Log[s23])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (48*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*Log[s23])/((omega + 2*Q^2)*
       (omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*(omega + Q^2 - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[s23])/((omega + 2*Q^2)*(omega - s)^2*
       (Q^2 + s)^2*(omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*
       ((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega^8*Pi*Q^2*s^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^6*Pi*Q^6*s^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (28*eq^2*gs^4*omega^7*Pi*Q^2*s^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^6*Pi*Q^4*s^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^5*Pi*Q^6*s^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (48*eq^2*gs^4*omega^6*Pi*Q^2*s^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^5*Pi*Q^4*s^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^6*s^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (44*eq^2*gs^4*omega^5*Pi*Q^2*s^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^4*s^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (16*eq^2*gs^4*omega^4*Pi*Q^2*s^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^8*Pi*Q^2*s*s23*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^7*Pi*Q^4*s*s23*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^6*Pi*Q^6*s*s23*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*gs^4*omega^7*Pi*Q^2*s^2*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (76*eq^2*gs^4*omega^6*Pi*Q^4*s^2*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (96*eq^2*gs^4*omega^5*Pi*Q^6*s^2*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^4*Pi*Q^8*s^2*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (56*eq^2*gs^4*omega^6*Pi*Q^2*s^3*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (200*eq^2*gs^4*omega^5*Pi*Q^4*s^3*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (80*eq^2*gs^4*omega^4*Pi*Q^6*s^3*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s^3*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (56*eq^2*gs^4*omega^5*Pi*Q^2*s^4*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (364*eq^2*gs^4*omega^4*Pi*Q^4*s^4*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^3*Pi*Q^6*s^4*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^8*s^4*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^4*Pi*Q^2*s^5*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (352*eq^2*gs^4*omega^3*Pi*Q^4*s^5*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^6*s^5*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^2*Pi*Q^4*s^6*s23*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^8*Pi*Q^2*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^7*Pi*Q^4*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^6*Pi*Q^6*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (4*eq^2*gs^4*omega^7*Pi*Q^2*s*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega^6*Pi*Q^4*s*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (144*eq^2*gs^4*omega^5*Pi*Q^6*s*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega^4*Pi*Q^8*s*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (12*eq^2*gs^4*omega^6*Pi*Q^2*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (296*eq^2*gs^4*omega^5*Pi*Q^4*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (232*eq^2*gs^4*omega^4*Pi*Q^6*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (384*eq^2*gs^4*omega^3*Pi*Q^8*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^2*Pi*Q^10*s^2*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (20*eq^2*gs^4*omega^5*Pi*Q^2*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (432*eq^2*gs^4*omega^4*Pi*Q^4*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^3*Pi*Q^6*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^2*Pi*Q^8*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega*Pi*Q^10*s^3*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (20*eq^2*gs^4*omega^4*Pi*Q^2*s^4*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (448*eq^2*gs^4*omega^3*Pi*Q^4*s^4*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (608*eq^2*gs^4*omega^2*Pi*Q^6*s^4*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^8*s^4*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^10*s^4*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*gs^4*omega^2*Pi*Q^4*s^5*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (704*eq^2*gs^4*omega*Pi*Q^6*s^5*s23^2*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^8*s^5*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (256*eq^2*gs^4*Pi*Q^6*s^6*s23^2*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (16*eq^2*gs^4*omega^7*Pi*Q^2*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (60*eq^2*gs^4*omega^6*Pi*Q^4*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^5*Pi*Q^6*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^4*Pi*Q^8*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*gs^4*omega^5*Pi*Q^4*s*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^4*Pi*Q^6*s*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*omega^3*Pi*Q^8*s*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^2*Pi*Q^10*s*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (40*eq^2*gs^4*omega^5*Pi*Q^2*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (100*eq^2*gs^4*omega^4*Pi*Q^4*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (448*eq^2*gs^4*omega^3*Pi*Q^6*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (256*eq^2*gs^4*omega^2*Pi*Q^8*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (512*eq^2*gs^4*omega*Pi*Q^10*s^2*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^4*Pi*Q^2*s^3*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (160*eq^2*gs^4*omega^3*Pi*Q^4*s^3*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (768*eq^2*gs^4*omega^2*Pi*Q^6*s^3*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^3*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*Pi*Q^10*s^3*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (160*eq^2*gs^4*omega^2*Pi*Q^4*s^4*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (896*eq^2*gs^4*omega*Pi*Q^6*s^4*s23^3*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (320*eq^2*gs^4*Pi*Q^8*s^4*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*Pi*Q^6*s^5*s23^3*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (20*eq^2*gs^4*omega^6*Pi*Q^2*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega^5*Pi*Q^4*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (96*eq^2*gs^4*omega^4*Pi*Q^6*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^3*Pi*Q^8*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^2*Pi*Q^10*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (24*eq^2*gs^4*omega^5*Pi*Q^2*s*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega^3*Pi*Q^6*s*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega*Pi*Q^10*s*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (4*eq^2*gs^4*omega^4*Pi*Q^2*s^2*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (320*eq^2*gs^4*omega^3*Pi*Q^4*s^2*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (224*eq^2*gs^4*omega^2*Pi*Q^6*s^2*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*omega*Pi*Q^8*s^2*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^10*s^2*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*gs^4*omega^2*Pi*Q^4*s^3*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (320*eq^2*gs^4*omega*Pi*Q^6*s^3*s23^4*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (256*eq^2*gs^4*Pi*Q^8*s^3*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (320*eq^2*gs^4*Pi*Q^6*s^4*s23^4*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (8*eq^2*gs^4*omega^5*Pi*Q^2*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (160*eq^2*gs^4*omega^4*Pi*Q^4*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (256*eq^2*gs^4*omega^3*Pi*Q^6*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^2*Pi*Q^8*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (8*eq^2*gs^4*omega^4*Pi*Q^2*s*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (192*eq^2*gs^4*omega^3*Pi*Q^4*s*s23^5*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^8*s*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23^5*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (640*eq^2*gs^4*omega*Pi*Q^6*s^2*s23^5*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*Pi*Q^8*s^2*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*Pi*Q^6*s^3*s23^5*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (64*eq^2*gs^4*omega^3*Pi*Q^4*s23^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (320*eq^2*gs^4*omega^2*Pi*Q^6*s23^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^6*Log[s23])/
      ((omega - s)^2*(Q^2 + s)^2*(s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (384*eq^2*gs^4*omega*Pi*Q^6*s*s23^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (64*eq^2*gs^4*Pi*Q^6*s^2*s23^6*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (128*eq^2*gs^4*omega*Pi*Q^6*s23^7*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) - 
     (128*eq^2*gs^4*Pi*Q^6*s*s23^7*Log[s23])/((omega - s)^2*(Q^2 + s)^2*
       (s - s23)^2*((omega - s)*s + Q^2*s23)*
       ((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)^2*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (4*eq^2*gs^4*Pi*Q^6*s^4*Log[s23])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (20*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (28*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (16*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (48*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (20*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (28*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*
       Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (16*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (20*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*Log[s23])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (60*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*Log[s23])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (12*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*
       Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (52*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (44*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) - (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) - (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*
       Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (16*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (20*eq^2*gs^4*omega*Pi*Q^6*s23^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*Log[s23])/((omega + 2*Q^2)*
       (Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*
       Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*
       ((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*
       SUNN^2) + (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[s23])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[s23])/((omega + 2*Q^2)*(Q^2 + s)^2*
       (s - s23)*((omega - s)*s + Q^2*s23)*(Q^2*s - 2*Q^2*s23 - 
        (omega - s)*s23)*SUNN^2) + (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (16*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (4*eq^2*gs^4*Pi*Q^6*s^4*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega*Pi*Q^10*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (40*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^10*s*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^10*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (48*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[s23])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[s23])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*((omega - s)*s + Q^2*s23)*(Q^2*(omega - s) - 2*Q^2*s23 - 
        s*s23)*SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^2*s23^2*
       Log[((s - s23)*(-omega + s + s23))/((omega + Q^2 - s23)*s23)])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*Pi*Q^2*s*s23^2*Log[((s - s23)*(-omega + s + s23))/
         ((omega + Q^2 - s23)*s23)])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)) - (8*eq^2*gs^4*Pi*Q^2*s23^3*
       Log[((s - s23)*(-omega + s + s23))/((omega + Q^2 - s23)*s23)])/
      ((omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^2*s23^2*Log[((s - s23)*(-omega + s + s23))/
         ((omega + Q^2 - s23)*s23)])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^2*s*s23^2*Log[((s - s23)*(-omega + s + s23))/
         ((omega + Q^2 - s23)*s23)])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^2*s23^3*Log[((s - s23)*(-omega + s + s23))/
         ((omega + Q^2 - s23)*s23)])/((omega - s)*(Q^2 + s)^2*
       ((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega^6*Pi*Q^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^4*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (32*eq^2*gs^4*omega^4*Pi*Q^6*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*omega^3*Pi*Q^8*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (88*eq^2*gs^4*omega^4*Pi*Q^4*s*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (84*eq^2*gs^4*omega^3*Pi*Q^6*s*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (32*eq^2*gs^4*omega^2*Pi*Q^8*s*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (40*eq^2*gs^4*omega^4*Pi*Q^2*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (112*eq^2*gs^4*omega^3*Pi*Q^4*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (84*eq^2*gs^4*omega^2*Pi*Q^6*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (28*eq^2*gs^4*omega^3*Pi*Q^2*s^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (72*eq^2*gs^4*omega^2*Pi*Q^4*s^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (44*eq^2*gs^4*omega*Pi*Q^6*s^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*Pi*Q^6*s^4*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (84*eq^2*gs^4*omega^4*Pi*Q^4*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (68*eq^2*gs^4*omega^3*Pi*Q^6*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^8*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (84*eq^2*gs^4*omega^4*Pi*Q^2*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (228*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (160*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (32*eq^2*gs^4*omega*Pi*Q^8*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (96*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (220*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (116*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (52*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (92*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (24*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (32*eq^2*gs^4*omega^4*Pi*Q^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (80*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (36*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (80*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (184*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (72*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (68*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (128*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (36*eq^2*gs^4*Pi*Q^6*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (24*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) + 
     (48*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (24*eq^2*gs^4*Pi*Q^4*s^2*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^6*Pi*Q^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (28*eq^2*gs^4*omega^5*Pi*Q^4*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega^4*Pi*Q^6*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega^3*Pi*Q^8*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (88*eq^2*gs^4*omega^4*Pi*Q^4*s*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*gs^4*omega^3*Pi*Q^6*s*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega^2*Pi*Q^8*s*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (40*eq^2*gs^4*omega^4*Pi*Q^2*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (112*eq^2*gs^4*omega^3*Pi*Q^4*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (84*eq^2*gs^4*omega^2*Pi*Q^6*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (28*eq^2*gs^4*omega^3*Pi*Q^2*s^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (72*eq^2*gs^4*omega^2*Pi*Q^4*s^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (44*eq^2*gs^4*omega*Pi*Q^6*s^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (12*eq^2*gs^4*Pi*Q^6*s^4*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (28*eq^2*gs^4*omega^5*Pi*Q^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (84*eq^2*gs^4*omega^4*Pi*Q^4*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (68*eq^2*gs^4*omega^3*Pi*Q^6*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega^2*Pi*Q^8*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (84*eq^2*gs^4*omega^4*Pi*Q^2*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (228*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (160*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega*Pi*Q^8*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (96*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (220*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (116*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (52*eq^2*gs^4*omega^2*Pi*Q^2*s^3*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (92*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (32*eq^2*gs^4*omega^4*Pi*Q^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (80*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (36*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (80*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (184*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (72*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (68*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (128*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (36*eq^2*gs^4*Pi*Q^6*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (24*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) - 
     (48*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (24*eq^2*gs^4*Pi*Q^4*s^2*s23^3*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/(4*(omega - s)^2*
          (omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)^2*(Q^2 + s)^2*
       (omega + Q^2 - s23)*((omega - s)*s + Q^2*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega*Pi*Q^10*s*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega^3*Pi*Q^4*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (24*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^4*s^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*Pi*Q^8*s^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^4*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*Pi*Q^6*s^4*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^8*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega*Pi*Q^10*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (28*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (20*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (24*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (36*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (44*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (12*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (16*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (32*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) + 
     (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^6*s*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^8*s*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*omega*Pi*Q^10*s*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*omega^3*Pi*Q^4*s^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (24*eq^2*gs^4*omega^2*Pi*Q^6*s^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega*Pi*Q^8*s^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*Pi*Q^10*s^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^3*Pi*Q^2*s^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^4*s^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (16*eq^2*gs^4*omega*Pi*Q^6*s^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (16*eq^2*gs^4*Pi*Q^8*s^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega^2*Pi*Q^2*s^4*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (20*eq^2*gs^4*omega*Pi*Q^4*s^4*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*Pi*Q^6*s^4*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*omega^3*Pi*Q^6*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega^2*Pi*Q^8*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*omega*Pi*Q^10*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (28*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*omega*Pi*Q^8*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*Pi*Q^10*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega^3*Pi*Q^2*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (20*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (24*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (40*eq^2*gs^4*Pi*Q^8*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (36*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (44*eq^2*gs^4*Pi*Q^6*s^3*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*omega*Pi*Q^2*s^4*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (16*eq^2*gs^4*Pi*Q^4*s^4*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*omega*Pi*Q^8*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*Pi*Q^10*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (12*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (8*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (32*eq^2*gs^4*Pi*Q^8*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (16*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (32*eq^2*gs^4*Pi*Q^4*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (8*eq^2*gs^4*Pi*Q^8*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (20*eq^2*gs^4*Pi*Q^6*s*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) - (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*s^2*(omega + Q^2 - s23)^2)])/((omega + 2*Q^2)*(omega - s)*
       (Q^2 + s)^2*(omega + Q^2 - s23)*(s - s23)*((omega - s)*s + Q^2*s23)*
       SUNN^2) + (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*Pi*Q^6*s^4*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (20*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (28*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (48*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (32*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (28*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (16*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (20*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (60*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (52*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (44*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (20*eq^2*gs^4*omega*Pi*Q^6*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (32*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) + 
     (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega*Pi*Q^8*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^6*s^4*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (20*eq^2*gs^4*omega^2*Pi*Q^6*s*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (28*eq^2*gs^4*omega*Pi*Q^8*s*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (12*eq^2*gs^4*Pi*Q^10*s*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (48*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (32*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (20*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (28*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^4*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^6*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (20*eq^2*gs^4*omega*Pi*Q^8*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^10*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega^2*Pi*Q^4*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (60*eq^2*gs^4*omega*Pi*Q^6*s*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (32*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (52*eq^2*gs^4*omega*Pi*Q^4*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (44*eq^2*gs^4*Pi*Q^6*s^2*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^3*Pi*Q^2*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (16*eq^2*gs^4*omega^2*Pi*Q^4*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (20*eq^2*gs^4*omega*Pi*Q^6*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^8*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (12*eq^2*gs^4*omega^2*Pi*Q^2*s*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega*Pi*Q^4*s*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (20*eq^2*gs^4*Pi*Q^6*s*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (12*eq^2*gs^4*omega*Pi*Q^2*s^2*s23^3*
       Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^4*s^2*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*Pi*Q^2*s^3*s23^3*Log[((omega + 2*Q^2)^2*(s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*s - 2*Q^2*s23 - (omega - s)*s23)^2)])/
      ((omega + 2*Q^2)*(Q^2 + s)^2*(s - s23)*((omega - s)*s + Q^2*s23)*
       (Q^2*s - 2*Q^2*s23 - (omega - s)*s23)*SUNN^2) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (4*eq^2*gs^4*Pi*Q^6*s^4*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (16*eq^2*gs^4*omega*Pi*Q^10*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (40*eq^2*gs^4*omega*Pi*Q^8*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (16*eq^2*gs^4*Pi*Q^10*s*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (8*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (32*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (16*eq^2*gs^4*Pi*Q^10*s23^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (48*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) + 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^10*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (8*eq^2*gs^4*omega^2*Pi*Q^8*s*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega*Pi*Q^10*s*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (4*eq^2*gs^4*omega^2*Pi*Q^6*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega*Pi*Q^8*s^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^10*s^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega*Pi*Q^6*s^3*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^8*s^3*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^6*s^4*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (16*eq^2*gs^4*omega*Pi*Q^10*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (40*eq^2*gs^4*omega*Pi*Q^8*s*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^10*s*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (32*eq^2*gs^4*omega*Pi*Q^6*s^2*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (40*eq^2*gs^4*Pi*Q^8*s^2*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) + 
     (8*eq^2*gs^4*omega*Pi*Q^4*s^3*s23*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (32*eq^2*gs^4*Pi*Q^6*s^3*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (8*eq^2*gs^4*Pi*Q^4*s^4*s23*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (16*eq^2*gs^4*Pi*Q^10*s23^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (48*eq^2*gs^4*Pi*Q^8*s*s23^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (52*eq^2*gs^4*Pi*Q^6*s^2*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (24*eq^2*gs^4*Pi*Q^4*s^3*s23^2*
       Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2) - 
     (4*eq^2*gs^4*Pi*Q^2*s^4*s23^2*Log[((omega + 2*Q^2)^2*(omega - s - s23)^2*
          (1 - Sqrt[((omega - s)^2 + 2*(omega - s)*s + s^2 + 4*Q^2*s23)/
             (omega + 2*Q^2)^2])*(1 + Sqrt[((omega - s)^2 + 2*(omega - s)*s + 
              s^2 + 4*Q^2*s23)/(omega + 2*Q^2)^2]))/
         (4*(Q^2*(omega - s) - 2*Q^2*s23 - s*s23)^2)])/
      ((omega + 2*Q^2)*(omega - s)*(Q^2 + s)^2*((omega - s)*s + Q^2*s23)*
       (Q^2*(omega - s) - 2*Q^2*s23 - s*s23)*SUNN^2))/(128*Pi^6), 
 "InputHash" -> 1145402436517207353857587485668188733018300608059703005084029\
5414483995189839, "Accepted" -> True|>
