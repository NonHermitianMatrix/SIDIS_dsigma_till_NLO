	subroutine histo_close
	parameter (nbhisto=2)
	common/init_close/ibin(nbhisto),wxmin(2),
     #   wxmax(2)
	open(unit=30,file='jgdd_try.res',
     #	status='unknown')
	read(30,100) inbevent,wfirst_int
100	format(1x,i12,e12.5)
	dimension wbin_size(2),wxnorma(2)
c
	do i=1,2
	  wbin_size(i) = (wxmax(i)-wxmin(i))/float(ibin(i))
	  wxnorma(i) = wfirst_int/(float(inbevent)*wbin_size(i))
	enddo
c
	call hopera(20,'+',920,20,wxnorma(1),1.)
	call hopera(21,'+',921,21,wxnorma(2),1.)
	call hrout(20,ICYCLE,' ')
	call hrout(21,ICYCLE,' ')
	call hrend('ntuple')
	call hrend('histogram')
	return
	end
