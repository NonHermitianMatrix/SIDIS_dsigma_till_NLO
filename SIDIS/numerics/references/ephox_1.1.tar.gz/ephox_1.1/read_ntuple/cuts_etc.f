	subroutine cuts_etc(
     #  pt_photmin,pt_jet1min,pt_jet1max,y_photmin,y_photmax,
     #  y_jet1min,y_jet1max,r_iso,epsilon,ethad,r_kt,
     #  r_c,r_sep,x_gam_min,iflag_xgam)
	implicit real*4 (a-h,l-z)
c	 ordering changed since rewritten by perl
	r_kt = 1.
	y_jet1min = -1.5
	y_jet1max = 1.8
	pt_photmin = 5.
	r_c = 1.
	y_photmin = -0.7
	r_sep = 1.
	y_photmax = 0.9
	pt_jet1min = 5.
	r_iso = 1.
	pt_jet1max = 150.
	iflag_xgam = 0
	x_gam_min = 0.
	epsilon= .1
	ethad = epsilon*pt3
	return
	end
