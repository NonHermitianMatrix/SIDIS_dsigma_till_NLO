#! /usr/bin/perl -w
##! /usr/local/bin/perl -w
###############################################################################
# this program consists of two blocks, one for the input parameters
# and one for the histograms of the generated events
#
# Block 1 of this program generates
# (1) the 4 parameter files to be read in by ephox*.exe
#    (param_ddir_name.dat, param_dfrag_name.dat, 
#     param_resdir_name.dat, param_resfrag_name.dat)
# (2) four subdirectories for each process where .bs and the .log files 
#    will be stored (ddir_name, dfrag_name, resdir_name, resfrag_name)
# (3) a file that launches the selected subprocesses at one time ("run_name.exe")
# 
#
# Block 2 is executed only if event generation has been selected in the input
# Block 2 defines parameters and cuts for filling of histograms and
# rewrites the corresponding Fortran files in src/histo/perlmod accordingly
#
###############################################################################
# variables used to define cuts and histograms
#---------------------------------------------------------------------
# keys for variables to be written to cuts_etc.f  
#---------------------------------------------------------------------
@listfilenames=qw(name_ntuple name_histo);
@listcutpt=qw(pt_gam_min pt_jet_min pt_jet_max);
@listcutrap=qw(eta_gam_min eta_gam_max eta_jet_min eta_jet_max);
@listcutiso=qw(r_iso epsilon ethad);
@listcutj= qw(r_kt r_cone r_sep);
@listcutx= qw(xgam_min iflag_xgam);
@list_cutvar=(@listcutpt,@listcutrap,@listcutiso,@listcutj,@listcutx,degree_or_rad);
@list_var_histo_clef = (@listfilenames,@list_cutvar);
# --------------------------------------------------------------------
# values for variables to be written to cuts_etc.f
# ------------------------------------------------------------------  
@def_var= qw(pt_photmin pt_jet1min pt_jet1max 
y_photmin y_photmax y_jet1min y_jet1max 
r_iso epsilon ethad r_kt r_c r_sep 
xgam_min iflag_xgam degree);
#@cut_var_string{@list_cutvar}=@def_var;	
# --------------------------------------------------------------------
# to add a new cut variable add an arbitrary name to "@list_cutvar"
# and add the name of the variable to "@def_var" at same position in the 
# two lists;
# in histo_selection.f, you have to add the new variable to the argument list 
# of the subroutine "cuts_etc" (called in histo_selection.f) by hand; 
# the file perlmod/cuts_etc.f containing the subroutine will be 
# adapted automatically 
#---------------------------------------------------------------------
# variables for filling of histograms 
#---------------------------------------------------------------------
# names given on the right-hand side of the arrow have to correspond 
# exactly to the variable names defined in histo_selection.f
# names on the left-hand side are the ones to be used in the input
# parameter file "param_histo.indat"
# if a new variable has been defined in histo_selection.f and should be 
# histogrammed, it has to be added to this list;
# in histo_selection.f, you have to add the new variable to the argument list 
# of the subroutine "fill_histo" (called in histo_selection.f) by hand; 
# only the file perlmod/fill_histo.f containing the subroutine will be 
# adapted automatically 
#--------------------------------------------------------------------
%hash_variable = ( "rapidity_gam" => ["y3"],
		   "rapidity_jet" => ["y_jet1"],
		   "x_gam_obs" => ["xgamobs"],
		   "x_gam_meas" => ["xgameas"],
		   "x_gam_LL" => ["xgamll"],
		   "p_perp" => ["ptra"],
		   "p_parallel" => ["ppa"],
		   "pt_jet" => ["pt_jet1"],
		   "vkt" => ["vkt"],
		   "fi_Snowmass" => ["fisno"],
		   "fi_vec" => ["fivec"],
		   "pt_gam" => ["pt3"],
		   "qt_gam_parton" => ["qt"],
		   "sum_ptgj" => ["sum_gaj"],
		   "min_pt_gj" => ["mingj"],
		   "max_pt_gj" => ["maxgj"],
		   "x_fragmentation" => ["x3"]);
$rh_variable = \%hash_variable;
%hash_proc= ("ddir"=>"jgdd","dfrag"=>"jgdf","resodir"=>"jgrd","resofrag"=>"jgrf");
#
# generates Fortran subroutines  which fill histograms
# according to parameters specified in param_ntuple.indat
#
$param_ntup="param_ntuple.indat";
$res_directory=".";
#$path_histo = "../src/histo/perlmod";
$path_histo = "./";
$fortran_init = "$path_histo/init_paw.f";
$fortran_end = "$path_histo/end_paw.f";
$nomgfill = "$path_histo/fill_histo.f";
$nomkinem = "$path_histo/cuts_etc.f";
#$ntuple_id = 10;
# 
$ivar = 0;
$ihisto_equi = 0;
$ihisto_nonequi = 0;
%hash_var_histo = ();
@list_nom = ();
@list_order = ();
@list_cut = ();
@list_titre = ();
@list_nb_bin = ();
@list_xmin = ();
@list_xmax = ();
@list_ref_bin_value= ();
@list_ref_histo_equi = ();
@list_ref_histo_nonequi = ();
#---------------------------------------------------------------------
# read input parameters for histos and fill %hash_var_histo and write an 
# info on chosen parameters into 
@list_cutvalues=();
open (EREAD,$param_ntup) || die "cannot open $param_ntup";
#open (EWRITE,">$res_directory/histo$namepaw.param") || die "cannot open $res_directory/histo$namepaw.param";
open (EWRITE,">$res_directory/histo.param") || die "cannot open $res_directory/histo.param";
while(<EREAD>) {
  chomp;
    s/^\s+//;
  unless (/^#/ || /^histo_equi/ || /^histo_nonequi/ || /^scatter_equi/) {  
# remove blanks
    s/\s+//g; 
    $hash_var_histo{$list_var_histo_clef[$ivar]} = "$_";
    push (@list_cutvalues, $_);
    print EWRITE "$list_var_histo_clef[$ivar]  $_\n";
    $ivar++;
  }
  if (/^histo_equi/) {
    s/\s$//;
    s/\s+/ /g;
    print EWRITE "$_\n";
    my ($temp_dummy,$temp_nom,$temp_order,$temp_cut,$temp_titre,$temp_nb_bin,$temp_xmin,$temp_xmax);
    ($temp_dummy,$temp_nom,$temp_order,$temp_cut,$temp_titre,$temp_nb_bin,$temp_xmin,$temp_xmax) = 
    			split(/ /,$_);
    push (@list_nom,$temp_nom);
    push (@list_order,$temp_order);
    push (@list_cut,$temp_cut);
    push (@list_titre,$temp_titre);
    push (@list_nb_bin,$temp_nb_bin);
    push (@list_xmin,$temp_xmin);
    push (@list_xmax,$temp_xmax);
    $ihisto_equi++;
  }
  if (/^histo_nonequi/) {
    s/\s$//;
    s/\s+/ /g;
    print EWRITE "$_\n";
     if ($ihisto_equi==0) {
     $nonequifirst="true";
     }
     else {$nonequifirst="false";
     }
    my ($temp_dummy,$temp_nom,$temp_order,$temp_cut,$temp_titre,
    $temp_nb_bin,@temp_bin_value,$rl_temp);
    ($temp_dummy,$temp_nom,$temp_order,$temp_cut,$temp_titre,
    $temp_nb_bin,@temp_bin_value) = 
    			split(/ /,$_);
    push (@list_nom,$temp_nom);
    push (@list_order,$temp_order);
    push (@list_cut,$temp_cut);
    push (@list_titre,$temp_titre);
    push (@list_nb_bin,$temp_nb_bin);
    $rl_temp=\@temp_bin_value;
    push (@list_ref_bin_value,$rl_temp);
    $ihisto_nonequi++;
#    print "temp_cut=$temp_cut\n";
#    foreach $l (@$rl_temp) { print "binedge = $l\n";}
  }  
}
close (EREAD);
close (EWRITE);
#
# reference to @temp_bin_value avoids that perl flattens list of lists
# automatically to a single list!
# debug
#  foreach $l (@list_cut) {print "$l\n";}
#
@temp = split(/\./,$hash_var_histo{"name_ntuple"});
$name_res = $temp[0].".res";
if ($temp[0] =~ m/jgdd/) {
  @name_dot = ("ddir = .true.","dfrag = .false.","rdir = .false.","rfrag = .false.");
}
elsif ($temp[0] =~ m/jgdf/) {
  @name_dot = ("ddir = .false.","dfrag = .true.","rdir = .false.","rfrag = .false.");
}
elsif ($temp[0] =~ m/jgrd/) {
  @name_dot = ("ddir = .false.","dfrag = .false.","rdir = .true.","rfrag = .false.");
}
elsif ($temp[0] =~ m/jgrf/) {
  @name_dot = ("ddir = .false.","dfrag = .false.","rdir = .false.","rfrag = .true.");
}
#
############ end of filling of lists ##################################
# pour chaque histo, on donne (dans param_ntuple.indat):
# un entier
# un identificateur
# la variable qui remplit l'histogramme
# un flag pour savoir si on remplit l'histogramme avec les resultats 
# Leading Log ou Next-to-Leading Log
# un tableau (en reference) pour les coupures specifiques a cet histogramme
# un titre
# le nombre de bin
# le maximum et minimum  de la variable
# ici on cree une reference a tous les objets du package Histo_equi 
# order of definition for histo_equi and histo_non_equi in paw_param.dat 
# should not matter!
#
$nb_histo=$ihisto_equi+$ihisto_nonequi;
if ($ihisto_nonequi==0) {
$nonequifirst="false";
}
if ($nonequifirst eq "true") {
#   print "$ihisto_nonequi nonequidistant histos have been defined first\n";
   $ihn = $ihisto_nonequi;
   }
else  {$ihn = 0;}  
for ($ih=$ihn;$ih < $ihisto_equi+$ihn;$ih++) {
    $help=eval($ih-$ihn);
    my $r_histo = Histo_equi::new(eval($ih+1),eval(20+$ih),
		    $list_nom[$ih],$list_order[$ih],$list_cut[$ih],
		    $list_titre[$ih],$list_nb_bin[$ih],
		    $list_xmin[$help],$list_xmax[$help]);
    push (@list_ref_histo_equi,$r_histo);
#    print "nom = $list_nom[$ih]\n";
#    print "maxbin = $list_xmax[$help]\n";
}
if ($nonequifirst eq "true") {
   $ih = 0;
   }
for ($ihn=$ih;$ihn < $ih+$ihisto_nonequi;$ihn++) {
    $l = $ihn-$ihisto_equi;
    my $r_histo = Histo_nonequi::new(eval($ihn+1),eval(20+$ihn),
		    $list_nom[$ihn],$list_order[$ihn],$list_cut[$ihn],
		    $list_titre[$ihn],$list_nb_bin[$ihn],
		    $list_ref_bin_value[$l]);
    push (@list_ref_histo_nonequi,$r_histo);
}
#
#
# write cut variables to subroutine cuts_etc
open (HISTO,">$nomkinem")|| die "cannot create  $nomkinem";
$histo = *HISTO;
print HISTO "\tsubroutine cuts_etc(\n";
print HISTO  "     #  ";
$k=1;
$lecutv = eval(@list_cutvar);
$lecheck = eval(@def_var);
if ($lecutv != $lecheck) { 
   print "warning: number of cut variables does not correspond to number of keys
   in list_var_histo_clef !\n";
}
# define hash with first two elements (=name.rz, name.dat) removed
$le=eval(@list_cutvalues-1);
@listvalues{@def_var}=@list_cutvalues[2..$le];
#foreach $l (@list_cutvalues[2..$le]) {print "$l\n";}
#
#foreach $l (values(%cut_var_string)) {
foreach $l (@def_var) {
  $helpa=int($k % 6);
#  print "$helpa\n";
  if ($l eq "rad" || $l eq "degree") {
     print HISTO "";}
  else {  
       if ($helpa == 0) {
          print HISTO "\n";
          print HISTO "     #  $l,";
       }
       else { 
             if ($k < eval($lecutv-1)) {
                 print HISTO "$l,"; 
             }
             else { print HISTO "$l)\n"; }	  
       }
   $k++;
  }
}
#@stringhash{values(%cut_var_string)}= values(%hash_var_histo);
#print HISTO "\timplicit real*4 (a-h,l-y)\n";
print HISTO "c\t ordering changed since rewritten by perl\n";
while (($key,$value) = each(%listvalues)) {
#  print "key = $key, value = $value\n";
   unless ($value eq "rad" || $value eq "degree" || $key eq "ethad" || $key eq
   "epsilon") {
       print HISTO "\t$key = $value\n";
   }    
}
# print ethad last since it needs value of epsilon
print HISTO "\tepsilon= $hash_var_histo{\"epsilon\"}\n";
# do not define ethad in terms of pt3 before pt3 has been defined!
#print HISTO "\tethad = $hash_var_histo{\"ethad\"}\n";
print_return($histo);
close (HISTO);
#
# creation du fichier de remplissage des histogrammes
# write all variables into a single list
@listvalues=();
foreach $key (keys(%hash_variable)) {
     for ($i=0; $i<=10; $i++) {
       if ($hash_variable{$key}[$i]) { 
	 push (@listvalues,$hash_variable{$key}[$i]);
        }
        if ($hash_variable{$key}[11]) { 
         print "attention, list of values in hash_variable contains more than 11 elements!\n";
	 print "automatic filling of arguments in fill_histo subroutine failed\n";
	 print " 12. variable: ".$hash_variable{$key}[11]."\n";
        }
   } #end for ($i=0; $i<=10; $i++)
}
$leli = eval(@listvalues);
#
open (REMPLISSAGE,">$nomgfill")|| die "cannot create  $nomgfill";
$remplissage = *REMPLISSAGE;
print REMPLISSAGE "\tsubroutine fill_histo(iprov,weight,\n";
print REMPLISSAGE "     #  ";
$k=1;
foreach $l (@listvalues) {
  $helpa=int($k % 6);
#  print "$helpa\n";
  if ($helpa == 0) {
      print REMPLISSAGE "\n";
      print REMPLISSAGE "     #  $l,";
  }
  else { 
      if ($k < $leli) {
          print REMPLISSAGE "$l,"; 
      }
      else { print REMPLISSAGE "$l)\n"; }	  
  }
   $k++;
}
print REMPLISSAGE "\timplicit real*4 (a-h,l-z)\n";
if ($hash_var_histo{degree_or_rad} eq "degree") {
  print REMPLISSAGE "\t  fisno = fisno*180/3.141592654\n";
}
$order = "lo";
print REMPLISSAGE "\t  if (iprov.eq.11) then\n";
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_remplissage($remplissage,$order,$rh_variable);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_remplissage($remplissage,$order,$rh_variable);
}
#foreach $r_scatter (@list_ref_scatter_equi) {
#    $r_scatter->print_remplissage($remplissage,$order,$rh_variable);
#}
print REMPLISSAGE "\t  endif\n";
$order = "nlo";
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_remplissage($remplissage,$order,$rh_variable);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_remplissage($remplissage,$order,$rh_variable);
}
#foreach $r_scatter (@list_ref_scatter_equi) {
#    $r_scatter->print_remplissage($remplissage,$order,$rh_variable);
#}
print_return($remplissage);
close (REMPLISSAGE);
#
# creation du fichier d'initialisation de paw
open (INITCREATE,">$fortran_init")|| die "cannot create  $fortran_init";
$valeur_de_ipawc = 3000000;
$init = *INITCREATE;
print INITCREATE "\tsubroutine histo_init(ddir,dfrag,rdir,rfrag)\n";
print INITCREATE "\tlogical ddir,dfrag,rdir,rfrag\n";
print INITCREATE "\tparameter(iwpawc = $valeur_de_ipawc)\n";
print INITCREATE "\tcommon/pawc/hmemor(iwpawc)\n";
print INITCREATE "\tparameter (nbhisto=$nb_histo)\n";
unless ($ihisto_equi eq 0) {
 print INITCREATE
 "\tcommon/init_close/ibin($nb_histo),wxmin($ihisto_equi),wxmax($ihisto_equi)\n";
}
unless ($ihisto_nonequi eq 0) {
  print INITCREATE "\tcommon/nonequi/";
#
  $count=1;
  foreach $r_histo (@list_ref_histo_nonequi) {
  $r_histo->print_common($init,$count,$ihisto_nonequi);
  $count=$count+1;
  }
}
#
@proc = keys(%hash_proc);
$le = eval(@proc-1);
#print "nb of subprocesses: ".eval($le+1)."\n";
for (my $i=0;$i<=$le;$i++) {
  print INITCREATE "\t$name_dot[$i]\n";
}
print INITCREATE "c\n";
print INITCREATE "\tcall hlimit(iwpawc)\n";
print INITCREATE "\tcall hropen(1,'histogram',\n";
print INITCREATE "     #\t\'$hash_var_histo{\"name_histo\"}\',\n";
print INITCREATE "     #\t'n',1024,istat)\n";
print INITCREATE "\tcall hropen(2,'ntuple',\n";
print INITCREATE "     #\t\'$hash_var_histo{\"name_ntuple\"}\',\n";
print INITCREATE "     #\t' ',8192,istat)\n";
print INITCREATE "\tcall hrin(0,9999,0) ! lecture\n";
print INITCREATE "c \n";
#
#
foreach $r_histo (@list_ref_histo_equi) {
# run the subroutine print_value on the $r_histo object of package Histo_equi
# with $init as an argument
    $r_histo->print_value($init);
}
foreach $r_histo (@list_ref_histo_nonequi) {
# run the subroutine print_value on the $r_histo object 
# of package Histo_nonequi with $init as an argument
    $r_histo->print_value($init);
}
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_hbook($init);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_hbook($init);
}
print_return($init);
close (INITCREATE);
#
# creation du fichier de fermeture paw
open (ENDCREATE,">$fortran_end")|| 
die "cannot create  $fortran_end";
$endcr = *ENDCREATE;
#print ENDCREATE "\tsubroutine histo_close(inbevent,wfirst_int)\n";
print ENDCREATE "\tsubroutine histo_close\n";
#print ENDCREATE "\timplicit real*8 (a-h,l-v,x-z)\n";
#print ENDCREATE "\timplicit real*4 (w)\n";
print ENDCREATE "\tparameter (nbhisto=$nb_histo)\n";
print ENDCREATE "\tcommon/init_close/ibin(nbhisto),wxmin($ihisto_equi),\n";
print ENDCREATE "     #   wxmax($ihisto_equi)\n";
unless ($ihisto_nonequi eq 0) {
 print ENDCREATE "\tcommon/nonequi/";
#
 $count=1;
 foreach $r_histo (@list_ref_histo_nonequi) {
 $r_histo->print_common($endcr,$count,$ihisto_nonequi);
 $count=$count+1;
 }
 print ENDCREATE "\tdimension ";
 $count=1;
 foreach $r_histo (@list_ref_histo_nonequi) {
 $r_histo->print_dim($endcr,$count,$ihisto_nonequi);
 $count=$count+1;
 }
} # end of  unless ($ihisto_nonequi eq 0)
unless ($ihisto_equi eq 0) { 
  print ENDCREATE "\tdimension wbin_size($ihisto_equi),wxnorma($ihisto_equi)\n";
  print ENDCREATE "c\n";
  print ENDCREATE "\topen(unit=30,file='$name_res',\n";
  print ENDCREATE "     #\tstatus='unknown')\n";
  print ENDCREATE "\tread(30,100) inbevent,wfirst_int\n";
  print ENDCREATE "100\tformat(1x,i12,e12.5)\n";
  print ENDCREATE "\tdo i=1,$ihisto_equi\n";
  print ENDCREATE "\t  wbin_size(i) = (wxmax(i)-wxmin(i))/float(ibin(i))\n";
  print ENDCREATE "\t  wxnorma(i) = wfirst_int/(float(inbevent)*wbin_size(i))\n"; 
  print ENDCREATE "\tenddo\n";
} #end of unless ($ihisto_equi eq 0) { 
#
foreach $r_histo (@list_ref_histo_nonequi) {
$r_histo->print_norma($endcr); 
} 
print ENDCREATE "c\n";  
#
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_opera($endcr);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_opera($endcr);
}
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_out($endcr);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_out($endcr);
}
print ENDCREATE "\tcall hrend('ntuple')\n";
print ENDCREATE "\tcall hrend('histogram')\n";
print_return($endcr);
close (ENDCREATE);
#
#######################################################################
# define global subroutines
#######################################################################
sub print_return {
  my ($fichier) = @_;
  print $fichier "\treturn\n";
  print $fichier "\tend\n";
}
##############################################################
# this subroutine takes two lists @list1 and @list2 
# and makes a hash out of it with @list1 as keys and @list2 as values
sub list_to_hash {
  my ($rl_list1,$rl_list2) = @_;
  my ($nb_element1,$nb_element2,$i,%hash_temp,$rh_hash_temp);
  $nb_element1 = @$rl_list1;
  $nb_element2 = @$rl_list2;
  if ($nb_element1 == $nb_element2) {
    for ($i=0;$i<$nb_element1;$i++) {
      $hash_temp{"$rl_list1->[$i]"} = $rl_list2->[$i];
    }
  }
  else {
    print "Error in list_to_hash\n";
    print "the two lists must have the same number of elements\n";
    print "number of elements in list1: $nb_element1\n";
    print "number of elements in list2: $nb_element2\n";
 }
  $rh_hash_temp = {%hash_temp};
  return($rh_hash_temp);
}
#
#
# define subroutine writefromuntil which reads a file and rewrites it
# from $stringtobegin until $stringtostop (included)
# arguments are $filetoread, $filetowrite, $stringtobegin, $stringtostop, writemode
# last argument specifies if $filetowrite is new or if writing should append
#
sub writefromuntil {
open (EREAD,"$_[0]") || die "cannot open $_[0]";
if ($_[4] eq "new") {
     open (EWRITE,">$_[1]") || die "cannot open $_[1]";
     }
elsif ($_[4] eq "append") {
     open (EWRITE,">>$_[1]") || die "cannot open $_[1]"; 
     }
elsif ($_[4] ne "append" or "new") {  
     print "specify \`new\` or \`append\` as last argument\n";
     return;
     };  
$start = 0;
LINE: while(<EREAD>) {
  chomp;
    if (/$_[2]/) {
        $start = 1;}
    if ($start == 1) {
     print EWRITE "$_\n";
    }
  last LINE if /$_[3]/;
  } #close while 
close (EREAD);
close (EWRITE);   
} #close sub
#
#######################################################################
# define packages
######################################################################
# $i = number of histo, $id = PAW histo identifier
package Histo_equi;
sub new {
  my ($i,$id,$nomvar,$order,$cut,$title,$nb_bin,$xmin,$xmax) = @_;
  my $r_hash_histo = {
    "id" => $id,
    "nomvar" => $nomvar,
    "order" => $order,
    "cut" => $cut,
    "title" => $title,
    "nb_bin" => "ibin($i)",
    "value_nb_bin" => $nb_bin,
    "min_bin" => "wxmin($i)",
    "value_min_bin" => $xmin,
    "max_bin" => "wxmax($i)",
    "value_max_bin" => $xmax,
    "normalisation" => "wxnorma($i)"
  };
  bless $r_hash_histo,'Histo_equi';
  return $r_hash_histo;
}
#
#
sub print_value {
  my ($r_histo,$df) = @_;
  print $df "\t".$r_histo->{"nb_bin"}." = ".$r_histo->{"value_nb_bin"}."\n";
  print $df "\t".$r_histo->{"min_bin"}." = ".$r_histo->{"value_min_bin"}."\n";
  print $df "\t".$r_histo->{"max_bin"}." = ".$r_histo->{"value_max_bin"}."\n";
  print $df "c\n";
}
#
sub print_hbook {
  my ($r_histo,$df) = @_;
  print $df "\tcall hbook1(".$r_histo->{"id"}.",'".
  $r_histo->{"title"}."',".
  $r_histo->{"nb_bin"}.",".
  $r_histo->{"min_bin"}.",".
  $r_histo->{"max_bin"}.",".
  "0.)\n";
  print $df "\tcall hbook1(9".$r_histo->{"id"}.",'dummy',".
  $r_histo->{"nb_bin"}.",".
  $r_histo->{"min_bin"}.",".
  $r_histo->{"max_bin"}.",".
  "0.)\n";
  print $df "\tcall hbarx(".$r_histo->{"id"}.")\n";
  print $df "\tcall hbarx(9".$r_histo->{"id"}.")\n";
  print $df "c\n";
}
#
sub print_opera {
  my ($r_histo,$df) = @_;
  print $df "\tcall hopera(".$r_histo->{"id"}.",'+',9".
  $r_histo->{"id"}.",".
  $r_histo->{"id"}.",".
  $r_histo->{"normalisation"}.",1.)\n";
}
#
sub print_remplissage {
  my ($r_histo,$df,$order,$rh_variable) = @_;
  my ($rl_temp,$first_parenthese,$last_parenthese,$machin,$truc,$variable);
  if ($r_histo->{"order"} eq $order) {
    eval('$rl_temp = '.$r_histo->{"cut"});
    $first_parenthese = "";
    $last_parenthese = "";
    if (scalar(@$rl_temp) > 3){
      $first_parenthese = "(";
      $last_parenthese = ")";
    }
# debug    
#    foreach $l (@$rl_temp){print "$l\n"; }
#
if ($rl_temp->[0]) {
# test if cut variables correspond to defined variables 
      for ($i=1;$i<=scalar(@$rl_temp);$i=$i+3) {	  
        $midvar=$rl_temp->[$i];
	if (not defined(@{$rh_variable->{"$midvar"}})) {
	    print "one of the cut variables for histo_equi not defined,\n"; 
	    print "please check spelling in param_histo.indat\n";
	}	
            $machin = ($i==1)? "\t  if  $first_parenthese":"     #\t  .and.";
            print $df "$machin";
#	    print "midvar = $midvar\n";
#	    print $rh_variable->{$midvar}[0];
#	    print "\n";
	    $le_varlist=scalar(@{$rh_variable->{$midvar}});
            for ($j=1;$j<=$le_varlist;$j++) {
#	      print @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1];
 	      $truc = ($j == 1)? "":"     #\t  .and.";
              print $df "$truc($rl_temp->[$i-1].le.".
 	      @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1]
 	      .".and.".
 	      @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1]
 	      .".le.$rl_temp->[$i+1])\n";
 	     }
#        } # end else
     } # end for ($i=1;$i<=scalar(@$rl_temp);$i=$i+3)		  
         print $df "     #\t  $last_parenthese then\n";
#   print $r_histo->{"nomvar"};
         foreach $variable (@{$rh_variable->{$r_histo->{"nomvar"}}}) {
            print $df "\t    call hfill (".$r_histo->{"id"}.",$variable,0.,weight)\n";
         }
         print $df "\t  endif\n";
   } # end if ($rl_temp->[0])
    else {
        foreach $variable (@{$rh_variable->{$r_histo->{"nomvar"}}}) {
        print $df "\t  call hfill (".$r_histo->{"id"}.",$variable,0.,weight)\n";
        }
   } 
  } # end if ($r_histo->{"order"} eq $order)
}
#
sub print_out {
  my ($r_histo,$df) = @_;
  print $df "\tcall hrout(".$r_histo->{"id"}.",ICYCLE,' ')\n";
}
#
########################################################################
# 
package Histo_nonequi;
sub new {
  my ($i,$id,$nomvar,$order,$cut,$title,$nb_bin,$rl_bin_value) = @_;
  my $r_hash_histo = {
    "id" => $id,
    "nomvar" => $nomvar,
    "order" => $order,
    "cut" => $cut,
    "title" => $title,
    "nb_bin" => "ibin($i)",
    "value_nb_bin" => $nb_bin,
    "binvec" => "wxbin$nomvar",
    "value_binvec" => $rl_bin_value,
    "normalisation" => "wxnorma$nomvar"
  };
# debug  
#      foreach $l (@$rl_bin_value) {
#     print "$l\n";
#   };
#   $leng=@rl_bin_value;
#   print "length of wxbin$nomvar = $leng\n";
  bless $r_hash_histo,'Histo_nonequi';
  return $r_hash_histo;
}
#
sub print_value {
  my ($r_histo,$fichier) = @_;
  print $fichier "c     bins for histo in ".$r_histo->{"nomvar"}."\n";
  print $fichier "\t".$r_histo->{"nb_bin"}." = ".$r_histo->{"value_nb_bin"}."\n";
  for ($l = 0; $l<=$r_histo->{"value_nb_bin"}; $l++) {
  $lp=eval($l+1);
  print $fichier "\t".$r_histo->{"binvec"}."($lp) = ".$r_histo->{"value_binvec"}[$l]."\n";
  }
  print $fichier "c\n";
}
#
sub print_common {
  my ($r_histo,$fichier,$count,$nbnonequi) = @_;
    $nbb=eval($r_histo->{"value_nb_bin"}+1);
    if ($count<$nbnonequi){
  print $fichier $r_histo->{"binvec"}."($nbb),\n";
  print $fichier "     #   ";
  }
  if ($count== $nbnonequi){
#  print "$count\n";
  print $fichier $r_histo->{"binvec"}."($nbb)\n";
  }
}
sub print_dim {
  my ($r_histo,$fichier,$count,$nbnonequi) = @_;
    $nb=$r_histo->{"value_nb_bin"};
    $nbb=eval($r_histo->{"value_nb_bin"}+1);
    if ($count<$nbnonequi){
  print $fichier $r_histo->{"normalisation"}."($nbb),\n";
  print $fichier "     #   ";
  }
  if ($count== $nbnonequi){
#  print "$count\n";
  print $fichier $r_histo->{"normalisation"}."($nbb)\n";
  }
}
#
sub print_hbook {
  my ($r_histo,$fichier) = @_;
# Born histo id has 1 in front of HO histo id    
#  print $fichier "\tcall hbookb(1".$r_histo->{"id"}.",'Born ".
#  $r_histo->{"title"}."',".
#  $r_histo->{"nb_bin"}.",".
#  $r_histo->{"binvec"}.",".
#  "0.)\n";
  print $fichier "\tcall hbookb(".$r_histo->{"id"}.",'".
  $r_histo->{"title"}."',".
  $r_histo->{"nb_bin"}.",".
  $r_histo->{"binvec"}.",".
  "0.)\n";
  print $fichier "\tcall hbookb(9".$r_histo->{"id"}.",'dummy',".
  $r_histo->{"nb_bin"}.",".
  $r_histo->{"binvec"}.",".
  "0.)\n";
#  print $fichier "\tcall hbarx(1".$r_histo->{"id"}.")\n";
  print $fichier "\tcall hbarx(".$r_histo->{"id"}.")\n";
  print $fichier "\tcall hbarx(9".$r_histo->{"id"}.")\n";
  print $fichier "c\n";
}
#
sub print_norma {
  my ($r_histo,$fichier) = @_;
    $nb=$r_histo->{"value_nb_bin"};
    $ibin=$r_histo->{"nb_bin"};
    $normvec=$r_histo->{"normalisation"};
    $binvec=$r_histo->{"binvec"};
  print $fichier "\t do j=1,$ibin\n";
  print $fichier "\t $normvec(j) = wfirst_int/(float(inbevent)*\n";
  print $fichier "     #	($binvec(j+1)-$binvec(j)))\n";
  print $fichier "\t enddo \n";
}
#
sub print_opera {
  my ($r_histo,$fichier) = @_;
  print $fichier "\tcall hpak(9".$r_histo->{"id"}.",".$r_histo->{"normalisation"}.")\n";
#  print $fichier "\tcall hopera(1".$r_histo->{"id"}.",'*',9".
#  $r_histo->{"id"}.",1".
#  $r_histo->{"id"}.",".
#  "1.,1.)\n";
  print $fichier "\tcall hopera(".$r_histo->{"id"}.",'*',9".
  $r_histo->{"id"}.",".
  $r_histo->{"id"}.",".
  "1.,1.)\n";
  print $fichier "c\n";
}
#
sub print_remplissage {
  my ($r_histo,$df,$order,$rh_variable) = @_;
  my ($rl_temp,$first_parenthese,$last_parenthese,$machin,$truc,$var);
  if ($r_histo->{"order"} eq $order) {
    eval('$rl_temp = '.$r_histo->{"cut"});
    $first_parenthese = "";
    $last_parenthese = "";
    if (scalar(@$rl_temp) > 3){
      $first_parenthese = "(";
      $last_parenthese = ")";
    }
    if (scalar(@$rl_temp) > 0) {
      for ($i=1;$i<=scalar(@$rl_temp);$i=$i+3) {
       $midvar=$rl_temp->[$i];
       if (not defined(@{$rh_variable->{"$midvar"}})) {
	    print "one of the cut variables for histo_equi not defined,\n"; 
	    print "please check spelling in param_histo.indat\n";
	}
        $machin = ($i==1)? "\t  if  $first_parenthese":"     #\t  .and.";
        print $df "$machin";
        for ($j=1;$j<=scalar(@{$rh_variable->{$rl_temp->[$i]}});$j++) {
	  $truc = ($j == 1)? "":"     #\t  .and.";
          print $df "$truc($rl_temp->[$i-1].le.".
	  @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1]
	  .".and.".
	  @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1]
	  .".le.$rl_temp->[$i+1])\n";
	}
      }	
      print $df "     #\t  $last_parenthese then\n";
      foreach $var (@{$rh_variable->{$r_histo->{"nomvar"}}}) {
      print $df "\t  call hfill (".$r_histo->{"id"}.",$var,0.,weight)\n";
      }
      print $df "\t  endif\n";
    } # end if (scalar(@$rl_temp) > 0)      
     else {
       foreach $var (@{$rh_variable->{$r_histo->{"nomvar"}}}) {
       print $df "\t  call hfill (".$r_histo->{"id"}.",$var,0.,weight)\n";
       }
     }
 }
}
#
#
sub print_fillhisto {
  my ($r_histo,$fichier) = @_;
  print $fichier "\tcall hfill(".$r_histo->{"id"}.","
  .$r_histo->{"nomvar"}.",0.,weight)\n";
}
#
sub print_out {
  my ($r_histo,$df) = @_;
  print $df "\tcall hrout(".$r_histo->{"id"}.",ICYCLE,' ')\n";
}
#
########################################################################
