	subroutine fill_histo(iprov,weight,
     #  xgameas,xgamll,vkt,x3,pt_jet1,
     #  ptra,mingj,pt3,y_jet1,maxgj,sum_gaj,
     #  fisno,y3,qt,fivec,ppa,xgamobs)
	implicit real*4 (a-h,l-z)
	  if (iprov.eq.11) then
	  endif
	  if  ((0.9.le.xgamobs.and.xgamobs.le.1.)
     #	  .and.(0.9.le.xgameas.and.xgameas.le.1.)
     #	  ) then
	    call hfill (20,y3,0.,weight)
	  endif
	  call hfill (21,vkt,0.,weight)
	return
	end
