	subroutine histo_init(ddir,dfrag,rdir,rfrag)
	logical ddir,dfrag,rdir,rfrag
	parameter(iwpawc = 3000000)
	common/pawc/hmemor(iwpawc)
	parameter (nbhisto=2)
	common/init_close/ibin(2),wxmin(2),wxmax(2)
	ddir = .true.
	dfrag = .false.
	rdir = .false.
	rfrag = .false.
c
	call hlimit(iwpawc)
	call hropen(1,'histogram',
     #	'jgdd.dat',
     #	'n',1024,istat)
	call hropen(2,'ntuple',
     #	'jgdd_try.rz',
     #	' ',8192,istat)
	call hrin(0,9999,0) ! lecture
c 
	ibin(1) = 8
	wxmin(1) = -0.7
	wxmax(1) = 0.9
c
	ibin(2) = 20
	wxmin(2) = 0
	wxmax(2) = 10
c
	call hbook1(20,'dsigma/detaga',ibin(1),wxmin(1),wxmax(1),0.)
	call hbook1(920,'dummy',ibin(1),wxmin(1),wxmax(1),0.)
	call hbarx(20)
	call hbarx(920)
c
	call hbook1(21,'dsigma/dvkt',ibin(2),wxmin(2),wxmax(2),0.)
	call hbook1(921,'dummy',ibin(2),wxmin(2),wxmax(2),0.)
	call hbarx(21)
	call hbarx(921)
c
	return
	end
