C                        PROGRAM GAMDISTB 
C**************************************************************************
C         (new version with b-quark and new thresholds in F2)
C                        (February 2002)
C
C     This is an interpolation program which reads the files GRPOL and 
C     GRVDM and gives the quark and gluon distributions in real photon 
C     as functions of x and Q**2.
C
C     The Q**2 evolution is a BLL evolution (MSbar scheme)
C
C     A massless charm distribution is generated for Q**2 > mc**2
C     A massless bottom distribution is generated for Q**2 > mb**2
C
C     The distributions are the sum of a pointlike part (PL) and of a
C     Vdm part (VDM):
C                     dist=PL + CNP*VDM
C     CNP is a factor which can be adjusted ( the default value is CNP=1.).
C
C     The file GRPOL contains the pointlike part of the distributions.
C     The file GRVDM contains the vdm part (A precise definition of this
C     latter is given in the paper "PARTON DISTRIBUTIONS IN THE PHOTON",
C     Z.Phys. C64(1994)621, by P.Aurenche,M.Fontannaz and J.Ph.Guillet).
C
C     The output of the program is written in the file GETOUT with the 
C     following conventions
C                             xUPLUS=x(u+ubar)
C                             xDPLUS=x(d+dbar)
C                             xSPLUS=x(s+sbar)
C                             xCPLUS=x(c+cbar)
C                             xBPLUS=x(b+bbar)  
C                             xSING =x(UPLUS+DPLUS+SPLUS+CPLUS+BPLUS)
C                             xGLU  =x*g
C     
C      The interpolation is valid for     2.5 < Q**2 < 5.0E+5 Gev**2,
C                             and for    .002 < x   
C
C
C      THE INTERPOLATION PROGRAM USES "POLINT" FROM "NUMERICAL RECIPES"      
C
C      The program also gives the structure function F2:
C                        F2 = q*Cq + g*Cg + Cgam
C      Cq and Cg are the Wilson coeficients and Cgam is the direct term.
C
C      Although the heavy quark evolution is massless, the direct term
C      Cgam includes the effects due to the heavy quark mass. The heavy
C      quark thresholds are therefore correctly described at the lowest 
C      ordre in alphastrong (Details are given in the paper).
C
C      The heavy quark contributions to F2 can be set equal to zero with
C      the HFLAV flag (IHFLAV=0 -> no heavy flavor contributions to F2)
C      
C      If cf2 =  .0 , F2 is not calculated. If cf2#.0,F2 is calculated.
C      Note that the prediction for F2 for x close to 1. is not reliable,
C      because large log(1-x) are present in F2 that should be resummed.
C      Therefore the program returns F2=.0 if x>.90 .
C
C**************************************************************************

      program afg02
      implicit real*4 (L-M)
      dimension zq(4)
      COMMON/Q000/Q02,Q02V
      common/alfa/M2charm, M2bottom, M2top,Lambda4Square
      common/cst/cnp,cf2,ihflav
      data zq/10.0,50.0,100.0,1000.0/
c      data zq/.5,1.0,1.5,1.9,2.0,2.1,2.5,3.0,3.5,4.0/ 
C
C value of the VDM multiplicative factor cnp
      cnp = 1.
C
C With cf2=0. only the parton distributions are calculated
      cf2 = 0.
C
C If ihflav=0 , no contributions from heavy quarks to F2
      ihflav = 1
C
      call init
      call alfas_init(2)
      do j=1,4
c----- value of q2 fixed here --------------------------------------
      q2=zq(j)
c      q2 = 20.50 +( j-1)*.5
c      q2= 50.
        WRITE (13,90)Q2
        WRITE(13,91)
        do i=1,100
c----- value of x fixed here --------------------------------------
        x=.002 +(i-1)*.01
        call distga(cnp,ihflav,cf2,x,q2,xuplus,xdplus,xsplus,xcplus,
     #  xbplus,xsing,xglu,f2m)
        WRITE(13,92)X,xUPLUS,xDPLUS,xSPLUS,xCPLUS,xBPLUS,xSING,xGLU,
     #  F2M
        enddo
      enddo
   90   FORMAT(/,' Q2=',F9.2,' GEV**2')
   91   FORMAT(/,5X,' X',3X,'XUPLUS',5X,'XDPLUS',3X,'XSPLUS',4X,'XCPLUS',
     #  3x,'XBPLUS',4X,'XSING',6X,'XGLU',5X,' F2/ALPHA ')
   92 FORMAT(F8.3,9E10.3)
      end
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      subroutine init
      implicit real*4 (L-M)
      DIMENSION PAR(30),PAR2(30)
      common/parel/evol,evolv
      COMMON/ANEW/DELTA,deltav
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2
      COMMON/Q000/Q02,q02v
      COMMON/GFUNC/CALC(8,35,32)
      COMMON/GVDM/CELC(8,35,32)
      COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
      common/cst/cnp,cf2,ihflav
      common/alfa/M2charm, M2bottom, M2top,Lambda4Square
      OPEN(UNIT=13,FILE='GETOUT',STATUS='unknown')
      OPEN(UNIT=12,FILE='GRPOL',STATUS='OLD')
      OPEN(UNIT=14,FILE='GRVDM',STATUS='OLD')
C   SET UP FLAGS, I/O FILES, ETC.
C
C   STRUCTURE FUNCTIONS CONVENTIONS
C   IORD=0                     LEADING ORDER
C   IORD=1             NEXT TO LEADING ORDER
C
      READ(12,*) PAR
      READ(12,2) CALC
      READ(14,*) PAR2
      READ(14,2) CELC
   2  FORMAT(8E15.4)
C*****mass of the heavy quarks ******************************************
C      CM=1.41
      m2charm=par(24)
      m2bottom=par(25)
      m2top=par(26)
C
C******The parameters are fixed in the file GRPOL**********************     
C
      call wate32
      IORD=INT(PAR(28)+1.E-7)
      DELTA=PAR(29)
      deltav=par2(29)
      evol=par(23)
      evolv=par2(23)
      OWLAM=PAR(1)
      owlam2=OWLAM**2
      Lambda4Square=OWLAM**2
      iconv = .0
      WRITE (13,*) ' Q02=',PAR(30),'  LAMBDA4=',PAR(1),'evol=',evol,
     #'  DELTA=',DELTA,'  CNP =',cnp,'  IHFLAV=',ihflav,
     #'    Flag_F2 = ',cf2
      Q02=PAR(30)
      q02v=par2(30)
      write(13,*) 'q02v=',par2(30),' deltav=',par2(29),'  evolv=',evolv,
     #'  cmom=',par2(20)
      return 
      end
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      subroutine distga(cnp,ihflav,cf2,x,q2,uplus,dplus,splus,
     # cplus,bplus,sing,glu,f2m)
      implicit real*4 (L-M)
      COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
      common/flav/flavor
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2
      common/qs/q2sto
      common/alfa/M2charm, M2bottom, M2top,Lambda4Square
      dimension q(7),qq(7)
      if(q2.lt.2.5.or.q2.gt.5.0e+5) then
      print*,'Value of Q2 too small or too large'
      print*,'Q2 must be larger then 2.5 or smaller then 5.0+5 GeV2'
      stop
      endif 
      if(x.lt..002) then
      print*,'Value of x smaller than .002'
      stop
      endif 
      if(x.gt..999) then
      uplus=.0
      dplus=.0
      splus=.0
      cplus=.0
      bplus=.0 
      sing=.0
      glu=.0
      f2m=.0
      return
      endif
      q2sto=q2
      PI=4.*ATAN(1.)
      PI2=PI**2
      CF=4./3.
c l'appel de alfas fixe flavor en fonction de q2
      alfpi= alfas(2,q2)/2./pi
c l'evolution VDM ne contient pas de Bottom
      VDMNf=4.
      cutc=.0
      cutb=.0
      w2=q2*(1.-x)/x
      if(w2.gt.(4.*M2charm)) cutc=1.
      if(w2.gt.(4.*M2bottom)) cutb=1.
      if(ihflav.eq.0) then
      cutc=.0
      cutb=.0
      endif
c
c-- passage du seuil du charme -------------------------------
c-- pres de xth, je passe de c(x,q2) a log(q2/m2) ------------
c-- voir les modifications dans WCM ------------------------
c
      XTHC=1./(1.+4.*m2charm/Q2)
      xthcd= xthc - .02
      if(x.gt.xthcd.and.x.lt.xthc) cutc=.0      
      if(q2.gt.70.and.w2.gt.(4.*m2charm)) cutc=1.
c-------------------------------------------------------------
      XTHb=1./(1.+4.*m2bottom/Q2)
      cutcq=1.
      cutbq=1.
      if(q2.lt.m2charm) cutcq=.0
      if(q2.lt.m2bottom+1.5) cutbq=.0
c      ALQ2=ALOG(Q2/OWLAM2)
c      ALFPI= 2. /(B0*ALQ2+B1*ALOG(ALQ2)/B0)
      CALL DIST(X,Q)
      ADD=Q(1)/FLAVOR
      UPLUS=Q(5)+ADD
      DPLUS=-Q(6)+ADD
      SPLUS=-Q(4)+ADD
      CPLUS=(-Q(3)+ADD)*cutcq
      bplus=(-q(2)+add)*cutbq
      SING=Q(1)
      GLU=Q(7)         
      CALL DIST2(X,QQ)
      ADD2=QQ(1)/VDMNf
      UPLU2=QQ(5)+ADD2
      DPLU2=-QQ(6)+ADD2
      SPLU2=-QQ(4)+ADD2
      CPLU2=(-QQ(3)+ADD2)*cutcq
      if(cplu2.lt..0) cplu2=.0
      bplu2= .0*cutbq
      SING2=QQ(1)
      GLU2=QQ(7)
      UPLUS=UPLUS+UPLU2*cnp
      DPLUS=DPLUS+DPLU2*cnp
      SPLUS=SPLUS+SPLU2*cnp
      CPLUS=CPLUS+CPLU2*cnp
      bplus=bplus+bplu2*cnp
      SING=SING+SING2*cnp
      GLU=GLU+GLU2*cnp
      if(cf2.eq.0.) then
      f2 = .0
      return
      endif
      F2=4.*UPLUS/9.+DPLUS/9.+SPLUS/9.
      F2hf=(4./9.)*CPLUS*CUTC + (1./9.)*bplus*cutb
      F2=F2+F2hf
      IF(IORD)13,13,12
 13   STOP
 12    CONTINUE
      AL=0.5*ALFPI
      AL1=ALOG(1.-X)
      XQ=F2+F2*AL*CF*(-9.-2.*PI2/3.+AL1*(-3.+2.*AL1))
      XM=1.-X
      XP=1.+X
      DO 81 I=1,NTERMS
      Y=0.5*(1.-X)*XI(I)+0.5*(1.+X)
      XY=X/Y
      cutgc=1.
      cutgb=1.
      IF(XY.GT.XTHc) CUTGc=0.
      IF(XY.GT.XTHb) CUTGb=0. 
      AL1=ALOG(1.-Y)
      CALL DIST(XY,Q)
      ADD=Q(1)/FLAVOR
      UPLU=Q(5)+ADD
      DPLU=-Q(6)+ADD
      SPLU=-Q(4)+ADD
      CPLU=-Q(3)+ADD
      bplu=-q(2)+add
      CALL DIST2(XY,QQ)
      AD=QQ(1)/VDMNf
      UPL=QQ(5)+AD
      DPL=-QQ(6)+AD
      SPL=-QQ(4)+AD
      CPL=-QQ(3)+AD
      bpl=.0
      UPLU=UPLU+UPL*cnp
      DPLU=DPLU+DPL*cnp
      SPLU=SPLU+SPL*cnp
      CPLU=(CPLU+CPL*cnp)*cutcq
      bplu=(bplu+bpl*cnp)*cutbq
      XQQ=4.*UPLU/9.+DPLU/9.+SPLU/9.+(4./9.)*CPLU*CUTc+(1./9.)*bplu*cutb
 6    C22=CF*(6.+4.*Y-2.*(1.+Y*Y)/(1.-Y)*ALOG(Y)-2.*(1.+Y)*AL1)
      C23=CF*(-3.+4.*AL1)/(1.-Y)
      COEGM=4./3.+(8./9.)*CUTGc+(2./9.)*cutgb
      CG2=(-1.+8.*Y*(1.-Y)+(1.-2.*Y+2.*Y*Y)*ALOG(1./Y-1.))*COEGM
      XQ=XQ +.5*(1.-X)*WI(I)*AL*(C22*XQQ+C23*(XQQ- F2))
      XQ=XQ+.5*(1.-X)*WI(I)*AL*CG2*(Q(7)+cnp*QQ(7))
   81 continue
      COE3=3.*3.*(2./27.)*(1./(2.*PI*137.))*2.
c      COE4=3.*(34./81.)*(1./(2.*PI*137.))*2.  
ccc      termct = COE3*(8.*X*(1.-X)-1.+(1.-2.*X+2.*X*X)*ALOG(1./X-1.))*x
      F2M=XQ+COE3*(8.*X*(1.-X)-1.+(1.-2.*X+2.*X*X)*ALOG(1./X-1.))*X
      WMc=WCM(X,Q2,m2charm)
ccc      wau = wmc*(4./9.)**2
      WMb=WCM(X,Q2,m2bottom)
ccc      print*,'X=',x,'   F2lotot=',f2,'   f2lohf=',f2hf
ccc      print*,'XQ=',xq,'  TERMCT=',termct,'   F2M3=',f2m
      F2MA=F2M+(4./9.)**2*WMc*CUTc+(1./9.)**2*wmb*cutb
      F2m=F2MA*137.
c-----coupure a cause du mauvais comportement de f2 a grand x -------
      if(x.gt..90) f2m=.0
ccc      print*,'   WMC=',wau,'   F2M4=',f2ma,'   f2=',f2m
      return
      END
      FUNCTION WCM(X,Q2,m2)
      implicit real*4 (L-M)
      CMS=m2
      cutw=0.
      if(q2/cms.lt.1.) cutw=1. 
      xth = q2/(q2+4.*cms)
      xthd = xth - .02
      if(x.lt.xth.and.x.gt.xthd) cutw=1.
      if(q2.gt.70) cutw=.0
      SC=Q2*(1.-X)/X
      BE=4.*CMS/SC
      IF(BE.GE.1.) WCM=0.
      IF(BE.GE.1.) GO TO 1
      SQ=SQRT(1.-BE)
      A1=((1.+SQ)/2.)**2 
      A2=(1.-X)/X
      WCM=(8.*(1.-X)*X-1.-be*(1.-x)**2)*SQ
      wcma= 4.*cms/q2*x*(1.-3.*x)-8.*cms**2/q2**2*x**2
      wcm=wcm+(X**2+(1.-X)**2+wcma)*ALOG(A1*A2)
      wcm = wcm +wcma*alog(q2/cms)+cutw*(x**2+(1.-x)**2)*alog(q2/cms)
      WCM=3./(3.1416*137.)*X*WCM
 1    RETURN
      END
      SUBROUTINE DIST(X,Q)
      implicit real*4 (L-M)
      DIMENSION Q(7)
      COMMON/QS/Q2
      COMMON/Q000/Q02,q02v
      COMMON/ANEW/DELTA,deltav
      common/parel/evol,evolv
      common/alfa/M2charm, M2bottom, M2top,Lambda4Square
      common/sseuil/sch,sbo
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2
      evolsq=evol**2
      SB=0.
      IF(Q2-Q02) 1,1,3
    3 SB=ALOG(ALOG(Q2/evolsq)/ALOG(Q02/evolsq))
    1 CONTINUE
      s0=alog(q02/evolsq)
      tch=alog(m2charm/evolsq)
      tbo=alog(m2bottom/evolsq)
      sch = alog(tch/s0)
      sbo = alog(tbo/s0)
      CALL GINTER(8,0,X,SB,Q(7))
      CALL GINTER(7,0,X,SB,SING1)
      CALL GINTER(4,0,X,SB,SPLUSNS)
      CALL GINTER(3,0,X,SB,CPLUSNS)
      CALL GINTER(5,0,X,SB,UPLUSNS)
      CALL GINTER(6,0,X,SB,DPLUSNS)
      CALL GINTER(2,0,X,SB,bPLUSNS)
      q(2)=bplusns
      Q(3)=CPLUSNS
      Q(4)=SPLUSNS
      Q(5)=UPLUSNS
      Q(6)=DPLUSNS
 8    Q(1)=SING1
      RETURN
      END
      SUBROUTINE DIST2(X,QQ)
      DIMENSION QQ(7)
      common/parel/evol,evolv
      COMMON/QS/Q2
      COMMON/Q000/Q02,q02v
      COMMON/ANEW/DELTA,deltav
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2
      evolvsq=evolv**2
      SB=0.
      IF(Q2-Q02v) 1,1,3
    3 SB=ALOG(ALOG(Q2/evolvsq)/ALOG(Q02v/evolvsq))
    1 CONTINUE
C      PROGRAM DISTL0.FOR
      CALL GINTER2(8,0,X,SB,QQ(7))
      CALL GINTER2(7,0,X,SB,SING2)
      CALL GINTER2(4,0,X,SB,SPLUSNS)
      CALL GINTER2(3,0,X,SB,CPLUSNS)
      CALL GINTER2(5,0,X,SB,UPLUSNS)
      CALL GINTER2(6,0,X,SB,DPLUSNS)
      QQ(3)=CPLUSNS
      QQ(4)=SPLUSNS
      QQ(5)=UPLUSNS
      QQ(6)=DPLUSNS
 8    QQ(1)=SING2
      RETURN
      END                                                                      
      SUBROUTINE GINTER(I,NDRV,X,S,ANS)
      DIMENSION F1(32),F2(32),F3(32),F0(32)
      COMMON/GFUNC/GF(8,35,32)
      common/sseuil/sch,sbo
      COMMON/ANEW/DELTA,deltav
      DIMENSION AF(3),AS(3)
      common/getindex/index
      index = i
      N=3
      ib=sbo/delta+1
      IS=S/DELTA+1
      is0=is-1
      IS1=IS+1
      IS2=IS1+1
      DO 1 L=1,32
      KL=L+32*NDRV
      if(is0.gt.0) then
      f0(l)=gf(i,is0,kl)
      else
      f0(l)=.0
      endif 
      F1(L)=GF(I,IS,KL)
      F2(L)=GF(I,IS1,KL)
      F3(L)=GF(I,IS2,KL)
    1 CONTINUE
      af0=getfv4(x,f0)
      AF(1)=GETFV4(X,F1)
      AF(2)=GETFV4(X,F2)
      AF(3)=GETFV4(X,F3)
      if(is.eq.ib) then
        if(s.ge.sbo) then
        af(1)=2.*af(2)-af(3)
        else
        af(2)=af(1)
        af(1)=af0
        af(3)=2.*af(2)-af(1)
        is=is-1
        endif
      endif
      AS(1)=(IS-1)*DELTA
      AS(2)=AS(1)+DELTA
      AS(3)=AS(2)+DELTA
      CALL POLINT(AS,AF,N,S,AANS,DY)
cccc----tests de precision -------------------------------
cc      absans=abs(aans)
cc      ady=abs(dy)
cc      if (ady.gt.absans/20.) print*,as(1),as(2),as(3),af(1),af(2),af(3)
cc     # ,s,x,aans,dy,i
      ANS=AANS
      RETURN
      END
      SUBROUTINE GINTER2(I,NDRV,X,S,ANS)
      DIMENSION F1(32),F2(32),F3(32)
      COMMON/GVDM/GFV(8,35,32)
      COMMON/ANEW/DELTA,deltav
      DIMENSION AF(3),AS(3)
c pas de seuil dans GINTER2, car pas de bottom dans VDM
      common/getindex/index
      index=100+i
      N=3
      IS=S/DELTAv+1
      IS1=IS+1
      IS2=IS1+1
      DO 1 L=1,32
      KL=L+32*NDRV
      F1(L)=GFV(I,IS,KL)
      F2(L)=GFV(I,IS1,KL)
      F3(L)=GFV(I,IS2,KL)
    1 CONTINUE
      AF(1)=GETFV4(X,F1)
      AF(2)=GETFV4(X,F2)
      AF(3)=GETFV4(X,F3)
      AS(1)=(IS-1)*DELTAv
      AS(2)=AS(1)+DELTAv
      AS(3)=AS(2)+DELTAv
      CALL POLINT(AS,AF,N,S,AANS,DY)
      ANS=AANS
      RETURN
      END

      SUBROUTINE WATE32
C  32 POINT GAUSSIAN QUADRATURE ROUTINE
      DIMENSION X(16),W(16)
      COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
      NTERMS=32
      X(1)=0.048307665687738316235
      X(2)=0.144471961582796493485
      X(3)=0.239287362252137074545
      X(4)=0.331868602282127649780
      X(5)=0.421351276130635345364
      X(6)=0.506899908932229390024
      X(7)=0.587715757240762329041
      X(8)=0.663044266930215200975
      X(9)=0.732182118740289680387
      X(10)=0.794483795967942406963
      X(11)=0.849367613732569970134
      X(12)=0.896321155766052123965
      X(13)=0.934906075937739689171
      X(14)=0.964762255587506430774
      X(15)=0.985611511545268335400
      X(16)=0.997263861849481563545
      W(1)=0.096540088514727800567
      W(2)=0.095638720079274859419
      W(3)=0.093844399080804565639
      W(4)=0.091173878695763884713
      W(5)=0.087652093004403811143
      W(6)=0.083311924226946755222
      W(7)=0.078193895787070306472
      W(8)=0.072345794108848506225
      W(9)=0.065822222776361846838
      W(10)=0.058684093478535547145
      W(11)=0.050998059262376176196
      W(12)=0.042835898022226680657
      W(13)=0.034273862913021433103
      W(14)=0.025392065309262059456
      W(15)=0.016274394730905670605
      W(16)=0.007018610009470096600
      DO 1 I=1,16
      XI(I)=-X(17-I)
      WI(I)=W(17-I)
      XI(I+16)=X(I)
      WI(I+16)=W(I)
    1 CONTINUE
      DO 2 I=1,32
    2 XX(I)=0.5*(XI(I)+1.)
      XX(33)=1.0
      RETURN
      END
       FUNCTION GETFV4(X,FVL)
C  NOUVEAU PROGRAMME D'INTERPOLATION UTILISANT UNE ROUTINE DE MATH. RECIPES
       DIMENSION FVL(32)
       COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
       DIMENSION A(4),B(4)
       common/getindex/index
       N=4
       EPS=1.E-7
       XAM=XX(1)-EPS
       XAP=XX(1)+EPS
       XBM=XX(32)-EPS
       IF(X.LT.XAM) PRINT*,'X trop petit','    X = ',X
       IF(X.GT.XAM.AND.X.LT.XAP) then
       getfv4=FVL(1)
       return
       endif
       IF(X.LT.XX(2)) GO TO 51
       IF(X.GT.XX(30)) GO TO 61
       DO 1 I=3,23
       IF(X.GT.XX(I)) GO TO 1
       A(1)=XX(I-1)
       A(2)=XX(I)
       A(3)=XX(I+1)
       A(4)=XX(I+2)
       B(1)=FVL(I-1)
       B(2)=FVL(I)
       B(3)=FVL(I+1)
       B(4)=FVL(I+2)
       GO TO 81
   1   CONTINUE
       DO 2 I=24,30
       IF(X.GT.XX(I)) GO TO 2
       A(1)=XX(I-2)
       A(2)=XX(I-1)
       A(3)=XX(I)
       A(4)=XX(I+1)
       B(1)=FVL(I-2)
       B(2)=FVL(I-1)
       B(3)=FVL(I)
       B(4)=FVL(I+1)
       GO TO 81
  2    CONTINUE
  61   A(1)=XX(29)
       A(2)=XX(30)
       A(3)=XX(31)
       A(4)=XX(32)
       B(1)=FVL(29)
       B(2)=FVL(30)
       B(3)=FVL(31)
       B(4)=FVL(32)
       GO  TO 81
  51   continue
       A(1)=XX(1)
       A(2)=XX(2)
       A(3)=XX(3)
       A(4)=XX(4)
       B(1)=FVL(1)
       B(2)=FVL(2)
       B(3)=FVL(3)
       B(4)=FVL(4)
 81    CONTINUE
cc-------test de precision- polintaux print l'interpolation pour x=.012 ---
c       xaux = abs(x - .012)
c       if(xaux.lt..000001) then
c          call polintaux(A,B,N,X,Y,DY) 
c          stop
c       endif
          CALL POLINT(A,B,N,X,Y,DY)
cc------- ancien appel de ratint, mais ratint produit des spikes! ------
c          CALL RATINT(A,B,N,X,Y,DY)
       RES=Y
       ares = abs(res)
       ady = abs(dy)
       ar = .0
c------- test de precision --------------------------
c       if(ares.lt.1.e-4) go to 87
c       if(ares.gt.1.e-9)       ar=ady/ares
c       if (ady.gt..03*ares) print*,'index_saveur = ',index
c       if (ady.gt..03*ares) print*,x,a(1),a(2),a(3),a(4),y
c       if (ady.gt..03*ares) print*,dy,b(1),b(2),b(3),b(4),ar
 87    GETFV4=RES
       RETURN
       END
       FUNCTION GETFV3(X,FVL)
C  NOUVEAU PROGRAMME D'INTERPOLATION UTILISANT UNE ROUTINE DE MATH. RECIPES
       DIMENSION FVL(32)
       COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
       DIMENSION A(3),B(3)
       N=3
       EPS=1.E-7
       XAM=XX(1)-EPS
       XAP=XX(1)+EPS
       XBM=XX(32)-EPS
       IF(X.LT.XAM) PRINT*,' X = ',X
       IF(X.GT.XAM.AND.X.LT.XAP) then
       getfv3=FVL(1)
       return
       endif
       IF(X.LT.XX(2)) GO TO 51
       IF(X.GT.XX(30)) GO TO 61
       DO 1 I=3,30
       IF(X.GT.XX(I)) GO TO 1
       A(1)=XX(I-2)
       A(2)=XX(I-1)
       A(3)=XX(I)
       B(1)=FVL(I-2)
       B(2)=FVL(I-1)
       B(3)=FVL(I)
       GO TO 81
   1   CONTINUE
  61   A(1)=XX(30)
       A(2)=XX(31)
       A(3)=XX(32)
       B(1)=FVL(30)
       B(2)=FVL(31)
       B(3)=FVL(32)
       GO  TO 81
  51   A(1)=XX(1)
       A(2)=XX(2)
       A(3)=XX(3)
       B(1)=FVL(1)
       B(2)=FVL(2)
       B(3)=FVL(3)
 81    CONTINUE
cc-------test de precision----------------
c       xaux = abs(x - .012)
c       if(xaux.lt..000001) then
c          call polintaux(A,B,N,X,Y,DY) 
c          stop
c       endif
          CALL POLINT(A,B,N,X,Y,DY)

c          CALL RATINT(A,B,N,X,Y,DY)

       RES=Y
       ares = abs(res)
       ady = abs(dy)
c       ar=ady/ares
c       if (ady.gt..02*ares) print*,x,a(1),a(2),a(3),y
c       if (ady.gt..02*ares) print*,dy,b(1),b(2),b(3),ar
 87    GETFV3=RES
       RETURN
       END


      SUBROUTINE POLINT(XA,YA,N,X,Y,DY)
      PARAMETER (NMAX=10)
      DIMENSION XA(N),YA(N),C(NMAX),D(NMAX)
      NS=1
      DIF=ABS(X-XA(1))
      DO 11 I=1,N
        DIFT=ABS(X-XA(I))
        IF (DIFT.LT.DIF) THEN
          NS=I
          DIF=DIFT
        ENDIF
        C(I)=YA(I)
        D(I)=YA(I)
11    CONTINUE
      Y=YA(NS)
      NS=NS-1
      DO 13 M=1,N-1
        DO 12 I=1,N-M
          HO=XA(I)-X
          HP=XA(I+M)-X
          W=C(I+1)-D(I)
          DEN=HO-HP
          IF(DEN.EQ.0.)PAUSE
          DEN=W/DEN
          D(I)=HP*DEN
          C(I)=HO*DEN
12      CONTINUE
        IF (2*NS.LT.N-M)THEN
          DY=C(NS+1)
        ELSE
          DY=D(NS)
          NS=NS-1
        ENDIF
        Y=Y+DY
13    CONTINUE
      RETURN
      END
      SUBROUTINE POLINTaux(XA,YA,N,X,Y,DY)
      PARAMETER (NMAX=10)
      DIMENSION XA(N),YA(N),C(NMAX),D(NMAX)
      print*,x,xa(1),xa(2),xa(3),ya(1),ya(2),ya(3)
      NS=1
      DIF=ABS(X-XA(1))
      print*,'dif=',dif,'   ns=',ns
      DO 11 I=1,N
        DIFT=ABS(X-XA(I))
        IF (DIFT.LT.DIF) THEN
          NS=I
          DIF=DIFT
        ENDIF
        C(I)=YA(I)
        D(I)=YA(I)
      print*,'i=',i,'   ns=',ns,'   c(i)=',c(i),'   d(i)=',d(i)
11    CONTINUE
      Y=YA(NS)
      NS=NS-1
      DO 13 M=1,N-1
        DO 12 I=1,N-M
          HO=XA(I)-X
          HP=XA(I+M)-X
          W=C(I+1)-D(I)
          DEN=HO-HP
          IF(DEN.EQ.0.)PAUSE
          DEN=W/DEN
          D(I)=HP*DEN
          C(I)=HO*DEN
       print*,'M=',m,'  I=',i,'  HO=',ho,'  HP=',hp,
     $  '  W=',w,'  DEN=',den
       print*,'C(I)=',c(i),'   D(I)=',d(i)
12      CONTINUE
        IF (2*NS.LT.N-M)THEN
          DY=C(NS+1)
        ELSE
          DY=D(NS)
          NS=NS-1
        ENDIF
        Y=Y+DY
      print*,'M=',m,'   DY=',dy,'    Y=',y
13    CONTINUE
c      stop
      RETURN
      END
      SUBROUTINE RATINT(XA,YA,N,X,Y,DY)                                       
      PARAMETER (NMAX=10,TINY=1.E-25)                                         
      DIMENSION XA(N),YA(N),C(NMAX),D(NMAX)                                   
      NS=1                                                                    
      HH=ABS(X-XA(1))                                                         
      DO 11 I=1,N                                                             
        H=ABS(X-XA(I))                                                        
        IF (H.EQ.0.)THEN                                                      
          Y=YA(I)                                                             
          DY=0.0                                                              
          RETURN                                                              
        ELSE IF (H.LT.HH) THEN                                                
          NS=I                                                                
          HH=H                                                                
        ENDIF                                                                 
        C(I)=YA(I)                                                            
        D(I)=YA(I)+TINY                                                       
11    CONTINUE                                                                
      Y=YA(NS)                                                                
      NS=NS-1                                                                 
      DO 13 M=1,N-1                                                           
        DO 12 I=1,N-M                                                         
          W=C(I+1)-D(I)                                                       
          H=XA(I+M)-X                                                         
          T=(XA(I)-X)*D(I)/H                                                  
          DD=T-C(I+1)                                                         
          IF(DD.EQ.0.)PAUSE                                                   
          DD=W/DD                                                             
          D(I)=C(I+1)*DD                                                      
          C(I)=T*DD                                                           
12      CONTINUE                                                              
        IF (2*NS.LT.N-M)THEN                                                  
          DY=C(NS+1)                                                          
        ELSE                                                                  
          DY=D(NS)                                                            
          NS=NS-1                                                             
        ENDIF                                                                 
        Y=Y+DY                                                                
13    CONTINUE                                                                
      RETURN                                                                  
      END                                                                     

	! Compute alphaS with the implicit method and continuity at thresholds
	!=====================================================================

	! Warning: scale must be lower than top threshold.


	! The initialisation routine
	!---------------------------
	
	subroutine alfas_init(loop)
		implicit real*4 (l-m)
		integer loop
				
c		real*4 M2charm, M2bottom, M2top,Lambda4Square
		common/alfa/M2charm, M2bottom, M2top,Lambda4Square

		! uses 
c		real*4 getLambda3Sqr,getLambda5Sqr
		
		! internals
		 
	        dimension Lambda2(5)
		common / AlphaS_Lambdas / Lambda2

	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

	
	
	data pi / 3.141592653589793 /
		
	integer Nf

	do Nf=3,5
		b0(Nf)=( 33-2*Nf)/(12*pi)
		b1(Nf)=(153-19*Nf)/(24*pi**2*b0(Nf))
	enddo
	
	if (loop .eq. 1)then
		Lambda2(3)=lambda4Square**(b0(4)/b0(3) )
     _			* M2charm**(1 - b0(4)/b0(3))
		Lambda2(4)=lambda4Square
		Lambda2(5)=Lambda4Square**( b0(4)/b0(5) ) 
     _			* M2bottom**(1 - b0(4)/b0(3))
	elseif(loop .eq. 2) then
		Lambda2(3)=getLambda3Sqr(lambda4Square, M2charm)
		Lambda2(4)=lambda4Square
		Lambda2(5)=getLambda5Sqr(lambda4Square, M2bottom)
	else
		write(*,*) 'illegal number of loops in alfas'
		stop
	endif
		
	end
	

	! The main function
	!------------------

	 function alfas(loop, scale2)
		implicit real*4 (l-m)	
		integer loop		

	!uses

	if (loop .eq. 1) then
		alfas = alphaS1loop(scale2)
	else if (loop .eq. 2) then
		alfas = alphaS2loop(scale2)
	else
		write(*,*) 'illegal number of loops in alfas'
		stop
	endif

	end


	! Compute AlphaS at 1 loops

	 function alphaS1loop(scale2)
		implicit real*4 (l-m)

		common/alfa/M2charm, M2bottom, M2top,Lambda4Square
	
		! internals
		dimension lambda2(5) 
		common / AlphaS_Lambdas / Lambda2
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

	if (scale2 .gt. M2bottom) then
		alphaS1loop=1/( b0(5) * log( scale2/Lambda2(5) ) )
	elseif (scale2 .gt. M2charm) then
		alphaS1loop=1/( b0(4) * log( scale2/Lambda2(4) ) )		
	else
		alphaS1loop=1/( b0(3) * log( scale2/Lambda2(3) ) )		
	endif

	end


	! Compute AlphaS at 2 loops
	!--------------------------

	 function alphaS2loop(scale2)

                implicit real*4 (l-m)
		
		common/alfa/M2charm, M2bottom, M2top,Lambda4Square
	
		! uses
		
		! internals
		dimension lambda2(5)		 
		common / AlphaS_Lambdas / Lambda2
                common/flav/fflavor
	if (scale2 .gt. M2bottom) then
                fflavor=5.
		alphaS2loop=alphaSflav(scale2, 5, Lambda2(5))
	elseif (scale2 .gt. M2charm) then
                fflavor=4.
		alphaS2loop=alphaSflav(scale2, 4, Lambda2(4))
	else
                fflavor=3.
		alphaS2loop=alphaSflav(scale2, 3, Lambda2(3))
	endif

	end



	! Compute alphaS with f flavors at 2 loops
	!-----------------------------------------

	 function alphaSflav(scale2, Nf, Lambda2)
		implicit real*4 (l-m)
		integer Nf
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

		! uses

	! The relative precision for the computation of alphaS			
	data eps / 1d-5 /


	! We solve the equation whose solution is alphaS with the Newton's
	! method. The initial value is the 1loop value.

	Logar=b0(Nf)*log( scale2/lambda2 )


	alpha1=1/Logar

1	continue
	alpha=alpha1    
	alpha1 = alpha - (oneOverBetaInt(alpha,Nf) - Logar)*beta(alpha,Nf)     
	if ( abs(alpha1-alpha)/alpha .gt. eps ) goto 1

	alphaSflav=alpha1

	end


	! Compute Lambda5**2 from Lambda4**2 by requiring the continuity of
	! alphaS at the threshold, at 2 loops
	!-------------------------------------------------------------------

	 function getLambda5Sqr(Lambda4Sqr, M2bottom)
		implicit real*4 (l-m)
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

		!uses

		
	alpha=alphaSflav(M2bottom, 4, Lambda4Sqr)
	getLambda5Sqr = M2bottom * exp( -oneOverBetaInt(alpha,5)/b0(5) )
	end


	! Compute Lambda3**2 from Lambda4**2 by requiring the continuity of
	! alphaS at the threshold, at 2 loops
	!-------------------------------------------------------------------

	 function getLambda3Sqr(Lambda4Sqr, M2charm)
		implicit real*4 (l-m)
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

		!uses


	alpha=alphaSflav(M2charm, 4, Lambda4Sqr)
	getLambda3Sqr = M2charm * exp( -oneOverBetaInt(alpha,3)/b0(3) )
	end


	! The primitiv of 1/beta at 2 loop
	!---------------------------------

	 function oneOverBetaInt(alphaS, Nf)
		implicit real*4 (l-m)
		integer Nf
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

	oneOverBetaInt=
     _		1/alphaS + b1(Nf)*log( b0(Nf)*alphaS/(1 + b1(Nf)*alphaS) )
	end 


	! The beta function at 2 loops
	!-----------------------------

	 function beta(alphaS, Nf)
		implicit real*4 (l-m)
		integer Nf
                dimension b0(5), b1(5)    
		common / AlphaS_betaCoeffs / b0, b1

	beta=-b0(Nf)*alphaS**2 * (1 + b1(Nf)*alphaS)
	end
	     
