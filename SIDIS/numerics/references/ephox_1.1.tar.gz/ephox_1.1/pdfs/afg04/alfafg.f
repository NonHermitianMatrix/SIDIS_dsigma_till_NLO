                                                                                     
	! Compute alphaS with the implicit method and continuity at thresholds
	!=====================================================================

	! Warning: scale must be lower than top threshold.


	! The initialisation routine
	!---------------------------
	
	subroutine alfas_init(loop)
		implicit real*8(l-m)
		integer loop
				
c		real*8M2charm, M2bottom, M2top,Lambda4Square
		common/alfa/M2charm, M2bottom, M2top,Lambda4Square

		! uses 
c		real*8getLambda3Sqr,getLambda5Sqr
		
		! internals
		 
	        dimension Lambda2(5)
		common / AlphaS_Lambdas / Lambda2

	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

	
	
	data pi / 3.141592653589793 /
		
	integer Nf
	do Nf=3,5
		b0(Nf)=( 33-2*Nf)/(12*pi)
		b1(Nf)=(153-19*Nf)/(24*pi**2*b0(Nf))
	enddo
	
	if (loop .eq. 1)then
		Lambda2(3)=lambda4Square**(b0(4)/b0(3) )
     _			* M2charm**(1 - b0(4)/b0(3))
		Lambda2(4)=lambda4Square
		Lambda2(5)=Lambda4Square**( b0(4)/b0(5) ) 
     _			* M2bottom**(1 - b0(4)/b0(3))
	elseif(loop .eq. 2) then
		Lambda2(3)=getLambda3Sqr(lambda4Square, M2charm)
		Lambda2(4)=lambda4Square
		Lambda2(5)=getLambda5Sqr(lambda4Square, M2bottom)
	else
		write(*,*) 'illegal number of loops in alfas'
		stop
	endif
		
	end
	

	! The main function
	!------------------

	 double precision function alfas(loop, scale2)
		implicit real*8(l-m)	
		integer loop		

	!uses

	if (loop .eq. 1) then
		alfas = alphaS1loop(scale2)
	else if (loop .eq. 2) then
		alfas = alphaS2loop(scale2)
	else
		write(*,*) 'illegal number of loops in alfas'
		stop
	endif

	end


	! Compute AlphaS at 1 loops

	 double precision function alphaS1loop(scale2)
		implicit real*8(l-m)

		common/alfa/M2charm, M2bottom, M2top,Lambda4Square
	
		! internals
		dimension lambda2(5) 
		common / AlphaS_Lambdas / Lambda2
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

	if (scale2 .gt. M2bottom) then
		alphaS1loop=1/( b0(5) * log( scale2/Lambda2(5) ) )
	elseif (scale2 .gt. M2charm) then
		alphaS1loop=1/( b0(4) * log( scale2/Lambda2(4) ) )		
	else
		alphaS1loop=1/( b0(3) * log( scale2/Lambda2(3) ) )		
	endif

	end


	! Compute AlphaS at 2 loops
	!--------------------------

	 double precision function alphaS2loop(scale2)

c                implicit real*8(l-m)
		implicit real*8 (A-H,L-Z)
		common/alfa/M2charm, M2bottom, M2top,Lambda4Square
	
		! uses
		
		! internals
		dimension lambda2(5)		 
		common / AlphaS_Lambdas / Lambda2
                common/flav/fflavor

	if (scale2 .gt. M2bottom) then
                fflavor=5.d0
		alphaS2loop=alphaSflav(scale2, 5, Lambda2(5))
	elseif (scale2 .gt. M2charm) then
                fflavor=4.d0
		alphaS2loop=alphaSflav(scale2, 4, Lambda2(4))
	else
                fflavor=3.d0
		alphaS2loop=alphaSflav(scale2, 3, Lambda2(3))
	endif

	end



	! Compute alphaS with f flavors at 2 loops
	!-----------------------------------------

	 double precision function alphaSflav(scale2, Nf, Lambda2)
		implicit real*8(l-m)
		real*8 scale2
		integer Nf
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

		! uses

	! The relative precision for the computation of alphaS			
	data eps / 1d-5 /

	! We solve the equation whose solution is alphaS with the Newton's
	! method. The initial value is the 1loop value.

	Logar=b0(Nf)*log( scale2/lambda2 )


	alpha1=1/Logar

1	continue
	alpha=alpha1    
	alpha1 = alpha - (oneOverBetaInt(alpha,Nf) - Logar)*beta(alpha,Nf)     
	if ( abs(alpha1-alpha)/alpha .gt. eps ) goto 1

	alphaSflav=alpha1

	end


	! Compute Lambda5**2 from Lambda4**2 by requiring the continuity of
	! alphaS at the threshold, at 2 loops
	!-------------------------------------------------------------------

	 double precision function getLambda5Sqr(Lambda4Sqr, M2bottom)
		implicit real*8(l-m)
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

		!uses

	alpha=alphaSflav(M2bottom, 4, Lambda4Sqr)
	getLambda5Sqr = M2bottom * exp( -oneOverBetaInt(alpha,5)/b0(5) )
	end


	! Compute Lambda3**2 from Lambda4**2 by requiring the continuity of
	! alphaS at the threshold, at 2 loops
	!-------------------------------------------------------------------

	 double precision function getLambda3Sqr(Lambda4Sqr, M2charm)
		implicit real*8(l-m)
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

		!uses

	alpha=alphaSflav(M2charm, 4, Lambda4Sqr)
	getLambda3Sqr = M2charm * exp( -oneOverBetaInt(alpha,3)/b0(3) )
	end


	! The primitiv of 1/beta at 2 loop
	!---------------------------------

	 double precision function oneOverBetaInt(alphaS, Nf)
		implicit real*8(l-m)
		integer Nf
	        dimension b0(5), b1(5)
		common / AlphaS_betaCoeffs / b0, b1

	oneOverBetaInt=
     _		1/alphaS + b1(Nf)*log( b0(Nf)*alphaS/(1 + b1(Nf)*alphaS) )
	end 


	! The beta function at 2 loops
	!-----------------------------

	 double precision function beta(alphaS, Nf)
		implicit real*8(l-m)
		integer Nf
                dimension b0(5), b1(5)    
		common / AlphaS_betaCoeffs / b0, b1

	beta=-b0(Nf)*alphaS**2 * (1 + b1(Nf)*alphaS)
	end
	     
