c replaces InterfaceAFG.f for new photon distribution functions
c 06.05.2002
C**************************************************************************
C         (new version with b-quark and new thresholds in F2)
C                        (February 2002)
C
C     This is an interpolation program which reads the files GRPOL and 
C     GRVDM and gives the quark and gluon distributions in real photon 
C     as functions of x and Q**2.
C
C     The Q**2 evolution is a BLL evolution (MSbar scheme)
C
C     A massless charm distribution is generated for Q**2 > mc**2
C     A massless bottom distribution is generated for Q**2 > mb**2
C
C     The distributions are the sum of a pointlike part (PL) and of a
C     Vdm part (VDM):
C                     dist=PL + CNP*VDM
C     CNP is a factor which can be adjusted ( the default value is CNP=1.).
C
C     The file GRPOL contains the pointlike part of the distributions.
C     The file GRVDM contains the vdm part (A precise definition of this
C     latter is given in the paper "PARTON DISTRIBUTIONS IN THE PHOTON",
C     Z.Phys. C64(1994)621, by P.Aurenche,M.Fontannaz and J.Ph.Guillet).
C
C     The output of the program is written in the file GETOUT with the 
C     following conventions
C                             xUPLUS=x(u+ubar)
C                             xDPLUS=x(d+dbar)
C                             xSPLUS=x(s+sbar)
C                             xCPLUS=x(c+cbar)
C                             xBPLUS=x(b+bbar)  
C                             xSING =x(UPLUS+DPLUS+SPLUS+CPLUS+BPLUS)
C                             xGLU  =x*g
C     
C      The interpolation is valid for     2.5 < Q**2 < 5.0E+5 Gev**2,
C                             and for    .002 < x   
C
C
C      THE INTERPOLATION PROGRAM USES "POLINT" FROM "NUMERICAL RECIPES"      
C
C      The program also gives the structure function F2:
C                        F2 = q*Cq + g*Cg + Cgam
C      Cq and Cg are the Wilson coeficients and Cgam is the direct term.
C
C      Although the heavy quark evolution is massless, the direct term
C      Cgam includes the effects due to the heavy quark mass. The heavy
C      quark thresholds are therefore correctly described at the lowest 
C      ordre in alphastrong (Details are given in the paper).
C
C      The heavy quark contributions to F2 can be set equal to zero with
C      the HFLAV flag (IHFLAV=0 -> no heavy flavor contributions to F2)
C      
C      If cf2 =  .0 , F2 is not calculated. If cf2#.0,F2 is calculated.
C      Note that the prediction for F2 for x close to 1. is not reliable,
C      because large log(1-x) are present in F2 that should be resummed.
C      Therefore the program returns F2=.0 if x>.90 .
C
C**************************************************************************
      subroutine init_afg
      implicit real (L-M)
      DIMENSION PAR(30),PAR2(30)
      common/parel/evol,evolv
      COMMON/ANEW/DELTA,deltav
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2
      COMMON/Q000/Q02,q02v
      COMMON/GFUNC/CALC(8,35,32)
      COMMON/GVDM/CELC(8,35,32)
      COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
      common/cst/cnp,cf2,ihflav
      common/alfafs/M2charm, M2bottom,M2top,Lambda4Square
      CHARACTER*128 PATH_PDF
      COMMON/CHEMINPDF/PATH_PDF
      COMMON/LONGPPDF/ILENPPDF
c
c      OPEN(UNIT=42,FILE='../pdfs/afg02/GRPOL',STATUS='OLD')
c      OPEN(UNIT=44,FILE='../pdfs/afg02/GRVDM',STATUS='OLD')
      OPEN(42,file=PATH_PDF(1:ILENPPDF)//'afg04/GRPOL',status='old')
      OPEN(44,file=PATH_PDF(1:ILENPPDF)//'afg04/GRVDM',status='old')
c
      READ(42,*) PAR
      READ(42,2) CALC
      READ(44,*) PAR2
      READ(44,2) CELC
c
      close(42)
      close(44)
C
C value of the VDM multiplicative factor cnp
      cnp = 1.
C
C With cf2=0. only the parton distributions are calculated
      cf2 = 0.
C
C If ihflav=0 , no contributions from heavy quarks to F2
      ihflav = 1
c
   2  FORMAT(8E15.4)
C*****mass of the heavy quarks ******************************************
C      CM=1.41
      m2charm=par(24)
      m2bottom=par(25)
      m2top=par(26)
C
C******The parameters are fixed in the file GRPOL**********************     
C
      call wate32
      IORD=INT(PAR(28)+1.E-7)
      DELTA=PAR(29)
      deltav=par2(29)
      evol=par(23)
      evolv=par2(23)
      OWLAM=PAR(1)
      owlam2=OWLAM**2
      Lambda4Square=OWLAM**2
      iconv = .0
c      WRITE (13,*) ' Q02=',PAR(30),'  LAMBDA4=',PAR(1),'evol=',evol,
c     #'  DELTA=',DELTA,'  CNP =',cnp,'  IHFLAV=',ihflav,
c     #'    Flag_F2 = ',cf2
      Q02=PAR(30)
      q02v=par2(30)
c      write(13,*) 'q02v=',par2(30),' deltav=',par2(29),'  evolv=',evolv,
c     #'  cmom=',par2(20)
      return 
      end
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      subroutine afgdist(xd,q2d,dxpdf)
      REAL*8 xd,q2d,DXPDF(-6:6)
      real*4 x,q2
      common/cst/cnp,cf2,ihflav
      x = sngl(xd)
      q2 = sngl(q2d)
      call distga(cnp,ihflav,cf2,x,q2,uplus,dplus,splus,
     # cplus,bplus,sing,glu)
      DXPDF(0)=dble(GLU)
      DXPDF(1)=dble(DPLUS/2.)
      DXPDF(2)=dble(UPLUS/2.)
      DXPDF(3)=dble(SPLUS/2.)
      DXPDF(4)=dble(CPLUS/2.)
      DXPDF(5)=dble(BPLUS/2.)
      DXPDF(6)=0.d0
      DXPDF(-1)=DXPDF(1)
      DXPDF(-2)=DXPDF(2)
      DXPDF(-3)=DXPDF(3)
      DXPDF(-4)=DXPDF(4) 
      DXPDF(-5)=DXPDF(5)
      DXPDF(-6)=0.d0       
      return
      end
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
       subroutine distga(cnp,ihflav,cf2,x,q2,uplus,dplus,splus,
     # cplus,bplus,sing,glu)
      real*4 M2charm,M2bottom,M2top,Lambda4Square 
      COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
      common/flav/flavor
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2
      common/qs/q2sto
      common/alfafs/M2charm,M2bottom,M2top,Lambda4Square
      dimension q(7),qq(7)
      if(q2.lt.2.1.or.q2.gt.5.0e+5) then
      print*,'Value of Q2 too small or too large'
      print*,'Q2 must be larger then 2.1 or smaller then 5.0+5 GeV2'
      print*,'Q2 = ',q2
      return
c      stop
      endif 
      if(x.lt..002) then
      print*,'Value of x smaller than .002'
      stop
      endif 
      if(x.gt..999) then
      uplus=.0
      dplus=.0
      splus=.0
      cplus=.0
      bplus=.0 
      sing=.0
      glu=.0
      f2m=.0
      return
      endif
      q2sto=q2
      PI=4.*ATAN(1.)
      PI2=PI**2
      CF=4./3.
c l'appel de alfasnf fixe flavor en fonction de q2
      call alphaS2nf(q2)
c l'evolution VDM ne contient pas de Bottom
      VDMNf=4.
      cutc=.0
      cutb=.0
      w2=q2*(1.-x)/x
      if(w2.gt.(4.*M2charm)) cutc=1.
      if(w2.gt.(4.*M2bottom)) cutb=1.
      if(ihflav.eq.0) then
      cutc=.0
      cutb=.0
      endif
c
c-- passage du seuil du charme -------------------------------
c-- pres de xth, je passe de c(x,q2) a log(q2/m2) ------------
c-- voir les modifications dans WCM ------------------------
c
      XTHC=1./(1.+4.*m2charm/Q2)
      xthcd= xthc - .02
      if(x.gt.xthcd.and.x.lt.xthc) cutc=.0      
      if(q2.gt.70.and.w2.gt.(4.*m2charm)) cutc=1.
c-------------------------------------------------------------
      XTHb=1./(1.+4.*m2bottom/Q2)
      cutcq=1.
      cutbq=1.
      if(q2.lt.m2charm) cutcq=.0
      if(q2.lt.m2bottom+1.5) cutbq=.0
c      ALQ2=ALOG(Q2/OWLAM2)
c      ALFPI= 2. /(B0*ALQ2+B1*ALOG(ALQ2)/B0)
      CALL DIST(X,Q)
      ADD=Q(1)/FLAVOR
      UPLUS=Q(5)+ADD
      DPLUS=-Q(6)+ADD
      SPLUS=-Q(4)+ADD
      CPLUS=(-Q(3)+ADD)*cutcq
      bplus=(-q(2)+add)*cutbq
      SING=Q(1)
      GLU=Q(7)         
      CALL DIST2(X,QQ)
      ADD2=QQ(1)/VDMNf
      UPLU2=QQ(5)+ADD2
      DPLU2=-QQ(6)+ADD2
      SPLU2=-QQ(4)+ADD2
      CPLU2=(-QQ(3)+ADD2)*cutcq
      if(cplu2.lt..0) cplu2=.0
      bplu2= .0*cutbq
      SING2=QQ(1)
      GLU2=QQ(7)
      UPLUS=UPLUS+UPLU2*cnp
      DPLUS=DPLUS+DPLU2*cnp
      SPLUS=SPLUS+SPLU2*cnp
      CPLUS=CPLUS+CPLU2*cnp
      bplus=bplus+bplu2*cnp
      SING=SING+SING2*cnp
      GLU=GLU+GLU2*cnp
      return
      END
c      
      FUNCTION WCM(X,Q2,m2)
      implicit real (L-M)
      CMS=m2
      cutw=0.
      if(q2/cms.lt.1.) cutw=1. 
      xth = q2/(q2+4.*cms)
      xthd = xth - .02
      if(x.lt.xth.and.x.gt.xthd) cutw=1.
      if(q2.gt.70) cutw=.0
      SC=Q2*(1.-X)/X
      BE=4.*CMS/SC
      IF(BE.GE.1.) WCM=0.
      IF(BE.GE.1.) GO TO 1
      SQ=SQRT(1.-BE)
      A1=((1.+SQ)/2.)**2 
      A2=(1.-X)/X
      WCM=(8.*(1.-X)*X-1.-be*(1.-x)**2)*SQ
      wcma= 4.*cms/q2*x*(1.-3.*x)-8.*cms**2/q2**2*x**2
      wcm=wcm+(X**2+(1.-X)**2+wcma)*ALOG(A1*A2)
      wcm = wcm +wcma*alog(q2/cms)+cutw*(x**2+(1.-x)**2)*alog(q2/cms)
      WCM=3./(3.1416*137.)*X*WCM
 1    RETURN
      END
      SUBROUTINE DIST(X,Q)
      implicit real (L-M)
      DIMENSION Q(7)
      COMMON/QS/Q2
      COMMON/Q000/Q02,q02v
      COMMON/ANEW/DELTA,deltav
      common/parel/evol,evolv
      common/alfafs/M2charm,M2bottom,M2top,Lambda4Square
      common/sseuil/sch,sbo
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2
      evolsq=evol**2
      SB=0.
      IF(Q2-Q02) 1,1,3
    3 SB=ALOG(ALOG(Q2/evolsq)/ALOG(Q02/evolsq))
    1 CONTINUE
      s0=alog(q02/evolsq)
      tch=alog(m2charm/evolsq)
      tbo=alog(m2bottom/evolsq)
      sch = alog(tch/s0)
      sbo = alog(tbo/s0)
      CALL GINTER(8,0,X,SB,Q(7))
      CALL GINTER(7,0,X,SB,SING1)
      CALL GINTER(4,0,X,SB,SPLUSNS)
      CALL GINTER(3,0,X,SB,CPLUSNS)
      CALL GINTER(5,0,X,SB,UPLUSNS)
      CALL GINTER(6,0,X,SB,DPLUSNS)
      CALL GINTER(2,0,X,SB,bPLUSNS)
      q(2)=bplusns
      Q(3)=CPLUSNS
      Q(4)=SPLUSNS
      Q(5)=UPLUSNS
      Q(6)=DPLUSNS
 8    Q(1)=SING1
      RETURN
      END
      SUBROUTINE DIST2(X,QQ)
      DIMENSION QQ(7)
      common/parel/evol,evolv
      COMMON/QS/Q2
      COMMON/Q000/Q02,q02v
      COMMON/ANEW/DELTA,deltav
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2
      evolvsq=evolv**2
      SB=0.
      IF(Q2-Q02v) 1,1,3
    3 SB=ALOG(ALOG(Q2/evolvsq)/ALOG(Q02v/evolvsq))
    1 CONTINUE
C      PROGRAM DISTL0.FOR
      CALL GINTER2(8,0,X,SB,QQ(7))
      CALL GINTER2(7,0,X,SB,SING2)
      CALL GINTER2(4,0,X,SB,SPLUSNS)
      CALL GINTER2(3,0,X,SB,CPLUSNS)
      CALL GINTER2(5,0,X,SB,UPLUSNS)
      CALL GINTER2(6,0,X,SB,DPLUSNS)
      QQ(3)=CPLUSNS
      QQ(4)=SPLUSNS
      QQ(5)=UPLUSNS
      QQ(6)=DPLUSNS
 8    QQ(1)=SING2
      RETURN
      END                                                                      
      SUBROUTINE GINTER(I,NDRV,X,S,ANS)
      DIMENSION F1(32),F2(32),F3(32),F0(32)
      COMMON/GFUNC/GF(8,35,32)
      common/sseuil/sch,sbo
      COMMON/ANEW/DELTA,deltav
      DIMENSION AF(3),AS(3)
      common/getindex/index
      index = i
      N=3
      ib=sbo/delta+1
      IS=S/DELTA+1
      is0=is-1
      IS1=IS+1
      IS2=IS1+1
      DO 1 L=1,32
      KL=L+32*NDRV
      if(is0.gt.0) then
      f0(l)=gf(i,is0,kl)
      else
      f0(l)=.0
      endif 
      F1(L)=GF(I,IS,KL)
      F2(L)=GF(I,IS1,KL)
      F3(L)=GF(I,IS2,KL)
    1 CONTINUE
      af0=getfv4(x,f0)
      AF(1)=GETFV4(X,F1)
      AF(2)=GETFV4(X,F2)
      AF(3)=GETFV4(X,F3)
      if(is.eq.ib) then
        if(s.ge.sbo) then
        af(1)=2.*af(2)-af(3)
        else
        af(2)=af(1)
        af(1)=af0
        af(3)=2.*af(2)-af(1)
        is=is-1
        endif
      endif
      AS(1)=(IS-1)*DELTA
      AS(2)=AS(1)+DELTA
      AS(3)=AS(2)+DELTA
      CALL POLINT(AS,AF,N,S,AANS,DY)
cccc----tests de precision -------------------------------
cc      absans=abs(aans)
cc      ady=abs(dy)
cc      if (ady.gt.absans/20.) print*,as(1),as(2),as(3),af(1),af(2),af(3)
cc     # ,s,x,aans,dy,i
      ANS=AANS
      RETURN
      END
      SUBROUTINE GINTER2(I,NDRV,X,S,ANS)
      DIMENSION F1(32),F2(32),F3(32)
      COMMON/GVDM/GFV(8,35,32)
      COMMON/ANEW/DELTA,deltav
      DIMENSION AF(3),AS(3)
c pas de seuil dans GINTER2, car pas de bottom dans VDM
      common/getindex/index
      index=100+i
      N=3
      IS=S/DELTAv+1
      IS1=IS+1
      IS2=IS1+1
      DO 1 L=1,32
      KL=L+32*NDRV
      F1(L)=GFV(I,IS,KL)
      F2(L)=GFV(I,IS1,KL)
      F3(L)=GFV(I,IS2,KL)
    1 CONTINUE
      AF(1)=GETFV4(X,F1)
      AF(2)=GETFV4(X,F2)
      AF(3)=GETFV4(X,F3)
      AS(1)=(IS-1)*DELTAv
      AS(2)=AS(1)+DELTAv
      AS(3)=AS(2)+DELTAv
      CALL POLINT(AS,AF,N,S,AANS,DY)
      ANS=AANS
      RETURN
      END

      SUBROUTINE WATE32
C  32 POINT GAUSSIAN QUADRATURE ROUTINE
      DIMENSION X(16),W(16)
      COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
      NTERMS=32
      X(1)=0.048307665687738316235
      X(2)=0.144471961582796493485
      X(3)=0.239287362252137074545
      X(4)=0.331868602282127649780
      X(5)=0.421351276130635345364
      X(6)=0.506899908932229390024
      X(7)=0.587715757240762329041
      X(8)=0.663044266930215200975
      X(9)=0.732182118740289680387
      X(10)=0.794483795967942406963
      X(11)=0.849367613732569970134
      X(12)=0.896321155766052123965
      X(13)=0.934906075937739689171
      X(14)=0.964762255587506430774
      X(15)=0.985611511545268335400
      X(16)=0.997263861849481563545
      W(1)=0.096540088514727800567
      W(2)=0.095638720079274859419
      W(3)=0.093844399080804565639
      W(4)=0.091173878695763884713
      W(5)=0.087652093004403811143
      W(6)=0.083311924226946755222
      W(7)=0.078193895787070306472
      W(8)=0.072345794108848506225
      W(9)=0.065822222776361846838
      W(10)=0.058684093478535547145
      W(11)=0.050998059262376176196
      W(12)=0.042835898022226680657
      W(13)=0.034273862913021433103
      W(14)=0.025392065309262059456
      W(15)=0.016274394730905670605
      W(16)=0.007018610009470096600
      DO 1 I=1,16
      XI(I)=-X(17-I)
      WI(I)=W(17-I)
      XI(I+16)=X(I)
      WI(I+16)=W(I)
    1 CONTINUE
      DO 2 I=1,32
    2 XX(I)=0.5*(XI(I)+1.)
      XX(33)=1.0
      RETURN
      END
       FUNCTION GETFV4(X,FVL)
C  NOUVEAU PROGRAMME D'INTERPOLATION UTILISANT UNE ROUTINE DE MATH. RECIPES
       DIMENSION FVL(32)
       COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
       DIMENSION A(4),B(4)
       common/getindex/index
       N=4
       EPS=1.E-7
       XAM=XX(1)-EPS
       XAP=XX(1)+EPS
       XBM=XX(32)-EPS
       IF(X.LT.XAM) PRINT*,'X trop petit','    X = ',X
       IF(X.GT.XAM.AND.X.LT.XAP) then
       getfv4=FVL(1)
       return
       endif
       IF(X.LT.XX(2)) GO TO 51
       IF(X.GT.XX(30)) GO TO 61
       DO 1 I=3,23
       IF(X.GT.XX(I)) GO TO 1
       A(1)=XX(I-1)
       A(2)=XX(I)
       A(3)=XX(I+1)
       A(4)=XX(I+2)
       B(1)=FVL(I-1)
       B(2)=FVL(I)
       B(3)=FVL(I+1)
       B(4)=FVL(I+2)
       GO TO 81
   1   CONTINUE
       DO 2 I=24,30
       IF(X.GT.XX(I)) GO TO 2
       A(1)=XX(I-2)
       A(2)=XX(I-1)
       A(3)=XX(I)
       A(4)=XX(I+1)
       B(1)=FVL(I-2)
       B(2)=FVL(I-1)
       B(3)=FVL(I)
       B(4)=FVL(I+1)
       GO TO 81
  2    CONTINUE
  61   A(1)=XX(29)
       A(2)=XX(30)
       A(3)=XX(31)
       A(4)=XX(32)
       B(1)=FVL(29)
       B(2)=FVL(30)
       B(3)=FVL(31)
       B(4)=FVL(32)
       GO  TO 81
  51   continue
       A(1)=XX(1)
       A(2)=XX(2)
       A(3)=XX(3)
       A(4)=XX(4)
       B(1)=FVL(1)
       B(2)=FVL(2)
       B(3)=FVL(3)
       B(4)=FVL(4)
 81    CONTINUE
cc-------test de precision- polintaux print l'interpolation pour x=.012 ---
c       xaux = abs(x - .012)
c       if(xaux.lt..000001) then
c          call polintaux(A,B,N,X,Y,DY) 
c          stop
c       endif
          CALL POLINT(A,B,N,X,Y,DY)
cc------- ancien appel de ratint, mais ratint produit des spikes! ------
c          CALL RATINT(A,B,N,X,Y,DY)
       RES=Y
       ares = abs(res)
       ady = abs(dy)
       ar = .0
c------- test de precision --------------------------
c       if(ares.lt.1.e-4) go to 87
c       if(ares.gt.1.e-9)       ar=ady/ares
c       if (ady.gt..03*ares) print*,'index_saveur = ',index
c       if (ady.gt..03*ares) print*,x,a(1),a(2),a(3),a(4),y
c       if (ady.gt..03*ares) print*,dy,b(1),b(2),b(3),b(4),ar
 87    GETFV4=RES
       RETURN
       END
       FUNCTION GETFV3(X,FVL)
C  NOUVEAU PROGRAMME D'INTERPOLATION UTILISANT UNE ROUTINE DE MATH. RECIPES
       DIMENSION FVL(32)
       COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
       DIMENSION A(3),B(3)
       N=3
       EPS=1.E-7
       XAM=XX(1)-EPS
       XAP=XX(1)+EPS
       XBM=XX(32)-EPS
       IF(X.LT.XAM) PRINT*,' X = ',X
       IF(X.GT.XAM.AND.X.LT.XAP) then
       getfv3=FVL(1)
       return
       endif
       IF(X.LT.XX(2)) GO TO 51
       IF(X.GT.XX(30)) GO TO 61
       DO 1 I=3,30
       IF(X.GT.XX(I)) GO TO 1
       A(1)=XX(I-2)
       A(2)=XX(I-1)
       A(3)=XX(I)
       B(1)=FVL(I-2)
       B(2)=FVL(I-1)
       B(3)=FVL(I)
       GO TO 81
   1   CONTINUE
  61   A(1)=XX(30)
       A(2)=XX(31)
       A(3)=XX(32)
       B(1)=FVL(30)
       B(2)=FVL(31)
       B(3)=FVL(32)
       GO  TO 81
  51   A(1)=XX(1)
       A(2)=XX(2)
       A(3)=XX(3)
       B(1)=FVL(1)
       B(2)=FVL(2)
       B(3)=FVL(3)
 81    CONTINUE
cc-------test de precision----------------
c       xaux = abs(x - .012)
c       if(xaux.lt..000001) then
c          call polintaux(A,B,N,X,Y,DY) 
c          stop
c       endif
          CALL POLINT(A,B,N,X,Y,DY)

c          CALL RATINT(A,B,N,X,Y,DY)

       RES=Y
       ares = abs(res)
       ady = abs(dy)
c       ar=ady/ares
c       if (ady.gt..02*ares) print*,x,a(1),a(2),a(3),y
c       if (ady.gt..02*ares) print*,dy,b(1),b(2),b(3),ar
 87    GETFV3=RES
       RETURN
       END


      SUBROUTINE POLINT(XA,YA,N,X,Y,DY)
      PARAMETER (NMAX=10)
      DIMENSION XA(N),YA(N),C(NMAX),D(NMAX)
      NS=1
      DIF=ABS(X-XA(1))
      DO 11 I=1,N
        DIFT=ABS(X-XA(I))
        IF (DIFT.LT.DIF) THEN
          NS=I
          DIF=DIFT
        ENDIF
        C(I)=YA(I)
        D(I)=YA(I)
11    CONTINUE
      Y=YA(NS)
      NS=NS-1
      DO 13 M=1,N-1
        DO 12 I=1,N-M
          HO=XA(I)-X
          HP=XA(I+M)-X
          W=C(I+1)-D(I)
          DEN=HO-HP
          IF(DEN.EQ.0.)PAUSE
          DEN=W/DEN
          D(I)=HP*DEN
          C(I)=HO*DEN
12      CONTINUE
        IF (2*NS.LT.N-M)THEN
          DY=C(NS+1)
        ELSE
          DY=D(NS)
          NS=NS-1
        ENDIF
        Y=Y+DY
13    CONTINUE
      RETURN
      END
      SUBROUTINE POLINTaux(XA,YA,N,X,Y,DY)
      PARAMETER (NMAX=10)
      DIMENSION XA(N),YA(N),C(NMAX),D(NMAX)
      print*,x,xa(1),xa(2),xa(3),ya(1),ya(2),ya(3)
      NS=1
      DIF=ABS(X-XA(1))
      print*,'dif=',dif,'   ns=',ns
      DO 11 I=1,N
        DIFT=ABS(X-XA(I))
        IF (DIFT.LT.DIF) THEN
          NS=I
          DIF=DIFT
        ENDIF
        C(I)=YA(I)
        D(I)=YA(I)
      print*,'i=',i,'   ns=',ns,'   c(i)=',c(i),'   d(i)=',d(i)
11    CONTINUE
      Y=YA(NS)
      NS=NS-1
      DO 13 M=1,N-1
        DO 12 I=1,N-M
          HO=XA(I)-X
          HP=XA(I+M)-X
          W=C(I+1)-D(I)
          DEN=HO-HP
          IF(DEN.EQ.0.)PAUSE
          DEN=W/DEN
          D(I)=HP*DEN
          C(I)=HO*DEN
       print*,'M=',m,'  I=',i,'  HO=',ho,'  HP=',hp,
     $  '  W=',w,'  DEN=',den
       print*,'C(I)=',c(i),'   D(I)=',d(i)
12      CONTINUE
        IF (2*NS.LT.N-M)THEN
          DY=C(NS+1)
        ELSE
          DY=D(NS)
          NS=NS-1
        ENDIF
        Y=Y+DY
      print*,'M=',m,'   DY=',dy,'    Y=',y
13    CONTINUE
c      stop
      RETURN
      END
      SUBROUTINE RATINT(XA,YA,N,X,Y,DY)
      PARAMETER (NMAX=10,TINY=1.E-25)                                         
      DIMENSION XA(N),YA(N),C(NMAX),D(NMAX)                                   
      NS=1                                                                    
      HH=ABS(X-XA(1))                                                         
      DO 11 I=1,N                                                             
        H=ABS(X-XA(I))                                                        
        IF (H.EQ.0.)THEN                                                      
          Y=YA(I)                                                             
          DY=0.0                                                              
          RETURN                                                              
        ELSE IF (H.LT.HH) THEN                                                
          NS=I                                                                
          HH=H                                                                
        ENDIF                                                                 
        C(I)=YA(I)                                                            
        D(I)=YA(I)+TINY                                                       
11    CONTINUE                                                                
      Y=YA(NS)                                                                
      NS=NS-1                                                                 
      DO 13 M=1,N-1                                                           
        DO 12 I=1,N-M                                                         
          W=C(I+1)-D(I)                                                       
          H=XA(I+M)-X                                                         
          T=(XA(I)-X)*D(I)/H                                                  
          DD=T-C(I+1)                                                         
          IF(DD.EQ.0.)PAUSE                                                   
          DD=W/DD                                                             
          D(I)=C(I+1)*DD                                                      
          C(I)=T*DD                                                           
12      CONTINUE                                                              
        IF (2*NS.LT.N-M)THEN                                                  
          DY=C(NS+1)                                                          
        ELSE                                                                  
          DY=D(NS)                                                            
          NS=NS-1                                                             
        ENDIF                                                                 
        Y=Y+DY                                                                
13    CONTINUE                                                                
      RETURN                                                                  
      END                                                                     

c to fix flavors

	 subroutine alphaS2nf(scale2)

                implicit real (l-m)
		
		common/alfafs/M2charm,M2bottom,M2top,Lambda4Square
	
		! uses
		! internals
                common/flav/fflavor
c
 	if (scale2 .gt. M2bottom) then
                fflavor=5.
	elseif (scale2 .gt. M2charm) then
                fflavor=4.
	else
                fflavor=3.
	endif

	end



