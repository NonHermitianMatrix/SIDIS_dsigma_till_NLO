      ! interface for the photon structure function of afg
c 27.09.01 name of subroutine polint changed to polintafg to avoid 
c multiply defined names when loading pdflib     
      subroutine Init_afg

	real calc(8,20,32)
	common /gfunc/ calc
	
	real celc(8,20,32)
	common /gvdm/ celc
	
	real par(30), par2(30)
	CHARACTER*128 PATH_PDF
	common /gpar/ par, par2
	COMMON/CHEMINPDF/PATH_PDF
	COMMON/LONGPPDF/ILENPPDF
	
	open(11, file=PATH_PDF(1:ILENPPDF)//'afg/GRPOL',status='old')
	open(22, file=PATH_PDF(1:ILENPPDF)//'afg/GRVDM',status='old')
c	open(11, file='GRPOL',status='old')
c	open(22, file='GRVDM',status='old')
	read(11,*) par
	read(11,'(8E15.4)') calc
	read(22,*) par2
	read(22,'(8E15.4)') celc
	close(11)
	close(22)
      
      end
      
      SUBROUTINE  AFGDIST(XG,M2,DXPDF)
      REAL*8 XG,M2,DXPDF(-6:6)
      COMMON/GPAR/PAR(30),PAR2(30) 
      DIMENSION Q(7),QQ(7)
      COMMON/ANEW/DELTA
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2,RLAM,RLAM2
      COMMON/QS/Q2
      COMMON/Q000/Q02
      COMMON/GFUNC/CALC(8,20,32)
      COMMON/GVDM/CELC(8,20,32)
      COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
      COMMON/CHARM/CM
      REAL KA
C   SET UP FLAGS, I/O FILES, ETC.
C
C   STRUCTURE FUNCTIONS CONVENTIONS
C   IORD=0                     LEADING ORDER
C   IORD=1             NEXT TO LEADING ORDER
C
 
       KA=1.0
cc	ka=0.0 !kill the vdm part
      
C*****mass of the charm quark******************************************
      CM=1.41
C
C******The parameters are fixed in the file GRPOL**********************     
C
      IORD=INT(PAR(28)+1.E-7)
      FLAV=PAR(25)
      DELTA=PAR(29)
      OWLAM=PAR(1)
      OWLAM2=OWLAM**2
      Q02=PAR(30)
      CALL WATE32
      Q2=M2
      X=XG
      CALL DIST(X,Q)
      ADD=Q(1)/FLAV
      UPLUS=Q(5)+ADD
      DPLUS=-Q(4)+ADD
      SPLUS=-Q(6)+ADD
      CPLUS=-Q(3)+ADD
      SING=Q(1)
      GLU=Q(7)         
      CALL DIST2(X,QQ)
      ADD2=QQ(1)/FLAV
      UPLU2=QQ(5)+ADD2
      DPLU2=-QQ(4)+ADD2
      SPLU2=-QQ(6)+ADD2
      CPLU2=-QQ(3)+ADD2
      SING2=QQ(1)
      GLU2=QQ(7)
      UPLUS=UPLUS+UPLU2*KA
      DPLUS=DPLUS+DPLU2*KA
      SPLUS=SPLUS+SPLU2*KA
      CPLUS=CPLUS+CPLU2*KA
      SING=SING+SING2*KA
      GLU=GLU+GLU2*KA
      DXPDF(0)=GLU
      DXPDF(1)=DPLUS/2.
      DXPDF(2)=UPLUS/2.
      DXPDF(3)=SPLUS/2.
      DXPDF(4)=CPLUS/2.
      DXPDF(-1)=DXPDF(1)
      DXPDF(-2)=DXPDF(2)
      DXPDF(-3)=DXPDF(3)
      DXPDF(-4)=DXPDF(4)       
      RETURN
      END
c      
      SUBROUTINE DIST(X,Q)
      DIMENSION Q(7)
      COMMON/QS/Q2
      COMMON/Q000/Q02
      COMMON/ANEW/DELTA
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2,RLAM,RLAM2
      SB=0.
      IF(Q2-Q02) 1,1,3
    3 SB=ALOG(ALOG(Q2/OWLAM2)/ALOG(Q02/OWLAM2))
    1 CONTINUE
C      PROGRAM DISTL0.FOR
      CALL GINTER(8,0,X,SB,Q(7))
      CALL GINTER(7,0,X,SB,SING)
      CALL GINTER(4,0,X,SB,DPLUSNS)
      CALL GINTER(3,0,X,SB,CPLUSNS)
      CALL GINTER(5,0,X,SB,UPLUSNS)
      CALL GINTER(6,0,X,SB,SPLUSNS)
      Q(3)=CPLUSNS
      Q(4)=DPLUSNS
      Q(5)=UPLUSNS
      Q(6)=SPLUSNS
 8    Q(1)=SING
      RETURN
      END
c      
      SUBROUTINE DIST2(X,QQ)
      DIMENSION QQ(7)
      COMMON/QS/Q2
      COMMON/Q000/Q02
      COMMON/ANEW/DELTA
      COMMON/CONV/ IORD,ICONV,OWLAM,OWLAM2,RLAM,RLAM2
      SB=0.
      IF(Q2-Q02) 1,1,3
    3 SB=ALOG(ALOG(Q2/OWLAM2)/ALOG(Q02/OWLAM2))
    1 CONTINUE
C      PROGRAM DISTL0.FOR
      CALL GINTER2(8,0,X,SB,QQ(7))
      CALL GINTER2(7,0,X,SB,SING)
      CALL GINTER2(4,0,X,SB,DPLUSNS)
      CALL GINTER2(3,0,X,SB,CPLUSNS)
      CALL GINTER2(5,0,X,SB,UPLUSNS)
      CALL GINTER2(6,0,X,SB,SPLUSNS)
      QQ(3)=CPLUSNS
      QQ(4)=DPLUSNS
      QQ(5)=UPLUSNS
      QQ(6)=SPLUSNS
 8    QQ(1)=SING
      RETURN
      END 
c                                                                           
      SUBROUTINE GINTER(I,NDRV,X,S,ANS)
      DIMENSION F1(32),F2(32),F3(32)
      COMMON/GFUNC/GF(8,20,32)
      COMMON/ANEW/DELTA
      DIMENSION AF(3),AS(3)
      N=3
      IS=S/DELTA+1
      IS1=IS+1
      IS2=IS1+1
      DO 1 L=1,32
      KL=L+32*NDRV
      F1(L)=GF(I,IS,KL)
      F2(L)=GF(I,IS1,KL)
      F3(L)=GF(I,IS2,KL)
    1 CONTINUE
      AF(1)=GETFV(X,F1)
      AF(2)=GETFV(X,F2)
      AF(3)=GETFV(X,F3)
      AS(1)=(IS-1)*DELTA
      AS(2)=AS(1)+DELTA
      AS(3)=AS(2)+DELTA
      CALL POLINTAFG(AS,AF,N,S,AANS,DY)
      ANS=AANS
      RETURN
c      
      END
      SUBROUTINE GINTER2(I,NDRV,X,S,ANS)
      DIMENSION F1(32),F2(32),F3(32)
      COMMON/GVDM/GFV(8,20,32)
      COMMON/ANEW/DELTA
      DIMENSION AF(3),AS(3)
      N=3
      IS=S/DELTA+1
      IS1=IS+1
      IS2=IS1+1
      DO 1 L=1,32
      KL=L+32*NDRV
      F1(L)=GFV(I,IS,KL)
      F2(L)=GFV(I,IS1,KL)
      F3(L)=GFV(I,IS2,KL)
    1 CONTINUE
      AF(1)=GETFV(X,F1)
      AF(2)=GETFV(X,F2)
      AF(3)=GETFV(X,F3)
      AS(1)=(IS-1)*DELTA
      AS(2)=AS(1)+DELTA
      AS(3)=AS(2)+DELTA
      CALL POLINTAFG(AS,AF,N,S,AANS,DY)
      ANS=AANS
      RETURN
      END

      SUBROUTINE WATE32
C  32 POINT GAUSSIAN QUADRATURE ROUTINE
      DIMENSION X(16),W(16)
      COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
      NTERMS=32
      X(1)=0.048307665687738316235
      X(2)=0.144471961582796493485
      X(3)=0.239287362252137074545
      X(4)=0.331868602282127649780
      X(5)=0.421351276130635345364
      X(6)=0.506899908932229390024
      X(7)=0.587715757240762329041
      X(8)=0.663044266930215200975
      X(9)=0.732182118740289680387
      X(10)=0.794483795967942406963
      X(11)=0.849367613732569970134
      X(12)=0.896321155766052123965
      X(13)=0.934906075937739689171
      X(14)=0.964762255587506430774
      X(15)=0.985611511545268335400
      X(16)=0.997263861849481563545
      W(1)=0.096540088514727800567
      W(2)=0.095638720079274859419
      W(3)=0.093844399080804565639
      W(4)=0.091173878695763884713
      W(5)=0.087652093004403811143
      W(6)=0.083311924226946755222
      W(7)=0.078193895787070306472
      W(8)=0.072345794108848506225
      W(9)=0.065822222776361846838
      W(10)=0.058684093478535547145
      W(11)=0.050998059262376176196
      W(12)=0.042835898022226680657
      W(13)=0.034273862913021433103
      W(14)=0.025392065309262059456
      W(15)=0.016274394730905670605
      W(16)=0.007018610009470096600
      DO 1 I=1,16
      XI(I)=-X(17-I)
      WI(I)=W(17-I)
      XI(I+16)=X(I)
      WI(I+16)=W(I)
    1 CONTINUE
      DO 2 I=1,32
    2 XX(I)=0.5*(XI(I)+1.)
      XX(33)=1.0
      RETURN
      END
       FUNCTION GETFV(X,FVL)
C  NOUVEAU PROGRAMME D'INTERPOLATION UTILISANT UNE ROUTINE DE MATH. RECIPES
       DIMENSION FVL(32)
       COMMON/GAUS32/XI(32),WI(32),NTERMS,XX(33)
       DIMENSION A(4),B(4)
       N=4
       EPS=1.E-7
       XAM=XX(1)-EPS
       XAP=XX(1)+EPS
       !!!!!! IF(X.LT.XAM) PRINT*,' X = ',X
       IF(X.LT.XAM) goto 51
       IF(X.GT.XAM.AND.X.LT.XAP) GO TO 50
       GO TO 80
   50  Y=FVL(1)
       GO TO 77
   80  IF(X.LT.XX(2)) GO TO 51
       IF(X.GT.XX(30)) GO TO 61
       DO 1 I=3,30
       IF(X.GT.XX(I)) GO TO 1
       A(1)=XX(I-2)
       A(2)=XX(I-1)
       A(3)=XX(I)
       A(4)=XX(I+1)
       B(1)=FVL(I-2)
       B(2)=FVL(I-1)
       B(3)=FVL(I)
       B(4)=FVL(I+1)
       GO TO 70
   1   CONTINUE
  61   A(1)=XX(29)
       A(2)=XX(30)
       A(3)=XX(31)
       A(4)=XX(32)
       B(1)=FVL(29)
       B(2)=FVL(30)
       B(3)=FVL(31)
       B(4)=FVL(32)
       GO  TO 70
  51   A(1)=XX(1)
       A(2)=XX(2)
       A(3)=XX(3)
       A(4)=XX(4)
       B(1)=FVL(1)
       B(2)=FVL(2)
       B(3)=FVL(3)
       B(4)=FVL(4)
  70   CONTINUE
C 70   IF(X.GT..2.AND.X.LT..8) THEN
             CALL POLINTAFG(A,B,N,X,Y,DY)
C      ELSE
C            CALL RATINT(A,B,N,X,Y,DY)
C      ENDIF
  77   GETFV=Y
       RETURN
       END
 
      SUBROUTINE POLINTAFG(XA,YA,N,X,Y,DY)                                       
      PARAMETER (NMAX=10)                                                     
      DIMENSION XA(N),YA(N),C(NMAX),D(NMAX)                                   
      NS=1                                                                    
      DIF=ABS(X-XA(1))                                                        
      DO 11 I=1,N                                                             
        DIFT=ABS(X-XA(I))                                                     
        IF (DIFT.LT.DIF) THEN                                                 
          NS=I                                                                
          DIF=DIFT                                                            
        ENDIF                                                                 
        C(I)=YA(I)                                                            
        D(I)=YA(I)                                                            
11    CONTINUE                                                                
      Y=YA(NS)                                                                
      NS=NS-1                                                                 
      DO 13 M=1,N-1                                                           
        DO 12 I=1,N-M                                                         
          HO=XA(I)-X                                                          
          HP=XA(I+M)-X                                                        
          W=C(I+1)-D(I)                                                       
          DEN=HO-HP                                                           
          IF(DEN.EQ.0.)PAUSE                                                  
          DEN=W/DEN                                                           
          D(I)=HP*DEN                                                         
          C(I)=HO*DEN                                                         
12      CONTINUE                                                              
        IF (2*NS.LT.N-M)THEN                                                  
          DY=C(NS+1)                                                          
        ELSE                                                                  
          DY=D(NS)                                                            
          NS=NS-1                                                             
        ENDIF                                                                 
        Y=Y+DY                                                                
13    CONTINUE                                                                
      RETURN                                                                  
      END                                                                     
