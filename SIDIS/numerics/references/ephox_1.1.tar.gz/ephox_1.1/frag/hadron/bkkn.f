c parametrisation des pion et des kaons a la Binnewies et al.: 
c Phys. Rev 52 p4947
C
      SUBROUTINE FONFRAPI(XC,IPION,QP2,XDUP,XDUBP,XDDP,XDDBP,XDSP,XDCP,
     # XDBP,XDBBP,XDTP,XDTBP,XDGP)
      IMPLICIT REAL*8 (A-H,L-Z)
C IPION=1 LO FRAGMENTATION FOR (PI^+ + PI^-)/2
C IPION=2 NLO FRAGMENTATION FOR (PI^+ + PI^-)/2
      IF (IPION.EQ.1) THEN      
        LAMBDA2 = (.108)**2
      ELSE IF (IPION.EQ.2) THEN
        LAMBDA2 = (.227)**2
      ENDIF
      Q02 = 2.D0
      Q02C = 2.9788**2
      Q02B = 9.46037**2
      SB = DLOG( DLOG(QP2/LAMBDA2) /  DLOG(Q02/LAMBDA2) )
      IF (QP2.GE.Q02C) THEN
        SBC = DLOG( DLOG(QP2/LAMBDA2) /  DLOG(Q02C/LAMBDA2) )
      ELSE
        SBC = 0.D0
      ENDIF
      IF (QP2.GE.Q02B) THEN
        SBB = DLOG( DLOG(QP2/LAMBDA2) /  DLOG(Q02B/LAMBDA2) )
      ELSE
        SBB = 0.D0
      ENDIF
      IPI = IPION 
      IF (IPI.EQ.1) THEN
C IPION=1 LO FRAGMENTATION FOR (PI^+ + PI^-)
C  PARAMETRES DE LA VALENCE 
        NV = 1.090 - 1.198*SB + 0.757*SB**2 - 0.179*SB**3
        ALV = -0.850 - 1.007*SB + 0.434*SB**2
        BEV = 1.440 + 0.321*SB + 0.176*SB**2
        GAV = 0.
C  PARAMETRES DE LA MER 
        NS = 3.480 - 2.463*SB + 0.523*SB**2
        ALS = -1.030 - 0.362*SB + 0.030*SB**2
        BES = 3.900 + 0.833*SB - 0.056*SB**2
        GAS = 0.
C  PARAMETRES DU CHARME 
        NC = 4.510 - 3.933*SBC + 1.156*SBC**2
        ALC = -0.860 - 0.441*SBC + 0.043*SBC**2
        BEC = 4.530 + 0.752*SBC - 0.040*SBC**2
        GAC = 0.
C  PARAMETRES DU BOTTOM 
        NB = 3.600 - 6.873*SBB + 8.697*SBB**2 - 5.258*SBB**3
        ALB = -1.120 - 0.743*SBB + 0.367*SBB**2 + 0.075*SBB**3
        BEB = 7.120 - 0.596*SBB + 1.698*SBB**2 - 0.759*SBB**3
        GAB = 0.
C  PARAMETRES DE LA GLUE
        NG = 6.570 - 9.142*SB + 2.431*SB**2 + 0.681*SB**3
        ALG = -0.460 - 0.118*SB + 0.530*SB**2 - 0.720*SB**3
        BEG = 3.010 + 1.924*SB + 0.247*SB**2 - 0.731*SB**3
        GAG = 0.256*SB + 0.458*SB**2
      ELSE IF (IPI.EQ.2) THEN
C IPION=2 NLO FRAGMENTATION FOR (PI^+ + PI^-)
C  PARAMETRES DE LA VALENCE 
        NV = 1.150 - 1.522*SB + 1.378*SB**2 - 0.527*SB**3
        ALV = -0.740 - 1.680*SB + 1.546*SB**2 - 0.596*SB**3
        BEV = 1.430 + 0.543*SB - 0.023*SB**2
        GAV = 0.
C  PARAMETRES DE LA MER 
        NS = 4.250 - 3.147*SB + 0.755*SB**2
        ALS = -0.770 - 0.573*SB + 0.117*SB**2
        BES = 4.480 + 0.890*SB - 0.138*SB**2
        GAS = 0.
C  PARAMETRES DU CHARME 
        NC = 3.990 - 3.321*SBC + 0.925*SBC**2
        ALC = -0.790 - 0.520*SBC + 0.081*SBC**2
        BEC = 4.780 + 0.716*SBC - 0.075*SBC**2
        GAC = 0.
C  PARAMETRES DU BOTTOM 
        NB = 4.010 - 13.199*SBB + 18.208*SBB**2 - 6.536*SBB**3
        ALB = -1.030 - 1.931*SBB - 1.372*SBB**2 + 5.020*SBB**3
        BEB = 7.860 - 2.224*SBB + 0.206*SBB**2 + 4.215*SBB**3
        GAB = -0.179*SBB + 0.205*SBB**2
C  PARAMETRES DE LA GLUE 
        NG = 5.530 - 9.228*SB + 5.192*SB**2 - 0.966*SB**3
        ALG = -0.320 + 0.318*SB - 0.561*SB**2
        BEG = 2.700 + 2.553*SB - 0.907*SB**2
        GAG = 0.751*SB + 0.496*SB**2
      ENDIF
      DV = NV*XC**ALV*(1.D0-XC)**BEV*(1.D0+GAV/XC)
      DS = NS*XC**ALS*(1.D0-XC)**BES*(1.D0+GAS/XC)
      IF (QP2.GE.Q02C) THEN
        DC = NC*XC**ALC*(1.D0-XC)**BEC*(1.D0+GAC/XC)
      ELSE
        DC = 0.D0
      ENDIF
      IF (QP2.GE.Q02B) THEN
        DB = NB*XC**ALB*(1.D0-XC)**BEB*(1.D0+GAB/XC)
      ELSE
        DB = 0.D0
      ENDIF
      DG = NG*XC**ALG*(1.D0-XC)**BEG*(1.D0+GAG/XC)
C
      XDUP = XC*DV/2.D0 
      XDUBP = XDUP 
      XDDP = XC*DV/2.D0  
      XDDBP = XDDP
      XDSP = XC*DS/2.D0 
      XDCP = XC*DC/2.D0 
      XDBP = XC*DB/2.D0  
      XDBBP = XDBP 
      XDTP = 0.D0 
      XDTBP = 0.D0
      XDGP = XC*DG/2.D0 
      RETURN
      END
