c this is final version of DIR_SUB to be compiled by Makefile in working/
c 02.12.02 include jet and isol in cone subtraction term in 2->3 parts
c 26.11.02: change jet definition, cut_jets now included in jet_definition,
c yjet_lead,ptjet_lead passed in common, not redefined for x_gam^obs
c 10.01.02: include new jet subroutine
c 21.12.01 replace all VEC_$DMULT etc. with VEC_DMULT since new compiler 
c does not accept it 
c 20.12.01: split doubletosingle from this subroutine (now in 
c src/histo/, double precision for histo_selection input, single for ntuple)
c (choice which one is loaded made in Makefile)
c iprov,ntrack passed as arguments of doubletosingle
c merging, acceptance added to common algorithme
c 03.10.01: isolation included on integration level 
c (done before only in frag parts where lower bound on z4 is changed by iso)
c 16.05.01: 5||1 and 5||2 split into two functions to be able to define eta 
c 02.05.01: difference to photpro_phoj_dir_ori.f: common added with 
c ptj_lead and yj_lead of jet which serves to define x_gam^obs
c 26.02.01: jets included (with on/off flag to comprise inclusive case)
c !!! photon changed to particle 3 in event generation !!!!! 8.12.00
c starting point le 07/04/00
C changed to photoproduction  17.08.00 
C changes: crossing in initial state removed,WW,IH1,K0max,alpha_em,..
C 
	SUBROUTINE DIR_SUB
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL LO,NLO,GENER,INTEG,INTEGA
	integer*4 ntrack,iprov
	CHARACTER*128 PATH_BSFILE
        PARAMETER (IRANDOM=500)
	COMMON/NPT/INPT
	COMMON/BPARM1/XL(50),XU(50),IDIM,IWILD,IG(50),ICALL
	COMMON/BPARM2/ACC1,ACC2,ITMX1,ITMX2
	COMMON/BORN/IBORN
	COMMON/BOX/IBOX
	COMMON/BASPRING/ISPRING
	COMMON/APPROX/LO,NLO
	COMMON/CALCUL/INTEG,INTEGA,GENER
	COMMON/NBEVENT/INBEVENT
	COMMON/BASEPARAM/JTMX1,JTMX2,JCALL,JCALL1,JCALL2,IXTRY
	COMMON/ACCURACY/ACCU
	COMMON/PROCESSD/J_PROCESSD_MIN,J_PROCESSD_MAX
	COMMON/RANDD/RNUMB
	COMMON/CHEMINBS/PATH_BSFILE
	COMMON/LONG/ILEN
	DIMENSION WRVEC(IRANDOM),WRVEC1(IRANDOM)
	EXTERNAL F4DIMD3,F4DIMD4,F2DIMD1,F2DIMD2,F2DIMD3,F1DIMD
c
	PI=DATAN(1.D0)*4.D0
ccccccccccccccccccccccccccccccccccccccccccccccccc
c       BORN 
cccccccccccccccccccccccccccccccccccccccccccccccccc
	IF (LO) THEN
	IBORN = 1
cccc
	if (j_processd_min.eq.2.and.j_processd_max.eq.2.
     #	and.ibox.eq.0) then
	RESFB = 0
	SDFB = 0
	else
	IF (INTEGA.OR.INTEG) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 3
	IWILD = 3
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
	CALL BASES (F1DIMD,RESFB,SDFB,CTIME,IT1,IT2)
C on ecrit la grille
c debug
c	write(*,*) 'here4'
c	  open(UNIT=4,FILE='/scratch/try.bs',STATUS='UNKNOWN')
c     #     ,FORM='UNFORMATTED')
c	write(4,*) ' writing to 4 after bases call'
c 	CLOSE(4)
c	write(*,*) 'after4'
c
        IF (INTEGA) THEN
	  OPEN(UNIT=33,FILE=PATH_BSFILE(1:ILEN)//'twopart2.bs',
     #	  STATUS='UNKNOWN',FORM='UNFORMATTED')
	  CALL BSWRIT(33)
	  CLOSE(33)
	ENDIF  
C	
	ENDIF
c&&&
c
c&&&
	endif
cccc
	ENDIF
cccc	
C******************************************************************
C       Partie 2 --> 3
C******************************************************************
cccc
	IF (NLO) THEN
cccc
	IBORN = 0
c	 
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 6
	IWILD = 6
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	CALL BASES (F4DIMD3,RESF34,SDF34,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 6
	IWILD = 6
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	CALL BASES (F4DIMD3,RESF34,SDF34,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(18,FILE=PATH_BSFILE(1:ILEN)//'threepart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(18)
	CLOSE(18)
C	
	ENDIF
c###
C
c###
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 6
	IWILD = 6
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	CALL BASES (F4DIMD4,RESF44,SDF44,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 6
	IWILD = 6
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	CALL BASES (F4DIMD4,RESF44,SDF44,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(19,FILE=PATH_BSFILE(1:ILEN)//'threepart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(19)
	CLOSE(19)
C	
	ENDIF
c###
C******************************************************************
C       Partie 2 --> 2 colineaire
C******************************************************************
C       5||1:
c
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMD1,RESF21,SDF21,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMD1,RESF21,SDF21,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(21,FILE=PATH_BSFILE(1:ILEN)//'qtwopart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(21)
	CLOSE(21)
C	
	ENDIF
c###
c       5 || 2:
c###
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMD2,RESF22,SDF22,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMD2,RESF22,SDF22,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(22,FILE=PATH_BSFILE(1:ILEN)//'qtwopart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(22)
	CLOSE(22)
C	
	ENDIF
c###
C
c###
c     collinear to final
c

	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMD3,RESF23,SDF23,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMD3,RESF23,SDF23,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(23,FILE=PATH_BSFILE(1:ILEN)//'qtwopart3.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(23)
	CLOSE(23)
C	
	ENDIF
c&&&
c
c&&&
c	ENDIF
c###
C
C******************************************************************
C       Partie 2 --> 2 virtuelle et born
C******************************************************************
c&&&
c
c&&&
	if (j_processd_min.eq.2.and.j_processd_max.eq.2) then
	  RESF1 = 0
	  SDF1 = 0
	else
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 3
	IWILD = 3
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
	CALL BASES (F1DIMD,RESF1,SDF1,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 3
	IWILD = 3
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
	CALL BASES (F1DIMD,RESF1,SDF1,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(20,FILE=PATH_BSFILE(1:ILEN)//'twopart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(20)
	CLOSE(20)
C	
	ENDIF !end IF intega
c&&&
	endif ! end if processd_min = 2 
c###
C
cccc
	ENDIF  ! end IF NLO
cccc
cccc
C******************************************************************
C       calcul de la section efficace totale ordre superieur
C******************************************************************
	IF (INTEG) THEN
	  RESF2 = RESF21+RESF22+RESF23
	  SDF2 = SDF21+SDF22+SDF23
C
	  RESHO = RESF34+RESF44+RESF2+RESF1
	  SDHO =  SDF34+SDF44+SDF2+SDF1
	  RESB = RESFB
	  SDFB = SDFB
	  RESSUM = RESB+RESHO
	  SDSUM = SDFB+SDHO
	  WRITE (8,*) 'CCCCCCCCCCCCCCCCCCCCCC'
	  WRITE (8,*) 'BORN',RESFB,' SDFB',SDFB
	  WRITE (8,*) 'H.O.',RESHO,' SDFHO',SDHO
	  WRITE (8,*) 'CCCCCCCCCCCCCCCCCCCCCC'
c	  open (15,file='separate.res',status='unknown') 
	  WRITE (8,*) 'separate results:'
	  WRITE (8,*) 'RESF34',RESF34,' SDF34',SDF34
	  WRITE (8,*) 'RESF44',RESF44,' SDF44',SDF44
	  WRITE (8,*) 'RESF21',RESF21,' SDF21',SDF21
	  WRITE (8,*) 'RESF22',RESF22,' SDF22',SDF22
	  WRITE (8,*) 'RESF23',RESF23,' SDF23',SDF23
	  WRITE (8,*) 'RESF1',RESF1,' SDF1',SDF1
	  WRITE (8,*) 'ccccccccccccccccccccccccccc'
	  WRITE (8,*) 'Born+H.O.',RESSUM,' SDSUM',SDSUM
	  WRITE (8,*) 'ccccccccccccccccccccccccccc'
c	  close(15)
	ENDIF
C******************************************************************
C       calcul du nombre d'evenements a generer pour chacune des
C       parties
C******************************************************************
	IF (INTEGA) THEN
	  IF (NLO) THEN
	    RESF2 = RESF21+RESF22+RESF23
	    TOTHO = RESF34+RESF44+RESF2+RESF1
	  ELSE
	    TOTHO = 0.D0
	  ENDIF
	  IF (LO) THEN
	    TOTB = RESFB
	  ELSE
	    TOTB = 0.D0
	  ENDIF
	  TOT = TOTHO + TOTB
	  IF (TOT.EQ.0.D0) THEN
	    WRITE (8,*) 'TOT=0. JOB FINISHED'
	    RETURN
	  ENDIF
	  OPEN(4,FILE=PATH_BSFILE(1:ILEN)//'integral.res',
     #	  STATUS='UNKNOWN')
	  WRITE(4,*) RESF34, RESF44
	  WRITE(4,*) RESF21, RESF22, RESF23
	  WRITE(4,*) RESF1, RESFB
	  WRITE(4,*) TOT
	  CLOSE(4)	  
	ENDIF
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc              generation des evenements                     ccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
C******************************************************************
cccc
	IF (GENER) THEN
cccc
	OPEN(14,FILE=PATH_BSFILE(1:ILEN)//'integral.res',
     #	STATUS='UNKNOWN')
	READ(14,*) RESF34, RESF44
	READ(14,*) RESF21, RESF22, RESF23
	READ(14,*) RESF1,RESFB
	READ(14,*) TOT
	CLOSE(14)
	XNORM = DFLOAT(INBEVENT)/TOT
c###	  
c   saves for normalization
        WRITE(12,100) INBEVENT,TOT
100     FORMAT(1X,I12,D12.5)
cccc
	IF (NLO) THEN
cccc
c        goto 111
c
	IBORN = 0
c
	ISPRING = 2
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 6
	IWILD = 6
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF34*XNORM)
c
	OPEN(18,FILE=PATH_BSFILE(1:ILEN)//'threepart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(18)
	CLOSE(18)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : 3 partons : 5//3'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 34
        NTRACK = 3
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
            CALL RANLUX(WRVEC,IRANDOM)
            CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB = DBLE(WRVEC(I1+1))
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F4DIMD3,IXTRY)
	  CALL DOUBLETOSINGLED(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
C
C
c###
	ISPRING = 2
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 6
	IWILD = 6
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF44*XNORM)
c
	OPEN(19,FILE=PATH_BSFILE(1:ILEN)//'threepart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(19)
	CLOSE(19)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : 3 partons : 5//4'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 44
        NTRACK = 3
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
            CALL RANLUX(WRVEC,IRANDOM)
            CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB = DBLE(WRVEC(I1+1))
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F4DIMD4,IXTRY)
	  CALL DOUBLETOSINGLED(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	 ENDDO
c###
C
c###
	ISPRING = 2
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF21*XNORM)
c
	OPEN(21,FILE=PATH_BSFILE(1:ILEN)//'qtwopart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(21)
	CLOSE(21)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation: quasi 2 partons : col.ini 5||1'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 21
        NTRACK = 2
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
            CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F2DIMD1,IXTRY)
	  CALL DOUBLETOSINGLED(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
c
	ISPRING = 2
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF22*XNORM)
c
	OPEN(22,FILE=PATH_BSFILE(1:ILEN)//'qtwopart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(22)
	CLOSE(22)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation: quasi 2 partons : col.ini 5||2'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 22
        NTRACK = 2
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
            CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F2DIMD2,IXTRY)
	  CALL DOUBLETOSINGLED(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO	
c###
C
c###
	ISPRING = 2
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	  INBREALEVENT = INT(RESF23*XNORM)
c
	  OPEN(23,FILE=PATH_BSFILE(1:ILEN)//'qtwopart3.bs',
     #	  STATUS='UNKNOWN',FORM='UNFORMATTED')
	  CALL BSREAD(23)
	  CLOSE(23)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : quasi 2 partons : col. fi4'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
          IPROV = 23
          NTRACK = 2
          POID = 1.D0
	  DO I = 1,INBREALEVENT
	    I1 = MOD(I-1,IRANDOM)
	    IF (I1.EQ.0) THEN
              CALL RANLUX(WRVEC1,IRANDOM)
            ENDIF
	    RNUMB1 = DBLE(WRVEC1(I1+1))
	    CALL SPRING(F2DIMD3,IXTRY)
	    CALL DOUBLETOSINGLED(RNUMB1,PI,POID,iprov,ntrack)
	    CALL GFILL
	  ENDDO
c	ENDIF
c###
c 111    continue
c###
	ISPRING = 2
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 3
	IWILD = 3
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
	  INBREALEVENT = INT(RESF1*XNORM)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : 2 partons : virtuelle'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)	
c
	if (INBREALEVENT.eq.0) then
	   goto 112
	else
c
	  OPEN(20,FILE=PATH_BSFILE(1:ILEN)//'twopart1.bs',
     #	  STATUS='UNKNOWN',FORM='UNFORMATTED')
	  CALL BSREAD(20)
	  CLOSE(20)
          IPROV = 10
          NTRACK = 2
          POID = 1.D0
	  DO I = 1,INBREALEVENT
	    I1 = MOD(I-1,IRANDOM)
	    IF (I1.EQ.0) THEN
              CALL RANLUX(WRVEC1,IRANDOM)
            ENDIF
	    RNUMB1 = DBLE(WRVEC1(I1+1))
	    CALL SPRING(F1DIMD,IXTRY)
	    CALL DOUBLETOSINGLED(RNUMB1,PI,POID,iprov,ntrack)
	    CALL GFILL
	  ENDDO
	endif
c###
 112    continue
cccc
	ENDIF
cccc
c###
	IF (LO) THEN
c###
	INBREALEVENT = INT(RESFB*XNORM)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : 2 partons : born'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
	if (INBREALEVENT.eq.0) then
	   goto 113
	else
c	
	IBORN = 1
	ISPRING = 2
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 3
	IWILD = 3
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
c
	OPEN(33,FILE=PATH_BSFILE(1:ILEN)//'twopart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(33)
	CLOSE(33)
        IPROV = 11
        NTRACK = 2
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
            CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F1DIMD,IXTRY)
	  CALL DOUBLETOSINGLED(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
        endif  ! end if inbrealevent=0
 113	continue
	ENDIF  ! end If (LO)
cccc
	ENDIF  ! end if GENER
cccc
	RETURN
	END
C
C*****************************************************
C  Partie ou PT5 < PTM
C*****************************************************
C INTEGRALE A 4 DIMENSIONS
	DOUBLE PRECISION FUNCTION F4DIMD3(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/COUP/PTM,R
	COMMON/ALEM/ILOOPEM
	COMMON/SCALE/M,MF,MU
	COMMON/FACONV/HC2
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSD/J_PROCESSD_MIN,J_PROCESSD_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	COMMON/RANDD/RNUMB
	COMMON/FICUT/FIMIN
	common/isophot/iphotisol
	common/COUP_HISTO/R_ISOL,EPSILON_H	
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	DIMENSION XX(20)
	PARAMETER (K0MAX=2)
	DIMENSION SF0(K0MAX),CAMP0(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX),SPCOU(K0MAX)
	DIMENSION P1(4),P2(4),P3(4),P4(4),P5(4)
	DIMENSION P1P(4),P2P(4),P3P(4),P5P(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ PT5 --------------------------------------------
c x1c_min = pt5/dsqrt(s)*exp(y3) + gpt4/dsqrt(s)*exp(y4)
c x2c_min = pt5/dsqrt(s)*exp(-y3) + gpt4/dsqrt(s)*exp(-y4)
c Comme pt5**2 <= S*(1-x1c)*(1-x2c), on a donc
c pt5**2 <= S*(1-x1c_min)*(1-x2c_min) d'ou
c pt5 <= (S + gpt4**2 -2*rs*gpt4*cosh(y4))/
c (2*(rs*cosh(y3)-gpt4*cosh(y3-y4))))
	pt5max1 = (dsqrt(s)-gpt4*dexp(y4))*dexp(-y3)
	pt5max2 = (dsqrt(s)-gpt4*dexp(-y4))*dexp(y3)
	at1 = 2.d0*(dsqrt(s)*dcosh(y3)-gpt4*dcosh(y3-y4))
	if (at1.gt.0.d0) then
	  pt5max3 = (s+gpt4**2-2.d0*dsqrt(s)*gpt4*dcosh(y4))/at1
	else
	  pt5max3 = dsqrt(s)/2.d0
	endif
	pt5max = dmin1(pt5max1,pt5max2,pt5max3)
** 	xmin_pt5 = gpt4-dsqrt(s)/(2.d0*dcosh(y3))
** 	PT5MIN = dmax1(xmin_pt5,PTM)
	PT5MIN = PTM
	if (pt5min.gt.pt5max) then
	  f4dimd3 = 0.d0
	  return
	endif	
	PT5 = PT5MIN + (PT5MAX-PT5MIN)*XX(4)
C ------------------ FI35 -------------------------------------------
c x1c_min = pt5/dsqrt(s)*exp(y3) + gpt4/dsqrt(s)*exp(y4)
c x2c_min = pt5/dsqrt(s)*exp(-y3) + gpt4/dsqrt(s)*exp(-y4)
	x11 = pt5/dsqrt(s)*dexp(y3)+gpt4/dsqrt(s)*dexp(y4)
	x21 = pt5/dsqrt(s)*dexp(-y3)+gpt4/dsqrt(s)*dexp(-y4)
c en principe vrai
	if (x11.gt.un.or.x21.gt.un) then
	  f4dimd3 = 0.d0
	  return
	endif
	SY5MAX = DLOG(DSQRT(S)/PT5*(1.d0-x11))
	SY5MIN = -DLOG(DSQRT(S)/PT5*(1.d0-x21))
c en principe vrai
	if (sy5max.lt.sy5min) then
	  f4dimd3 = 0.d0
	  return
	endif
	if (pt5.le.gpt4/2.d0) then
	  fimin = 0.d0
	else
	  fimin = dacos(gpt4**2/(2.d0*pt5**2)-1.d0)
	endif
	GPT3MAX = DMIN1(GPT4+PT5,DSQRT(S)/(2.D0*DCOSH(Y3)))
	xarg = (gpt4**2-gpt3max**2-pt5**2)/
     #	(2.d0*gpt3max*pt5)
	if (xarg.lt.-1.d0) then
	  xmax_fi = pi
	else if (xarg.gt.1.d0) then
	  f4dimd3 = 0.d0
	  return
	else
	  xmax_fi = dacos(xarg)
	endif
	fimax = dmin1(pi,xmax_fi)
	if (y3.le.sy5max.and.y3.ge.sy5min) then
** 	  OMEGAMIN = 0.D0
** 	  OMEGAMAX = PI
	  OMEGAMIN = datan(fimin/(sy5max-y3))
	  OMEGAMAX = pi-datan(fimin/dabs(sy5min-y3))
	  srmax2 = dmax1((sy5max-y3)**2+fimax**2,
     #	  (sy5min-y3)**2+fimax**2)
	  rmax2 = dsqrt(srmax2)
	  rmin2 = fimin
	else if (y3.lt.sy5max.and.y3.lt.sy5min) then
** 	  OMEGAMIN = 0.D0
** 	  OMEGAMAX = PI/2.d0
	  OMEGAMIN = datan(fimin/(sy5max-y3))
	  OMEGAMAX = datan(fimax/(sy5min-y3))
	  srmax2 = (sy5max-y3)**2+fimax**2
	  rmax2 = dsqrt(srmax2)
	  rmin2 = dsqrt(fimin**2+(sy5min-y3)**2)
	else if (y3.gt.sy5max.and.y3.gt.sy5min) then
** 	  OMEGAMIN = pi/2.d0
** 	  OMEGAMAX = PI
	  OMEGAMIN = pi-datan(fimax/dabs(sy5max-y3))
	  OMEGAMAX = pi-datan(fimin/dabs(sy5min-y3))
	  srmax2 = (sy5min-y3)**2+fimax**2
	  rmax2 = dsqrt(srmax2)
	  rmin2 = dsqrt(fimin**2+(sy5max-y3)**2)
	endif
	if (omegamin.le.omegamax) then
	  OMEGA = OMEGAMIN + (OMEGAMAX-OMEGAMIN)*XX(5)
	else	  
	   f4dimd3 = 0.d0
	   return
	endif
	xbig = 1.d+20
	xsmall = 1.d-12
	if (omega.lt.xsmall.or.omega.gt.(pi-xsmall)) then
	  rmax1 = xbig
	else
	  rmax1 = fimax/dsin(omega)
	endif
	rrmax = dmin1(rmax1,rmax2)
	rrmin = rmin2
cc	RRMIN = R
** 	RRMIN = 0.d0
	if (rrmin.le.rrmax) then
	  RR = RRMIN + (RRMAX-RRMIN)*XX(6)
	else	  
	   f4dimd3 = 0.d0
	   return
	endif
	FI35 = RR*DSIN(OMEGA)
	IF (FI35.GT.PI) THEN
c	  write (19,*) 'FI35.GT.PI:',fi35
	   F4DIMD3 = 0.D0
	   RETURN
	ENDIF
C ------------------ GPT3 ------------------------------------------
	GPT3MIN = PT5
	if ((GPT4-PT5*DSIN(FI35)).le.0.d0) then
	  F4DIMD3 = 0.d0
	  return
	endif
	GPT3 = -PT5*DCOS(FI35)+DSQRT(GPT4**2-(PT5*DSIN(FI35))**2)
	if (gpt3.gt.gpt3max.or.gpt3.lt.gpt3min) then
	  F4DIMD3 = 0.d0
	  return
	endif
	PT3 = GPT3
C ------------------ X -------------------------------------------
	X1C = GPT3/DSQRT(S)*DEXP(Y3) + GPT4/DSQRT(S)*DEXP(Y4)
	X2C = GPT3/DSQRT(S)*DEXP(-Y3) + GPT4/DSQRT(S)*DEXP(-Y4)
	IF (X1C.GE.UN.OR.X2C.GE.UN) THEN
	  F4DIMD3 = 0.D0
	  RETURN
	ENDIF
	sup_pt5 = dsqrt(s*(1.d0-x1c)*(1.d0-x2c))
	if (pt5.gt.sup_pt5) then
	  F4DIMD3 = 0.D0
	  RETURN
	ENDIF	
C ------------------ Y5 -------------------------------------------
	Y5MAX = DLOG(DSQRT(S)/PT5*(1.D0-X1C))
	Y5MIN = -DLOG(DSQRT(S)/PT5*(1.D0-X2C))
	Y5 = Y3 + RR*DCOS(OMEGA)
	IF (Y5.GT.Y5MAX.OR.Y5.LT.Y5MIN) THEN
	   F4DIMD3 = 0.D0
	   RETURN
	ENDIF
C ------------------ X -------------------------------------------
	X1 = X1C + PT5/DSQRT(S)*DEXP(Y5)
	X2 = X2C + PT5/DSQRT(S)*DEXP(-Y5)
	IF (X1.GE.UN.OR.X2.GE.UN) THEN
c	  write (19,*) 'x1,x2:',x1,x2
	  F4DIMD3 = 0.D0
	  RETURN
	ENDIF
c coupure en angle-------------------------------------------------
        R35S = (Y3-Y5)**2+FI35**2
        RS = R**2
	icorr = 0
        IF (R35S.LT.RS) THEN
           icorr = 1
        ENDIF
c coupure en isolement-------------------------------------------------
	cos_fi45 = -(GPT3*DCOS(FI35)+PT5)/GPT4
	fi45 = zacos(cos_fi45)
c       if no isolation cuts on photon are imposed (iphotisol.eq.0), 
c       photon is always isolated (fulfills any isolation criteria)
c       flag iphotisol is read in in param.f
        xisol = 1.d0
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE
	 call isolement(y4,y5,fi45,un,pt5,gpt4,r_isol,epsilon_h,
     #	 isol)  
	ENDIF	 
	 if (.not.isol) then
	   if (icorr.eq.0) then
	     F4DIMD3 = 0.D0
	     RETURN
	   else 
	     xisol = 0.d0
	   endif  
	 endif  
c --------------------------------------------------------------------------	
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)*
     #	  RR*(RRMAX-RRMIN)*(OMEGAMAX-OMEGAMIN)*
     #	  (PT5MAX-PT5MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)*
     #	  RR*(RRMAX-RRMIN)*(OMEGAMAX-OMEGAMIN)*
     #	  (PT5MAX-PT5MIN)
	ENDIF
	x1p = gpt4/dsqrt(s)*(dexp(y3)+dexp(y4))
	x2p = gpt4/dsqrt(s)*(dexp(-y3)+dexp(-y4))
C ------------------------------------------- 
	P1(1) = X1*DSQRT(S)/2.D0
	P1(2) = 0.D0
	P1(3) = 0.D0
	P1(4) = X1*DSQRT(S)/2.D0
C ------------------------------------------- 
	P2(1) = X2*DSQRT(S)/2.D0
	P2(2) = 0.D0
	P2(3) = 0.D0
	P2(4) = -X2*DSQRT(S)/2.D0
C ------------------------------------------- 
	P4(1) = GPT4*DCOSH(Y4)
	P4(2) = GPT4
	P4(3) = 0.D0
	P4(4) = GPT4*DSINH(Y4)
C -------------------------------------------
c attention fi35 est l'angle entre 3 et 5
c minus sign in P5(3) is convention
	P5(1) = PT5*DCOSH(Y5)
c	P5(2) = PT5*DCOS(FI35)
c	P5(3) = PT5*DSIN(FI35)
	P5(2) = -PT5*(GPT3*DCOS(FI35)+PT5)/GPT4
	P5(3) = -PT5*GPT3*DSIN(FI35)/GPT4
	P5(4) = PT5*DSINH(Y5)
C ------------------------------------------- 
	P3(1) = P1(1) + P2(1) - P4(1) - P5(1)
	P3(2) = P1(2) + P2(2) - P4(2) - P5(2)
	P3(3) = P1(3) + P2(3) - P4(3) - P5(3)
	P3(4) = P1(4) + P2(4) - P4(4) - P5(4)
C -------------------------------------------
	P1P(1) = X1P*DSQRT(S)/2.D0
	P1P(2) = 0.D0
	P1P(3) = 0.D0
	P1P(4) = X1P*DSQRT(S)/2.D0
C ------------------------------------------- 
	P2P(1) = X2P*DSQRT(S)/2.D0
	P2P(2) = 0.D0
	P2P(3) = 0.D0
	P2P(4) = -X2P*DSQRT(S)/2.D0
C ------------------------------------------- 
	P5P(1) = PT5*DCOSH(Y3)
	P5P(2) = -PT5
	P5P(3) = 0.D0
	P5P(4) = PT5*DSINH(Y3)
C ------------------------------------------- 
	P3P(1) = P1P(1) + P2P(1) - P4(1) - P5P(1)
	P3P(2) = P1P(2) + P2P(2) - P4(2) - P5P(2)
	P3P(3) = P1P(3) + P2P(3) - P4(3) - P5P(3)
	P3P(4) = P1P(4) + P2P(4) - P4(4) - P5P(4)
c ------------------coupure jet------------------------------
c if no jets are measured, cut_jet is always true since any cut 
c conditions will be fulfilled
        xjet = 1.d0
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
c 07.01.02 changed to new jet_selection routine, requires def of absolute angles;
c 02.12.02 angles defined such that pt5(3) is negative;
c par convention: fi3 entre 0 et pi, donc calcule fi3 par arccos
	fi3 = zacos(P3(2)/gpt3)
c	write(*,*) 'fi3 = ', fi3
c comme fi3 est entre 0 et pi, fi5 doit etre entre pi et 2pi
	fi5 = zinvcos(P5(2),P5(3),pt5,pi)
	test35 = dabs(fi5-fi3-fi35)
        if  (test35.gt.1.d-6) then
	     write (17,*) 'attention, fi3-fi5 !=fi35 in  F4DIMD3',
     #	     test35,fi3,fi5,fi35
	   endif
c
	  call jet_selection(y3,y5,fi35,fi3,fi5,gpt3,pt5,
     #	  algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,inb_jet,
     #    xej,xpjx,xpjy,xpjz,cut_jet)
c
	  xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X1)
	  if (.not.cut_jet) then
	     if (icorr.eq.0) then
	       F4DIMD3 = 0.D0
	       RETURN  
	     else if (icorr.eq.1) then
	       xjet = 0.d0
	     endif
	  endif
	ENDIF
c ------------- set the scales ----------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	CALL FSPCOUD(N,SPCOU)
c	
	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c_{ij} = alpha_s*alpha^2/(4*c_i*c_j*Pi*s^2)
	CIJ = ALFAS(ILOOP,MU*MU)*ALPHA_EM**2/(PI*S*S)*FACIN
c
	CALL STRFRAD(X1,X2,IH2,SF0)
	call AMPD3(s,x1,x2,y3,gpt3,y5,pt5,fi35,CAMP0)
	CALL VEC_DMULT_VECTOR(CAMP0,SF0,K0MAX,TEMP0)
	CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	F4DIMD3 = 0.d0
	DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	  F4DIMD3 = TEMP1(I) + F4DIMD3
	ENDDO
	F4DIMD3 = CIJ*F4DIMD3*GPT3/DSQRT(GPT4**2-(PT5*DSIN(FI35))**2)
	if (icorr.eq.1) then
c --- coupure en isolement in subtraction cone ---------------------------------
        xisolp = 1.d0
	IF (iphotisol.ne.0) THEN
 	     call isolement(y4,y3,pi,un,pt5,gpt4,r_isol,epsilon_h,
     #	          isol)
 	     if (.not.(isol)) then
 	       xisolp = 0.d0
 	     endif
	ENDIF     
c ------------------coupure jet in subtraction cone ------------------------------
	  xjetp = 1.d0
	  IF (jetmode.ne.0) THEN
	    gpt3p = gpt4-pt5	    
	    fi3p = zacos(P3p(2)/gpt3p)
	    fi5p = zinvcos(P5p(2),P5p(3),pt5,pi)
	    test35 = dabs(fi3p-fi5p)
            if  (test35.gt.1.d-6) then
	      write (17,*) 'attention, fi3-fi5 !=0 in  F4DIMD3P',
     #	      test35,fi3p,fi5p
	    endif
	    call jet_selection(y3,y3,0.d0,fi3p,fi5p,gpt3p,pt5,
     #	    algorithm,r_kt,r_c,r_sep,merging,merged,
     #      ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,inb_jet,
     #      xej,xpjx,xpjy,xpjz,cut_jet)
	    if (.not.(cut_jet)) then
	      xjetp = 0.d0
	    endif
	  ENDIF
c ------------------ fin jet ------------------------------------	  
	  IF (IAUREN.EQ.0) THEN
	    CALL CHOISCALE(P3P,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	    FACIN = 1.D0
	  ELSE IF (IAUREN.EQ.1) THEN
	    M = GPT4*CM
	    MU = M
	    MF = M
	    FACIN = 1.D0/(2.D0*PI*GPT4)
	  ENDIF
	  ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c_{ij} = alpha_s*alpha^2/(4*c_i*c_j*Pi*s^2)
	  CIJ = ALFAS(ILOOP,MU*MU)*ALPHA_EM**2/(PI*S*S)*FACIN
c
	  CALL STRFRAD(X1P,X2P,IH2,SF0)
	  call ampd_corr3(s,x1p,x2p,y3,gpt4-pt5,pt5,r35s,camp0)
	  CALL VEC_DMULT_VECTOR(CAMP0,SF0,K0MAX,TEMP0)
	  CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	  F4DIMD3P = 0.d0
	  DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	    F4DIMD3P = TEMP1(I) + F4DIMD3P
	  ENDDO
	  F4DIMD3P = CIJ*F4DIMD3P*(gpt4-pt5)/GPT4
	  F4DIMD3 = F4DIMD3*xisol*xjet - F4DIMD3P*xisolp*xjetp
	endif ! end if icorr=1
C
	F4DIMD3 = F4DIMD3 * XJACOB * PT5*GPT4 * HC2
C
	IF (ISPRING.EQ.1) THEN
	  F4DIMD3 = DABS(F4DIMD3)
	ELSE IF (ISPRING.EQ.2) THEN
	  HALF = 0.5D0
	  IF (RNUMB.LE.HALF) THEN
	    XFI12 = 2.D0*PI-ZACOS(P3(2)/GPT3)
	    XFI13 = ZACOS(-(GPT3*DCOS(FI35)+PT5)/GPT4)
	  ELSE
	    XFI12 = ZACOS(P3(2)/GPT3)
	    XFI13 = 2.D0*PI-ZACOS(-(GPT3*DCOS(FI35)+PT5)/GPT4)
	  ENDIF
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = PT5
	  XY3 = Y5
	  XETA = X1
	  RESFUNC = F4DIMD3
	  F4DIMD3 = DABS(F4DIMD3)
	ENDIF
C
	RETURN
	END 
C*****************************************************
C INTEGRALE A 4 DIMENSIONS
	DOUBLE PRECISION FUNCTION F4DIMD4(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/COUP/PTM,R
	COMMON/ALEM/ILOOPEM
	COMMON/SCALE/M,MF,MU
	COMMON/FACONV/HC2
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSD/J_PROCESSD_MIN,J_PROCESSD_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	COMMON/RANDD/RNUMB
	COMMON/FICUT/FIMIN
	common/isophot/iphotisol
	COMMON/COUP_HISTO/R_ISOL,EPSILON_H
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	DIMENSION XX(20)
	PARAMETER (K0MAX=2)
	DIMENSION SF0(K0MAX),CAMP0(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX),SPCOU(K0MAX)
	DIMENSION P1(4),P2(4),P3(4),P4(4),P5(4)
	DIMENSION P1P(4),P2P(4),P3P(4),P5P(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ PT5 --------------------------------------------
	PT5MAX = DSQRT(GPT4**2+GPT_JETSUP**2)
	PT5MIN = PTM
	PT5 = PT5MIN + (PT5MAX-PT5MIN)*XX(4)
C ------------------ FI45 -------------------------------------------
	x11 = gpt4/dsqrt(s)*dexp(y4)+dabs(gpt4-pt5)/dsqrt(s)*dexp(y3)
	x21 = gpt4/dsqrt(s)*dexp(-y4)+dabs(gpt4-pt5)/dsqrt(s)*dexp(-y3)
	if (x11.gt.un.or.x21.gt.un) then
	  f4dimd4 = 0.d0
	  return
	endif
	SY5MAX = DLOG(DSQRT(S)/PT5*(1.d0-x11))
	SY5MIN = -DLOG(DSQRT(S)/PT5*(1.d0-x21))
	if (sy5max.lt.sy5min) then
	  f4dimd4 = 0.d0
	  return
	endif
	if (pt5.le.gpt4/2.d0) then
	  fimax = pi
	else
	  fimax = dacos(-gpt4/(2.d0*pt5))
	endif
	GPT3MAX = DMIN1(GPT4+PT5,DSQRT(S)/(2.D0*DCOSH(Y3)))
	xarg = (gpt3max**2-gpt4**2-pt5**2)/
     #	(2.d0*gpt4*pt5)
	if (xarg.gt.1.d0) then
	  fimin = 0.d0
	else if (xarg.lt.-1.d0) then
	  f4dimd4 = 0.d0
	  return
	else
	  fimin = dacos(xarg)
	endif
	if (y4.le.sy5max.and.y4.ge.sy5min) then
** 	  OMEGAMIN = 0.D0
** 	  OMEGAMAX = PI
	  OMEGAMIN = datan(fimin/(sy5max-y4))
	  OMEGAMAX = pi-datan(fimin/dabs(sy5min-y4))
	  srmax2 = dmax1((sy5max-y4)**2+fimax**2,
     #	  (sy5min-y4)**2+fimax**2)
	  rmax2 = dsqrt(srmax2)
	  rmin2 = fimin
	else if (y4.lt.sy5max.and.y4.lt.sy5min) then
** 	  OMEGAMIN = 0.D0
** 	  OMEGAMAX = PI/2.d0
	  OMEGAMIN = datan(fimin/(sy5max-y4))
	  OMEGAMAX = datan(fimax/(sy5min-y4))
	  srmax2 = (sy5max-y4)**2+fimax**2
	  rmax2 = dsqrt(srmax2)
	  rmin2 = dsqrt(fimin**2+(sy5min-y4)**2)
	else if (y4.gt.sy5max.and.y4.gt.sy5min) then
** 	  OMEGAMIN = pi/2.d0
** 	  OMEGAMAX = PI
	  OMEGAMIN = pi-datan(fimax/dabs(sy5max-y4))
	  OMEGAMAX = pi-datan(fimin/dabs(sy5min-y4))
	  srmax2 = (sy5min-y4)**2+fimax**2
	  rmax2 = dsqrt(srmax2)
	  rmin2 = dsqrt(fimin**2+(sy5max-y4)**2)
	endif
	if (omegamin.le.omegamax) then
	  OMEGA = OMEGAMIN + (OMEGAMAX-OMEGAMIN)*XX(5)
	else	  
	   f4dimd4 = 0.d0
	   return
	endif
	xbig = 1.d+20
	xsmall = 1.d-12
	if (omega.lt.xsmall.or.omega.gt.(pi-xsmall)) then
	  rmax1 = xbig
	else
	  rmax1 = pi/dsin(omega)
	endif
	rrmax = dmin1(rmax1,rmax2)
	rrmin = rmin2
	RR = RRMIN + (RRMAX-RRMIN)*XX(6)
	FI45 = RR*DSIN(OMEGA)
	IF (FI45.GT.PI) THEN
	   F4DIMD4 = 0.D0
	   RETURN
	ENDIF
C ------------------ GPT3 ------------------------------------------
	GPT3MIN = PT5
	GPT3 = DSQRT(GPT4**2+PT5**2+2.D0*PT5*GPT4*DCOS(FI45))
	IF (GPT3.LT.GPT3MIN.OR.GPT3.GT.GPT3MAX) THEN
	   F4DIMD4 = 0.D0
	   RETURN
	ENDIF
C ------------------ X -------------------------------------------
	X1C = GPT3/DSQRT(S)*DEXP(Y3) + GPT4/DSQRT(S)*DEXP(Y4)
	X2C = GPT3/DSQRT(S)*DEXP(-Y3) + GPT4/DSQRT(S)*DEXP(-Y4)
	IF (X1C.GE.UN.OR.X2C.GE.UN) THEN
	  F4DIMD4 = 0.D0
	  RETURN
	ENDIF
	sup_pt5 = dsqrt(s*(1.d0-x1c)*(1.d0-x2c))
	if (pt5.gt.sup_pt5) then
	  F4DIMD4 = 0.D0
	  RETURN
	ENDIF	
C ------------------ Y5 -------------------------------------------
	Y5MAX = DLOG(DSQRT(S)/PT5*(1.D0-X1C))
	Y5MIN = -DLOG(DSQRT(S)/PT5*(1.D0-X2C))
	Y5 = Y4 + RR*DCOS(OMEGA)
	IF (Y5.GT.Y5MAX.OR.Y5.LT.Y5MIN) THEN
	   F4DIMD4 = 0.D0
	   RETURN
	ENDIF
C ------------------ X -------------------------------------------
	X1 = X1C + PT5/DSQRT(S)*DEXP(Y5)
	X2 = X2C + PT5/DSQRT(S)*DEXP(-Y5)
	IF (X1.GE.UN.OR.X2.GE.UN) THEN
	  F4DIMD4 = 0.D0
	  RETURN
	ENDIF
c coupure en angle (pour definir "petit cone")--------------------------
        R45S = (Y4-Y5)**2+FI45**2
        RS = R**2
	icorr = 0
        IF (R45S.LT.RS) THEN
           icorr = 1
        ENDIF
c coupure en isolement-------------------------------------------------
        xisol = 1.d0	
        IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE
	 call isolement(y4,y5,fi45,un,pt5,gpt4,r_isol,epsilon_h,
     #	isol)  
c
	if (.not.isol) then
	   if (icorr.eq.0) then
	      F4DIMD4 = 0.D0
	      RETURN
	   else 
	   xisol = 0.d0
	   endif 
	 endif    
	ENDIF
c --------------------------------------------------------------------------		
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)*
     #	  RR*(RRMAX-RRMIN)*(OMEGAMAX-OMEGAMIN)*
     #	  (PT5MAX-PT5MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)*
     #	  RR*(RRMAX-RRMIN)*(OMEGAMAX-OMEGAMIN)*
     #	  (PT5MAX-PT5MIN)
	ENDIF
	x1s = (gpt4+pt5)/dsqrt(s)*(dexp(y3)+dexp(y4))
	x2s = (gpt4+pt5)/dsqrt(s)*(dexp(-y3)+dexp(-y4))
C ------------------------------------------- 
	P1(1) = X1*DSQRT(S)/2.D0
	P1(2) = 0.D0
	P1(3) = 0.D0
	P1(4) = X1*DSQRT(S)/2.D0
C ------------------------------------------- 
	P2(1) = X2*DSQRT(S)/2.D0
	P2(2) = 0.D0
	P2(3) = 0.D0
	P2(4) = -X2*DSQRT(S)/2.D0
C ------------------------------------------- 
	P4(1) = GPT4*DCOSH(Y4)
	P4(2) = GPT4
	P4(3) = 0.D0
	P4(4) = GPT4*DSINH(Y4)
C ------------------------------------------- 
	P5(1) = PT5*DCOSH(Y5)
	P5(2) = PT5*DCOS(FI45)
	P5(3) = PT5*DSIN(FI45)
	P5(4) = PT5*DSINH(Y5)
C ------------------------------------------- 
	P3(1) = P1(1) + P2(1) - P4(1) - P5(1)
	P3(2) = P1(2) + P2(2) - P4(2) - P5(2)
	P3(3) = P1(3) + P2(3) - P4(3) - P5(3)
	P3(4) = P1(4) + P2(4) - P4(4) - P5(4)
C -------------------------------------------
	P1P(1) = X1S*DSQRT(S)/2.D0
	P1P(2) = 0.D0
	P1P(3) = 0.D0
	P1P(4) = X1S*DSQRT(S)/2.D0
C ------------------------------------------- 
	P2P(1) = X2S*DSQRT(S)/2.D0
	P2P(2) = 0.D0
	P2P(3) = 0.D0
	P2P(4) = -X2S*DSQRT(S)/2.D0
C ------------------------------------------- 
	P5P(1) = PT5*DCOSH(Y4)
	P5P(2) = PT5
	P5P(3) = 0.D0
	P5P(4) = PT5*DSINH(Y4)
C ------------------------------------------- 
	P3P(1) = P1P(1) + P2P(1) - P4(1) - P5P(1)
	P3P(2) = P1P(2) + P2P(2) - P4(2) - P5P(2)
	P3P(3) = P1P(3) + P2P(3) - P4(3) - P5P(3)
	P3P(4) = P1P(4) + P2P(4) - P4(4) - P5P(4)
c ---------- coupure jet -----------------------------------------------
	cos_fi35 = -(GPT4*DCOS(FI45)+PT5)/GPT3
	fi35 = zacos(cos_fi35)
	xjet = 1.d0
c if no jets are measured, cut_jet is always true since any cut 
c conditions will be fulfilled
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
c 07.01.02 changed to new jet_selection routine;
c requires def of absolute angles
c from line 1479: phi45=fi5 < pi -> pi< fi3< 2pi
	fi3 = zinvcos(P3(2),P3(3),gpt3,pi)
	fi5 = zacos(P5(2)/pt5)
c	test=dabs(fi45-fi5)
c        if  (test.gt.1.d-6) then
c	     write (27,*) 'attention, fi5 not= fi45 in  F4DIMD4',
c     #	     test,fi5,fi45
c	endif
	test35 = dmin1(dabs(dabs(fi3-fi5)-fi35),
     #	   dabs(2.d0*pi-dabs(fi3-fi5)-fi35))
        if  (test35.gt.1.d-6) then
	     write (17,*) 'attention, fi3-fi5 !=fi35 in  F4DIMD4',
     #	     test35,fi3,fi5,fi35
	endif
c	
	  call jet_selection(y3,y5,fi35,fi3,fi5,gpt3,pt5,
     #	  algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,
     #    inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
c
	  xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X1)
c	         
	 if (.not.cut_jet) then
	   if (icorr.eq.0) then
	     F4DIMD4 = 0.D0
	     RETURN
	   else if (icorr.eq.1) then 
	     xjet = 0.d0
	   endif
	 endif 
	ENDIF
c -------------- set the scales ---------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	CALL FSPCOUD(N,SPCOU)
c
	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c_{ij} = alpha_s*alpha^2/(4*c_i*c_j*Pi*s^2)
	CIJ = ALFAS(ILOOP,MU*MU)*ALPHA_EM**2/(PI*S*S)*FACIN
c
	CALL STRFRAD(X1,X2,IH2,SF0)
	call AMPD4(s,x1,x2,y4,gpt4,y5,pt5,fi45,CAMP0)
	CALL VEC_DMULT_VECTOR(CAMP0,SF0,K0MAX,TEMP0)
	CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	F4DIMD4 = 0.d0
	DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	  F4DIMD4 = TEMP1(I) + F4DIMD4
	ENDDO
	F4DIMD4 = F4DIMD4*CIJ
	if (icorr.eq.1) then
c coupure en isolement in cone subtraction-------------------------------------
	xisolp = 1.d0
	IF (iphotisol.ne.0) THEN
	  call isolement(y4,y4,0.d0,un,pt5,gpt4,r_isol,epsilon_h,
     #	  isol)
	  if (.not.(isol)) then
	     xisolp = 0.d0
	  endif
	ENDIF
c -------------- coupure jet in cone subtraction--------------------------------
	  xjetp = 1.d0
	  IF (jetmode.ne.0) THEN
	    gpt3p = gpt4+pt5
	    fi3p = zinvcos(P3P(2),P3P(3),gpt3p,pi)
	    fi5p = zinvcos(P5P(2),P5P(3), pt5,pi)
	    test35 = dabs(fi3p-fi5p)-pi
            if  (test35.gt.1.d-6) then
	       write (17,*) 'attention, fi3-fi5 !=pi in  F4DIMD4P',
     #	       test35,fi3p,fi5p
	    endif
c	    
	   call jet_selection(y3,y4,pi,fi3p,fi5p,gpt3p,pt5,
     #	   algorithm,r_kt,r_c,r_sep,merging,merged,
     #     ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,
     #     inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)	    
	    if (.not.(cut_jet)) then
	       xjetp = 0.d0
	    endif
	  ENDIF
c ------------------ fin jet ------------------------------------	
	  IF (IAUREN.EQ.0) THEN
	    CALL CHOISCALE(P3P,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	    FACIN = 1.D0
	  ELSE IF (IAUREN.EQ.1) THEN
	    M = GPT4*CM
	    MU = M
	    MF = M
	    FACIN = 1.D0/(2.D0*PI*GPT4)
	  ENDIF
	  ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c_{ij} = alpha_s*alpha^2/(4*c_i*c_j*Pi*s^2)
	  CIJ = ALFAS(ILOOP,MU*MU)*ALPHA_EM**2/(PI*S*S)*FACIN
c
	  CALL STRFRAD(X1S,X2S,IH2,SF0)
	  call ampd_corr4(s,x1s,x2s,y4,gpt4,pt5,r45s,camp0)
	  CALL VEC_DMULT_VECTOR(CAMP0,SF0,K0MAX,TEMP0)
	  CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	  F4DIMD4P = 0.d0
	  DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	    F4DIMD4P = TEMP1(I) + F4DIMD4P
	  ENDDO
	  F4DIMD4P = CIJ*F4DIMD4P
	  F4DIMD4 = F4DIMD4*xisol*xjet - F4DIMD4P*xisolp*xjetp
	endif
C
	F4DIMD4 = F4DIMD4 * XJACOB * (GPT4*PT5) * HC2
C
	IF (ISPRING.EQ.1) THEN
	  F4DIMD4 = DABS(F4DIMD4)
	ELSE IF (ISPRING.EQ.2) THEN
	  HALF = 0.5D0
	  IF (RNUMB.LE.HALF) THEN
	    XFI12 = 2.D0*PI-ZACOS(P3(2)/GPT3)
	    XFI13 = FI45
	  ELSE
	    XFI12 = ZACOS(P3(2)/GPT3)
	    XFI13 = 2.D0*PI-FI45
	  ENDIF
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = PT5
	  XY3 = Y5
	  XETA = X1
	  RESFUNC = F4DIMD4
	  F4DIMD4 = DABS(F4DIMD4)
	ENDIF
C
	RETURN
	END 
C********************************************************************
C INTEGRALE A 2 DIMENSIONS (5||1 only)
	DOUBLE PRECISION FUNCTION F2DIMD1(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/SCALE/M,MF,MU
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/ALEM/ILOOPEM
	COMMON/FACONV/HC2
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSD/J_PROCESSD_MIN,J_PROCESSD_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	common/isophot/iphotisol
	common/COUP_HISTO/R_ISOL,EPSILON_H
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead
	common/xele/xe 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	DIMENSION XX(20)
	PARAMETER (K0MAX=2)
	DIMENSION SY31(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX)
	DIMENSION SPCOU(K0MAX)
	DIMENSION P3(4),P4(4),P5(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,DSQRT(S)/(2.D0*DCOSH(Y4)),GPT_JETSUP)
	GPT4MIN = DMAX1(GPTINF,GPT_JETINF)
	GPT4MAX = DMAX1(GPT4MIN,GPT4MAXP)
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ U -------------------------------------------
	U1 = XX(4)
c ------------------------------------------	
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)
	ENDIF
	CALL FSPCOUD(N,SPCOU)
	GPT3 = GPT4
	X10 = GPT3*(DEXP(Y3)+DEXP(Y4))/DSQRT(S)
	X20 = GPT3*(DEXP(-Y3)+DEXP(-Y4))/DSQRT(S)
	if (x10.gt.un.or.x20.gt.un) then
	  F2DIMD1 = 0.D0
	  return
	endif
c --------------coupure en isolement-------------------------------
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE
	call isolement(0.d0,0.d0,0.d0,un,0.d0,gpt4,r_isol,epsilon_h,
     #	isol)   
	ENDIF 
c
	if (.not.isol) then
	  F2DIMD1 = 0.D0
	  RETURN
	endif
c ----------coupure jet-------------------------------------------------
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
c second y3 and fi35 = 0 serve only to produce r35=0
          fi3=pi
	  fi5=0.d0
  	  call jet_selection(y3,y3,0.d0,fi3,fi5,gpt3,0.d0,
     #    algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,    
     #	  inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
	  if (.not.cut_jet) then
	    F2DIMD1 = 0.D0
	    RETURN
	  endif  
	ENDIF
c --------------------------------------------------------------------------
	  P3(1) = GPT3*DCOSH(Y3)
	  P3(2) = -GPT3
	  P3(3) = 0.D0
	  P3(4) = GPT3*DSINH(Y3)
C ------------------------------------------- 
	  P5(1) = 0.D0
	  P5(2) = 0.D0
	  P5(3) = 0.D0
	  P5(4) = 0.D0
C ------------------------------------------- 
	  P4(1) = GPT4*DCOSH(Y4)
	  P4(2) = GPT4
	  P4(3) = 0.D0
	  P4(4) = GPT4*DSINH(Y4)
C -------------------------------------------
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c^b_{ij} = 2*pi*alpha^2/(4*c_i*c_j*s**2)
	CBIJ = ALPHA_EM**2*2.D0*PI/(S*S)*FACIN
	ALPI = ALFAS(ILOOP,MU*MU)/(2.D0*PI)
c
	CALL SSY31(S,GPT3,Y3,Y4,X10,X20,M,U1,IH2,SY31)
	IF (jetmode.eq.1) THEN
	  xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*XE)
	ENDIF  
	CALL VEC_DMULT_VECTOR(SY31,SPCOU,K0MAX,TEMP1)
	F2DIMD1 = 0.d0
	DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	  F2DIMD1 = TEMP1(I) + F2DIMD1
	ENDDO
C
	F2DIMD1 = F2DIMD1 * XJACOB * ALPI * CBIJ * HC2
C
	IF (ISPRING.EQ.1) THEN
	  F2DIMD1 = DABS(F2DIMD1)
	ELSE IF (ISPRING.EQ.2) THEN
	  XFI12 = PI
	  XFI13 = 0.D0
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = 0.D0
	  XY3 = 0.D0
	  XETA = XE
	  RESFUNC = F2DIMD1
	  F2DIMD1 = DABS(F2DIMD1)
	ENDIF
C
	RETURN
	END 
C********************************************************************
C INTEGRALE A 2 DIMENSIONS (5||2 only)
	DOUBLE PRECISION FUNCTION F2DIMD2(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/SCALE/M,MF,MU
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/ALEM/ILOOPEM
	COMMON/FACONV/HC2
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSD/J_PROCESSD_MIN,J_PROCESSD_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	common/isophot/iphotisol
	common/COUP_HISTO/R_ISOL,EPSILON_H
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	DIMENSION XX(20)
	PARAMETER (K0MAX=2)
	DIMENSION SV2(K0MAX),SY3(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX)
	DIMENSION SPCOU(K0MAX)
	DIMENSION P3(4),P4(4),P5(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,DSQRT(S)/(2.D0*DCOSH(Y4)),GPT_JETSUP)
	GPT4MIN = DMAX1(GPTINF,GPT_JETINF)
	GPT4MAX = DMAX1(GPT4MIN,GPT4MAXP)
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ U -------------------------------------------
	U1 = XX(4)
c ------------------------------------------	
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)
	ENDIF
	CALL FSPCOUD(N,SPCOU)
	GPT3 = GPT4
	X10 = GPT3*(DEXP(Y3)+DEXP(Y4))/DSQRT(S)
	X20 = GPT3*(DEXP(-Y3)+DEXP(-Y4))/DSQRT(S)
	if (x10.gt.un.or.x20.gt.un) then
	  F2DIMD2 = 0.D0
	  return
	endif
c --------------coupure en isolement-------------------------------
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE
	call isolement(0.d0,0.d0,0.d0,un,0.d0,gpt4,r_isol,epsilon_h,
     #	isol)   
	ENDIF 
	if (.not.isol) then
	  F2DIMD2 = 0.D0
	  RETURN
	endif
c ----------coupure jet-------------------------------------------------
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
	  fi3=pi
c second y3 and fi35=0 serves only to produce r35=0
  	  call jet_selection(y3,y3,0.d0,fi3,0.d0,gpt3,0.d0,
     #    algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,    
     #	  inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
          xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X10)
	  if (.not.cut_jet) then
	    F2DIMD2 = 0.D0
	    RETURN
	  endif  
	ENDIF
c --------------------------------------------------------------------------	
	  P3(1) = GPT3*DCOSH(Y3)
	  P3(2) = -GPT3
	  P3(3) = 0.D0
	  P3(4) = GPT3*DSINH(Y3)
C ------------------------------------------- 
	  P5(1) = 0.D0
	  P5(2) = 0.D0
	  P5(3) = 0.D0
	  P5(4) = 0.D0
C ------------------------------------------- 
	  P4(1) = GPT4*DCOSH(Y4)
	  P4(2) = GPT4
	  P4(3) = 0.D0
	  P4(4) = GPT4*DSINH(Y4)
C -------------------------------------------
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c^b_{ij} = 2*pi*alpha^2/(4*c_i*c_j*s**2)
	CBIJ = ALPHA_EM**2*2.D0*PI/(S*S)*FACIN
	ALPI = ALFAS(ILOOP,MU*MU)/(2.D0*PI)
c
	CALL SSY32(S,GPT3,Y3,Y4,X10,X20,M,U1,IH2,SY3)
c       SSV2 includes integration over fi in sigma^ir, not related to 5||2
c       only present because dim of integrations is the same	
	CALL SSV2(S,GPT3,Y3,Y4,X10,X20,U1,IH2,SV2)
	CALL VEC_DADD_VECTOR(SY3,SV2,K0MAX,TEMP0)
	CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	F2DIMD2 = 0.d0
	DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	  F2DIMD2 = TEMP1(I) + F2DIMD2
	ENDDO
C
	F2DIMD2 = F2DIMD2 * XJACOB * ALPI * CBIJ * HC2
C
	IF (ISPRING.EQ.1) THEN
	  F2DIMD2 = DABS(F2DIMD2)
	ELSE IF (ISPRING.EQ.2) THEN
	  XFI12 = PI
	  XFI13 = 0.D0
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = 0.D0
	  XY3 = 0.D0
	  XETA = X10
	  RESFUNC = F2DIMD2
	  F2DIMD2 = DABS(F2DIMD2)
	ENDIF
C
	RETURN
	END 	
c **********************************************************************
C INTEGRALE A 2 DIMENSIONS
	DOUBLE PRECISION FUNCTION F2DIMD3(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/SCALE/M,MF,MU
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/ALEM/ILOOPEM
	COMMON/FACONV/HC2
	COMMON/COUP/PTMM,R
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSD/J_PROCESSD_MIN,J_PROCESSD_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	common/isophot/iphotisol
	common/COUP_HISTO/R_ISOL,EPSILON_H
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	DIMENSION XX(20)
	PARAMETER (K0MAX=2)
	DIMENSION SY4R(K0MAX),SY4P(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX)
	DIMENSION SPCOU(K0MAX)
	DIMENSION P3(4),P4(4),P5(4)
	PI=DATAN(1.D0)*4.D0
	ZERO = 0.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4))
     #	,DSQRT(S)/(2.D0*DCOSH(Y3)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
	GPT3MAXP = DMIN1(GPT_JETSUP,DSQRT(S)/(2.D0*DCOSH(Y3)))
	GPT3MAX = DMAX1(GPT_JETINF,GPT3MAXP)
	GPT3MIN = GPT_JETINF
	PT4 = GPT4
	YS = (Y3-Y4)/2.D0
	Y = (Y3+Y4)/2.D0
	X4MIN = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	X10 = PT4*(DEXP(Y3)+DEXP(Y4))/DSQRT(S)
	X20 = PT4*(DEXP(-Y3)+DEXP(-Y4))/DSQRT(S)
	if (x10.gt.un.or.x20.gt.un) then
	  F2DIMD3 = 0.D0
	  return
	endif
	PT5X = DSQRT(S)/(2.D0*DCOSH(YS))*(1.D0-X10)*(1.D0-X20)/
     #  ((1.D0-X10)*DEXP(-Y)+(1.D0-X20)*DEXP(Y))
	PTM = DMIN1(PTMM,PT5X)
cc	PTM = PTMM
C
	Z4MAX0 = 1.D0
	Z4MIN0 = DMAX1(X4MIN,GPT4/GPT3MAXP,X10,X20)
	Z4SUP = PT4/(PTM+PT4)
	  Z4MIN = Z4MIN0
	  Z4MAX = Z4MAX0
c juste pour tester (en principe inutile)
	if (z4min.gt.z4max) then
	  F2DIMD3 = 0.D0
	  write (18,*) 'attention z4min > z4max',z4min,z4max
	  return
	endif
	Z4 = Z4MIN + (Z4MAX-Z4MIN)*XX(4)
C
	GPT3 = GPT4/Z4
c juste pour tester (en principe inutile)
	IF (GPT3.GT.GPT3MAX.OR.GPT3.LT.GPT3MIN) THEN
	  F2DIMD3 = 0.D0
	  write (18,*) 'attention gpt3 > gpt3min ou gpt3 < gpt3max',
     #	              gpt3,gpt3min,gpt3max
	  RETURN
	ENDIF
c coupure en isolement-------------------------------------------------
	pt5 = (1.d0-z4)/z4*gpt4
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE 
	call isolement(0.d0,0.d0,0.d0,un,pt5,gpt4,r_isol,epsilon_h,
     #	isol)
        ENDIF
	if (.not.isol) then
	  F2DIMD3 = 0.D0
	  RETURN
	endif
c ------------ coupure jet-----------------------------------------------
c if no jets are measured, cut_jet is always true since any cut 
c conditions will be fulfilled
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
	  fi3=pi
	  fi5=0.d0
c second y3 and fi35=0 serves only to produce r35=0
  	  call jet_selection(y3,y3,0.d0,fi3,fi5,gpt3,0.d0,
     #    algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,
     #	  inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
          x1s=x10/z4
          xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X1S)
c
	  if (.not.cut_jet) then
	    F2DIMD3 = 0.D0
	    RETURN
	  endif  
	ENDIF
c --------------------------------------------------------------------------			
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)
     #    *(Z4MAX-Z4MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Z4MAX-Z4MIN)
	ENDIF
	CALL FSPCOUD(N,SPCOU)
C ------------------------------------------- 
	  P3(1) = GPT3*DCOSH(Y3)
	  P3(2) = -GPT3
	  P3(3) = 0.D0
	  P3(4) = GPT3*DSINH(Y3)
C ------------------------------------------- 
	  P5(1) = 0.D0
	  P5(2) = 0.D0
	  P5(3) = 0.D0
	  P5(4) = 0.D0
C ------------------------------------------- 
	  P4(1) = GPT4*DCOSH(Y4)
	  P4(2) = GPT4
	  P4(3) = 0.D0
	  P4(4) = GPT4*DSINH(Y4)
C -------------------------------------------
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c^b_{ij} = 2*pi*alpha^2/(4*c_i*c_j*s**2)
	CBIJ = ALPHA_EM**2*2.D0*PI/(S*S)*FACIN
	ALPI = ALFAS(ILOOP,MU*MU)/(2.D0*PI)
c
	CALL SSY4P(S,GPT4,X10,X20,Z4,Y3,Y4,MF,IH2,SY4P)
	IF (Z4.LE.Z4SUP) THEN
	  CALL SSY4R(S,GPT4,X10,X20,Z4,R,Y3,Y4,IH2,SY4R)
	ELSE
	  CALL VEC_DINIT(SY4R,K0MAX,ZERO)	  
	ENDIF
	CALL VEC_DADD_VECTOR(SY4R,SY4P,K0MAX,TEMP0)
	CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	F2DIMD3 = 0.d0
	DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	  F2DIMD3 = TEMP1(I) + F2DIMD3
	ENDDO
C
	F2DIMD3 = F2DIMD3 * XJACOB * ALPI * CBIJ * HC2
c
	IF (ISPRING.EQ.1) THEN
	  F2DIMD3 = DABS(F2DIMD3)
	ELSE IF (ISPRING.EQ.2) THEN
	  XFI12 = PI
	  XFI13 = 0.D0
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = 0.D0
	  XY3 = 0.D0
	  XETA = X10/Z4
	  RESFUNC = F2DIMD3
	  F2DIMD3 = DABS(F2DIMD3)
	ENDIF
C
	RETURN
	END 
C*****************************************************
C INTEGRALE A 1 DIMENSION
	DOUBLE PRECISION FUNCTION F1DIMD(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/SCALE/M,MF,MU
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/ALEM/ILOOPEM
	COMMON/FACONV/HC2
	COMMON/BORN/IBORN
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSD/J_PROCESSD_MIN,J_PROCESSD_MAX
	COMMON/BOX/IBOX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	common/isophot/iphotisol
	COMMON/COUP_HISTO/R_ISOL,EPSILON_H
	COMMON/COUP/PTMM,R
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	DIMENSION XX(20)
	PARAMETER (K0MAX=2)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX),TEMP2(K0MAX),TEMP3(K0MAX)
	DIMENSION C0SV12(K0MAX),C0SV3(K0MAX),C0SV4(K0MAX),C0FBORN(K0MAX)
	DIMENSION SPCOU(K0MAX)
	DIMENSION C0SY3R(K0MAX)
	DIMENSION P3(4),P4(4),P5(4)
	PI = DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
	YS = (Y3-Y4)/2.D0
	Y = (Y3+Y4)/2.D0
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,DSQRT(S)/(2.D0*DCOSH(Y4)),GPT_JETSUP)
	GPT4MAX = DMAX1(GPTINF,GPT_JETINF,GPT4MAXP)
c	GPT4MAX = GPTSUP
	GPT4MIN = DMAX1(GPTINF,GPT_JETINF)
	GPT4SUP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4)))
	GPT3SUP = DMIN1(GPT_JETSUP,DSQRT(S)/(2.D0*DCOSH(Y3)))
	GPT3MAXP = DMIN1(GPT_JETSUP,DSQRT(S)/(2.D0*DCOSH(Y3)))
	GPT3MAX = DMAX1(GPT_JETINF,GPT3MAXP)
	GPT3MIN = GPT_JETINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
	GPT3 = GPT4
c
	X10 = GPT4*(DEXP(Y3)+DEXP(Y4))/DSQRT(S)
	X20 = GPT4*(DEXP(-Y3)+DEXP(-Y4))/DSQRT(S)
	if (x10.gt.un.or.x20.gt.un) then
	  F1DIMD = 0.D0
	  return
	endif
c
	PT5X = DSQRT(S)/(2.D0*DCOSH(YS))*(1.D0-X10)*(1.D0-X20)/
     #  ((1.D0-X10)*DEXP(-Y)+(1.D0-X20)*DEXP(Y))
cc	PTM = DMIN1(PTMM,PT5X)
	PTM = PTMM
c
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)
	ENDIF
	CALL FSPCOUD(N,SPCOU)
c coupure en isolement-------------------------------------------------
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE 
	call isolement(0.d0,0.d0,0.d0,un,0.d0,gpt4,r_isol,epsilon_h,
     #	isol)
        ENDIF
	if (.not.isol) then
	  F1DIMD = 0.D0
	  RETURN
	endif
c ------------- coupure jet -----------------------------------------
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
	  fi3=pi
	  fi5=0.d0
c second y3 and fi35=0 serve only to produce r35=0	  
  	  call jet_selection(y3,y3,0.d0,fi3,fi5,gpt3,0.d0,
     #    algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,
     #	  inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
          xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X10)
	  if (.not.cut_jet) then
	    F1DIMD = 0.D0
	    RETURN
	  endif
	ENDIF
c --------------------------------------------------------------------------			
	  P3(1) = GPT3*DCOSH(Y3)
	  P3(2) = -GPT3
	  P3(3) = 0.D0
	  P3(4) = GPT3*DSINH(Y3)
C ------------------------------------------- 
	  P5(1) = 0.D0
	  P5(2) = 0.D0
	  P5(3) = 0.D0
	  P5(4) = 0.D0
C ------------------------------------------- 
	  P4(1) = GPT4*DCOSH(Y4)
	  P4(2) = GPT4
	  P4(3) = 0.D0
	  P4(4) = GPT4*DSINH(Y4)
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c^b_{ij} = 2*pi*alpha^2/(4*c_i*c_j*s**2)
	CBIJ = ALPHA_EM**2*2.D0*PI/(S*S)*FACIN 
	ALPHAS = ALFAS(ILOOP,MU*MU)
	ALPI = ALPHAS/(2.D0*PI)
c
	IF (IBORN.EQ.0) THEN 
	  CALL SSV12(S,GPT3,GPT4,PTM,Y3,Y4,X10,X20,M,MU,IH2,C0SV12)
	  CALL SSV3(S,GPT4,Y3,Y4,X10,X20,IH2,C0SV3)
	  CALL SSV4(S,GPT4,GPT3SUP,PTM,Y3,Y4,X10,X20,MF,IH2,C0SV4)
	  CALL SSY3R(S,GPT4,X10,X20,PTM,R,Y3,Y4,IH2,C0SY3R)
	  CALL VEC_DMULT_VECTOR(C0SV12,SPCOU,K0MAX,TEMP0)
	  CALL VEC_DMULT_VECTOR(C0SV3,SPCOU,K0MAX,TEMP1)
	  CALL VEC_DMULT_VECTOR(C0SV4,SPCOU,K0MAX,TEMP2)
	  CALL VEC_DMULT_VECTOR(C0SY3R,SPCOU,K0MAX,TEMP3)
	  SV12 = 0.d0
	  SV3 = 0.d0
	  SV4 = 0.d0
	  SY3R = 0.d0
	  DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	    SV12 = TEMP0(I) + SV12 
	    SV3 =  TEMP1(I) + SV3
	    SV4 =  TEMP2(I) + SV4
	    SY3R = TEMP3(I) + SY3R
	  ENDDO
	  BORN = 0.d0
	ELSE IF (IBORN.EQ.1) THEN
	  BOX = 0.D0
	  FBORN = 0.D0
	  IF (IBOX.EQ.0.OR.IBOX.EQ.2) THEN
	    CALL SFBORN(S,N,GPT3,Y3,Y4,IH2,C0FBORN)
	    CALL VEC_DMULT_VECTOR(C0FBORN,SPCOU,K0MAX,TEMP3)
	    DO I = J_PROCESSD_MIN,J_PROCESSD_MAX
	    FBORN = TEMP3(I) + FBORN
	    ENDDO
	    SV12 = 0.d0
	    SV3 =  0.d0
	    SV4 =  0.d0
	    SY3R = 0.d0
	    BORN = FBORN
	  ENDIF
	  IF (IBOX.EQ.1.OR.IBOX.EQ.2) THEN
	    CALL GLGL_GAGA(S,N,GPT3,Y3,Y4,IH2,BOITE)
	    BOX =  BOITE*ALPHAS**2/(16.D0*PI**2)
	  ENDIF
	  SV12 = 0.d0
	  SV3 = 0.d0
	  SV4 = 0.d0
	  SY3R = 0.d0
	  BORN = FBORN + BOX
	ENDIF
c
	RESB = BORN + (SV12+SV3+SV4+SY3R)*ALPI
	F1DIMD = RESB * XJACOB * CBIJ * HC2
C
	IF (ISPRING.EQ.1) THEN
	  F1DIMD = DABS(F1DIMD)
	ELSE IF (ISPRING.EQ.2) THEN
	  XFI12 = PI
	  XFI13 = 0.D0
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = 0.D0
	  XY3 = 0.D0
	  XETA = X10
	  RESFUNC = F1DIMD
	  F1DIMD = DABS(F1DIMD)
	ENDIF
	RETURN
	END 
C********************************************************************
C===================================================================
	SUBROUTINE AMPD3(s,x1,x2,y3,pt3,y5,pt5,fi35,CAMP)
	IMPLICIT REAL*8(A-H,L-Z)
	PARAMETER (K0MAX=2)
	DIMENSION H12(K0MAX),H13(K0MAX),H14(K0MAX)
	DIMENSION H34(K0MAX),H23(K0MAX),H24(K0MAX),CONS(K0MAX)
	DIMENSION CAMP(K0MAX)
	S12 =  x1*x2*s/2.d0
	S13 =  x1*pt3*dsqrt(s)/2.d0*dexp(-y3)
	S23 =  x2*pt3*dsqrt(s)/2.d0*dexp(y3)
	S15 =  x1*pt5*dsqrt(s)/2.d0*dexp(-y5)
	S25 =  x2*pt5*dsqrt(s)/2.d0*dexp(y5)
	S35 =  pt3*pt5*coshmcos(y3-y5,fi35)
	S14 =  s12-s13-s15
	S24 =  s12-s23-s25
	S34 =  s13+s23-s35
	S45 =  s15+s25-s35
	E12 = S12/(S15*S25)
	E13 = S13/(S15*S35)
	E23 = S23/(S25*S35)
	E34P = S34/(S15+S25)/S35
C -------------------------------------------
	CALL SH12D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H12)
	CALL SH13D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H13)
	CALL SH23D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H23)
	CALL SH34D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H34)
	CALL SCONSD(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,CONS)
	DO I=1,K0MAX
	  CAMP(I) = (0.5D0*H12(I)*E12+H13(I)*E13
     #	             +H23(I)*E23+H34(I)*E34P+0.5D0*CONS(I))
	ENDDO
	RETURN
	END
C===================================================================
	subroutine ampd_corr3(s,x1,x2,y3,pt3,pt5,rs,camp)
	implicit real*8(a-h,l-z)
	parameter (K0MAX=2)
	dimension h12(k0max),h13(k0max),h14(k0max)
	dimension h34(k0max),h23(k0max),h24(k0max),cons(k0max)
	dimension camp(k0max)
	s12 =  x1*x2*s/2.d0
	s13 =  x1*pt3*dsqrt(s)/2.d0*dexp(-y3)
	s23 =  x2*pt3*dsqrt(s)/2.d0*dexp(y3)
	s15 =  x1*pt5*dsqrt(s)/2.d0*dexp(-y3)
	s25 =  x2*pt5*dsqrt(s)/2.d0*dexp(y3)
	s35 =  0.d0
	s14 =  s12-s13-s15
	s24 =  s12-s23-s25
	s34 =  s13+s23-s35
	s45 =  s15+s25-s35
c -------------------------------------------
	call sh13d(s12,s13,s14,s15,s23,s24,s25,s34,s35,s45,h13)
	call sh23d(s12,s13,s14,s15,s23,s24,s25,s34,s35,s45,h23)
	call sh34d(s12,s13,s14,s15,s23,s24,s25,s34,s35,s45,h34)
	do i=1,k0max
	  camp(i) = (h13(i)+h23(i)+h34(i))*2.d0/rs/(pt5*pt5)
	enddo
	return
	end
C===================================================================
	SUBROUTINE AMPD4(s,x1,x2,y4,pt4,y5,pt5,fi45,CAMP)
	IMPLICIT REAL*8(A-H,L-Z)
	PARAMETER (K0MAX=2)
	DIMENSION H12(K0MAX),H13(K0MAX),H14(K0MAX)
	DIMENSION H34(K0MAX),H23(K0MAX),H24(K0MAX),CONS(K0MAX)
	DIMENSION CAMP(K0MAX)
	S12 =  x1*x2*s/2.d0
	S14 =  x1*pt4*dsqrt(s)/2.d0*dexp(-y4)
	S24 =  x2*pt4*dsqrt(s)/2.d0*dexp(y4)
	S15 =  x1*pt5*dsqrt(s)/2.d0*dexp(-y5)
	S25 =  x2*pt5*dsqrt(s)/2.d0*dexp(y5)
	S45 =  pt4*pt5*coshmcos(y4-y5,fi45)
	S13 =  s12-s14-s15
	S23 =  s12-s24-s25
	S34 =  s14+s24-s45
	S35 =  s15+s25-s45
	E12 = S12/(S15*S25)
	E13 = S13/(S15*S35)
	E23 = S23/(S25*S35)
	E14 = S14/(S15*S45)
	E24 = S24/(S25*S45)
	E34S = S34/(S15+S25)/S45
C -------------------------------------------
	CALL SH12D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H12)
	CALL SH14D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H14)
	CALL SH24D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H24)
	CALL SH34D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H34)
	CALL SCONSD(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,CONS)
	DO I=1,K0MAX
	  CAMP(I) = (0.5D0*H12(I)*E12+H14(I)*E14
     #	             +H24(I)*E24+H34(I)*E34S+0.5D0*CONS(I))
	ENDDO
	RETURN
	END
C===================================================================
	subroutine ampd_corr4(s,x1,x2,y4,pt4,pt5,rs,camp)
	implicit real*8(a-h,l-z)
	parameter (K0MAX=2)
	dimension h12(k0max),h13(k0max),h14(k0max)
	dimension h34(k0max),h23(k0max),h24(k0max),cons(k0max)
	dimension camp(k0max)
	s12 =  x1*x2*s/2.d0
	s14 =  x1*pt4*dsqrt(s)/2.d0*dexp(-y4)
	s24 =  x2*pt4*dsqrt(s)/2.d0*dexp(y4)
	s15 =  x1*pt5*dsqrt(s)/2.d0*dexp(-y4)
	s25 =  x2*pt5*dsqrt(s)/2.d0*dexp(y4)
	s45 =  0.d0
	s13 =  s12-s14-s15
	s23 =  s12-s24-s25
	s34 =  s14+s24-s45
	s35 =  s15+s25-s45
C -------------------------------------------
	call sh14d(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,h14)
	call sh24d(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,h24)
	call sh34d(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,h34)
	do i=1,k0max
	  camp(i) = (h14(i)+h24(i)+h34(i))*2.d0/rs/(pt5*pt5)
	enddo
	return
	end
C********************************************************************
