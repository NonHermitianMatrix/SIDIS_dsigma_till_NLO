C*****************************************************	
C pour photoproduction d'un photon direct
C*************************************************
c correction d'un bug 	QCHARGE -> Qcharge**2 le 12.10.00
c
	SUBROUTINE STRFRAD(X1,X2,IH2,SFD)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/GDF/JNF
	COMMON/SCALE/M,MF,MU
	DIMENSION F2(-6:6),D4(-6:6)
C no crossing, therefore K0MAX=J0MAX	
	PARAMETER (K0MAX=2,J0MAX=2)
c qcharge est la valeur absolue de la charge des quarks fois 3 au carre
	DIMENSION SF(K0MAX),SFD(K0MAX),QCHARGE(6)
	DATA QCHARGE/1.D0,4.D0,1.D0,4.D0,1.D0,4.D0/
C structure functions and WW in /pdfs/distfun.f
	CALL GAMSTRU(X1,F1)
	CALL FSTRU(X2,M*M,IH2,F2)
C initialisation du tableau SF(K0MAX)
	ZERO = 0.D0
	CALL VEC_DINIT(SF,K0MAX,ZERO)
	CALL VEC_DINIT(SFD,K0MAX,ZERO)
C on commence les processus
	DO I=1,JNF
C	ph + qi --> jet + ph
C	j0 = 1 : ph + qi --> jet + ph 
	    SF(1) = F1*QCHARGE(I)**2*(F2(I) + F2(-I)) + SF(1)
	ENDDO		    
C	j0 = 2 : ph + g --> jet + ph
	    SF(2) = F1*F2(0) + SF(2)
C	summation over flavors in jet has been done in htermdir_jet.f already
C
C on divise tout par x1 x2
	XX = 1.D0/(X1*X2)
	CALL VEC_DMULT_CONSTANT(SF,K0MAX,XX,SFD)	    
	RETURN
	END
C
c ********************************************************************
