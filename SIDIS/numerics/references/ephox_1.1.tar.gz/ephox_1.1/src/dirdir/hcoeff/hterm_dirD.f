C*****************************************************
CC  TERMES QUI VIENNENT DE 5 COLLINEAIRE A 1
C*****************************************************
C PARTIE EN 1/(1-Z1)+
	SUBROUTINE VEC_15ZD(SC,TC,UC,Z1,M,PTM,VPART15Z)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART15Z(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART15Z(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = 0.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = eqi**4*E(SC,TC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(2) = t0
	VPART15Z(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = -eqi**4*E(TC,SC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2
     #)-FAQP(z1))/N
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*E(TC,SC,UC,N)*(-ANM4_QP(z1)-A4_QP(z1)*dlog(ptm**2/M**2
     #)+FAQP(z1))/N
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART15Z(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C PARTIE EN LOG(1-Z1)/(1-Z1)+
	SUBROUTINE VEC_15LD(SC,TC,UC,Z1,VPART15L)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART15L(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART15L(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = 0.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = -eqi**4*E(SC,TC,UC,N)*FBQP(z1)/N
	VTEMP(2) = t0
	VPART15L(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = eqi**4*E(TC,SC,UC,N)*FBQP(z1)/N
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*E(TC,SC,UC,N)*FBQP(z1)/N
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART15L(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C PARTIE EN DELTA(1-Z1)
	SUBROUTINE VEC_15DD(SC,TC,UC,M,PTM,VPART15D)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART15D(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART15D(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = 0.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = -eqi**4*E(SC,TC,UC,N)*FCQP(1.D0)/N
	VTEMP(2) = t0
	VPART15D(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = eqi**4*E(TC,SC,UC,N)*FCQP(1.D0)/N
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*E(TC,SC,UC,N)*FCQP(1.D0)/N
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART15D(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C*****************************************************
CC  TERMES QUI VIENNENT DE 5 COLLINEAIRE A 2
C*****************************************************
C PARTIE EN 1/(1-Z2)+
	SUBROUTINE VEC_25ZD(SC,TC,UC,Z2,M,PTM,VPART25Z)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART25Z(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART25Z(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = -eqi**4*F(UC,SC,TC,N)*(ANM4_QQ(z2)+A4_QQ(z2)*dlog(ptm**2/M**2
     #)-FAQQ(z2))
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = 0.D0
	VTEMP(2) = t0
	VPART25Z(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = -eqi**4*F(UC,SC,TC,N)*(N-1.D0)*(N+1.D0)*(ANM4_QG(z2)+A4_QG(z2
     #)*dlog(ptm**2/M**2)-FAQG(z2))/N
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*F(UC,SC,TC,N)*(N-1.D0)*(N+1.D0)*(-ANM4_QG(z2)-A4_QG(z2
     #)*dlog(ptm**2/M**2)+FAQG(z2))/N
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART25Z(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C PARTIE EN LOG(1-Z2)/(1-Z2)+
	SUBROUTINE VEC_25LD(SC,TC,UC,Z2,VPART25L)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART25L(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART25L(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = eqi**4*F(UC,SC,TC,N)*FBQQ(z2)
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = 0.D0
	VTEMP(2) = t0
	VPART25L(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = eqi**4*F(UC,SC,TC,N)*FBQG(z2)*(N-1.D0)*(N+1.D0)/N
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*F(UC,SC,TC,N)*FBQG(z2)*(N-1.D0)*(N+1.D0)/N
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART25L(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C PARTIE EN DELTA(1-Z2)
	SUBROUTINE VEC_25DD(SC,TC,UC,M,PTM,VPART25D)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART25D(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART25D(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = -eqi**4*F(UC,SC,TC,N)*(B_QQ()*dlog(ptm**2/M**2)-FCQQ(1.D0))
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = 0.D0
	VTEMP(2) = t0
	VPART25D(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = eqi**4*F(UC,SC,TC,N)*FCQG(1.D0)*(N-1.D0)*(N+1.D0)/N
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*F(UC,SC,TC,N)*FCQG(1.D0)*(N-1.D0)*(N+1.D0)/N
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART25D(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C*****************************************************
CC  TERMES QUI VIENNENT DE 5 COLLINEAIRE A 3
C*****************************************************
C PARTIE EN LOG(R**2)
	SUBROUTINE VEC_35RD(SC,TC,UC,ZM,R,VPART35R)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART35R(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART35R(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = -(N**2-1.D0)/N*(5.D0/8.D0-2.D0*dlog(2.D0)-2.D0*dlog(1.D0-zm)-
     #zm-zm**2/2.D0)*dlog(R**2)*eqi**4*F(UC,SC,TC,N)/2.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = -(N**2-1.D0)/N*(7.D0/8.D0+2.D0*dlog(2.D0)+2.D0*dlog(zm)-2.D0*
     #zm+zm**2/2.D0)*dlog(R**2)*eqi**4*F(UC,SC,TC,N)/2.D0
	VTEMP(2) = t0
	VPART35R(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = 0.D0
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = 0.D0
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART35R(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C PARTIE EN DELTA(1-Z3)
	SUBROUTINE VEC_35DD(SC,TC,UC,VPART35D)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART35D(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART35D(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = -(N**2-1.D0)/N*(27.D0/8.D0-0.3141592653589793D1**2/3.D0+4.D0*
     #dlog(2.D0)**2.D0+dlog(2.D0)/2.D0)*eqi**4*F(UC,SC,TC,N)/2.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = -(N**2-1.D0)/N*(25.D0/8.D0-0.3141592653589793D1**2/3.D0-4.D0*
     #dlog(2.D0)**2.D0-dlog(2.D0)/2.D0)*eqi**4*F(UC,SC,TC,N)/2.D0
	VTEMP(2) = t0
	VPART35D(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = 0.D0
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = 0.D0
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART35D(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C*****************************************************
CC  TERMES QUI VIENNENT DE 5 COLLINEAIRE A 4
C*****************************************************
C PARTIE EN LOG(R**2)
	SUBROUTINE VEC_45RD(SC,TC,UC,Z4,R,VPART45R)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART45R(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART45R(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = 0.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = -eqi**4*A4_PQ(z4)*dlog(R**2)/(1.D0-z4)*E(TC,SC,UC,N)
	VTEMP(2) = t0
	VPART45R(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = eqi**4*A4_PQ(z4)*dlog(R**2)/(1.D0-z4)*E(SC,TC,UC,N)
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*A4_PQ(z4)*dlog(R**2)/(1.D0-z4)*E(SC,TC,UC,N)
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART45R(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C PARTIE EN 1/(1-Z4)+
	SUBROUTINE VEC_45ZD(SC,TC,UC,Z4,MF,PT4,VPART45Z)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART45Z(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART45Z(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = 0.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = -eqi**4*E(TC,SC,UC,N)*(ANM4_PQ(z4)+A4_PQ(z4)*dlog(pt4**2/Mf**
     #2)-DAPQ(z4))
	VTEMP(2) = t0
	VPART45Z(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = eqi**4*E(SC,TC,UC,N)*(ANM4_PQ(z4)+A4_PQ(z4)*dlog(pt4**2/Mf**2
     #)-DAPQ(z4))
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*E(SC,TC,UC,N)*(ANM4_PQ(z4)+dlog(pt4**2/Mf**2)*A4_PQ(z4
     #)-DAPQ(z4))
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART45Z(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C PARTIE EN LOG(1-Z4)/(1-Z4)+
	SUBROUTINE VEC_45LD(SC,TC,UC,Z4,VPART45L)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART45L(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART45L(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = 0.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = eqi**4*E(TC,SC,UC,N)*(DBPQ(z4)-2.D0*A4_PQ(z4))
	VTEMP(2) = t0
	VPART45L(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = eqi**4*E(SC,TC,UC,N)*(-DBPQ(z4)+2.D0*A4_PQ(z4))
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = eqi**4*E(SC,TC,UC,N)*(-DBPQ(z4)+2.D0*A4_PQ(z4))
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART45L(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C PARTIE EN DELTA(1-Z4)
	SUBROUTINE VEC_45DD(SC,TC,UC,MF,PT4,VPART45D)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPART45D(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART45D(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      t0 = 0.D0
	VTEMP(1) = t0
c       ph + qi --> g + ph
      t0 = eqi**4*E(TC,SC,UC,N)*DCPQ(1.D0)
	VTEMP(2) = t0
	VPART45D(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      t0 = -eqi**4*E(SC,TC,UC,N)*DCPQ(1.D0)
	VTEMP(3) = t0 + VTEMP(3)
c       ph + g --> qbi + ph
      t0 = -eqi**4*E(SC,TC,UC,N)*DCPQ(1.D0)
	VTEMP(4) = t0 + VTEMP(4)
	ENDDO
	VPART45D(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
C*****************************************************
CC  TERMES QUI VIENNENT DE LA PARTIE VIRTUELLE
C*****************************************************
	SUBROUTINE VEC_VID(S,SC,TC,UC,MU,PT,PTM,VPARTVI)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VPARTVI(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPARTVI(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
	MU2 = MU**2
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
c       ph + qi --> qi + ph
      teraj = B_QQ()*dlog(ptm**2/S)*eqi**4*F(UC,SC,TC,N)+B_QQ()*dlog(pt*
     #*2/S)*eqi**4*F(UC,SC,TC,N)-(N**2-1.D0)/N*dlog(-UC/S)*F(UC,SC,TC,N)
     #*eqi**4*dlog(ptm**2/S)-A4_QQ(1.D0)*eqi**4*F(UC,SC,TC,N)*(dlog(pt**
     #2/S)**2.D0/4.D0-dlog(pt**2/S)*dlog(ptm**2/S)/2.D0)+A4_QQ(1.D0)*eqi
     #**4*F(UC,SC,TC,N)*dlog(ptm**2/S)**2.D0/4.D0
      teres = -4.D0*eqi**4*(N**2-1.D0)*(UC**2*dlog(-UC/S)**2.D0+(SC**2+U
     #C**2)*(dlog(SC/S)**2.D0-0.3141592653589793D1**2)+(-2.D0*SC**2-2.D0
     #*UC**2)*dlog(-UC/S)*dlog(SC/S)-2.D0*SC*TC*dlog(-UC/S)+TC*(3.D0*TC+
     #2.D0*SC)*dlog(SC/S)+0.3141592653589793D1**2*UC**2+0.31415926535897
     #93D1**2*SC**2/2.D0+0.3141592653589793D1**2*TC**2/2.D0-7.D0/2.D0*SC
     #**2-7.D0/2.D0*TC**2)/TC/SC-4.D0*eqi**4*(N**2-1.D0)*(UC**2*dlog(-UC
     #/S)**2.D0+(TC**2+UC**2)*dlog(-TC/S)**2.D0+(-2.D0*TC**2-2.D0*UC**2)
     #*dlog(-UC/S)*dlog(-TC/S)-2.D0*SC*TC*dlog(-UC/S)+SC*(3.D0*SC+2.D0*T
     #C)*dlog(-TC/S)+0.3141592653589793D1**2*UC**2+0.3141592653589793D1*
     #*2*SC**2/2.D0+0.3141592653589793D1**2*TC**2/2.D0-7.D0/2.D0*TC**2-7
     #.D0/2.D0*SC**2)/SC/TC
	VTEMP(1) = TERAJ+TERES
c       ph + qi --> g + ph
      teraj = 0.D0
      teres = 0.D0
	VTEMP(2) = TERAJ+TERES
	VPARTVI(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      teraj = 0.D0
      teres = 0.D0
	VTEMP(3) = TERAJ+TERES + VTEMP(3)
c       ph + g --> qbi + ph
      teraj = 0.D0
      teres = 0.D0
	VTEMP(4) = TERAJ+TERES + VTEMP(4)
	ENDDO
	VPARTVI(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
c ***************************************************************
	SUBROUTINE VEC_VI2D(S,SC,TC,UC,YS,FI,VPARTVI2)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	PARAMETER (J0MAX=2)
	DIMENSION VPARTVI2(J0MAX),HH34(J0MAX)
	PI=4.D0*DATAN(1.D0)
	DO I = 1,J0MAX
	  VPARTVI2(I) = 0.D0
	  HH34(I) = 0.D0
	ENDDO
C-------------------------------------------------------------------
	s12 = sc/2.d0
	s13 = -tc/2.d0
	s23 = -uc/2.d0
	s14 = s23
	s24 = s13
	s34 = s12
	s15 = 0.d0
	s25 = 0.d0
	s35 = 0.d0
	s45 = 0.d0
	CALL VEC_H34D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     #HH34)
	DW=DCOSH(2.D0*YS)+DCOS(2.D0*FI)
	XJ1=DLOG(DSIN(FI))
	XJ2=DSIN(2.D0*FI)*DLOG(DSIN(FI))*DATAN(DSIN(FI)/(1.D0-DCOS(FI)))
	A34=4.D0*XJ2+DSINH(2.D0*YS)*2.D0*YS*XJ1
	FFG=A34/DW+DLOG(2.D0)*DLOG(4.D0*DCOSH(YS)**2)
	DO I = 1,J0MAX
	  VPARTVI2(I) = HH34(I)*(FFG+FFG)/PI
	ENDDO
	RETURN
	END
C*****************************************************
