C constant part G(P5) 
C ----------------------------------------------------
	SUBROUTINE VEC_CONSD(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     #	VCONS)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VCONS(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VCONS(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
C	(include numerators of charges later in structdir_jet.f)
c       ph + qi --> qi + ph
      hcons = 0.D0
	VTEMP(1) = HCONS
c       ph + qi --> g + ph
      hcons = 0.D0
	VTEMP(2) = HCONS
	VCONS(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      hcons = 0.D0
	VTEMP(3) = HCONS + VTEMP(3)
c       ph + g --> qbi + ph
      hcons = 0.D0
	VTEMP(4) = HCONS + VTEMP(4)
	ENDDO
	VCONS(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
