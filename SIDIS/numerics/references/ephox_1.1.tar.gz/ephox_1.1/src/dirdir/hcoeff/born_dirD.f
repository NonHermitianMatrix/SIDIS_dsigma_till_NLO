C************************************************************
CC  elements de matrice 2 -> 2 
CC (BORN terms, not averaged over initial spins and colours)
C************************************************************
	SUBROUTINE VEC_BD(SC,TC,UC,N,VBORN)
	IMPLICIT REAL*8 (A-H,L-Z)
	PARAMETER (J0MAX=2)
	PARAMETER (EQI=0.3333333333333333)
	DIMENSION VBORN(J0MAX)
	DO I = 1,J0MAX
	  VBORN(I) = 0.D0
	ENDDO
C
C	j0 = 1 : ph + qi --> jet + ph
	VBORN(1) = -eqi**4*F(UC,SC,TC,N)
C	j0 = 2 : ph + g  --> jet + ph
	VBORN(2) = 0.D0
	RETURN
	END
