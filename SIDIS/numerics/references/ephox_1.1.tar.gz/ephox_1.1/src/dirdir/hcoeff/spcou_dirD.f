C*************************************************************
C average over initial spins and colours for 2 -> 2 matrix el.
C*************************************************************
	SUBROUTINE FSPCOUD(N,SPCOU)
	IMPLICIT REAL*8 (A-H,L-Z)
	PARAMETER (K0MAX=2)
	DIMENSION SPCOU(K0MAX)
	ZERO =0.D0
	CALL VEC_DINIT(SPCOU,K0MAX,ZERO)
	VC = N*N - 1.D0
C
C	j0 = 1 : ph + qi --> jet + ph
	SPCOU(1) = 1.D0/(4.D0*N)
C	j0 = 2 : ph + g --> jet + ph
	SPCOU(2) = 1.D0/(4.D0*VC)
	RETURN
	END
