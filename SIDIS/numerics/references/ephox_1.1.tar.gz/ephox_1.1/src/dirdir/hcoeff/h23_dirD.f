C coefficients devant p_2.p_3/(p_2.p_5 p_3.p_5)
C ----------------------------------------------------
	SUBROUTINE VEC_H23D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     #	VH23)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VH23(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VH23(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
C	(include numerators of charges later in structdir_jet.f)
c       ph + qi --> qi + ph
      hh23 = 8.D0*N*eqi**4*CF/s12/s24/s13/s34*(s12**3*s13+s12*s13**3+s24
     #**3*s34+s24*s34**3+s25**3*(s15+s25-s45)+s25*(s15+s25-s45)**3)
	VTEMP(1) = HH23
c       ph + qi --> g + ph
      hh23 = 0.D0
	VTEMP(2) = HH23
	VH23(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      hh23 = 0.D0
	VTEMP(3) = HH23 + VTEMP(3)
c       ph + g --> qbi + ph
      hh23 = 0.D0
	VTEMP(4) = HH23 + VTEMP(4)
	ENDDO
	VH23(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
