C coefficients devant p_3.p_4/(p_3.p_5 p_4.p_5)
C ----------------------------------------------------
	SUBROUTINE VEC_H34D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     #	VH34)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VH34(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VH34(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
C	(include numerators of charges later in structdir_jet.f)
c       ph + qi --> qi + ph
      hh34 = 0.D0
	VTEMP(1) = HH34
c       ph + qi --> g + ph
      hh34 = -8.D0/s34*N*eqi**4*CF/s24/s23/s12*(s12**3*s15+s12*s15**3+s2
     #4**3*s45+s24*s45**3+s23**3*(s15+s25-s45)+s23*(s15+s25-s45)**3)
	VTEMP(2) = HH34
	VH34(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      hh34 = 0.D0
	VTEMP(3) = HH34 + VTEMP(3)
c       ph + g --> qbi + ph
      hh34 = 0.D0
	VTEMP(4) = HH34 + VTEMP(4)
	ENDDO
	VH34(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
