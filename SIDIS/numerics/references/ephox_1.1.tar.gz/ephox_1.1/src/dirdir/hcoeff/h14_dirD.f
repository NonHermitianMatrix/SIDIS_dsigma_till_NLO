C coefficients devant p_1.p_4/(p_1.p_5 p_4.p_5)
C ----------------------------------------------------
	SUBROUTINE VEC_H14D(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     #	VH14)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=2,I0MAX=4)
	DIMENSION VH14(J0MAX),VTEMP(I0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VH14(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	j0 = 1 : ph + qi --> jet + ph
C
	EQI = 0.333333333333D0
C	(include numerators of charges later in structdir_jet.f)
c       ph + qi --> qi + ph
      hh14 = 0.D0
	VTEMP(1) = HH14
c       ph + qi --> g + ph
      hh14 = 8.D0/s14*N*eqi**4*CF/s24/s23/s12*(s12**3*s15+s12*s15**3+s24
     #**3*s45+s24*s45**3+s23**3*(s15+s25-s45)+s23*(s15+s25-s45)**3)
	VTEMP(2) = HH14
	VH14(1) = VTEMP(1) + VTEMP(2)
C
C	j0 = 2 : ph + g --> jet + ph
C
	DO I=1,JNF
	  EQI = QCH(I)
c       ph + g --> qi + ph
      hh14 = 8.D0/s14*N*eqi**4*CF/s34/s23/s13*(s15**3*s13+s15*s13**3+s45
     #**3*s34+s45*s34**3+s25**3*s23+s25*s23**3)
	VTEMP(3) = HH14 + VTEMP(3)
c       ph + g --> qbi + ph
      hh14 = 8.D0/s14*N*eqi**4*CF/s34/s23/s13*(s13**3*s15+s13*s15**3+s34
     #**3*s45+s34*s45**3+s23**3*s25+s23*s25**3)
	VTEMP(4) = HH14 + VTEMP(4)
	ENDDO
	VH14(2) = VTEMP(3) + VTEMP(4)
	RETURN
	END
