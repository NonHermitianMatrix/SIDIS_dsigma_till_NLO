C*****************************************************
C facteur de couleur pour les differents elements de matrice 2 --> 2
C*****************************************************
	SUBROUTINE FSPCOUresD(N,SPCOU)
	IMPLICIT REAL*8 (A-H,L-Z)
	PARAMETER (K0MAX=22,J0MAX=11)
	DIMENSION SPCOU(K0MAX)
	ZERO =0.D0
	CALL VEC_DINIT(SPCOU,K0MAX,ZERO)
	VC = N*N - 1.D0
C on commence les processus
C
C	qi + qk --> jet + ph
C
C	j0 = 1 : D + U --> jet + ph
	SPCOU(1) = 1.D0/(4.D0*N*N)
C	j0 = 2 : D + Dp --> jet + ph
	SPCOU(2) = 1.D0/(4.D0*N*N)
C	j0 = 3 : U + Up --> jet + ph
	SPCOU(3) = 1.D0/(4.D0*N*N)
C
C	qi + qbk --> jet + ph
C
C	j0 = 4 : D + Ub --> jet + ph
	SPCOU(4) = 1.D0/(4.D0*N*N)
C	j0 = 5 : D + Dpb --> jet + ph
	SPCOU(5) = 1.D0/(4.D0*N*N)
C	j0 = 6 : U + Upb --> jet + ph
	SPCOU(6) = 1.D0/(4.D0*N*N)
C
C	j0 = 7 : qi + qi --> jet + ph
C
	SPCOU(7) = 1.D0/(4.D0*N*N)
C
C	qi + qbi --> jet + ph
C
C	j0 = 8 : D + Db --> jet + ph
	SPCOU(8) = 1.D0/(4.D0*N*N)
C	j0 = 9 : U + Ub --> jet + ph
	SPCOU(9) = 1.D0/(4.D0*N*N)
C
C	j0 = 10 : qi + g --> jet + ph
C
	SPCOU(10) = 1.D0/(4.D0*N*VC)
C
C	j0 = 11 : g + g --> jet + ph
C
	SPCOU(11) = 1.D0/(4.D0*VC*VC)
C
	DO I=1,J0MAX
	  SPCOU(I+11) = SPCOU(I)
	ENDDO
	RETURN
	END
