C*****************************************************	
C pour production d'un photon
c photon strufu has to be called with x1/eta in reso subroutine!
c account for extra eta coming in by division with x1/eta 
c in big reso subroutines 	
	SUBROUTINE STRFRAPHD(X1,IH1,X2,IH2,ETA,SFO)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/GDF/JNF
	COMMON/SCALE/M,MF,MU
	DIMENSION F1(-6:6),F2(-6:6),D3(-6:6)
	PARAMETER (K0MAX=22,J0MAX=11)
c qcharge est la valeur absolue de la charge des quarks fois 3 au carre
	DIMENSION SF(K0MAX),SFO(K0MAX),QCHARGE(6)
	DATA QCHARGE/1.D0,4.D0,1.D0,4.D0,1.D0,4.D0/
c	
	CALL GAMSTRU(ETA,Fww)
c ih1 must be flag for parton distributions in the photon	
	CALL FSTRU(X1,M*M,IH1,F1)
	CALL FSTRU(X2,M*M,IH2,F2)
C initialisation du tableau SF(K0MAX)
	ZERO = 0.D0
	CALL VEC_DINIT(SF,K0MAX,ZERO)
	CALL VEC_DINIT(SFO,K0MAX,ZERO)
C on commence les processus
	DO I=1,JNF,2
	  DO K=2,JNF,2
C	qi + qk --> jet + ph
C	j0 = 1 : D + U --> jet + ph 
	    SF(1) = F1(I)*F2(K) + 	    
     #              F1(-I)*F2(-K) + SF(1)
	    SF(1+11) = F1(K)*F2(I) + 	    
     #                 F1(-K)*F2(-I) + SF(1+11)
C	qi + qbk --> qi + ph
C	j0 = 4 : D + Ub --> jet + ph
	    SF(4) = F1(I)*F2(-K) + 	    
     #              F1(-I)*F2(K) + SF(4)
	    SF(4+11) = F1(-K)*F2(I) + 	    
     #                 F1(K)*F2(-I) + SF(4+11)
	  ENDDO
	ENDDO
	DO I=1,JNF,2
	  DO K=I+2,JNF,2
C	j0 = 2 : D + Dp --> jet + ph
	    SF(2) = F1(I)*F2(K) + 	    
     #              F1(-I)*F2(-K) + SF(2)
	    SF(2+11) = F1(K)*F2(I) + 	    
     #                 F1(-K)*F2(-I) + SF(2+11)
C	j0 = 3 : U + Up --> jet + ph
	    SF(3) = F1(I+1)*F2(K+1) + 	    
     #              F1(-I-1)*F2(-K-1) + SF(3)
	    SF(3+11) = F1(K+1)*F2(I+1) + 	    
     #                 F1(-K-1)*F2(-I-1) + SF(3+11)
C	j0 = 5 : D + Dpb --> jet + ph
	    SF(5) = F1(I)*F2(-K) + 	    
     #              F1(-I)*F2(K) + SF(5)
	    SF(5+11) = F1(-K)*F2(I) + 	    
     #                 F1(K)*F2(-I) + SF(5+11)
C	j0 = 6 : U + Upb --> jet + ph
	    SF(6) = F1(I+1)*F2(-K-1) + 	    
     #              F1(-I-1)*F2(K+1) + SF(6)
	    SF(6+11) = F1(-K-1)*F2(I+1) + 	    
     #                 F1(K+1)*F2(-I-1) + SF(6+11)
	  ENDDO
	ENDDO
	DO I=1,JNF,2
C	qi + qbi --> jet + ph
C	j0 = 8 : D + Db --> jet + ph
	  SF(8) = F1(I)*F2(-I) + SF(8)
	  SF(8+11) = F1(-I)*F2(I) + SF(8+11)
C	j0 = 9 : U + Ub --> jet + ph
	  SF(9) = F1(I+1)*F2(-I-1) + SF(9)
	  SF(9+11) = F1(-I-1)*F2(I+1) + SF(9+11)
	ENDDO
	DO I=1,JNF
C	j0 = 7 : qi + qi --> jet + ph
	  SF(7) = QCHARGE(I)*(F1(I)*F2(I) + 	    
     #             F1(-I)*F2(-I))/2.D0 + SF(7)
C	j0 = 10 : qi + g --> jet + ph
	  SF(10) = QCHARGE(I)*(F1(I)*F2(0) + 	    
     #            F1(-I)*F2(0)) + SF(10)
	  SF(10+11) = QCHARGE(I)*(F1(0)*F2(I) + 	    
     #               F1(0)*F2(-I)) + SF(10+11)
	ENDDO 	    
C	j0 = 11 : g + g --> qi + ph
	SF(11) = F1(0)*F2(0)/2.d0 + SF(11)
C
     	SF(7+11) = SF(7)
C
     	SF(11+11) = SF(11)
C
C on divise tout par x1 x2 et multiplie par Fww(eta)/eta
	XX = Fww/(X1*X2*ETA)
	CALL VEC_DMULT_CONSTANT(SF,K0MAX,XX,SFO)	    
	RETURN
	END
C
