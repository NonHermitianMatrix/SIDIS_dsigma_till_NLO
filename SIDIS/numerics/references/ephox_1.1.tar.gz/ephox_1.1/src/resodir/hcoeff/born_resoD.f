C*****************************************************
C elements de matrice 2 --> 2
C ces elements de matrice ne sont pas moyennes sur les
C spin et couleurs initiaux
C*****************************************************
c
	SUBROUTINE VEC_BresD(SC,TC,UC,N,VBORN)
	IMPLICIT REAL*8 (A-H,L-Z)
	PARAMETER (J0MAX=11)
	PARAMETER (EQI=0.3333333333333333)
	DIMENSION VBORN(J0MAX)
	DO I = 1,J0MAX
		VBORN(I) = 0.D0
	ENDDO
C on commence les processus
C
C	qi + qk --> jet + ph
C
C	j0 = 1 : D + U --> jet + ph
c       qi + qk --> qi + photon
c       qi + qk --> qk + photon
	VBORN(1) = 0.D0
C	j0 = 2 : D + Dp --> jet + ph
c       qi + qk --> qi + photon
c       qi + qk --> qk + photon
	VBORN(2) = 0.D0
C	j0 = 3 : U + Up --> jet + ph
c       qi + qk --> qi + photon
c       qi + qk --> qk + photon
	VBORN(3) = 0.D0
C
C	qi + qbk --> jet + ph
C
C	j0 = 4 : D + Ub --> jet + ph
c       qi + qbk --> qi + photon
c       qi + qbk --> qbk + photon
	VBORN(4) = 0.D0
C	j0 = 5 : D + Dpb --> jet + ph
c       qi + qbk --> qi + photon
c       qi + qbk --> qbk + photon
	VBORN(5) = 0.D0
C	j0 = 6 : U + Upb --> jet + ph
c       qi + qbk --> qi + photon
c       qi + qbk --> qbk + photon
	VBORN(6) = 0.D0
C
C	j0 = 7 : qi + qi --> jet + ph
C
c       qi + qi --> qi + photon
c       qi + qbi --> qi + photon
	VBORN(7) = 0.D0
C
C	qi + qbi --> jet + ph
C
C	j0 = 8 : D + Db --> jet + ph
c       qi + qbi --> qk + photon
c       qi + qbi --> qbk + photon
c       qi + qbi --> qi + photon
c       qi + qbi --> qbi + photon
c       qi + qbi --> g + photon
	VBORN(8) = E(SC,TC,UC,N)*EQI**2
C	j0 = 9 : U + Ub --> jet + ph
c       qi + qbi --> qk + photon
c       qi + qbi --> qbk + photon
c       qi + qbi --> qi + photon
c       qi + qbi --> qbi + photon
c       qi + qbi --> g + photon
	VBORN(9) = E(SC,TC,UC,N)*EQI**2*4.D0
C
C	j0 = 10 : qi + g --> jet + ph
C
c       qi + g --> qi + photon
c       qi + g --> g + photon
 	VBORN(10) = -E(TC,SC,UC,N)*EQI**2
C
C	j0 = 11 : g + g --> jet + ph
C
c       g + g --> qi + photon
c       g + g --> qbi + photon
	VBORN(11) = 0.D0
C
	RETURN
	END
C
