C*****************************************************	
C pour production d'un photon	
	SUBROUTINE STRFRAPHO(X1,IH1,X2,IH2,X4,IH4,ETA,SFO)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/GDF/JNF
	COMMON/SCALE/M,MF,MU
	DIMENSION F1(-6:6),F2(-6:6),D4(-6:6)
	PARAMETER (K0MAX=32,J0MAX=16)
	DIMENSION SF(K0MAX),SFO(K0MAX)
c
	CALL GAMSTRU(ETA,Fww)
c ih1 must be flag for parton distributions in the photon (ih1 = 2)	
	CALL FSTRU(X1,M*M,IH1,F1)
	CALL FSTRU(X2,M*M,IH2,F2)
	CALL DFRAG(X4,MF*MF,IH4,D4)
C initialisation du tableau SF(K0MAX)
	ZERO = 0.D0
	CALL VEC_DINIT(SF,K0MAX,ZERO)
	CALL VEC_DINIT(SFO,K0MAX,ZERO)
C on commence les processus
	DO I=1,JNF-1
	  DO K=I+1,JNF
C	j0 = 1 : qi + qk --> jet + qk
	    SF(1) = F1(I)*F2(K)*D4(K) + F1(K)*F2(I)*D4(I) +	    
     #              F1(-I)*F2(-K)*D4(-K) + F1(-K)*F2(-I)*D4(-I) + SF(1)
	    SF(1+16) = F1(K)*F2(I)*D4(K) + F1(I)*F2(K)*D4(I) + 	    
     #                 F1(-K)*F2(-I)*D4(-K) + F1(-I)*F2(-K)*D4(-I) + 
     #                 SF(1+J0MAX)
C	j0 = 2 : qi + qk --> jet + g
	    SF(2) = F1(I)*F2(K)*D4(0) + 	    
     #              F1(-I)*F2(-K)*D4(0) + SF(2)
	    SF(2+16) = F1(K)*F2(I)*D4(0) + 	    
     #                 F1(-K)*F2(-I)*D4(0) + SF(2+J0MAX)
C	j0 = 3 : qi + qbk --> jet + qbk
	    SF(3) = F1(I)*F2(-K)*D4(-K) + F1(K)*F2(-I)*D4(-I) + 	    
     #              F1(-I)*F2(K)*D4(K) + F1(-K)*F2(I)*D4(I) + SF(3)
	    SF(3+16) = F1(-K)*F2(I)*D4(-K) + F1(-I)*F2(K)*D4(-I) +	    
     #                 F1(K)*F2(-I)*D4(K) + F1(I)*F2(-K)*D4(I) + 
     #                 SF(3+J0MAX)
C	j0 = 7 : qi + qbi --> jet + qbk
	    SF(7) = F1(I)*F2(-I)*D4(-K) + F1(K)*F2(-K)*D4(-I) + 	    
     #              F1(-I)*F2(I)*D4(K) + F1(-K)*F2(K)*D4(I) + SF(7)
	    SF(7+16) = F1(-I)*F2(I)*D4(-K) +  F1(-K)*F2(K)*D4(-I) +	    
     #                 F1(I)*F2(-I)*D4(K) + F1(K)*F2(-K)*D4(I) + 
     #                 SF(7+J0MAX)
	  ENDDO
	ENDDO
	DO I=1,JNF
	  DO K=1,JNF
	    IF (K.NE.I) THEN
C	j0 = 4 : qi + qbk --> jet + g
	      SF(4) = F1(I)*F2(-K)*D4(0) + SF(4)
	      SF(4+16) = F1(-K)*F2(I)*D4(0) + SF(4+J0MAX)
C	j0 = 10 : qi + g --> jet + qk
	      SF(10) = F1(I)*F2(0)*D4(K) + 	    
     #                F1(-I)*F2(0)*D4(-K) + SF(10)
	      SF(10+16) = F1(0)*F2(I)*D4(K) + 	    
     #                   F1(0)*F2(-I)*D4(-K) + SF(10+J0MAX)
C	j0 = 11 : qi + g --> jet + qbk
	      SF(11) = F1(I)*F2(0)*D4(-K) + 	    
     #                F1(-I)*F2(0)*D4(K) + SF(11)
	      SF(11+16) = F1(0)*F2(I)*D4(-K) + 	    
     #                   F1(0)*F2(-I)*D4(K) + SF(11+J0MAX)
	    ENDIF
	  ENDDO
	ENDDO 	    
	DO I=1,JNF
C	j0 = 5 : qi + qi --> jet + qi
	  SF(5) = (F1(I)*F2(I)*D4(I) + 	    
     #             F1(-I)*F2(-I)*D4(-I))/2.D0 + SF(5)
C	j0 = 6 : qi + qi --> jet + g
	  SF(6) = (F1(I)*F2(I)*D4(0) + 	    
     #             F1(-I)*F2(-I)*D4(0))/2.D0 + SF(6)
C	j0 = 8 : qi + qbi --> jet + qbi
	    SF(8) = F1(I)*F2(-I)*D4(-I) + 	    
     #              F1(-I)*F2(I)*D4(I) + SF(8)
	    SF(8+16) = F1(-I)*F2(I)*D4(-I) + 	    
     #                 F1(I)*F2(-I)*D4(I) + SF(8+J0MAX)
C	j0 = 9 : qi + qbi --> jet + g
	    SF(9) = F1(I)*F2(-I)*D4(0) + SF(9)
	    SF(9+16) = F1(-I)*F2(I)*D4(0) + SF(9+J0MAX)
C	j0 = 12 : qi + g --> jet + qbi
	    SF(12) = F1(I)*F2(0)*D4(-I) + 	    
     #              F1(-I)*F2(0)*D4(I) + SF(12)
	    SF(12+16) = F1(0)*F2(I)*D4(-I) + 	    
     #                 F1(0)*F2(-I)*D4(I) + SF(12+J0MAX)
C	j0 = 13 : qi + g --> jet + g
	    SF(13) = F1(I)*F2(0)*D4(0) + 	    
     #              F1(-I)*F2(0)*D4(0) + SF(13)
	    SF(13+16) = F1(0)*F2(I)*D4(0) + 	    
     #                 F1(0)*F2(-I)*D4(0) + SF(13+J0MAX)
C	j0 = 14 : qi + g --> jet + qi
	    SF(14) = F1(I)*F2(0)*D4(I) + 	    
     #              F1(-I)*F2(0)*D4(-I) + SF(14)
	    SF(14+16) = F1(0)*F2(I)*D4(I) + 	    
     #                 F1(0)*F2(-I)*D4(-I) + SF(14+J0MAX)
C	j0 = 15 : g + g --> jet + qi
	  SF(15) = (F1(0)*F2(0)*D4(I) + 	    
     #             F1(0)*F2(0)*D4(-I))/2.d0 + SF(15)
	ENDDO 	    
C	j0 = 16 : g + g --> jet + g
	SF(16) = (F1(0)*F2(0)*D4(0))/2.d0
C
     	SF(5+16) = SF(5)
     	SF(6+16) = SF(6)
C
     	SF(15+16) = SF(15)
     	SF(16+16) = SF(16)
C
C on divise tout par x1 x2 et multiplie par Fww(eta)/eta
	XX = Fww/(X1*X2*ETA)
	CALL VEC_DMULT_CONSTANT(SF,K0MAX,XX,SFO)	    
	RETURN
	END
C
