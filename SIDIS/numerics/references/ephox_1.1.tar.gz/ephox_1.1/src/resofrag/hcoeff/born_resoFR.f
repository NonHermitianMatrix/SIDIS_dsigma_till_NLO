C*****************************************************
C elements de matrice 2 --> 2
C ces elements de matrice ne sont pas moyennes sur les
C spin et couleurs initiaux
C*****************************************************
	SUBROUTINE VEC_BresO(SC,TC,UC,N,VBORN)
	IMPLICIT REAL*8 (A-H,L-Z)
	PARAMETER (J0MAX=16)
	DIMENSION VBORN(J0MAX)
	DO I = 1,J0MAX
		VBORN(I) = 0.D0
	ENDDO
C on commence les processus
C	j0 = 1 : qi + qk --> jet + qk
	VBORN(1) = A(SC,TC,UC,N)
C	j0 = 2 : qi + qk --> jet + g
	VBORN(2) = 0.D0
c	j0 = 3 : qi + qbk --> jet + qbk
	VBORN(3) = A(UC,TC,SC,N)
C	j0 = 4 : qi + qbk --> jet + g
	VBORN(4) = 0.D0
C	j0 = 5 : qi + qi --> jet + qi
	VBORN(5) = A(SC,TC,UC,N) + A(SC,UC,TC,N) + B(SC,TC,UC,N)
C	j0 = 6 : qi + qi --> jet + g
	VBORN(6) = 0.D0
C	j0 = 7 : qi + qbi --> jet + qbk
	VBORN(7) = A(TC,SC,UC,N)
C	j0 = 8 : qi + qbi --> jet + qbi
	VBORN(8) = A(UC,TC,SC,N) + A(UC,SC,TC,N) + B(UC,TC,SC,N)
C	j0 = 9 : qi + qbi --> jet + g
	VBORN(9) = C(SC,TC,UC,N)
C	j0 = 10 : qi + g --> jet + qk
	VBORN(10) = 0.D0
C	j0 = 11 : qi + g --> jet + qbk
	VBORN(11) = 0.D0
C	j0 = 12 : qi + g --> jet + qbi
	VBORN(12) = 0.D0
C	j0 = 13 : qi + g --> jet + g
	VBORN(13) = -C(TC,SC,UC,N)
C	j0 = 14 : qi + g --> jet + qi
	VBORN(14) = -C(UC,SC,TC,N)
C	j0 = 15 : g + g --> jet + qi
	VBORN(15) = C(SC,UC,TC,N)
C	j0 = 16 : g + g --> jet + g
	VBORN(16) = Dg(SC,TC,UC,N)
C
	RETURN
	END
