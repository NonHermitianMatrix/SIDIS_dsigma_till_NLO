C*****************************************************
C facteur de couleur pour les differents elements de matrice 2 --> 2
C*****************************************************
	SUBROUTINE FSPCOUresO(N,SPCOU)
	IMPLICIT REAL*8 (A-H,L-Z)
	PARAMETER (K0MAX=32,J0MAX=16)
	DIMENSION SPCOU(K0MAX)
	ZERO =0.D0
	CALL VEC_DINIT(SPCOU,K0MAX,ZERO)
	VC = N*N - 1.D0
C on commence les processus
C	j0 = 1 : qi + qk --> jet + qk
	SPCOU(1) = 1.D0/(4.D0*N*N)
C	j0 = 2 : qi + qk --> jet + g
	SPCOU(2) = 1.D0/(4.D0*N*N)
c	j0 = 3 : qi + qbk --> jet + qbk
	SPCOU(3) = 1.D0/(4.D0*N*N)
C	j0 = 4 : qi + qbk --> jet + g
	SPCOU(4) = 1.D0/(4.D0*N*N)
C	j0 = 5 : qi + qi --> jet + qi
	SPCOU(5) = 1.D0/(4.D0*N*N)
C	j0 = 6 : qi + qi --> jet + g
	SPCOU(6) = 1.D0/(4.D0*N*N)
C	j0 = 7 : qi + qbi --> jet + qbk
	SPCOU(7) = 1.D0/(4.D0*N*N)
C	j0 = 8 : qi + qbi --> jet + qbi
	SPCOU(8) = 1.D0/(4.D0*N*N)
C	j0 = 9 : qi + qbi --> jet + g
	SPCOU(9) = 1.D0/(4.D0*N*N)
C	j0 = 10 : qi + g --> jet + qk
	SPCOU(10) = 1.D0/(4.D0*N*VC)
C	j0 = 11 : qi + g --> jet + qbk
	SPCOU(11) = 1.D0/(4.D0*N*VC)
C	j0 = 12 : qi + g --> jet + qbi
	SPCOU(12) = 1.D0/(4.D0*N*VC)
C	j0 = 13 : qi + g --> jet + g
	SPCOU(13) = 1.D0/(4.D0*N*VC)
C	j0 = 14 : qi + g --> jet + qi
	SPCOU(14) = 1.D0/(4.D0*N*VC)
C	j0 = 15 : g + g --> jet + qi
	SPCOU(15) = 1.D0/(4.D0*VC*VC)
C	j0 = 16 : g + g --> jet + g
	SPCOU(16) = 1.D0/(4.D0*VC*VC)
C
	DO I=1,J0MAX
	  SPCOU(I+J0MAX) = SPCOU(I)
	ENDDO
	RETURN
	END
C
