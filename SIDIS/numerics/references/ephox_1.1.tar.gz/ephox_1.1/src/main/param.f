c choix des differents parametres
	SUBROUTINE PARAM
	IMPLICIT REAL*8 (A-H,L-Z)
	LOGICAL LO,NLO,GENER,INTEG,INTEGA
	LOGICAL DDIR,DFRAG,RDIR,RFRAG
	LOGICAL flag_grids
        COMMON/ALFA/MASCH2,MASBO2,MASTO2,LAMBDA4SQUARE
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/GDF/JNF
	COMMON/COUL/N,CF,GTR
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/COUP/PTM,R
	common/flags/flag_grids
	common/gluweight/ggawght,gprotwght
	common/jets/jetmode
	COMMON/W50512/QCDL4,QCDL5
	COMMON/ALEM/ILOOPEM
	COMMON/COUPEL/ETAINF,ETASUP,Q2MAXW,XGACUT
	COMMON/FACONV/HC2
	COMMON/NBOUCLE/ILOOP
	COMMON/FSCHEME/ISCHEME
	COMMON/AURENCHE/IAUREN
	COMMON/BOX/IBOX
	COMMON/PROCESSD/J_PROCESSD_MIN,J_PROCESSD_MAX
	COMMON/PROCESSO/J_PROCESSO_MIN,J_PROCESSO_MAX
	COMMON/PROCESSresD/J_PROCESSresD_MIN,J_PROCESSresD_MAX
	COMMON/PROCESSresO/J_PROCESSresO_MIN,J_PROCESSresO_MAX
	COMMON/APPROX/LO,NLO
	COMMON/CALCUL/INTEG,INTEGA,GENER
	COMMON/NBEVENT/INBEVENT
	COMMON/BASEPARAM/JTMX1,JTMX2,JCALL,JCALL1,JCALL2,IXTRY
	COMMON/ACCURACY/ACCU
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	COMMON/PCLASS/DDIR,DFRAG,RDIR,RFRAG
	common/isophot/iphotisol
	common/frixione/isofrixione
	common/etfix/isofix
	common/emax/etmax
	COMMON/FICUT/FIMIN
	COMMON/FRAGFLAG/IFLAG
        CHARACTER*20 PARM(20)
	COMMON/PDF/VALUE(20),VALUEP(20)
	CHARACTER*128 PATH_BSFILE,PATH_RZFILE,PATH_PDF
	COMMON/CHEMINBS/PATH_BSFILE
	COMMON/LONG/ILEN
	COMMON/CHEMINRZ/PATH_RZFILE
	COMMON/LONGRZ/ILENRZ
	COMMON/CHEMINPDF/PATH_PDF
	COMMON/LONGPPDF/ILENPPDF
	common/lname/ilname
	common/coup_histo/r_isol,epsilon_h
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	common/testc/jcount	
c	
c	write (6,*) 'reads parameters'
c nom pour le chemin ou se trouveront les fichiers .bs
	read *,path_bsfile
	ilen = icharnum(path_bsfile)
	OPEN(UNIT=8,FILE=PATH_BSFILE(1:ILEN)//'output.param',
     #	STATUS='unknown')
	write (8,*) 'ilen=',ilen
	write (8,*) 'path_bsfile=',path_bsfile(1:ilen)     
c path for the tables needed for pdfs, fragfus
c	read *, path_pdf
	path_pdf = '../pdfs/'
	ilenppdf = icharnum(path_pdf)	
	write (8,*) 'ilenppdf= ', ilenppdf
	write (8,*) 'path_pdf= ', path_pdf(1:ilenppdf)	
c nom pour le chemin ou se trouveront les fichiers .rz et .res
	read *,path_rzfile
	ilenrz = icharnum(path_rzfile)	
	write (8,*) 'ilenrz=',ilenrz
	write (8,*) 'path_rzfile=',path_rzfile(1:ilenrz)
c If flag_grids = true, the PHOTON distribution functions are read from the
c grids GRPOL and GRVDM; not from PDFLIB
	read *, flag_grids
	write(8,*) 'flag_grids=',flag_grids
c
c determination dans pdflib des fonctions de distribution dans 
c le hadron h1
c only used for resolved case and flag_grids = false; 
c then it determines parton distributions in the photon, see distfun.f
	PARM(1) = 'NPTYPE'
	read *,valuep(1)
	write(8,*) 'valuep(1)=',valuep(1)
	PARM(2) = 'NGROUP'
	read *,valuep(2)
	write(8,*) 'valuep(2)=',valuep(2)
	PARM(3) = 'NSET'
	read *,valuep(3)
	write(8,*) 'valuep(3)=',valuep(3)
c ih1 et ih2 determinent le choix des particules initiales, ih = 0:
c proton; ih = 1: antiproton, ih = 2: photon, ih = 3: pion
c ih2 est la particule cible, ih1 est la particule incidente
c	read *,ih1
	ih1 = 2
c	write(8,*) 'ih1=',ih1
	read *,ih2
	write(8,*) 'ih2=',ih2
c determination dans pdflib des fonctions de distribution dans 
c le hadron h2
	PARM(1) = 'NPTYPE'
	PARM(2) = 'NGROUP'
	PARM(3) = 'NSET'
	read *,value(1)
	write(8,*) 'value(1)=',value(1)
	read *,value(2)
	write(8,*) 'value(2)=',value(2)
	read *,value(3)
	write(8,*) 'value(3)=',value(3)
c pdfset (see pftopdg_mrs99.f)	fixes lambda_QCD -> fills common W50512
c	IF (flag_grids) then
	 CALL PDFSET(PARM,VALUE)
c	ELSE (not needed since then param_loc is loaded)
c	 CALL PDFSET_LOC(PARM,VALUE)
c	ENDIF 
c ih3 and ih4 determine the choice of the fragmentation functions
c ih3 is not needed since leg 3 is a jet, fix it to anything
	ih3 = 0
	read *,ih4
	write(8,*) 'ih4=',ih4
c choix de l'echelle: ichoi_scale selectionne les familles d'echelle 
  	read *,ichoi_scale
	write(8,*) 'ichoi_scale=',ichoi_scale
c cm,cmu et cmf sont des facteurs de normalisation des differents choix
c pour respectivement les echelles de factorisation initial, de
c renormalisation et de factorisation final
	read *,cm
	write(8,*) 'cm=',cm
	read *,cmu
	write(8,*) 'cmu=',cmu
	read *,cmf
	write(8,*) 'cmf=',cmf	
c alpha electromagnetique, iloopem = 0 alpha_em = 1/137, autrement
c alpha_em est running comme dans jetset
	read *,iloopem
	write(8,*) 'iloopem=',iloopem
c nombre de boucles dans l'evaluation de alpha_s
	read *,iloop
	write(8,*) 'iloop=',iloop
c saveurs actives
	read *,jnf
	write(8,*) 'jnf=',jnf
c masses des differents quarks. Ces masses rentrent dans alpha_s pour
c savoir le nombre de saveurs actives.
	MASCH2 = (1.41D0)**2
	IF (JNF.EQ.5) THEN
	  MASBO2 = (4.5D0)**2
	ELSE IF (JNF.EQ.4) THEN
	  MASBO2 = (1.D+10)**2
	ENDIF
	MASTO2 = (1.D+10)**2
	LAMBDA4SQUARE = QCDL4**2
	if ((value(1).eq.1.d0).and.(value(2).eq.4.d0).and.
     #	(value(3).eq.34.d0)) then
	  LAMBDA4SQUARE = (.296)**2
	endif
c	write (*,*) 'QCDL4 = ', QCDL4
c constantes de SU(3)_couleur
	N = 3.D0
	CF = (N*N-1.D0)/(2.D0*N)
	GTR = DFLOAT(JNF)/2.D0
c facteur (hbarr*c)**2
	read *,hc2
	write(8,*) 'hc2=',hc2
c etainf of photon for WW spectrum
	read *,etainf
	write(8,*) 'etainf=',etainf
c etasup of photon for WW spectrum
	read *,etasup
	write(8,*) 'etasup=',etasup
c  Q2max  for WW spectrum
	read *,q2maxw
	write(8,*) 'q2maxw=',q2maxw
c flag to switch on and off inclusion of box in dirdir part ph + q -> q+ph
c ibox = 2 LOdd = born + box
c ibox = 0 LOdd = born
c ibox = 1 LOdd = box
	read *,ibox 
	write(8,*) 'ibox=',ibox  
c coupures theoriques en pt et R
	ICOUP = 0
	read *,ptm
	write(8,*) 'ptm=',ptm
	read *,r
	write(8,*) 'r=',r
c
	read *,nlo
	write(8,*) 'nlo=',nlo
	read *,lo
	write(8,*) 'lo=',lo
c si INTEG est TRUE il n'y a que l'integration (section efficace
c integree)
	read *,integ
	write(8,*) 'integ=',integ
c si INTEGA est TRUE il n'y a que l'integration (valeur absolue de la
c section efficace)
	read *,intega
	write(8,*) 'intega=',intega
c si GENER est TRUE alors on a la generation et l'integration	
	read *,gener
	write(8,*) 'gener=',gener 	
c ici : pour choisir entre collider et cible fixe
c ici = 0 collider, ici = 1 ciblefixe
	read *,ici
	write (8,*) 'ici=',ici
c energie disponible dans le cdm proton-(anti)proton pour collider
c ou ebeam pour experience cible fixe
	read *,ebeam
c	write (8,*) 'ebeam=',ebeam
c calcul de racine de s
	if (ici.eq.0) then
	  rs = ebeam
	  s = rs**2
	  write(8,*) 'sqrt(s) =',rs
	else if (ici.eq.1) then
	  xmp = .93828d0
	  xmpi = .139567d0
	  if (ih1.le.2) then
	    xm_inci = xmp
	  else if (ih1.eq.3) then
	    xm_inci = xmpi
	  else
	    write (*,*) 'bad choice of incident particle'
	  endif
	  if (ih2.le.1) then
	    xm_cible = xmp
	  else
	    write (*,*) 'bad choice of target particule'
	  endif
	  rs = dsqrt(xm_inci**2+xm_cible**2+2.d0*xm_cible*ebeam)
	  s = rs**2
	  write(8,*) 'ebeam =',ebeam
	  write(8,*) 'rs =',rs
	endif
c value of x_ga^cut to cut x_gam^obs	
c	read *,xgacut
c	write(8,*) 'xgacut=',xgacut
c value of proton energy in Lab frame
	read *, eproton
	write(8,*) 'Eproton=', eproton
c value of electron energy in Lab frame
	read *, eelectron
	write(8,*) 'Eelectron=', eelectron
c value of rapidity shift LAB -> CMS
	yshift = dlog(eproton/eelectron)/2.d0
	write(8,*) 'yshift=',yshift
c rapidite min. du photon
	read *,yinfLAB
	write(8,*) 'yinfLAB=',yinfLAB
c rapidite max. du photon
	read *,ysupLAB
	write(8,*) 'ysupLAB=',ysupLAB
c impulsion transverse min. du photon
	read *,gptinf
	write(8,*) 'gptinf=',gptinf
c impulsion transverse max. du photon
	read *,gptsup
	write(8,*) 'gptsup=',gptsup
c rapidite min. du "jet" (parton 3)
c	read *,y_jetinfLAB
c take sqrt(s) dependent limits to improve convergence
	y_jetinfLAB = -dlog(2.d0*rs/gptinf)+yshift
	write(8,*) 'y3infLAB=',y_jetinfLAB
c rapidite max. du "jet"(parton 3)
	y_jetsupLAB = dlog(2.d0*rs/gptinf)+yshift
	write(8,*) 'y3supLAB=',y_jetsupLAB
c shift rapidities from LAB to CM frame
c means yCMS_my = -yLAB_HERA + yshift
c if electron=myp1=positive z-direction: yshift = 1.7
c yLAB_HERA is given for proton=my p2=positive z-direction
c 
	YSUP = -YINFLAB + YSHIFT
	YINF = -YSUPLAB + YSHIFT
	Y_JETSUP = -Y_JETINFLAB + YSHIFT
	Y_JETINF = -Y_JETSUPLAB + YSHIFT
c	write(6,*) 'ysupCMS=',ysup	
c	write(6,*) 'yinfCMS=',yinf
c	
c impulsion transverse min. du parton 3
c	read *,gpt_jetinf
	gpt_jetinf = 0.D0
	write(8,*) 'gpt3inf=',gpt_jetinf
c
c impulsion transverse max. du parton 3
c	read *,gpt_jetsup
c fix to sqrt(s)/2, cuts for jets see below 
	gpt_jetsup = rs/2.D0
	write(8,*) 'gpt3sup=',gpt_jetsup
c flag for isolated (flag=1) or nonisolated (0) photon (in histoselection)
	read *,iphotisol
	write(8,*) 'iphotisol=',iphotisol
c coupure d'isolement du photon: 
	read *,r_isol
	write(8,*) 'r_isol=',r_isol	
c flag for isolation criterion: 0 usual cone, 1 Frixione
c	read *,isofrixione
c	write(8,*) 'isofrixione=',isofrixione	
        isofrixione=0
c flag for isolation criterion: 0 usual cone: etmax=eps_h*ptgam, 1 fixed etmax
	read *,isofix
	write(8,*) 'isofix=',isofix
c value of eps for etmax=eps_h*ptgam		
	read *,epsilon_h
	write(8,*) 'epsilon_h=',epsilon_h
c value of etmax for fixed etmax
	read *,etmax
	write(8,*) 'etmax=',etmax			
c mode for inclusive or jets
	read *,jetmode
	write(8,*) 'jetmode=',jetmode
c caracteristique du(des) jet(s)
	read *,algorithm
	write(8,*) 'algorithm=',algorithm
	read *,r_kt
	write(8,*) 'r_kt=',r_kt
	read *,r_c
	write(8,*) 'r_c=',r_c
	read *,r_sep
	write(8,*) 'r_sep=',r_sep
	read *,merging
	write(8,*) 'merging=',merging
	read *,acceptance
	write(8,*) 'acceptance=',acceptance
	read *,yjet_minLAB
	write(8,*) 'yjet_minLAB=',yjet_minLAB
	read *,yjet_maxLAB
	write(8,*) 'yjet_maxLAB=',yjet_maxLAB	
	read *,ptjet_min
	write(8,*) 'ptjet_min=',ptjet_min
	read *,ptjet_max
	write(8,*) 'ptjet_max=',ptjet_max
c shift rapidities from LAB to CM frame	
	YJET_MAX = -YJET_MINLAB + YSHIFT
	YJET_MIN = -YJET_MAXLAB + YSHIFT
c	
c BASES parameters
c inbevent est le nb d'evenements generes
 	read *,inbevent
	write(8,*) 'inbevent=',inbevent
c jtmx1 et jtmx2 sont le nb d'iteration dans bases pour la grille et
c l'integrale
  	read *,jtmx1
	write(8,*) 'jtmx1=',jtmx1
	read *,jtmx2
	write(8,*) 'jtmx2=',jtmx2
c jcall,jcall1 et jcall2 sont le nb d'appelles par iteration pour
c respectivement les quasi deux donne deux, les deux donne trois et les
c vrai deux donne deux
  	read *,jcall1
	write(8,*) 'jcall1=',jcall1
  	read *,jcall
	write(8,*) 'jcall=',jcall
  	read *,jcall2
	write(8,*) 'jcall2=',jcall2
c ixtry est le nb d'essai pour la rejection d'evenement dans spring
  	read *,ixtry
	write(8,*) 'ixtry=',ixtry
c accu est la precion en pour cent de bases
	read *,accu
	write(8,*) 'accu=',accu
c ddir,dfrag,rdir,rfrag servent a selectionner les parties directes ou frag
c pour etat initial direct (d) ou resolu (r)
	read *,ddir
	write (8,*) 'ddir=',ddir
	read *,dfrag
	write (8,*) 'dfrag=',dfrag
	read *,rdir
	write (8,*) 'rdir=',rdir
	read *,rfrag
	write (8,*) 'rfrag=',rfrag
c
c weight to scale gluon distribution in the photon
	read *,ggawght
	write(8,*) 'weight for gluon in photon= ',ggawght
c selection des sousprocessus
c partie directe initial directe final
C
C	j0 = 1 : ph + qi --> jet + ph 
C	j0 = 2 : ph + g -->  jet + ph
	read *,j_processd_min
	write(8,*) 'j_processd_min=',j_processd_min
	read *,j_processd_max
	write(8,*) 'j_processd_max=',j_processd_max
C	
C partie direct initial frag final
C
C	ph + qi --> jet + qk
C	j0 = 1 : ph + D --> jet + U
C       j0 = 2 : ph + U --> jet + D
C	j0 = 3 : ph + D --> jet + Dp
C	j0 = 4 : ph + U --> jet + Up
C	j0 = 5 : ph + D --> jet + Ub
C	j0 = 6 : ph + U --> jet + Db
C	j0 = 7 : ph + D --> jet + Dpb
C	j0 = 8 : ph + U --> jet + Upb
C	ph + qi --> jet + qi
C	j0 = 9 : ph + D --> jet + D
C	j0 = 10 : ph + U --> jet + U
C
C	j0 = 11 : ph + qi --> jet + qbi
C	j0 = 12 : ph + qi --> jet + g
C	j0 = 13 : ph + g --> jet + qi
C	j0 = 14 : ph + g --> jet + g
	read *,j_processo_min
	write(8,*) 'j_processo_min=',j_processo_min
	read *,j_processo_max
	write(8,*) 'j_processo_max=',j_processo_max
c	
c	resolved initial direct final
c
	read *,j_processresd_min
	write(8,*) 'j_processresd_min=',j_processresd_min
	read *,j_processresd_max
	write(8,*) 'j_processresd_max=',j_processresd_max
c
c	resolved initial frag final	
c
	read *,j_processreso_min
	write(8,*) 'j_processreso_min=',j_processreso_min
	read *,j_processreso_max
	write(8,*) 'j_processreso_max=',j_processreso_max
c
c ischeme: schema de factorisation pour les pattes initiales
c 0: MSBARR; 1:DIS
c	read *,ischeme
c	write(8,*) 'ischeme=',ischeme
c pour retrouver les calculs de Aurenche et al. (scale=pt du photon)
c	read *,iauren
c	write(8,*) 'iauren=',iauren
c jcount serves only to check how many events are rejected if jets are defined
c in event generation only	
	jcount=0
c
c	
	CLOSE (8)
	RETURN
	END
	
