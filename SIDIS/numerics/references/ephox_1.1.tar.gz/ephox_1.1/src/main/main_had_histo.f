c latest version 31.01.01
c PAW histo_init and histo_close subroutines generated with histo_gener.pl
	PROGRAM MAIN
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL LO,NLO,GENER,INTEG,INTEGA
	LOGICAL DDIR,DFRAG,RDIR,RFRAG
	CHARACTER*128 PATH_BSFILE,PATH_RZFILE
	COMMON/APPROX/LO,NLO
	COMMON/CALCUL/INTEG,INTEGA,GENER
	COMMON/PCLASS/DDIR,DFRAG,RDIR,RFRAG
	COMMON/NBOUCLE/ILOOP
	COMMON/lname/ilname
	COMMON/CHEMINBS/PATH_BSFILE
	COMMON/LONG/ILEN
	COMMON/CHEMINRZ/PATH_RZFILE
	COMMON/LONGRZ/ILENRZ
	COMMON/NBEVENT/INBEVENT
	common/testc/jcount
c
c	read in parameters	
	CALL PARAM
c       shift LAB -> CMS rapidities is done in param.f	
c
c	open file where results of integ for sig^LO and sig^HO are written
	OPEN(UNIT=8,FILE=PATH_BSFILE(1:ILEN)//'sigmaint.res',
     #	STATUS='unknown')
c 	
	IF (GENER) THEN
c 	  initialize filling of histograms
	  CALL histo_init(inbevent)
	ENDIF	

C******************************************************************
c       open for writing file where nb of events and result of intega  
c       are written; needed for normalization in event generation 
	OPEN(UNIT=12,
     #	FILE=PATH_RZFILE(1:ILENRZ)//'.res'
     #	,STATUS='unknown')
cccc
	IF (DFRAG) THEN
	  CALL ONEB_SUB
	ENDIF
	IF (RFRAG) THEN
	  call init_afg
	  CALL RESO_ONEB_SUB
	ENDIF
cccc
        CLOSE(UNIT=12)
	CLOSE(UNIT=8)
c************************************************************************
	IF (GENER) THEN
c       open for reading file where nb of events and result of 
c       intega are written; needed for normalization
	  open(unit=12,file=PATH_RZFILE(1:ILENRZ)//'.res',
     #	  status='unknown')
	  read(12,100) inumb_event,wfirst_int
100       format(1x,i12,e12.5)
	  close(12)
	  write (*,*) 'nb of events, abs_int',inumb_event,wfirst_int
c
c 	  normalize and end filling of histograms
	  CALL histo_close(inumb_event,wfirst_int)
c
c	just to test jet def at integration level versus 
c	             jet def at event generation level
c	  open(unit=14,FILE=PATH_BSFILE(1:ILEN)//'jet_gener',
c     #	  status='unknown')
c	  write (14,*) 'rejected events in GENER after jet selection: '
c     #	  ,jcount
c	  close(14)
c	  
	ENDIF  
c###
	END
