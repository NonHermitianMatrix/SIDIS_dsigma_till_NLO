c latest version 17.07.01
c PAW ntuple_init and ntuple_close subroutines are in 
c init_ntuple.f and end_ntuple.f
	PROGRAM MAIN
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL LO,NLO,GENER,INTEG,INTEGA
	LOGICAL DDIR,DFRAG,RDIR,RFRAG,dir,frag
	CHARACTER*128 PATH_BSFILE,PATH_RZFILE
	COMMON/APPROX/LO,NLO
	COMMON/CALCUL/INTEG,INTEGA,GENER
	COMMON/PCLASS/DDIR,DFRAG,RDIR,RFRAG
	COMMON/Pcat/dir,frag
	COMMON/lname/ilname
	COMMON/CHEMINBS/PATH_BSFILE
	COMMON/LONG/ILEN
	COMMON/CHEMINRZ/PATH_RZFILE
	COMMON/LONGRZ/ILENRZ
	COMMON/NBEVENT/INBEVENT
c
c	read in parameters	
	CALL PARAM
c       shift LAB -> CMS rapidities is done in param.f
c	
	dir = DDIR.OR.RDIR
	frag= DFRAG.OR.RFRAG
c
c	open file where results of integ for sig^LO and sig^HO are written
	OPEN(UNIT=8,FILE=PATH_BSFILE(1:ILEN)//'sigmaint.res',
     #	STATUS='unknown')
c 	
	IF (GENER) THEN
c 	  initialize filling of ntuple
	  CALL ntuple_init(inbevent)
	ENDIF	

C******************************************************************
c       open for writing file where nb of events and result of intega  
c       are written; needed for normalization in event generation     
	OPEN(UNIT=12,
     #	FILE=PATH_RZFILE(1:ILENRZ)//'.res'
     #	,STATUS='unknown')
cccc
	IF ((DDIR.AND.DFRAG).OR.(DDIR.AND.RDIR)
     #	.OR.(DDIR.AND.RFRAG).OR.(DFRAG.AND.RDIR)
     #	.OR.(DFRAG.AND.RFRAG).OR.(RDIR.AND.RFRAG)) THEN
	  WRITE(6,*) 'STOP...TOO MANY OPTIONS for subprocesses SELECTED'
	  STOP
	ENDIF
cccc
	IF (DDIR) THEN
	  CALL DIR_SUB
	ENDIF
	IF (DFRAG) THEN
	  CALL ONEB_SUB
	ENDIF
	IF (RDIR) THEN
	  call Init_afg
	  CALL RESO_DIR_SUB
	ENDIF
	IF (RFRAG) THEN
	  call Init_afg
	  CALL RESO_ONEB_SUB
	ENDIF
cccc	
        CLOSE(UNIT=12)
	CLOSE(UNIT=8)
c************************************************************************
	IF (GENER) THEN
c       open for reading file where nb of events and result of 
c       intega are written; needed for normalization
	  open(unit=12,file=PATH_RZFILE(1:ILENRZ)//'.res',
     #	  status='unknown')
	  read(12,100) inumb_event,wfirst_int
100       format(1x,i12,e12.5)
	  close(12)	  
	  write (*,*) 'nb of events, abs_int',inumb_event,wfirst_int
c
c 	  end filling of ntuples
	  CALL ntuple_close
c
	ENDIF  
c###
	END
