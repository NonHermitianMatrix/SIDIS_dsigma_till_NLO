	SUBROUTINE FSTRU(X,M2,IH,F)
	IMPLICIT REAL*8 (A-H,L-Z)
	DIMENSION F(-6:6),DXPDF(-6:6)
        CHARACTER*20 PARM(20)
	logical flag_grids
        common/flags/flag_grids
	common/gluweight/ggawght,gprotwght
	COMMON/ALEM/ILOOPEM
        COMMON/PDF/VALUE(20),VALUEP(20)
        COMMON/W50513/XMIN,XMAX,Q2MIN,Q2MAX
	DIMENSION EQ(6),PD(6)
	DATA EQ/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DATA PD/2.D0,2.D0,1.D0,1.D0,1.D0,1.D0/
C 1=D 2=U 3=S 4=C 5=B 6=T 0=G
C -1=DB -2=UB -3=SB -4=CB -5=BB -6=TB
	  if (x.ge.1.d0.or.M2.gt.q2max) then
	    f(0)=0.d0
	    do i=1,6
	      f(i)=0.d0
	      f(-i)=0.d0
	    enddo
	    return
	  endif
	IF (IH.EQ.1) THEN
c ih = 1 fonctions de distribution dans le proton
	  PARM(1) = 'NPTYPE'
	  PARM(2) = 'NGROUP'
	  PARM(3) = 'NSET'
	  CALL PDFSET(PARM,VALUE)
	  IF (M2.LT.Q2MIN) THEN
	    M2 = Q2MIN
	  ENDIF
	  M = DSQRT(M2)
	  CALL PFTOPDG(X,M,DXPDF)
	  F(0) = DXPDF(0)/X
	  DO I=1,6
	    F(I) = DXPDF(I)/X
	    F(-I) = DXPDF(-I)/X
	  ENDDO
c debug
c	  F(0) = 1.d0
c	  DO I=1,6
c 	    F(I) = 1.d0
c 	    F(-I) = 1.d0
c	  ENDDO
	ELSE IF (IH.EQ.0) THEN
c ih = 0 fonctions de distribution dans l antiproton
	  PARM(1) = 'NPTYPE'
	  PARM(2) = 'NGROUP'
	  PARM(3) = 'NSET'
	  CALL PDFSET(PARM,VALUE)
	  IF (M2.LT.Q2MIN) THEN
	    M2 = Q2MIN
	  ENDIF
	  M = DSQRT(M2)
	  CALL PFTOPDG(X,M,DXPDF)
c	  
	  F(0) = DXPDF(0)/X
	  DO I=1,6
	    F(I) = DXPDF(-I)/X
	    F(-I) = DXPDF(I)/X
	  ENDDO
	 ELSE IF (IH.EQ.2) THEN
c ih = 2 fonctions de distribution dans le photon
c taken from guillet/fontanna/Photo_jets/jet2_jph/src
	  IF (M2.LT.Q2MIN) THEN
	    M2 = Q2MIN
	  ENDIF
	  M = DSQRT(M2)
          ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c	   ALPHA_EM = 1.d0/137.d0
          if(flag_grids) then
	  call afgdist(x,M2,dxpdf)
	    F(0) = ggawght*DXPDF(0)/X
	  DO I=1,6
 	    F(I) = DXPDF(I)/X
 	    F(-I) = DXPDF(-I)/X
	  ENDDO
c debug
c	F(0) = 1.d0
c	  DO I=1,6
c 	    F(I) = 1.d0
c 	    F(-I) = 1.d0
c	  ENDDO
          else  
c call pdflib 
	  PI = 4.D0*DATAN(1.D0)
	  DO IN=1,3
	    IMP=2*IN-1
	    IP=2*IN
	    EQ(IMP)=-1.D0/3.D0
	    EQ(IP)=2.D0/3.D0
	  ENDDO
	  PARM(1) = 'NPTYPE'
	  PARM(2) = 'NGROUP'
	  PARM(3) = 'NSET'
          coefmsb = 0.d0
          if(valuep(2).eq.5.and.valuep(3).eq.2) then 
	  coefmsb = 1.d0
	  endif 
c (then GRV in DIS scheme are called and have to be transformed to msbar)	  
	  CALL PDFSET(PARM,VALUEP)
c does not change common/w50512/qcdl4,qcdl5
	  CALL PFTOPDG(X,M,DXPDF)
          bg=((1.d0-x)**2+x**2)*dlog((1.d0-x)/x)+8.d0*x*(1.d0-x)-1.d0
          bg=3.d0*bg/(2.d0*pi)*alpha_em*coefmsb 
	  F(0) = ggawght*DXPDF(0)/X
	  DO I=1,6
 	    F(I) = DXPDF(I)/X/PD(I)-eq(i)**2*bg
 	    F(-I) = DXPDF(-I)/X-eq(i)**2*bg
	  ENDDO
         endif 
	ELSE IF (IH.EQ.3) THEN
c ih = 3 fonctions de distribution dans le pion
	  PARM(1) = 'NPTYPE'
	  PARM(2) = 'NGROUP'
	  PARM(3) = 'NSET'
	  CALL PDFSET(PARM,VALUEP)
	  IF (M2.LT.Q2MIN) THEN
	    M2 = Q2MIN
	  ENDIF
	  M = DSQRT(M2)
	  CALL PFTOPDG(X,M,DXPDF)
	  F(0) = DXPDF(0)/X
	  DO I=1,6
	    F(I) = DXPDF(-I)/X
	    F(-I) = DXPDF(I)/X
	  ENDDO
	ELSE IF (IH.EQ.4) THEN
c ih = 4 fonctions de distribution dans le Be
	  PARM(1) = 'NPTYPE'
	  PARM(2) = 'NGROUP'
	  PARM(3) = 'NSET'
	  CALL PDFSET(PARM,VALUEP)
	  IF (M2.LT.Q2MIN) THEN
	    M2 = Q2MIN
	  ENDIF
	  M = DSQRT(M2)
	  CALL PFTOPDG(X,M,DXPDF)
	  F(0) = DXPDF(0)/X
	  F(1) = (4.D0*DXPDF(1)+5.D0*DXPDF(2))/(9.D0*X)
	  F(2) = (4.D0*DXPDF(2)+5.D0*DXPDF(1))/(9.D0*X)
	  F(-1) = (4.D0*DXPDF(-1)+5.D0*DXPDF(-2))/(9.D0*X)
	  F(-2) = (4.D0*DXPDF(-2)+5.D0*DXPDF(-1))/(9.D0*X)
	  DO I=3,6
	    F(I) = DXPDF(-I)/X
	    F(-I) = DXPDF(I)/X
	  ENDDO
	ENDIF
	RETURN
	END
c	
c gamstru pour zeus
c
      SUBROUTINE GAMSTRU(X,FG)
      IMPLICIT REAL*8 (A-H,L-Z)
      COMMON/ALEM/ILOOPEM
      COMMON/COUPEL/ETAINF,ETASUP,Q2MAXW,XGACUT
      DATA ME/.511D-3/
      PI=DATAN(1.D0)*4.D0      
      Q02=ME**2
c      ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
      ALPHA_EM = 1.d0/137.d0
      ALPI=ALPHA_EM/PI
c      
c     this is z*distribution of photon in electron 
c
      X1=1.D0-X 
      X2=2.D0-X  
      IF (X.LT.0.999999D0) THEN
c  q2max (WW) pour zeus (read in in param.f)
c        Q2MAXW=1.D0
        IF (X.LE.ETASUP.AND.X.GE.ETAINF) THEN
         ALG=0.5D0*DLOG(Q2MAXW*X1)-DLOG(X*ME) 
         ADT=X1
        ELSE 
         ALG=0.D0
         ADT=0.D0
        ENDIF   
        FG= ALPI*( (1.D0+X1**2)*ALG - ADT ) 
      ELSE
        FG=0.D0
      ENDIF
 	FG = FG/X
cdebug	FG = 1.d0
      RETURN
      END

