c this is final version of dirFR subroutine to be compiled by Makefile in working/
c changes:
c 03.04.03: common/etfix/isofix and upper limit on gpt3 added for 
c case of fixed ETmax in isolation cone
c 04.12.02 include jet and isol in cone subtraction term in 2->3 parts,
c consistent angle definitions
c 26.11.02: change jet definition, cut_jets now included in jet_definition,
c yjet_lead,ptjet_lead passed in common, not redefined for x_gam^obs
c 16.10.02: in 5||4 and virtual part (contribution from lower limit 
c of 1/(1-z4)_+) : use gpt3 as integration variable instead of x4
c -> avoids  parts in f(1) contribution which depend on x4 -> allows to
c calculate observables which depend on x4 (like x_gam^obs)  
c 10.01.02: include new jet subroutine
c 21.12.01: all VEC_$DMULT etc. replaced by VEC_DMULT since new compiler 
c does not accept it 
c 20.12.01: split doubletosingle from this subroutine (now in 
c src/histo/, double precision for histo_selection input, single for ntuple)
c (choice which one is loaded is made in Makefile)
c iprov,ntrack passed as arguments of doubletosingle
c merging,acceptance added to common algorithme
c 16.05.01: 5||1 and 5||2 split into two functions to be able to define eta  
c 02.05.01: difference to photpro_phoj_frag_ori.f: common added with 
c ptj_lead and yj_lead of jet which serves to define x_gam^obs, ...
c 26.02.01: jets included (with on/off flag to comprise inclusive case)
c 15.02.01: isolation included in functions (with on/off flag)
c 2->3 kinem and event generation taken from jphnew/src/oneb/onephoto_jet.f
c such that (only!) in event generation photon is particle 3
c 09.01.01: facin for iauren=1 added for comparison with old prog
c changed 12.12.00
c changes: TEMP(I+16)...(initial state crossing) removed,
c alphas -> alpha_em, k0max, ih1  
c
	SUBROUTINE ONEB_SUB
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL LO,NLO,GENER,INTEG,INTEGA
	logical lvirt
	CHARACTER*128 PATH_BSFILE
        integer*4 ntrack,iprov
        PARAMETER (IRANDOM=500)
	COMMON/NPT/INPT
	COMMON/BPARM1/XL(50),XU(50),IDIM,IWILD,IG(50),ICALL
	COMMON/BPARM2/ACC1,ACC2,ITMX1,ITMX2
	COMMON/BORN/IBORN
	COMMON/BASPRING/ISPRING
	COMMON/APPROX/LO,NLO
	COMMON/CALCUL/INTEG,INTEGA,GENER
 	COMMON/NBEVENT/INBEVENT
	COMMON/BASEPARAM/JTMX1,JTMX2,JCALL,JCALL1,JCALL2,IXTRY
	COMMON/ACCURACY/ACCU
	COMMON/RANDD/RNUMB
	COMMON/CHEMINBS/PATH_BSFILE
	COMMON/LONG/ILEN
	COMMON/PROCESSO/J_PROCESSO_MIN,J_PROCESSO_MAX
	common/testcount/j(11)
	DIMENSION WRVEC(IRANDOM),WRVEC1(IRANDOM)
	EXTERNAL F4DIMO3,F4DIMO4,F2DIMO1,F2DIMO2,F2DIMO3,F1DIMO
c
	PI=DATAN(1.D0)*4.D0
	HALF = 0.5D0
ccccccccccccccccccccccccccccccccccccccccccccccccc
c       BORN 
cccccccccccccccccccccccccccccccccccccccccccccccccc
	IF (LO) THEN
cccc
	IF (INTEGA.OR.INTEG) THEN
	IBORN = 1
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
c
	  CALL BASES (F1DIMO,RESFB,SDFB,CTIME,IT1,IT2)
C on ecrit la grille
         IF (INTEGA) THEN
	  OPEN(33,FILE=PATH_BSFILE(1:ILEN)//'twopart2.bs',
     #	  STATUS='UNKNOWN',FORM='UNFORMATTED')
	  CALL BSWRIT(33)
	  CLOSE(33)
	 ENDIF 
C
	ENDIF
cccc
	ENDIF
cccc
C******************************************************************
C       Partie 2 --> 3
C******************************************************************
c
	do i=1,11
	  j(i) = 0
	enddo
c
cccc
	IF (NLO) THEN
cccc
	IBORN = 0
c	GOTO 111	
c###
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 7
	IWILD = 7
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	CALL BASES (F4DIMO3,RESF34,SDF34,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 7
	IWILD = 7
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
c debug	
c	goto 111
	CALL BASES (F4DIMO3,RESF34,SDF34,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(18,FILE=PATH_BSFILE(1:ILEN)//'threepart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(18)
	CLOSE(18)
C	
	ENDIF
c###
C
c###
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 7
	IWILD = 7
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	CALL BASES (F4DIMO4,RESF44,SDF44,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
c debug
c 111	continue
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 7
	IWILD = 7
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	CALL BASES (F4DIMO4,RESF44,SDF44,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(19,FILE=PATH_BSFILE(1:ILEN)//'threepart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(19)
	CLOSE(19)
C	
	ENDIF
c###
C******************************************************************
C       Partie 2 --> 2 colineaire
C******************************************************************
C
c      5||1
c###
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMO1,RESF21,SDF21,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMO1,RESF21,SDF21,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(21,FILE=PATH_BSFILE(1:ILEN)//'qtwopart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(21)
	CLOSE(21)
	ENDIF
c###
C
c###
c      5||2:
c###
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMO2,RESF22,SDF22,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMO2,RESF22,SDF22,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(22,FILE=PATH_BSFILE(1:ILEN)//'qtwopart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(22)
	CLOSE(22)
C	
	ENDIF
c###
C      5 || final
c###
c 111    continue
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMO3,RESF23,SDF23,CTIME,IT1,IT2)
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	CALL BASES (F2DIMO3,RESF23,SDF23,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(23,FILE=PATH_BSFILE(1:ILEN)//'qtwopart3.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(23)
	CLOSE(23)
C	
	ENDIF
c###
C
C******************************************************************
C       Partie 2 --> 2 virtuelle et born
C******************************************************************
c   lvirt = true if virtual part = 0
	lvirt = (j_processo_min.le.8.and.j_processo_max.le.8).or.
     #		(j_processo_min.eq.11.and.j_processo_max.eq.11).or.
     #		(j_processo_min.eq.14.and.j_processo_max.eq.14)
c###
	IF (INTEG) THEN
	ISPRING = 0
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
	if (lvirt) then
	  resf1 = 0.d0
	  sdf1 = 0.d0
	else
	  CALL BASES (F1DIMO,RESF1,SDF1,CTIME,IT1,IT2)
	endif
	ENDIF
c###
C
c###
	IF (INTEGA) THEN
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
	CALL BASES (F1DIMO,RESF1,SDF1,CTIME,IT1,IT2)
C on ecrit la grille
	OPEN(20,FILE=PATH_BSFILE(1:ILEN)//'twopart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSWRIT(20)
	CLOSE(20)
C	
	ENDIF
c###
C
cccc
	ENDIF
cccc
C******************************************************************
C       calcul de la section efficace totale ordre superieur
C******************************************************************
	IF (INTEG) THEN
	  RESF2 = RESF21+RESF22+RESF23
	  SDF2 = SDF21+SDF22+SDF23
C
	  RESHO = RESF34+RESF44+RESF2+RESF1
	  SDHO = SDF34+SDF44+SDF2+SDF1
	  RESB = RESFB
	  SDFB = SDFB
	  RESSUM = RESB+RESHO
	  SDSUM = SDFB+SDHO
	  WRITE (8,*) 'CCCCCCCCCCCCCCCCCCCCCC'
	  WRITE (8,*) 'BORN',RESFB,' SDFB',SDFB
	  WRITE (8,*) 'H.O.',RESHO,' SDFHO',SDHO
	  WRITE (8,*) 'CCCCCCCCCCCCCCCCCCCCCC'
	  WRITE (8,*) 'separate results:'
	  WRITE (8,*) 'RESF34',RESF34,' SDF34',SDF34
	  WRITE (8,*) 'RESF44',RESF44,' SDF44',SDF44
	  WRITE (8,*) 'RESF21',RESF21,' SDF21',SDF21
	  WRITE (8,*) 'RESF22',RESF22,' SDF22',SDF22
	  WRITE (8,*) 'RESF23',RESF23,' SDF23',SDF23
	  WRITE (8,*) 'RESF1',RESF1,' SDF1',SDF1
	  WRITE (8,*) 'ccccccccccccccccccccccccccc'
	  WRITE (8,*) 'Born+H.O.',RESSUM,' SDSUM',SDSUM
	  WRITE (8,*) 'ccccccccccccccccccccccccccc'
	ENDIF
C******************************************************************
C       calcul du nombre d'evenements a generer pour chacune des
C       parties
C******************************************************************
	IF (INTEGA) THEN
	  IF (NLO) THEN
	    RESF2 = RESF21+RESF22+RESF23
	    TOTHO = RESF34+RESF44+RESF2+RESF1
	  ELSE
	    TOTHO = 0.D0
	  ENDIF
	  IF (LO) THEN
	    TOTB = RESFB
	  ELSE
	    TOTB = 0.D0
	  ENDIF
	  TOT = TOTHO + TOTB
	  IF (TOT.EQ.0.D0) THEN
	    WRITE (8,*) 'TOT=0. JOB FINISHED'
	    RETURN
	  ENDIF
	  OPEN(4,FILE=PATH_BSFILE(1:ILEN)//'integral.res',
     #	  STATUS='UNKNOWN')
	  WRITE(4,*) RESF34, RESF44
	  WRITE(4,*) RESF21, RESF22, RESF23
	  WRITE(4,*) RESF1,RESFB
	  WRITE(4,*) TOT
	  CLOSE(4)	  
	ENDIF
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cccc              generation des evenements                     ccccccc
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
C******************************************************************
cccc
	IF (GENER) THEN
c	write(6,*) 'before open integral.res'
cccc
	OPEN(4,FILE=PATH_BSFILE(1:ILEN)//'integral.res',
     #	STATUS='UNKNOWN')
	READ(4,*) RESF34, RESF44
	READ(4,*) RESF21, RESF22, RESF23
	READ(4,*) RESF1,RESFB
	READ(4,*) TOT
	CLOSE(4)
c	write(6,*) 'after open integral.res'
	XNORM = DFLOAT(INBEVENT)/TOT
c	write(6,*) 'after xnorm'
c###	  
c   saves for normalization
        WRITE(12,100) INBEVENT,TOT
100     FORMAT(1X,I12,D12.5)
cccc
	IF (NLO) THEN
cccc
c###
	IBORN = 0
c###
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 7
	IWILD = 7
	DO I=1,IDIM
	  XL(I) = 0.D0
	  XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF34*XNORM)
c        
	OPEN(18,FILE=PATH_BSFILE(1:ILEN)//'threepart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(18)
	CLOSE(18)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : 3 partons : 5//3'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 34
        NTRACK = 3
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
            CALL RANLUX(WRVEC,IRANDOM)
            CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB = DBLE(WRVEC(I1+1))
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F4DIMO3,IXTRY)
	  CALL DOUBLETOSINGLEO(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
C
c###
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL1
	IDIM = 7
	IWILD = 7
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF44*XNORM)
c
	OPEN(19,FILE=PATH_BSFILE(1:ILEN)//'threepart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(19)
	CLOSE(19)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : 3 partons : 5//4'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 44
        NTRACK = 3
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
            CALL RANLUX(WRVEC,IRANDOM)
            CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB = DBLE(WRVEC(I1+1))
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F4DIMO4,IXTRY)
	  CALL DOUBLETOSINGLEO(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
C
c###
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF21*XNORM)
c
	OPEN(21,FILE=PATH_BSFILE(1:ILEN)//'qtwopart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(21)
	CLOSE(21)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation: quasi 2 partons : col.ini 5||1'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 21
        NTRACK = 2
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
             CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F2DIMO1,IXTRY)
	  CALL DOUBLETOSINGLEO(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
C
c###
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF22*XNORM)
c
	OPEN(22,FILE=PATH_BSFILE(1:ILEN)//'qtwopart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(22)
	CLOSE(22)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation: quasi 2 partons : col.ini 5||2'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 22
        NTRACK = 2
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
             CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F2DIMO2,IXTRY)
	  CALL DOUBLETOSINGLEO(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO	
c###
C      5||final
c###
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL
	IDIM = 5
	IWILD = 5
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
	ENDDO
	INBREALEVENT = INT(RESF23*XNORM)
c
	OPEN(23,FILE=PATH_BSFILE(1:ILEN)//'qtwopart3.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(23)
	CLOSE(23)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : quasi 2 partons : col. fi4'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 23
        NTRACK = 2
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
             CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F2DIMO3,IXTRY)
	  CALL DOUBLETOSINGLEO(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
C
c###
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
	INBREALEVENT = INT(RESF1*XNORM)
c
	OPEN(20,FILE=PATH_BSFILE(1:ILEN)//'twopart1.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(20)
	CLOSE(20)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : 2 partons : virtuelle'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 10
        NTRACK = 2
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
             CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F1DIMO,IXTRY)
	  CALL DOUBLETOSINGLEO(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
C
cccc
	ENDIF
cccc
c###
	IF (LO) THEN
c###
	INBREALEVENT = INT(RESFB*XNORM)
C	
	IBORN = 1
	ISPRING = 1
	CALL BSINIT
	ACC1 = ACCU
	ACC2 = ACCU
	ITMX1 = JTMX1
	ITMX2 = JTMX2
	ICALL = JCALL2
	IDIM = 4
	IWILD = 4
	DO I=1,IDIM
          XL(I) = 0.D0
          XU(I) = 1.D0
        ENDDO
c
	OPEN(33,FILE=PATH_BSFILE(1:ILEN)//'twopart2.bs',
     #	STATUS='UNKNOWN',FORM='UNFORMATTED')
	CALL BSREAD(33)
	CLOSE(33)
c	
	WRITE(6,*)
	WRITE(6,*)'============================================='
	WRITE(6,*)'event generation : 2 partons : born'
	WRITE(6,*) INBREALEVENT,' events'
	WRITE(6,*)'============================================='
	WRITE(6,*)
C	
        IPROV = 11
        NTRACK = 2
        POID = 1.D0
	DO I = 1,INBREALEVENT
	  I1 = MOD(I-1,IRANDOM)
	  IF (I1.EQ.0) THEN
            CALL RANLUX(WRVEC1,IRANDOM)
          ENDIF
	  RNUMB1 = DBLE(WRVEC1(I1+1))
	  CALL SPRING(F1DIMO,IXTRY)
	  CALL DOUBLETOSINGLEO(RNUMB1,PI,POID,iprov,ntrack)
	  CALL GFILL
	ENDDO
c###
	ENDIF  
cccc
	ENDIF  
cccc
	RETURN
	END
C
C*****************************************************
C  Partie ou PT5 < PTM
C*****************************************************
C INTEGRALE A 4 DIMENSIONS
	DOUBLE PRECISION FUNCTION F4DIMO3(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/COUP/PTM,R
	COMMON/ALEM/ILOOPEM
	COMMON/SCALE/M,MF,MU
	COMMON/FACONV/HC2
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/SFRAGV/XFRAG1,XFRAG2
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSO/J_PROCESSO_MIN,J_PROCESSO_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	COMMON/RANDD/RNUMB
	COMMON/FICUT/FIMIN
	common/isophot/iphotisol
	COMMON/COUP_HISTO/R_ISOL,EPSILON_H
	common/etfix/isofix
	common/emax/etmax
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)	
	common/testcount/j(11)
	DIMENSION XX(20)
	PARAMETER (K0MAX=14)
	DIMENSION SF0(K0MAX),CAMP0(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX),SPCOU(K0MAX)
	DIMENSION P1(4),P2(4),PP4(4)
	DIMENSION P3(4),P4(4),P5(4)
	DIMENSION P1P(4),P2P(4),P4P(4),P3P(4),P5P(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ X4 ---------------------------------------------
	X4MAX = 1.D0
	IF (iphotisol.eq.0) THEN
	   X4MINP = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	ELSE   
	   X4MIN_INCL = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	   if (isofix.eq.1) then
	     et_max = etmax
	   else 
	     et_max = EPSILON_H*gpt4
	   endif  
	   X4MIN_ISOL = gpt4/(gpt4+et_max)
	   X4MINP = DMAX1(X4MIN_INCL,X4MIN_ISOL)
	ENDIF 
	X4MIN = DMIN1(X4MAX,X4MINP)
	X4 = X4MIN + (X4MAX-X4MIN)*XX(4)
	PT4 = GPT4/X4
C ------------------ PT5 --------------------------------------------
c x1c_min = pt5/dsqrt(s)*exp(y3) + pt4/dsqrt(s)*exp(y4)
c x2c_min = pt5/dsqrt(s)*exp(-y3) + pt4/dsqrt(s)*exp(-y4)
c Comme pt5**2 <= S*(1-x1c)*(1-x2c), on a donc
c pt5**2 <= S*(1-x1c_min)*(1-x2c_min) d'ou
c pt5 <= (S + pt4**2 -2*rs*pt4*cosh(y4))/
c (2*(rs*cosh(y3)-pt4*cosh(y3-y4))))
	pt5max1 = (dsqrt(s)-pt4*dexp(y4))*dexp(-y3)
	pt5max2 = (dsqrt(s)-pt4*dexp(-y4))*dexp(y3)
	at1 = 2.d0*(dsqrt(s)*dcosh(y3)-pt4*dcosh(y3-y4))
	if (at1.gt.0.d0) then
	  pt5max3 = (s+pt4**2-2.d0*dsqrt(s)*pt4*dcosh(y4))/at1
	else
	  pt5max3 = dsqrt(s)/2.d0
	endif
	pt5max = dmin1(pt5max1,pt5max2,pt5max3)
	PT5MIN = PTM
	if (pt5min.gt.pt5max) then
	  f4dimo3 = 0.d0
	  return
	endif	
	PT5 = PT5MIN + (PT5MAX-PT5MIN)*XX(5)
C ------------------ FI35 -------------------------------------------
c x1c_min = pt5/dsqrt(s)*exp(y3) + pt4/dsqrt(s)*exp(y4)
c x2c_min = pt5/dsqrt(s)*exp(-y3) + pt4/dsqrt(s)*exp(-y4)
	x11 = pt5/dsqrt(s)*dexp(y3)+pt4/dsqrt(s)*dexp(y4)
	x21 = pt5/dsqrt(s)*dexp(-y3)+pt4/dsqrt(s)*dexp(-y4)
c en principe vrai
	if (x11.gt.un.or.x21.gt.un) then
	  f4dimo3 = 0.d0
	  return
	endif
	SY5MAX = DLOG(DSQRT(S)/PT5*(1.d0-x11))
	SY5MIN = -DLOG(DSQRT(S)/PT5*(1.d0-x21))
c en principe vrai
	if (sy5max.lt.sy5min) then
	  f4dimo3 = 0.d0
	  return
	endif
	if (pt5.le.pt4/2.d0) then
	  fimin = 0.d0
	else
	  fimin = dacos(pt4**2/(2.d0*pt5**2)-1.d0)
	endif
	GPT3MAX = DMIN1(PT4+PT5,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,GPT_JETSUP)
	xarg = (pt4**2-gpt3max**2-pt5**2)/
     #	(2.d0*gpt3max*pt5)
	if (xarg.lt.-1.d0) then
	  xmax_fi = pi
	else if (xarg.gt.1.d0) then
	  f4dimo3 = 0.d0
	  return
	else
	  xmax_fi = dacos(xarg)
	endif
	fimax = dmin1(pi,xmax_fi)
	if (y3.le.sy5max.and.y3.ge.sy5min) then
	  OMEGAMIN = datan(fimin/(sy5max-y3))
	  OMEGAMAX = pi-datan(fimin/dabs(sy5min-y3))
	  srmax2 = dmax1((sy5max-y3)**2+fimax**2,
     #	  (sy5min-y3)**2+fimax**2)
	  rmax2 = dsqrt(srmax2)
	  rmin2 = fimin
	else if (y3.lt.sy5max.and.y3.lt.sy5min) then
	  OMEGAMIN = datan(fimin/(sy5max-y3))
	  OMEGAMAX = datan(fimax/(sy5min-y3))
	  srmax2 = (sy5max-y3)**2+fimax**2
	  rmax2 = dsqrt(srmax2)
	  rmin2 = dsqrt(fimin**2+(sy5min-y3)**2)
	else if (y3.gt.sy5max.and.y3.gt.sy5min) then
	  OMEGAMIN = pi-datan(fimax/dabs(sy5max-y3))
	  OMEGAMAX = pi-datan(fimin/dabs(sy5min-y3))
	  srmax2 = (sy5min-y3)**2+fimax**2
	  rmax2 = dsqrt(srmax2)
	  rmin2 = dsqrt(fimin**2+(sy5max-y3)**2)
	endif
	if (omegamin.le.omegamax) then
	  OMEGA = OMEGAMIN + (OMEGAMAX-OMEGAMIN)*XX(6)
	else	  
	   f4dimo3 = 0.d0
	   return
	endif
	xbig = 1.d+20
	xsmall = 1.d-12
	if (omega.lt.xsmall.or.omega.gt.(pi-xsmall)) then
	  rmax1 = xbig
	else
	  rmax1 = fimax/dsin(omega)
	endif
	rrmax = dmin1(rmax1,rmax2)
	rrmin = rmin2
	if (rrmin.le.rrmax) then
	  RR = RRMIN + (RRMAX-RRMIN)*XX(7)
	else	  
	   f4dimo3 = 0.d0
	   return
	endif
	FI35 = RR*DSIN(OMEGA)
	IF (FI35.GT.PI) THEN
	   F4DIMO3 = 0.D0
	   RETURN
	ENDIF
C ------------------ GPT3 ------------------------------------------
	GPT3MIN = DMAX1(PT5,GPT_JETINF)
	if ((PT4-PT5*DSIN(FI35)).le.0.d0) then
	  F4DIMO3 = 0.d0
	  return
	endif
	GPT3 = -PT5*DCOS(FI35)+DSQRT(PT4**2-(PT5*DSIN(FI35))**2)
	if (gpt3.gt.gpt3max.or.gpt3.lt.gpt3min) then
	  F4DIMO3 = 0.d0
	  return
	endif
	PT3 = GPT3
C ------------------ X -------------------------------------------
	X1C = GPT3/DSQRT(S)*DEXP(Y3) + PT4/DSQRT(S)*DEXP(Y4)
	X2C = GPT3/DSQRT(S)*DEXP(-Y3) + PT4/DSQRT(S)*DEXP(-Y4)
	IF (X1C.GE.UN.OR.X2C.GE.UN) THEN
	  F4DIMO3 = 0.D0
	  RETURN
	ENDIF
	sup_pt5 = dsqrt(s*(1.d0-x1c)*(1.d0-x2c))
	if (pt5.gt.sup_pt5) then
	  F4DIMO3 = 0.D0
	  RETURN
	ENDIF	
C ------------------ Y5 -------------------------------------------
	Y5MAX = DLOG(DSQRT(S)/PT5*(1.D0-X1C))
	Y5MIN = -DLOG(DSQRT(S)/PT5*(1.D0-X2C))
	Y5 = Y3 + RR*DCOS(OMEGA)
	IF (Y5.GT.Y5MAX.OR.Y5.LT.Y5MIN) THEN
	   F4DIMO3 = 0.D0
	   RETURN
	ENDIF
C ------------------ X -------------------------------------------
	X1 = X1C + PT5/DSQRT(S)*DEXP(Y5)
	X2 = X2C + PT5/DSQRT(S)*DEXP(-Y5)
	IF (X1.GE.UN.OR.X2.GE.UN) THEN
	  F4DIMO3 = 0.D0
	  RETURN
	ENDIF
c coupure en angle-------------------------------------------------
        R35S = (Y3-Y5)**2+FI35**2
        RS = R**2
	icorr = 0
        IF (R35S.LT.RS) THEN	
           icorr = 1
        ENDIF
c coupure en isolement-------------------------------------------------
	cos_fi45 = -(GPT3*DCOS(FI35)+PT5)/PT4
	fi45 = zacos(cos_fi45)
c       if no isolation cuts on photon are imposed (iphotisol.eq.0), 
c       photon is always isolated (fulfills any isolation criteria)
c       flag iphotisol is read in in param.f
	xisol = 1.d0
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE
	 call isolement(y4,y5,fi45,x4,pt5,gpt4,r_isol,epsilon_h,
     #	isol)  
	ENDIF	 
	 if (.not.isol) then
	   if (icorr.eq.0) then
	     F4DIMO3 = 0.D0
	     RETURN
	   else 
	     xisol = 0.d0
	   endif  
	 endif  	 
c ------------------ fin isolement ------------------------------------
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)*
     #	  (X4MAX-X4MIN)*RR*(RRMAX-RRMIN)*(OMEGAMAX-OMEGAMIN)*
     #	  (PT5MAX-PT5MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)*
     #	  (X4MAX-X4MIN)*RR*(RRMAX-RRMIN)*(OMEGAMAX-OMEGAMIN)*
     #	  (PT5MAX-PT5MIN)
	ENDIF
	x1p = pt4/dsqrt(s)*(dexp(y3)+dexp(y4))
	x2p = pt4/dsqrt(s)*(dexp(-y3)+dexp(-y4))
	gpt3p = (pt4-pt5)
C ------------------------------------------- 
	P1(1) = X1*DSQRT(S)/2.D0
	P1(2) = 0.D0
	P1(3) = 0.D0
	P1(4) = X1*DSQRT(S)/2.D0
C ------------------------------------------- 
	P2(1) = X2*DSQRT(S)/2.D0
	P2(2) = 0.D0
	P2(3) = 0.D0
	P2(4) = -X2*DSQRT(S)/2.D0
C ------------------------------------------- 
	P4(1) = GPT4*DCOSH(Y4)
	P4(2) = GPT4
	P4(3) = 0.D0
	P4(4) = GPT4*DSINH(Y4)
C ------------------------------------------- 
	PP4(1) = PT4*DCOSH(Y4)
	PP4(2) = PT4
	PP4(3) = 0.D0
	PP4(4) = PT4*DSINH(Y4)
C ------------------------------------------- 
c attention fi35 est l'angle entre 3 et 5
c whereas reference axis is in gpt4-direction
c choosing P5(3) negative is convention
	P5(1) = PT5*DCOSH(Y5)
	P5(2) = -PT5*(GPT3*DCOS(FI35)+PT5)/PT4
	P5(3) = -PT5*GPT3*DSIN(FI35)/PT4
	P5(4) = PT5*DSINH(Y5)
C ------------------------------------------- 
	P3(1) = P1(1) + P2(1) - PP4(1) - P5(1)
	P3(2) = P1(2) + P2(2) - PP4(2) - P5(2)
	P3(3) = P1(3) + P2(3) - PP4(3) - P5(3)
	P3(4) = P1(4) + P2(4) - PP4(4) - P5(4)
C -------------------------------------------
	P1P(1) = X1P*DSQRT(S)/2.D0
	P1P(2) = 0.D0
	P1P(3) = 0.D0
	P1P(4) = X1P*DSQRT(S)/2.D0
C ------------------------------------------- 
	P2P(1) = X2P*DSQRT(S)/2.D0
	P2P(2) = 0.D0
	P2P(3) = 0.D0
	P2P(4) = -X2P*DSQRT(S)/2.D0
C ------------------------------------------- 
	P5P(1) = PT5*DCOSH(Y3)
	P5P(2) = -PT5
	P5P(3) = 0.D0
	P5P(4) = PT5*DSINH(Y3)
C ------------------------------------------- 
	P3P(1) = P1P(1) + P2P(1) - PP4(1) - P5P(1)
	P3P(2) = P1P(2) + P2P(2) - PP4(2) - P5P(2)
	P3P(3) = P1P(3) + P2P(3) - PP4(3) - P5P(3)
	P3P(4) = P1P(4) + P2P(4) - PP4(4) - P5P(4)
C -------------------------------------------
c ------------------coupure jet------------------------------
c if no jets are measured, cut_jet is always true since any cut 
c conditions will be fulfilled
	xjet = 1.d0
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
c  new jet_selection routine requires def of absolute angles
	fi3 = zinvcos(P3(2),P3(3),gpt3,pi)
	fi5 = zinvcos(P5(2),P5(3), pt5,pi)
	test35 = dmin1(dabs(dabs(fi3-fi5)-fi35),
     #	   abs(2.d0*pi-dabs(fi3-fi5)-fi35))
        if  (test35.gt.1.d-6) then
	     write (17,*) 'attention, fi3-fi5 !=fi35 in F4DIMO3 ',
     #	     test35,fi3,fi5
	   endif
	  call jet_selection(y3,y5,fi35,fi3,fi5,gpt3,pt5,
     #	  algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,inb_jet,
     #    xej,xpjx,xpjy,xpjz,cut_jet)
     	  xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X1)
	ENDIF        
	  if (.not.cut_jet) then
	    if (icorr.eq.0) then
	      F4DIMO3 = 0.D0
	      RETURN
	    else 
	      xjet = 0.d0
	    endif
	  endif  
c -------- set the scales -------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	CALL FSPCOUO(N,SPCOU)
c
 	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c_{ij} = alpha_s^2*alpha/(4*c_i*c_j*Pi*s^2)
	CIJ = ALFAS(ILOOP,MU*MU)**2*ALPHA_EM/(PI*S*S)*FACIN
c
	CALL STRFRAO(X1,X2,IH2,X4,IH4,SF0)
	call AMPO3(s,x1,x2,y3,gpt3,y5,pt5,fi35,CAMP0)
	CALL VEC_DMULT_VECTOR(CAMP0,SF0,K0MAX,TEMP0)
	CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	F4DIMO3 = 0.d0
	DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	  F4DIMO3 = TEMP1(I) + F4DIMO3
	ENDDO
	F4DIMO3 = F4DIMO3*CIJ*GPT3/
     #	DSQRT(PT4**2-(PT5*DSIN(FI35))**2)
	if (icorr.eq.1) then
c --coupure en isolement in subtraction term --------------------------------
        xisolp = 1.d0
	IF (iphotisol.ne.0) THEN
 	     call isolement(y4,y3,pi,x4,pt5,gpt4,r_isol,epsilon_h,
     #	          isol)
 	     if (.not.(isol)) then
 	       xisolp = 0.d0
 	     endif
	ENDIF     
c ------------------coupure jet in subtraction term------------------------------
c if no jets are measured, cut_jet is always true since any cut 
c conditions will be fulfilled
	  xjetp = 1.d0
	  if (jetmode.ne.0) then
	    fi3p = zinvcos(P3p(2),P3p(3),gpt3p,pi)
	    fi5p = zinvcos(P5p(2),P5p(3),pt5,pi)
	    test35 = dabs(fi3p-fi5p)
            if  (test35.gt.1.d-6) then
	      write (17,*) 'attention, fi3-fi5 !=0 in  F4DIMO3P',
     #	      test35,fi3p,fi5p
	    endif
	    call jet_selection(y3,y3,0.d0,fi3p,fi5p,gpt3p,pt5,
     #	    algorithm,r_kt,r_c,r_sep,merging,merged,
     #      ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,inb_jet,
     #      xej,xpjx,xpjy,xpjz,cut_jet)
	    if (.not.(cut_jet)) then
	      xjetp = 0.d0
	    endif
          endif
c ------------------ fin jet in subtraction term ------------------------------
	  IF (IAUREN.EQ.0) THEN
	    CALL CHOISCALE(P3P,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	    FACIN = 1.D0
	  ELSE IF (IAUREN.EQ.1) THEN
	    M = GPT4*CM
	    MU = M
	    MF = M
	    FACIN = 1.D0/(2.D0*PI*GPT4)
	  ENDIF
 	  ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c_{ij} = alpha_s^2*alpha/(4*c_i*c_j*Pi*s^2)
	  CIJ = ALFAS(ILOOP,MU*MU)**2*ALPHA_EM/(PI*S*S)*FACIN
c
	  CALL STRFRAO(X1P,X2P,IH2,X4,IH4,SF0)
	  call ampo_corr3(s,x1p,x2p,y3,pt4-pt5,pt5,r35s,camp0)
	  CALL VEC_DMULT_VECTOR(CAMP0,SF0,K0MAX,TEMP0)
	  CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	  F4DIMO3P = 0.d0
	  DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	    F4DIMO3P = TEMP1(I) + F4DIMO3P
	  ENDDO
	  F4DIMO3P = F4DIMO3P*CIJ*(pt4-pt5)/PT4
	  F4DIMO3 = F4DIMO3*xisol*xjet - F4DIMO3P*xisolp*xjetp
	endif ! end if icorr=1
C
	F4DIMO3 = F4DIMO3 * XJACOB * (PT4/X4*PT5) * HC2
c	
	IF (ISPRING.EQ.1) THEN
	  HALF = 0.5D0
	  IF (RNUMB.LE.HALF) THEN
	    XFI12 = 2.D0*PI-ZACOS(P3(2)/GPT3)
	    XFI13 = ZACOS(-(GPT3*DCOS(FI35)+PT5)/PT4)
	  ELSE
	    XFI12 = ZACOS(P3(2)/GPT3)
	    XFI13 = 2.D0*PI-ZACOS(-(GPT3*DCOS(FI35)+PT5)/PT4)
	  ENDIF
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = PT5
	  XY3 = Y5
	  XFRAG1 = X4
	  XFRAG2 = UN
	  XETA = X1
	  RESFUNC = F4DIMO3
	  F4DIMO3 = DABS(F4DIMO3)
	ENDIF
C
	RETURN
	END 
C********************************************************************
C INTEGRALE A 4 DIMENSIONS
	DOUBLE PRECISION FUNCTION F4DIMO4(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/COUP/PTM,R
	COMMON/ALEM/ILOOPEM
	COMMON/SCALE/M,MF,MU
	COMMON/FACONV/HC2
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/SFRAGV/XFRAG1,XFRAG2
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSO/J_PROCESSO_MIN,J_PROCESSO_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	COMMON/RANDD/RNUMB
	COMMON/FICUT/FIMIN
	common/isophot/iphotisol
	COMMON/COUP_HISTO/R_ISOL,EPSILON_H
	common/etfix/isofix
	common/emax/etmax
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)	
	DIMENSION XX(20)
	PARAMETER (K0MAX=14)
	DIMENSION SF0(K0MAX),CAMP0(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX),SPCOU(K0MAX)
	DIMENSION P1(4),P2(4),PP4(4)
	DIMENSION P3(4),P4(4),P5(4)
	DIMENSION P1P(4),P2P(4),P3P(4),P5P(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ X4 -------------------------------------------
	X4MAX = 1.D0
	IF (iphotisol.eq.0) THEN
	   X4MINP = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	ELSE 
	X4MIN_INCL = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	   if (isofix.eq.1) then
	     et_max = etmax
	   else 
	     et_max = EPSILON_H*gpt4
	   endif  
	X4MIN_ISOL = gpt4/(gpt4+et_max)
	X4MINP = DMAX1(X4MIN_INCL,X4MIN_ISOL)
	ENDIF
c	X4MINP = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	X4MIN = DMIN1(X4MAX,X4MINP)
	X4 = X4MIN + (X4MAX-X4MIN)*XX(4)
	PT4 = GPT4/X4
C ------------------ PT5 --------------------------------------------
	PT5MAX = DSQRT(PT4**2+GPT_JETSUP**2)
	PT5MIN = PTM
	PT5 = PT5MIN + (PT5MAX-PT5MIN)*XX(5)
C ------------------ FI45 -------------------------------------------
	x11 = pt4/dsqrt(s)*dexp(y4)+dabs(pt4-pt5)/dsqrt(s)*dexp(y3)
	x21 = pt4/dsqrt(s)*dexp(-y4)+dabs(pt4-pt5)/dsqrt(s)*dexp(-y3)
	if (x11.gt.un.or.x21.gt.un) then
	  f4dimo4 = 0.d0
	  return
	endif
	SY5MAX = DLOG(DSQRT(S)/PT5*(1.d0-x11))
	SY5MIN = -DLOG(DSQRT(S)/PT5*(1.d0-x21))
	if (sy5max.lt.sy5min) then
	  f4dimo4 = 0.d0
	  return
	endif
	if (pt5.le.pt4/2.d0) then
	  fimax = pi
	else
	  fimax = dacos(-pt4/(2.d0*pt5))
	endif
	GPT3MAX = DMIN1(PT4+PT5,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,GPT_JETSUP)
	xarg = (gpt3max**2-pt4**2-pt5**2)/
     #	(2.d0*pt4*pt5)
	if (xarg.gt.1.d0) then
	  fimin = 0.d0
	else if (xarg.lt.-1.d0) then
	  f4dimo4 = 0.d0
	  return
	else
	  fimin = dacos(xarg)
	endif
	if (y4.le.sy5max.and.y4.ge.sy5min) then
	  OMEGAMIN = datan(fimin/(sy5max-y4))
	  OMEGAMAX = pi-datan(fimin/dabs(sy5min-y4))
	  srmax2 = dmax1((sy5max-y4)**2+fimax**2,
     #	  (sy5min-y4)**2+fimax**2)
	  rmax2 = dsqrt(srmax2)
	  rmin2 = fimin
	else if (y4.lt.sy5max.and.y4.lt.sy5min) then
	  OMEGAMIN = datan(fimin/(sy5max-y4))
	  OMEGAMAX = datan(fimax/(sy5min-y4))
	  srmax2 = (sy5max-y4)**2+fimax**2
	  rmax2 = dsqrt(srmax2)
	  rmin2 = dsqrt(fimin**2+(sy5min-y4)**2)
	else if (y4.gt.sy5max.and.y4.gt.sy5min) then
	  OMEGAMIN = pi-datan(fimax/dabs(sy5max-y4))
	  OMEGAMAX = pi-datan(fimin/dabs(sy5min-y4))
	  srmax2 = (sy5min-y4)**2+fimax**2
	  rmax2 = dsqrt(srmax2)
	  rmin2 = dsqrt(fimin**2+(sy5max-y4)**2)
	endif
	if (omegamin.le.omegamax) then
	  OMEGA = OMEGAMIN + (OMEGAMAX-OMEGAMIN)*XX(6)
	else	  
	   f4dimo4 = 0.d0
	   return
	endif
	xbig = 1.d+20
	xsmall = 1.d-12
	if (omega.lt.xsmall.or.omega.gt.(pi-xsmall)) then
	  rmax1 = xbig
	else
	  rmax1 = pi/dsin(omega)
	endif
	rrmax = dmin1(rmax1,rmax2)
	rrmin = rmin2
	if (rrmin.le.rrmax) then
	  RR = RRMIN + (RRMAX-RRMIN)*XX(7)
	else	  
	   f4dimo4 = 0.d0
	   return
	endif
	FI45 = RR*DSIN(OMEGA)
	IF (FI45.GT.PI) THEN
	  F4DIMO4 = 0.D0
	  RETURN
	ENDIF
C ------------------ GPT3 -------------------------------------------
	GPT3MIN = DMAX1(PT5,GPT_JETINF)
	GPT3 = DSQRT(PT4**2+PT5**2+2.D0*PT4*PT5*DCOS(FI45))
	if (gpt3.gt.gpt3max.or.gpt3.lt.gpt3min) then
	  F4DIMO4 = 0.d0
	  return
	endif
C ------------------ X -------------------------------------------
	X1C = PT4/DSQRT(S)*DEXP(Y4) + GPT3/DSQRT(S)*DEXP(Y3)
	X2C = PT4/DSQRT(S)*DEXP(-Y4) + GPT3/DSQRT(S)*DEXP(-Y3)
	IF (X1C.GE.UN.OR.X2C.GE.UN) THEN
	  F4DIMO4 = 0.D0
	  RETURN
	ENDIF
C ------------------ Y5 -------------------------------------------
	Y5MAX = DLOG(DSQRT(S)/PT5*(1.D0-X1C))
	Y5MIN = -DLOG(DSQRT(S)/PT5*(1.D0-X2C))
	Y5 = Y4 + RR*DCOS(OMEGA)
	IF (Y5.GT.Y5MAX.OR.Y5.LT.Y5MIN) THEN
	  F4DIMO4 = 0.D0
	  RETURN
	ENDIF
C ------------------ X -------------------------------------------
	X1 = X1C + PT5/DSQRT(S)*DEXP(Y5)
	X2 = X2C + PT5/DSQRT(S)*DEXP(-Y5)
	IF (X1.GE.UN.OR.X2.GE.UN) THEN
	  F4DIMO4 = 0.D0
	  RETURN
	ENDIF
c coupure en angle-------------------------------------------------
        R45S = (Y4-Y5)**2+FI45**2
        RS = R**2
	icorr = 0
        IF (R45S.LT.RS) THEN
          icorr = 1
        ENDIF
c coupure en isolement-------------------------------------------------
        xisol = 1.d0	
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE
	  call isolement(y4,y5,fi45,x4,pt5,gpt4,r_isol,epsilon_h,
     #	  isol)  
	ENDIF
	   if (.not.isol) then
	     if (icorr.eq.0) then
	       F4DIMO4 = 0.D0
	       RETURN
	      else 
	        xisol = 0.d0
	     endif 
	   endif  
c ------------------ fin isolement ------------------------------------	
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)*
     #	  RR*(RRMAX-RRMIN)*(OMEGAMAX-OMEGAMIN)*(X4MAX-X4MIN)*
     #	  (PT5MAX-PT5MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)*
     #	  RR*(RRMAX-RRMIN)*(OMEGAMAX-OMEGAMIN)*(X4MAX-X4MIN)*
     #	  (PT5MAX-PT5MIN)
	ENDIF
	x1p = (pt4+pt5)/dsqrt(s)*(dexp(y3)+dexp(y4))
	x2p = (pt4+pt5)/dsqrt(s)*(dexp(-y3)+dexp(-y4))
C ------------------------------------------- 
	P1(1) = X1*DSQRT(S)/2.D0
	P1(2) = 0.D0
	P1(3) = 0.D0
	P1(4) = X1*DSQRT(S)/2.D0
C ------------------------------------------- 
	P2(1) = X2*DSQRT(S)/2.D0
	P2(2) = 0.D0
	P2(3) = 0.D0
	P2(4) = -X2*DSQRT(S)/2.D0
C ------------------------------------------- 
	PP4(1) = PT4*DCOSH(Y4)
	PP4(2) = PT4
	PP4(3) = 0.D0
	PP4(4) = PT4*DSINH(Y4)
C ------------------------------------------- 
	P4(1) = GPT4*DCOSH(Y4)
	P4(2) = GPT4
	P4(3) = 0.D0
	P4(4) = GPT4*DSINH(Y4)
C ------------------------------------------- 
	P5(1) = PT5*DCOSH(Y5)
	P5(2) = PT5*DCOS(FI45)
	P5(3) = PT5*DSIN(FI45)
	P5(4) = PT5*DSINH(Y5)
C ------------------------------------------- 
	P3(1) = P1(1) + P2(1) - PP4(1) - P5(1)
	P3(2) = P1(2) + P2(2) - PP4(2) - P5(2)
	P3(3) = P1(3) + P2(3) - PP4(3) - P5(3)
	P3(4) = P1(4) + P2(4) - PP4(4) - P5(4)
C -------------------------------------------
	P1P(1) = X1P*DSQRT(S)/2.D0
	P1P(2) = 0.D0
	P1P(3) = 0.D0
	P1P(4) = X1P*DSQRT(S)/2.D0
C ------------------------------------------- 
	P2P(1) = X2P*DSQRT(S)/2.D0
	P2P(2) = 0.D0
	P2P(3) = 0.D0
	P2P(4) = -X2P*DSQRT(S)/2.D0
C ------------------------------------------- 
	P5P(1) = PT5*DCOSH(Y4)
	P5P(2) = PT5
	P5P(3) = 0.D0
	P5P(4) = PT5*DSINH(Y4)
C ------------------------------------------- 
	P3P(1) = P1P(1) + P2P(1) - PP4(1) - P5P(1)
	P3P(2) = P1P(2) + P2P(2) - PP4(2) - P5P(2)
	P3P(3) = P1P(3) + P2P(3) - PP4(3) - P5P(3)
	P3P(4) = P1P(4) + P2P(4) - PP4(4) - P5P(4)
C -------------------------------------------
c ------------- coupure jet ----------------------------------------
	cos_fi35 = -(PT4*DCOS(FI45)+PT5)/GPT3
	fi35 = zacos(cos_fi35)
	xjet=1.d0
c if no jets are measured, cut_jet is always true since any cut 
c conditions will be fulfilled
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
	fi3 = zinvcos(P3(2),P3(3),gpt3,pi)
	fi5 = zinvcos(P5(2),P5(3), pt5,pi)
	test35 = dmin1(dabs(dabs(fi3-fi5)-fi35),
     #	   abs(2.d0*pi-dabs(fi3-fi5)-fi35))
        if  (test35.gt.1.d-6) then
	     write (17,*) 'attention, fi3-fi5 !=fi35  in F4DIMO4',
     #	     test35,fi3,fi5
	   endif
	  call jet_selection(y3,y5,fi35,fi3,fi5,gpt3,pt5,
     #	  algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,
     #    inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
c
          xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X1)
	ENDIF        
	  if (.not.cut_jet) then
 	     if (icorr.eq.0) then	
	        F4DIMO4 = 0.D0
	        RETURN
	     else 
                xjet = 0.d0
	     endif	       
	  endif    
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	CALL FSPCOUO(N,SPCOU)
c
 	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c_{ij} = alpha_s^2*alpha/(4*c_i*c_j*Pi*s^2)
	CIJ = ALFAS(ILOOP,MU*MU)**2*ALPHA_EM/(PI*S*S)*FACIN
c
	CALL STRFRAO(X1,X2,IH2,X4,IH4,SF0)
	call AMPO4(s,x1,x2,y4,pt4,y5,pt5,fi45,CAMP0)
	CALL VEC_DMULT_VECTOR(CAMP0,SF0,K0MAX,TEMP0)
	CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	F4DIMO4 = 0.d0
	DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	  F4DIMO4 = TEMP1(I) + F4DIMO4
	ENDDO
	F4DIMO4 = CIJ*F4DIMO4
	if (icorr.eq.1) then
c ----- coupure en isolement in subtraction term ---------------------------------
	xisolp = 1.d0
	IF (iphotisol.ne.0) THEN
	  call isolement(y4,y4,0.d0,x4,pt5,gpt4,r_isol,epsilon_h,
     #	  isol)
	  if (.not.(isol)) then
	     xisolp = 0.d0
	  endif
	ENDIF
c -------------- coupure jet in subtraction term -------------------------------
	  xjetp = 1.d0
	  IF (jetmode.ne.0) THEN
	    gpt3p = pt4+pt5
	    fi3p = zinvcos(P3P(2),P3P(3),gpt3p,pi)
	    fi5p = zinvcos(P5P(2),P5P(3), pt5,pi)
	    test35 = dabs(fi3p-fi5p)-pi
            if  (test35.gt.1.d-6) then
	       write (17,*) 'attention, fi3-fi5 !=pi in  F4DIMO4P',
     #	       test35,fi3p,fi5p
	    endif
c	    
	   call jet_selection(y3,y4,pi,fi3p,fi5p,gpt3p,pt5,
     #	   algorithm,r_kt,r_c,r_sep,merging,merged,
     #     ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,
     #     inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)	    
	    if (.not.(cut_jet)) then
	       xjetp = 0.d0
	    endif
	  ENDIF
c ---------------------------------------------------------	  
	  IF (IAUREN.EQ.0) THEN
	    CALL CHOISCALE(P3P,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	    FACIN = 1.D0
	  ELSE IF (IAUREN.EQ.1) THEN
	    M = GPT4*CM
	    MU = M
	    MF = M
	    FACIN = 1.D0/(2.D0*PI*GPT4)
	  ENDIF
 	  ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
c c_{ij} = alpha_s^2*alpha/(4*c_i*c_j*Pi*s^2)
	  CIJ = ALFAS(ILOOP,MU*MU)**2*ALPHA_EM/(PI*S*S)*FACIN
c
	  CALL STRFRAO(X1P,X2P,IH2,X4,IH4,SF0)
	  call ampo_corr4(s,x1p,x2p,y4,pt4,pt5,r45s,camp0)
	  CALL VEC_DMULT_VECTOR(CAMP0,SF0,K0MAX,TEMP0)
	  CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	  F4DIMO4P = 0.d0
	  DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	    F4DIMO4P = TEMP1(I) + F4DIMO4P
	  ENDDO
	  F4DIMO4P = CIJ*F4DIMO4P
	  F4DIMO4 = F4DIMO4*xisol*xjet - F4DIMO4P*xisolp*xjetp
	endif ! end if icorr=1
C
	F4DIMO4 = F4DIMO4 * XJACOB * (PT4/X4*PT5) * HC2
c	
	IF (ISPRING.EQ.1) THEN
	  HALF = 0.5D0
	  IF (RNUMB.LE.HALF) THEN
	    XFI12 = 2.D0*PI-ZACOS(P3(2)/GPT3)
	    XFI13 = FI45
	  ELSE
	    XFI12 = ZACOS(P3(2)/GPT3)
	    XFI13 = 2.D0*PI-FI45
	  ENDIF
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = PT5
	  XY3 = Y5
	  XFRAG1 = X4
	  XFRAG2 = UN
	  XETA = X1
	  RESFUNC = F4DIMO4
	  F4DIMO4 = DABS(F4DIMO4)
	ENDIF
C
	RETURN
	END 
C*****************************************************
C INTEGRALE A 2 DIMENSIONS 5||1 only
	DOUBLE PRECISION FUNCTION F2DIMO1(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/SCALE/M,MF,MU
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/ALEM/ILOOPEM
	COMMON/FACONV/HC2
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/SFRAGV/XFRAG1,XFRAG2
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSO/J_PROCESSO_MIN,J_PROCESSO_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	common/isophot/iphotisol
	COMMON/COUP_HISTO/R_ISOL,EPSILON_H
	common/etfix/isofix
	common/emax/etmax
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead
	common/xele/xe 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	DIMENSION XX(20)
	PARAMETER (K0MAX=14)
	DIMENSION SY31(K0MAX),SPCOU(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX)
	DIMENSION P3(4),P4(4),P5(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4))
     #	,DSQRT(S)/(2.D0*DCOSH(Y3)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ GPT3 ------------------------------------------
c x4 = gpt4/gpt3 et x4min=2*gpt4/dsqrt(s)*dcosh(y4) <= gpt4/gpt3
c d'ou gpt3 <= dsqrt(s)/(2.d0*dcosh(y4))
	IF (iphotisol.eq.0) THEN
	   X4MIN = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	ELSE 
	X4MIN_INCL = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	   if (isofix.eq.1) then
	     et_max = etmax
	   else 
	     et_max = EPSILON_H*gpt4
	   endif  
	X4MIN_ISOL = gpt4/(gpt4+et_max)
	X4MIN = DMAX1(X4MIN_INCL,X4MIN_ISOL)
	ENDIF
	GPT3MAXP = DMIN1(GPT_JETSUP,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,GPT4/X4MIN)
	GPT3MAX = DMAX1(GPT4,GPT3MAXP)
	GPT3MIN = GPT4
	GPT3 = GPT3MIN + (GPT3MAX-GPT3MIN)*XX(4)
C ------------------ U -------------------------------------------
	U2 = XX(5)
c ----------------------------------------------------------------	
	X4 = GPT4/GPT3
	X10 = GPT3*(DEXP(Y3)+DEXP(Y4))/DSQRT(S)
	X20 = GPT3*(DEXP(-Y3)+DEXP(-Y4))/DSQRT(S)
	if (x10.gt.un.or.x20.gt.un) then
	  F2DIMO1 = 0.D0
	  return
	endif
c --------------coupure en isolement-------------------------------
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE
	   call isolement(0.d0,0.d0,0.d0,x4,0.d0,gpt4,r_isol,epsilon_h,
     #	   isol)    
c
	   if (.not.isol) then
	      F2DIMO1 = 0.D0
	      RETURN
	    endif   
	ENDIF
c ------------------ fin isolement ------------------------------------	
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)
     #	  *(GPT3MAX-GPT3MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(GPT3MAX-GPT3MIN)
	ENDIF
	CALL FSPCOUO(N,SPCOU)
C ------------------------------------------- 
	  P3(1) = GPT3*DCOSH(Y3)
	  P3(2) = -GPT3
	  P3(3) = 0.D0
	  P3(4) = GPT3*DSINH(Y3)
C ------------------------------------------- 
	  P5(1) = 0.D0
	  P5(2) = 0.D0
	  P5(3) = 0.D0
	  P5(4) = 0.D0
C ------------------------------------------- 
	  P4(1) = GPT4*DCOSH(Y4)
	  P4(2) = GPT4
	  P4(3) = 0.D0
	  P4(4) = GPT4*DSINH(Y4)
c ----------coupure jet-------------------------------------------------
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
          fi3=pi
	  fi5=0.d0
c second y3 and fi35 = 0 serve only to produce r35=0
  	  call jet_selection(y3,y3,0.d0,fi3,fi5,gpt3,0.d0,
     #    algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,    
     #	  inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
c        
	  if (.not.cut_jet) then
	    F2DIMO1 = 0.D0
	    RETURN
	  endif  
	ENDIF
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
 	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
	ALPHAS = ALFAS(ILOOP,MU*MU)
c c^b_{ij} = 2*pi*alpha_s*alpha/(4*c_i*c_j*s**2)
	CBIJ = ALPHAS*ALPHA_EM*2.D0*PI/(S*S)*FACIN
	ALPI = ALPHAS/(2.D0*PI)
c
	CALL SSY3O1(S,GPT4,Y3,Y4,M,X10,X20,X4,U2,IH2,IH4,SY31)
	IF (jetmode.eq.1) THEN
	  xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*XE)
	ENDIF
	CALL VEC_DMULT_VECTOR(SY31,SPCOU,K0MAX,TEMP1)
	F2DIM = 0.d0
	DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	  F2DIM = TEMP1(I) + F2DIM
	ENDDO
C
	F2DIMO1 = F2DIM * XJACOB * ALPI * CBIJ * HC2
c	
	IF (ISPRING.EQ.1) THEN
	  XFI12 = PI
	  XFI13 = 0.D0
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = 0.D0
	  XY3 = 0.D0
	  XFRAG1 = X4
	  XFRAG2 = UN
	  XETA = XE
	  RESFUNC = F2DIMO1
	  F2DIMO1 = DABS(F2DIMO1)
	ENDIF
	RETURN
	END 
C*****************************************************
C INTEGRALE A 2 DIMENSIONS 5||2 only
	DOUBLE PRECISION FUNCTION F2DIMO2(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/SCALE/M,MF,MU
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/ALEM/ILOOPEM
	COMMON/FACONV/HC2
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/SFRAGV/XFRAG1,XFRAG2
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSO/J_PROCESSO_MIN,J_PROCESSO_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	common/isophot/iphotisol
	COMMON/COUP_HISTO/R_ISOL,EPSILON_H
	common/etfix/isofix
	common/emax/etmax
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	DIMENSION XX(20)
	PARAMETER (K0MAX=14)
	DIMENSION SV2(K0MAX),SY3(K0MAX),SPCOU(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX)
	DIMENSION P3(4),P4(4),P5(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4))
     #	,DSQRT(S)/(2.D0*DCOSH(Y3)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ GPT3 ------------------------------------------
c x4 = gpt4/gpt3 et x4min=2*gpt4/dsqrt(s)*dcosh(y4) <= gpt4/gpt3
c d'ou gpt3 <= dsqrt(s)/(2.d0*dcosh(y4))
	IF (iphotisol.eq.0) THEN
	   X4MIN = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	ELSE 
	X4MIN_INCL = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
	   if (isofix.eq.1) then
	     et_max = etmax
	   else 
	     et_max = EPSILON_H*gpt4
	   endif  
	X4MIN_ISOL = gpt4/(gpt4+et_max)
	X4MIN = DMAX1(X4MIN_INCL,X4MIN_ISOL)
	ENDIF
	GPT3MAXP = DMIN1(GPT_JETSUP,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,GPT4/X4MIN)
	GPT3MAX = DMAX1(GPT4,GPT3MAXP)
	GPT3MIN = GPT4
	IF (GPT3MIN.GT.GPT3MAX) THEN
	  F2DIMO2 = 0.D0
	  RETURN
	ENDIF		
	GPT3 = GPT3MIN + (GPT3MAX-GPT3MIN)*XX(4)
C ------------------ U -------------------------------------------
	U2 = XX(5)
c ----------------------------------------------------------------	
	X4 = GPT4/GPT3
	X10 = GPT3*(DEXP(Y3)+DEXP(Y4))/DSQRT(S)
	X20 = GPT3*(DEXP(-Y3)+DEXP(-Y4))/DSQRT(S)
	if (x10.gt.un.or.x20.gt.un) then
	  F2DIMO2 = 0.D0
	  return
	endif
c --------------coupure en isolement-------------------------------
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE
	  call isolement(0.d0,0.d0,0.d0,x4,0.d0,gpt4,r_isol,epsilon_h,
     #	  isol)   
c
	  if (.not.isol) then
	    F2DIMO2 = 0.D0
	    RETURN
	  endif  
	ENDIF
c ------------coupure jet------------------------------------------
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
	  fi3=pi
c second y3 and fi35=0 serves only to produce r35=0
  	  call jet_selection(y3,y3,0.d0,fi3,0.d0,gpt3,0.d0,
     #    algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,    
     #	  inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
          xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X10)
	  if (.not.cut_jet) then
	     F2DIMO2 = 0.D0
	     RETURN
	  endif 
	ENDIF
c --------------------------------------------------------------------------	
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)
     #	  *(GPT3MAX-GPT3MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(GPT3MAX-GPT3MIN)
	ENDIF
	CALL FSPCOUO(N,SPCOU)
C ------------------------------------------- 
	  P3(1) = GPT3*DCOSH(Y3)
	  P3(2) = -GPT3
	  P3(3) = 0.D0
	  P3(4) = GPT3*DSINH(Y3)
C ------------------------------------------- 
	  P5(1) = 0.D0
	  P5(2) = 0.D0
	  P5(3) = 0.D0
	  P5(4) = 0.D0
C ------------------------------------------- 
	  P4(1) = GPT4*DCOSH(Y4)
	  P4(2) = GPT4
	  P4(3) = 0.D0
	  P4(4) = GPT4*DSINH(Y4)
C -------------------------------------------
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
 	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
	ALPHAS = ALFAS(ILOOP,MU*MU)
c c^b_{ij} = 2*pi*alpha_s*alpha/(4*c_i*c_j*s**2)
	CBIJ = ALPHAS*ALPHA_EM*2.D0*PI/(S*S)*FACIN
	ALPI = ALPHAS/(2.D0*PI)
c
	CALL SSY3O2(S,GPT4,Y3,Y4,M,X10,X20,X4,U2,IH2,IH4,SY3)
	CALL SSV2O(S,GPT4,Y3,Y4,X10,X20,X4,U2,IH2,IH4,SV2)
	CALL VEC_DADD_VECTOR(SY3,SV2,K0MAX,TEMP0)
	CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	F2DIM = 0.d0
	DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	  F2DIM = TEMP1(I) + F2DIM
	ENDDO
C
	F2DIMO2 = F2DIM * XJACOB * ALPI * CBIJ * HC2
c	
	IF (ISPRING.EQ.1) THEN
	  XFI12 = PI
	  XFI13 = 0.D0
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = 0.D0
	  XY3 = 0.D0
	  XFRAG1 = X4
	  XFRAG2 = UN
	  XETA = X10
	  RESFUNC = F2DIMO2
	  F2DIMO2 = DABS(F2DIMO2)
	ENDIF
	RETURN
	END 	
ccc	
C INTEGRALE A 2 DIMENSIONS 5||final
c integrate over gpt3 instead of x4
	DOUBLE PRECISION FUNCTION F2DIMO3(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/SCALE/M,MF,MU
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/ALEM/ILOOPEM
	COMMON/FACONV/HC2
	COMMON/COUP/PTMM,R
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/SFRAGV/XFRAG1,XFRAG2
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSO/J_PROCESSO_MIN,J_PROCESSO_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	common/isophot/iphotisol
	common/COUP_HISTO/R_ISOL,EPSILON_H
	common/etfix/isofix
	common/emax/etmax
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)	
	DIMENSION XX(20)
	PARAMETER (K0MAX=14)
	DIMENSION SY4R(K0MAX),SY4P(K0MAX),SPCOU(K0MAX)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX)
	DIMENSION P3(4),P4(4),P5(4)
	PI=DATAN(1.D0)*4.D0
	ZERO = 0.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
	YS = (Y3-Y4)/2.D0
	Y = (Y3+Y4)/2.D0
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,DSQRT(S)/(2.D0*DCOSH(Y4)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ GPT3 -------------------------------------------
	GPT3MAXNOI = DMIN1(GPT_JETSUP,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,DSQRT(S)/(2.D0*DCOSH(Y4)))
	GPT3MIN = DMAX1(GPT_JETINF,GPT4)
     	IF (iphotisol.eq.0) THEN
	GPT3MAX = GPT3MAXNOI
	ELSE
	   if (isofix.eq.1) then
	     et_max = etmax
	   else 
	     et_max = EPSILON_H*gpt4
	   endif  
	GPT3MAXI = gpt4+et_max
     	GPT3MAXISOL = DMIN1(GPT_JETSUP,GPT3MAXI)
 	GPT3MAX = DMIN1(GPT3MAXISOL,GPT3MAXNOI)
	ENDIF
	IF (GPT3MIN.GT.GPT3MAX) THEN
	  F2DIMO3 = 0.D0
c	  write (18,*) 'attention gpt3 < gpt3min ou gpt3 > gpt3max',
c     #	              gpt3,gpt3min,gpt3max
	  RETURN
	ENDIF	
	GPT3 = GPT3MIN + (GPT3MAX-GPT3MIN)*XX(4)	
c -----------------------------------------------------------------			
	X10 = GPT3*(DEXP(Y3)+DEXP(Y4))/DSQRT(S)
	X20 = GPT3*(DEXP(-Y3)+DEXP(-Y4))/DSQRT(S)
	if (x10.gt.un.or.x20.gt.un) then
	  F2DIMO3 =0.D0
	  return
	endif	
C -------------------z4 -------------------------------------------------
	small = 1.d-12
	Z4MAX = 1.D0-small
c	Z4MAXNI=DSQRT(S)/(2.D0*GPT3*DCOSH(Y4))
c	Z4MAXISOL=GPT4/GPT3*(1+EPSILON_H)	
c	Z4MIN0 = DMAX1(GPT4/GPT3,X10,X20)
        Z4MIN0 = GPT4/GPT3
	Z4MIN = Z4MIN0
	Z4 = Z4MIN + (Z4MAX-Z4MIN)*XX(5)
c juste pour tester (en principe inutile)
	if (z4min.ge.z4max) then
	  F2DIMO3 = 0.D0
	  print*, 'attention z4min > z4max',z4min,z4max
	  return
	endif	
c -------------------------------------------------------------------	
        X4=GPT4/(Z4*GPT3)
	PT4 = GPT3*Z4
	PT5X = DSQRT(S)/(2.D0*DCOSH(YS))*(1.D0-X10)*(1.D0-X20)/
     #  ((1.D0-X10)*DEXP(-Y)+(1.D0-X20)*DEXP(Y))
	PTM = DMIN1(PTMM,PT5X)
C
c coupure en isolement-------------------------------------------------
c	pt5 = (1.d0-z4)/(z4*x4)*gpt4
        pt5 = GPT3-PT4
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE 
	  call isolement(0.d0,0.d0,0.d0,x4,pt5,gpt4,r_isol,epsilon_h,
     #	  isol)
       	  if (.not.isol) then
	    F2DIMO3 = 0.D0
	    RETURN
	  endif  
	ENDIF
c -------- coupure jet -------------------------------------------
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
	  fi3=pi
	  fi5=0.d0
c second y3 and fi35=0 serves only to produce r35=0	
  	  call jet_selection(y3,y3,0.d0,fi3,fi5,gpt3,0.d0,
     #    algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,
     #	  inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
c          x1s=x10/z4
c          xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X1S)
          xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X10)
	  if (.not.cut_jet) then
	    F2DIMO3 = 0.D0
	    RETURN
	  endif
	ENDIF
c --------------------------------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)
     #	  *(GPT3MAX-GPT3MIN)*(Z4MAX-Z4MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)
     #	  *(GPT3MAX-GPT3MIN)*(Z4MAX-Z4MIN)
	ENDIF
	CALL FSPCOUO(N,SPCOU)
C ------------------------------------------- 
	  P3(1) = GPT3*DCOSH(Y3)
	  P3(2) = -GPT3
	  P3(3) = 0.D0
	  P3(4) = GPT3*DSINH(Y3)
C ------------------------------------------- 
	  P5(1) = 0.D0
	  P5(2) = 0.D0
	  P5(3) = 0.D0
	  P5(4) = 0.D0
C ------------------------------------------- 
	  P4(1) = GPT4*DCOSH(Y4)
	  P4(2) = GPT4
	  P4(3) = 0.D0
	  P4(4) = GPT4*DSINH(Y4)
C -------------------------------------------
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
 	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
	ALPHAS = ALFAS(ILOOP,MU*MU)
c c^b_{ij} = 2*pi*alpha_s*alpha/(4*c_i*c_j*s**2)
	CBIJ = ALPHAS*ALPHA_EM*2.D0*PI/(S*S)*FACIN
	ALPI = ALPHAS/(2.D0*PI)
c
	CALL SSY4PO(S,GPT3,GPT4,Y3,Y4,MF,X10,X20,Z4,IH2,IH4,SY4P)
c	CALL VEC_DINIT(SY4P,K0MAX,ZERO)	
c	Z4SUP = PT4/(PT4+PTM)
	IF (pt5.GE.PTM) THEN
	  CALL SSY4RO(S,GPT3,GPT4,Y3,Y4,R,X10,X20,Z4,IH2,IH4,SY4R)
	ELSE
	  CALL VEC_DINIT(SY4R,K0MAX,ZERO)	  
	ENDIF
	CALL VEC_DADD_VECTOR(SY4P,SY4R,K0MAX,TEMP0)
	CALL VEC_DMULT_VECTOR(TEMP0,SPCOU,K0MAX,TEMP1)
	F2DIM = 0.d0
	DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	  F2DIM = TEMP1(I) + F2DIM
	ENDDO
C
	F2DIMO3 = F2DIM * XJACOB * ALPI * CBIJ * HC2
c	
	IF (ISPRING.EQ.1) THEN
	  XFI12 = PI
	  XFI13 = 0.D0
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = 0.D0
	  XY3 = 0.D0
	  XFRAG1 = X4
	  XFRAG2 = UN
	  XETA = X10/Z4
	  RESFUNC = F2DIMO3
	  F2DIMO3 = DABS(F2DIMO3)
	ENDIF
	RETURN
	END 
C*****************************************************
C INTEGRALE A 1 DIMENSION
	DOUBLE PRECISION FUNCTION F1DIMO(XX)
	IMPLICIT REAL*8 (A-H,L-V,X-Z)
	IMPLICIT REAL*4 (W)
	LOGICAL ISOL,cut_jet
	COMMON/HADRON/IH1,IH2,IH3,IH4
	COMMON/SCALE/M,MF,MU
	COMMON/COUL/N,CF,GTR
	COMMON/PARAMI/YSUP,YINF,GPTSUP,GPTINF,S,YSHIFT
	COMMON/PARAM_JET/Y_JETSUP,Y_JETINF,GPT_JETSUP,GPT_JETINF
	COMMON/ALEM/ILOOPEM
	COMMON/FACONV/HC2
	COMMON/BORN/IBORN
	COMMON/COUP/PTMM,R
	COMMON/SORTIE/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	COMMON/SFRAGV/XFRAG1,XFRAG2
	COMMON/BASPRING/ISPRING
	COMMON/NBOUCLE/ILOOP
	COMMON/AURENCHE/IAUREN
	COMMON/PROCESSO/J_PROCESSO_MIN,J_PROCESSO_MAX
	COMMON/TYPESC/ICHOI_SCALE
	COMMON/NORMASC/CM,CMU,CMF
	common/isophot/iphotisol
	COMMON/COUP_HISTO/R_ISOL,EPSILON_H
	common/etfix/isofix
	common/emax/etmax
	common/jets/jetmode
	common/jet_cut/yjet_min,yjet_max,ptjet_min,ptjet_max
	common/jet_para/r_kt,r_c,r_sep
	common/jetkin/ptj_lead,yj_lead 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)	
	DIMENSION XX(20)
	PARAMETER (K0MAX=14)
	DIMENSION TEMP0(K0MAX),TEMP1(K0MAX),TEMP2(K0MAX),TEMP3(K0MAX)
	DIMENSION C0SV12(K0MAX),C0SV3(K0MAX),C0SV4(K0MAX),C0FBORN(K0MAX)
	DIMENSION C0SY3R(K0MAX),TEMP4(K0MAX)
	DIMENSION SPCOU(K0MAX)
	DIMENSION P3(4),P4(4),P5(4)
	PI=DATAN(1.D0)*4.D0
	UN = 1.D0
C ------------------ Y3 -------------------------------------------
	Y3MAX = Y_JETSUP
	Y3MIN = Y_JETINF
	Y3 = Y3MIN + (Y3MAX-Y3MIN)*XX(1)
C ------------------ Y4 -------------------------------------------
	Y4MAX = YSUP
	Y4MIN = YINF
	Y4 = Y4MIN + (Y4MAX-Y4MIN)*XX(2)
	YS = (Y3-Y4)/2.D0
	Y = (Y3+Y4)/2.D0
C ------------------ GPT4 ------------------------------------------
	GPT4MAXP = DMIN1(GPTSUP,DSQRT(S)/(2.D0*DCOSH(Y4))
     #	,DSQRT(S)/(2.D0*DCOSH(Y3)))
	GPT4MAX = DMAX1(GPTINF,GPT4MAXP)
	GPT4MIN = GPTINF
	GPT4 = GPT4MIN + (GPT4MAX-GPT4MIN)*XX(3)
C ------------------ GPT3 ------------------------------------------
c x4 = gpt4/gpt3 et x4min=2*gpt4/dsqrt(s)*dcosh(y4) <= gpt4/gpt3
c d'ou gpt3 <= dsqrt(s)/(2.d0*dcosh(y4))
	GPT3MAXNOI = DMIN1(GPT_JETSUP,DSQRT(S)/(2.D0*DCOSH(Y3))
     #	,DSQRT(S)/(2.D0*DCOSH(Y4)))
	GPT3MIN = DMAX1(GPT_JETINF,GPT4)
     	IF (iphotisol.eq.0) THEN
	GPT3MAX = GPT3MAXNOI
	ELSE
	   if (isofix.eq.1) then
	     et_max = etmax
	   else 
	     et_max = EPSILON_H*gpt4
	   endif  
	GPT3MAXI = gpt4+et_max
     	GPT3MAXISOL = DMIN1(GPT_JETSUP,GPT3MAXI)
	GPT3MAX = DMIN1(GPT3MAXISOL,GPT3MAXNOI)
	ENDIF     
	GPT3 = GPT3MIN + (GPT3MAX-GPT3MIN)*XX(4)
C
	X10 = GPT3*(DEXP(Y3)+DEXP(Y4))/DSQRT(S)
	X20 = GPT3*(DEXP(-Y3)+DEXP(-Y4))/DSQRT(S)
	if (x10.gt.un.or.x20.gt.un) then
	  F1DIMO = 0.D0
	  return
	endif
	PT5X = DSQRT(S)/(2.D0*DCOSH(YS))*(1.D0-X10)*(1.D0-X20)/
     #  ((1.D0-X10)*DEXP(-Y)+(1.D0-X20)*DEXP(Y))
	PTM = DMIN1(PTMM,PT5X)
cc	PTM = PTMM
c
	IF (IAUREN.EQ.0) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(Y4MAX-Y4MIN)*(GPT4MAX-GPT4MIN)
     #	  *(GPT3MAX-GPT3MIN)
	ELSE IF (IAUREN.EQ.1) THEN
	  XJACOB = (Y3MAX-Y3MIN)*(GPT3MAX-GPT3MIN)
	ENDIF
	CALL FSPCOUO(N,SPCOU)
	X4 = GPT4/GPT3
c en principe vrai mais a verif
	X4MAX = 1.D0
	X4MIN_INCL = 2.D0*GPT4/DSQRT(S)*DCOSH(Y4)
        X4MIN_ISOL = gpt4/(gpt4+et_max)
	IF (iphotisol.eq.0) THEN
	   X4MIN = X4MIN_INCL
	ELSE   
	   X4MIN = DMAX1(X4MIN_INCL,X4MIN_ISOL)
	ENDIF
	IF (X4.GT.X4MAX.OR.X4.LT.X4MIN) THEN
	  F1DIMO = 0.D0
	  write (18,*) 'attention x4 ne verifie pas x4min < x4 < x4max',
     #		x4,x4min,x4max
	ENDIF
c coupure en isolement-------------------------------------------------
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ELSE 
	  call isolement(0.d0,0.d0,0.d0,x4,0.d0,gpt4,r_isol,epsilon_h,
     #	  isol)
	  if (.not.isol) then
	    F1DIMO = 0.D0
	    RETURN
	  endif
	ENDIF
c -------------- coupure jet -----------------------------------------
	IF (jetmode.eq.0) THEN
	  cut_jet = .TRUE.
	ELSE
	  fi3=pi
	  fi5=0.d0
c second y3 and fi35=0 serve only to produce r35=0	  
  	  call jet_selection(y3,y3,0.d0,fi3,fi5,gpt3,0.d0,
     #    algorithm,r_kt,r_c,r_sep,merging,merged,
     #    ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,
     #	  inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
          xgamobs=(gpt4*exp(y4)+ptj_lead*exp(yj_lead))/(DSQRT(S)*X10)
	  if (.not.cut_jet) then
	    F1DIMO = 0.D0
	    RETURN
	  endif  
	ENDIF
c --------------------------------------------------------------------------
	  P3(1) = GPT3*DCOSH(Y3)
	  P3(2) = -GPT3
	  P3(3) = 0.D0
	  P3(4) = GPT3*DSINH(Y3)
C ------------------------------------------- 
	  P5(1) = 0.D0
	  P5(2) = 0.D0
	  P5(3) = 0.D0
	  P5(4) = 0.D0
C ------------------------------------------- 
	  P4(1) = GPT4*DCOSH(Y4)
	  P4(2) = GPT4
	  P4(3) = 0.D0
	  P4(4) = GPT4*DSINH(Y4)
C -------------------------------------------
c set the scales-------------------------------------------------
	IF (IAUREN.EQ.0) THEN
	  CALL CHOISCALE(P3,P4,CM,CMU,CMF,ICHOI_SCALE,M,MU,MF)
	  FACIN = 1.D0
	ELSE IF (IAUREN.EQ.1) THEN
	  M = GPT4*CM
	  MU = M
	  MF = M
	  FACIN = 1.D0/(2.D0*PI*GPT4)
	ENDIF
	ALPHA_EM = ALPHAEM(ILOOPEM,M*M)
	ALPHAS = ALFAS(ILOOP,MU*MU)
c c^b_{ij} = 2*pi*alpha_s*alpha/(4*c_i*c_j*s**2)
	CBIJ = ALPHAS*ALPHA_EM*2.D0*PI/(S*S)*FACIN
	ALPI = ALPHAS/(2.D0*PI)
c 
	IF (IBORN.EQ.0) THEN 
	  CALL SSV12O(S,GPT4,Y3,Y4,M,MU,X10,X20,PTM,X4,IH2,IH4,
     #	  C0SV12)
	  CALL SSV4O(S,GPT3,GPT4,GPT_JETSUP,Y3,Y4,MF,X10,X20,IH2,
     #	  IH4,C0SV4)
	  CALL SSY3RO(S,GPT4,Y3,Y4,X10,X20,PTM,R,X4,IH2,IH4,C0SY3R)
	  CALL SSV3O(S,GPT4,Y3,Y4,MF,X10,X20,X4,IH2,IH4,C0SV3)
	  CALL VEC_DMULT_VECTOR(C0SV12,SPCOU,K0MAX,TEMP0)
	  CALL VEC_DMULT_VECTOR(C0SV3,SPCOU,K0MAX,TEMP1)
	  CALL VEC_DMULT_VECTOR(C0SV4,SPCOU,K0MAX,TEMP2)
	  CALL VEC_DMULT_VECTOR(C0SY3R,SPCOU,K0MAX,TEMP3)
	  SV12 = 0.d0
	  SV3 = 0.d0
	  SV4 = 0.d0
	  SY3R = 0.d0
	  DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	    SV12 = TEMP0(I) + SV12
	    SV3 =  TEMP1(I) + SV3
	    SV4 =  TEMP2(I) + SV4
	    SY3R = TEMP3(I) + SY3R
	  ENDDO
	  FBORN = 0.d0
	ELSE IF (IBORN.EQ.1) THEN
	  CALL SFBORNO(S,N,GPT4,Y3,Y4,X4,IH2,IH4,C0FBORN)
	  CALL VEC_DMULT_VECTOR(C0FBORN,SPCOU,K0MAX,TEMP4)
	  FBORN = 0.d0
	  DO I = J_PROCESSO_MIN,J_PROCESSO_MAX
	    FBORN = TEMP4(I) + FBORN
	  ENDDO
	  SV12 = 0.d0
	  SV3 = 0.d0
	  SV4 = 0.d0
	  SY3R = 0.d0
	ENDIF
c 
	RESB = FBORN + (SV12+SV3+SV4+SY3R)*ALPI
c
	F1DIMO = RESB * XJACOB * CBIJ * HC2
C
	IF (ISPRING.EQ.1) THEN
	  XFI12 = PI
	  XFI13 = 0.D0
	  XPT1 = GPT4
	  XY1 = Y4
	  XPT2 = GPT3
	  XY2 = Y3
	  XPT3 = 0.D0
	  XY3 = 0.D0
	  XFRAG1 = X4
	  XFRAG2 = UN
	  XETA = X10
	  RESFUNC = F1DIMO
	  F1DIMO = DABS(F1DIMO)
	ENDIF
C
	RETURN
	END 
C===================================================================
	SUBROUTINE AMPO3(s,x1,x2,y3,pt3,y5,pt5,fi35,CAMP)
	IMPLICIT REAL*8(A-H,L-Z)
	PARAMETER (K0MAX=14)
	DIMENSION H12(K0MAX),H13(K0MAX),H14(K0MAX)
	DIMENSION H34(K0MAX),H23(K0MAX),H24(K0MAX),CONS(K0MAX)
	DIMENSION CAMP(K0MAX)
	S12 =  x1*x2*s/2.d0
	S13 =  x1*pt3*dsqrt(s)/2.d0*dexp(-y3)
	S23 =  x2*pt3*dsqrt(s)/2.d0*dexp(y3)
	S15 =  x1*pt5*dsqrt(s)/2.d0*dexp(-y5)
	S25 =  x2*pt5*dsqrt(s)/2.d0*dexp(y5)
	S35 =  pt3*pt5*coshmcos(y3-y5,fi35)
	S14 =  s12-s13-s15
	S24 =  s12-s23-s25
	S34 =  s13+s23-s35
	S45 =  s15+s25-s35
	E12 = S12/(S15*S25)
	E13 = S13/(S15*S35)
	E23 = S23/(S25*S35)
	E34P = S34/(S15+S25)/S35
C -------------------------------------------
	CALL SH12O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H12)
	CALL SH13O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H13)
	CALL SH23O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H23)
	CALL SH34O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H34)
	CALL SCONSO(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,CONS)
	DO I=1,K0MAX
	  CAMP(I) = (0.5D0*H12(I)*E12+H13(I)*E13
     #	             +H23(I)*E23+H34(I)*E34P+0.5D0*CONS(I))
	ENDDO
	RETURN
	END
C===================================================================
	subroutine ampo_corr3(s,x1,x2,y3,pt3,pt5,rs,camp)
	implicit real*8(a-h,l-z)
	parameter (K0MAX=14)
	dimension h12(k0max),h13(k0max),h14(k0max)
	dimension h34(k0max),h23(k0max),h24(k0max),cons(k0max)
	dimension camp(k0max)
	s12 =  x1*x2*s/2.d0
	s13 =  x1*pt3*dsqrt(s)/2.d0*dexp(-y3)
	s23 =  x2*pt3*dsqrt(s)/2.d0*dexp(y3)
	s15 =  x1*pt5*dsqrt(s)/2.d0*dexp(-y3)
	s25 =  x2*pt5*dsqrt(s)/2.d0*dexp(y3)
	s35 =  0.d0
	s14 =  s12-s13-s15
	s24 =  s12-s23-s25
	s34 =  s13+s23-s35
	s45 =  s15+s25-s35
c -------------------------------------------
	call sh13o(s12,s13,s14,s15,s23,s24,s25,s34,s35,s45,h13)
	call sh23o(s12,s13,s14,s15,s23,s24,s25,s34,s35,s45,h23)
	call sh34o(s12,s13,s14,s15,s23,s24,s25,s34,s35,s45,h34)
	do i=1,k0max
	  camp(i) = (h13(i)+h23(i)+h34(i))*2.d0/rs/(pt5*pt5)
	enddo
	return
	end
C===================================================================
	SUBROUTINE AMPO4(s,x1,x2,y4,pt4,y5,pt5,fi45,CAMP)
	IMPLICIT REAL*8(A-H,L-Z)
	PARAMETER (K0MAX=14)
	DIMENSION H12(K0MAX),H13(K0MAX),H14(K0MAX)
	DIMENSION H34(K0MAX),H23(K0MAX),H24(K0MAX),CONS(K0MAX)
	DIMENSION CAMP(K0MAX)
	S12 =  x1*x2*s/2.d0
	S14 =  x1*pt4*dsqrt(s)/2.d0*dexp(-y4)
	S24 =  x2*pt4*dsqrt(s)/2.d0*dexp(y4)
	S15 =  x1*pt5*dsqrt(s)/2.d0*dexp(-y5)
	S25 =  x2*pt5*dsqrt(s)/2.d0*dexp(y5)
	S45 =  pt4*pt5*coshmcos(y4-y5,fi45)
	S13 =  s12-s14-s15
	S23 =  s12-s24-s25
	S34 =  s14+s24-s45
	S35 =  s15+s25-s45
	E12 = S12/(S15*S25)
	E13 = S13/(S15*S35)
	E23 = S23/(S25*S35)
	E14 = S14/(S15*S45)
	E24 = S24/(S25*S45)
	E34S = S34/(S15+S25)/S45
C -------------------------------------------
	CALL SH12O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H12)
	CALL SH14O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H14)
	CALL SH24O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H24)
	CALL SH34O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,H34)
	CALL SCONSO(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,CONS)
	DO I=1,K0MAX
	  CAMP(I) = (0.5D0*H12(I)*E12+H14(I)*E14
     #	             +H24(I)*E24+H34(I)*E34S+0.5D0*CONS(I))
	ENDDO
	RETURN
	END
C===================================================================
	subroutine ampo_corr4(s,x1,x2,y4,pt4,pt5,rs,camp)
	implicit real*8(a-h,l-z)
	parameter (K0MAX=14)
	dimension h12(k0max),h13(k0max),h14(k0max)
	dimension h34(k0max),h23(k0max),h24(k0max),cons(k0max)
	dimension camp(k0max)
	s12 =  x1*x2*s/2.d0
	s14 =  x1*pt4*dsqrt(s)/2.d0*dexp(-y4)
	s24 =  x2*pt4*dsqrt(s)/2.d0*dexp(y4)
	s15 =  x1*pt5*dsqrt(s)/2.d0*dexp(-y4)
	s25 =  x2*pt5*dsqrt(s)/2.d0*dexp(y4)
	s45 =  0.d0
	s13 =  s12-s14-s15
	s23 =  s12-s24-s25
	s34 =  s14+s24-s45
	s35 =  s15+s25-s45
C -------------------------------------------
	call sh14o(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,h14)
	call sh24o(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,h24)
	call sh34o(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,h34)
	do i=1,k0max
	  camp(i) = (h14(i)+h24(i)+h34(i))*2.d0/rs/(pt5*pt5)
	enddo
	return
	end
C********************************************************************
	subroutine count(i)
	implicit real*8(a-h,l-z)
	common/testcount/j(11)
	j(i) = j(i) + 1
	return
	end
C********************************************************************
	subroutine trapnan(i,wx)
	implicit real*8 (a-h,l-v,x-z)
	implicit real*4 (w)
	wzero = 0.
	if (wx.lt.wzero.and.wx.gt.wzero) then
	  write (*,*) 'i=',' nan=',wx
	endif
	return
	end
C********************************************************************

