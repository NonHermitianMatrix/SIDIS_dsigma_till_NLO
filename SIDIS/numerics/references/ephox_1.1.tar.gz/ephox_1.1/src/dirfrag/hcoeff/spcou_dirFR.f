C*************************************************************
C average over initial spins and colours for 2 -> 2 matrix el.
C*************************************************************
	SUBROUTINE FSPCOUO(N,SPCOU)
	IMPLICIT REAL*8 (A-H,L-Z)
	PARAMETER (K0MAX=14)
	DIMENSION SPCOU(K0MAX)
	ZERO =0.D0
	CALL VEC_DINIT(SPCOU,K0MAX,ZERO)
	VC = N*N - 1.D0
C
C	j0 = 1 : ph + D --> jet + U
	SPCOU(1) = 1.D0/(4.D0*N)
C	j0 = 2 : ph + U --> jet + D
	SPCOU(2) = 1.D0/(4.D0*N)
C	j0 = 3 : ph + D --> jet + Dp
	SPCOU(3) = 1.D0/(4.D0*N)
C	j0 = 4 : ph + U --> jet + Up
	SPCOU(4) = 1.D0/(4.D0*N)
C	j0 = 5 : ph + D --> jet + Ub
	SPCOU(5) = 1.D0/(4.D0*N)
C	j0 = 6 : ph + U --> jet + Db
	SPCOU(6) = 1.D0/(4.D0*N)
C	j0 = 7 : ph + D --> jet + Dpb
	SPCOU(7) = 1.D0/(4.D0*N)
C	j0 = 8 : ph + U --> jet + Upb
	SPCOU(8) = 1.D0/(4.D0*N)
C	j0 = 9 : ph + D --> jet + D
	SPCOU(9) = 1.D0/(4.D0*N)
C	j0 = 10: ph + U --> jet + U
	SPCOU(10) = 1.D0/(4.D0*N)
C	j0 = 11: ph + qi--> jet + qbi
	SPCOU(11) = 1.D0/(4.D0*N)
C	j0 = 12: ph + qi--> jet + g
	SPCOU(12) = 1.D0/(4.D0*N)
C	j0 = 13: ph + g --> jet + qi
	SPCOU(13) = 1.D0/(4.D0*VC)
C	j0 = 14: ph + g --> jet + g
	SPCOU(14) = 1.D0/(4.D0*VC)
	RETURN
	END
