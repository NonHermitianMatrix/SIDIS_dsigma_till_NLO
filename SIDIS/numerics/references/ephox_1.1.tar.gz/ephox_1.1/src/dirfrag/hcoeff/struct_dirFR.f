C*******************************************************	
C pour photoproduction d'un photon de fragmentation
C*******************************************************
c correction 29.11.00: no summation over flavors for j0=14
c	
	SUBROUTINE STRFRAO(X1,X2,IH2,X4,IH4,SFO)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/GDF/JNF
	COMMON/SCALE/M,MF,MU
	DIMENSION F2(-6:6),D4(-6:6)
	PARAMETER (K0MAX=14,J0MAX=14)
c qcharge est la valeur absolue de la charge des quarks fois 3 au carre
	DIMENSION SF(K0MAX),SFO(K0MAX),QCHARGE(6)
	DATA QCHARGE/1.D0,4.D0,1.D0,4.D0,1.D0,4.D0/
	CALL GAMSTRU(X1,F1)
	CALL FSTRU(X2,M*M,IH2,F2)
	CALL DFRAG(X4,MF*MF,IH4,D4)
C initialisation du tableau SF(K0MAX)
	ZERO = 0.D0
	CALL VEC_DINIT(SF,K0MAX,ZERO)
	CALL VEC_DINIT(SFO,K0MAX,ZERO)
C on commence les processus
C non-factorizing charges already included in matrixel. by CQI,CQK (htermone,crossone)
C
	DO I=1,JNF,2
	  DO K=2,JNF,2
C	j0 = 1 : ph + D --> jet + U 
	SF(1) = F1*(F2(I)*D4(K) + F2(-I)*D4(-K)) + SF(1)
C	j0 = 5 : ph + D --> jet + Ub 
	SF(5) = F1*(F2(I)*D4(-K) + F2(-I)*D4(K)) + SF(5)
          ENDDO
	ENDDO	   	    
C
	DO I=2,JNF,2
	  DO K=1,JNF,2
C	j0 = 2 : ph + U --> jet + D 
	SF(2) = F1*(F2(I)*D4(K) + F2(-I)*D4(-K)) + SF(2)
C	j0 = 6 : ph + U --> jet + Db 
	SF(6) = F1*(F2(I)*D4(-K) + F2(-I)*D4(K)) + SF(6)
	  ENDDO
	ENDDO
C	
	DO I=1,JNF,2
	  DO K=1,JNF,2
	   IF (K.NE.I) THEN 
C	j0 = 3 : ph + D --> jet + Dp
	SF(3) = F1*(F2(I)*D4(K) + F2(-I)*D4(-K)) + SF(3)
C	j0 = 7 : ph + D --> jet + Dpb
        SF(7) = F1*(F2(I)*D4(-K) + F2(-I)*D4(K)) + SF(7)
	   ENDIF
	  ENDDO
	ENDDO
C	
	DO I=2,JNF,2
	  DO K=2,JNF,2
	   IF (K.NE.I) THEN 
C	j0 = 4 : ph + U --> jet + Up
	SF(4) = F1*(F2(I)*D4(K) + F2(-I)*D4(-K)) + SF(4)
C	j0 = 8 : ph + U --> jet + Upb
	SF(8) = F1*(F2(I)*D4(-K) + F2(-I)*D4(K)) + SF(8)
	   ENDIF
	  ENDDO
	ENDDO
C
	DO I=1,JNF,2	  
C	j0 = 9 : ph + D --> jet + D
	SF(9) = F1*(F2(I)*D4(I) + F2(-I)*D4(-I)) + SF(9)
	ENDDO
C	  
	DO I=2,JNF,2	  
C	j0 = 10 : ph + U --> jet + U
	SF(10) = F1*(F2(I)*D4(I) + F2(-I)*D4(-I)) + SF(10)
	ENDDO
C
	DO I=1,JNF
C	j0 = 11 : ph + qi --> jet + qbi
	SF(11) = QCHARGE(I)*F1*(F2(I)*D4(-I) + F2(-I)*D4(I)) + SF(11)
C	j0 = 12 : ph + qi --> jet + g
	SF(12) = QCHARGE(I)*F1*(F2(I)*D4(0) + F2(-I)*D4(0)) + SF(12)
C	j0 = 13 : ph + g --> jet + qi
	SF(13) = QCHARGE(I)*F1*(F2(0)*D4(I) + F2(0)*D4(-I)) + SF(13)
	ENDDO
C	j0 = 14 : ph + g --> jet + g
	SF(14) = F1*F2(0)*D4(0) + SF(14)
C
C on divise tout par x1 x2
	XX = 1.D0/(X1*X2)
	CALL VEC_DMULT_CONSTANT(SF,K0MAX,XX,SFO)	    
	RETURN
	END

