C*****************************************************
CC  TERMES QUI VIENNENT DE 5 COLLINEAIRE A 1
C*****************************************************
C PARTIE EN 1/(1-Z1)+
	SUBROUTINE VEC_15ZO(SC,TC,UC,Z1,M,PTM,CQI,CQK,VPART15Z)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART15Z(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART15Z(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*(-ANM4_QP(z1)-A4_QP(z1)*dlog(ptm**2/M**
     #2)+FAQP(z1))/N
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = eqi**2*A(UC,SC,TC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(2) = t0
	VPART15Z(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*(-ANM4_QP(z1)-A4_QP(z1)*dlog(ptm**2/M**
     #2)+FAQP(z1))/N
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = eqi**2*A(UC,SC,TC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(4) = t0
	VPART15Z(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*(-ANM4_QP(z1)-A4_QP(z1)*dlog(ptm**2/M**
     #2)+FAQP(z1))/N
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = eqi**2*A(UC,SC,TC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(6) = t0
	VPART15Z(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*(-ANM4_QP(z1)-A4_QP(z1)*dlog(ptm**2/M**
     #2)+FAQP(z1))/N
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = eqi**2*A(UC,SC,TC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(8) = t0
	VPART15Z(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = eqk**2*A(TC,UC,SC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = eqi**2*A(TC,SC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(10) = t0
	VPART15Z(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = eqk**2*A(TC,UC,SC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = eqi**2*A(TC,SC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(12) = t0
	VPART15Z(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = eqk**2*A(TC,UC,SC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = eqi**2*A(TC,SC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(14) = t0
	VPART15Z(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = eqk**2*A(TC,UC,SC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = eqi**2*A(TC,SC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(16) = t0
	VPART15Z(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = eqk**2*A(SC,TC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = eqk**2*A(UC,TC,SC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = eqi**2*(A(SC,TC,UC,N)+A(SC,UC,TC,N)+B(SC,TC,UC,N))*(dlog(ptm*
     #*2/M**2)*A4_QP(z1)+ANM4_QP(z1)-FAQP(z1))/N
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = eqi**2*(A(UC,TC,SC,N)+A(UC,SC,TC,N)+B(UC,TC,SC,N))*(ANM4_QP(z
     #1)+A4_QP(z1)*dlog(ptm**2/M**2)-FAQP(z1))/N
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = 0.D0
	VTEMP(21) = t0
	VPART15Z(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = eqk**2*A(SC,TC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = eqk**2*A(UC,TC,SC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2)
     #-FAQP(z1))/N
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = eqi**2*(A(SC,TC,UC,N)+A(SC,UC,TC,N)+B(SC,TC,UC,N))*(dlog(ptm*
     #*2/M**2)*A4_QP(z1)+ANM4_QP(z1)-FAQP(z1))/N
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = eqi**2*(A(UC,TC,SC,N)+A(UC,SC,TC,N)+B(UC,TC,SC,N))*(ANM4_QP(z
     #1)+A4_QP(z1)*dlog(ptm**2/M**2)-FAQP(z1))/N
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = 0.D0
	VTEMP(26) = t0
	VPART15Z(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = -eqi**2*(A(TC,UC,SC,N)+A(TC,SC,UC,N)+B(TC,UC,SC,N))*(-A4_QP(z
     #1)*dlog(ptm**2/M**2)-ANM4_QP(z1)+FAQP(z1))/N
	VTEMP(27) = t0
	VPART15Z(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = -eqi**2*C(SC,TC,UC,N)*(-ANM4_QP(z1)-A4_QP(z1)*dlog(ptm**2/M**
     #2)+FAQP(z1))/N
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = 0.D0
	VTEMP(29) = t0
	VPART15Z(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = 0.D0
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = -eqi**2*C(UC,SC,TC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2
     #)-FAQP(z1))/N
	VTEMP(31) = t0
	VPART15Z(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = eqi**2*C(TC,SC,UC,N)*(-ANM4_QP(z1)-A4_QP(z1)*dlog(ptm**2/M**2
     #)+FAQP(z1))/N
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = -eqi**2*C(TC,SC,UC,N)*(ANM4_QP(z1)+A4_QP(z1)*dlog(ptm**2/M**2
     #)-FAQP(z1))/N
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART15Z(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C PARTIE EN LOG(1-Z1)/(1-Z1)+
	SUBROUTINE VEC_15LO(SC,TC,UC,Z1,CQI,CQK,VPART15L)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART15L(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART15L(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*FBQP(z1)/N
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = -eqi**2*A(UC,SC,TC,N)*FBQP(z1)/N
	VTEMP(2) = t0
	VPART15L(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*FBQP(z1)/N
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = -eqi**2*A(UC,SC,TC,N)*FBQP(z1)/N
	VTEMP(4) = t0
	VPART15L(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*FBQP(z1)/N
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = -eqi**2*A(UC,SC,TC,N)*FBQP(z1)/N
	VTEMP(6) = t0
	VPART15L(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*FBQP(z1)/N
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = -eqi**2*A(UC,SC,TC,N)*FBQP(z1)/N
	VTEMP(8) = t0
	VPART15L(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = -eqk**2*A(TC,UC,SC,N)*FBQP(z1)/N
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = -eqi**2*A(TC,SC,UC,N)*FBQP(z1)/N
	VTEMP(10) = t0
	VPART15L(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = -eqk**2*A(TC,UC,SC,N)*FBQP(z1)/N
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = -eqi**2*A(TC,SC,UC,N)*FBQP(z1)/N
	VTEMP(12) = t0
	VPART15L(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = -eqk**2*A(TC,UC,SC,N)*FBQP(z1)/N
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = -eqi**2*A(TC,SC,UC,N)*FBQP(z1)/N
	VTEMP(14) = t0
	VPART15L(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = -eqk**2*A(TC,UC,SC,N)*FBQP(z1)/N
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = -eqi**2*A(TC,SC,UC,N)*FBQP(z1)/N
	VTEMP(16) = t0
	VPART15L(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = -eqk**2*A(SC,TC,UC,N)*FBQP(z1)/N
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = -eqk**2*A(UC,TC,SC,N)*FBQP(z1)/N
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = -eqi**2*FBQP(z1)*(A(SC,TC,UC,N)+A(SC,UC,TC,N)+B(SC,TC,UC,N))/
     #N
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = -eqi**2*FBQP(z1)*(A(UC,TC,SC,N)+A(UC,SC,TC,N)+B(UC,TC,SC,N))/
     #N
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = 0.D0
	VTEMP(21) = t0
	VPART15L(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = -eqk**2*A(SC,TC,UC,N)*FBQP(z1)/N
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = -eqk**2*A(UC,TC,SC,N)*FBQP(z1)/N
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = -eqi**2*FBQP(z1)*(A(SC,TC,UC,N)+A(SC,UC,TC,N)+B(SC,TC,UC,N))/
     #N
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = -eqi**2*FBQP(z1)*(A(UC,TC,SC,N)+A(UC,SC,TC,N)+B(UC,TC,SC,N))/
     #N
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = 0.D0
	VTEMP(26) = t0
	VPART15L(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = -eqi**2*FBQP(z1)*(A(TC,UC,SC,N)+A(TC,SC,UC,N)+B(TC,UC,SC,N))/
     #N
	VTEMP(27) = t0
	VPART15L(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = -eqi**2*C(SC,TC,UC,N)*FBQP(z1)/N
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = 0.D0
	VTEMP(29) = t0
	VPART15L(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = 0.D0
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = eqi**2*C(UC,SC,TC,N)*FBQP(z1)/N
	VTEMP(31) = t0
	VPART15L(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = eqi**2*C(TC,SC,UC,N)*FBQP(z1)/N
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = eqi**2*C(TC,SC,UC,N)*FBQP(z1)/N
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART15L(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C PARTIE EN DELTA(1-Z1)
	SUBROUTINE VEC_15DO(SC,TC,UC,M,PTM,CQI,CQK,VPART15D)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART15D(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART15D(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*FCQP(1.D0)/N
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = -eqi**2*A(UC,SC,TC,N)*FCQP(1.D0)/N
	VTEMP(2) = t0
	VPART15D(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*FCQP(1.D0)/N
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = -eqi**2*A(UC,SC,TC,N)*FCQP(1.D0)/N
	VTEMP(4) = t0
	VPART15D(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*FCQP(1.D0)/N
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = -eqi**2*A(UC,SC,TC,N)*FCQP(1.D0)/N
	VTEMP(6) = t0
	VPART15D(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = -eqk**2*A(SC,UC,TC,N)*FCQP(1.D0)/N
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = -eqi**2*A(UC,SC,TC,N)*FCQP(1.D0)/N
	VTEMP(8) = t0
	VPART15D(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = -eqk**2*A(TC,UC,SC,N)*FCQP(1.D0)/N
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = -eqi**2*A(TC,SC,UC,N)*FCQP(1.D0)/N
	VTEMP(10) = t0
	VPART15D(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = -eqk**2*A(TC,UC,SC,N)*FCQP(1.D0)/N
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = -eqi**2*A(TC,SC,UC,N)*FCQP(1.D0)/N
	VTEMP(12) = t0
	VPART15D(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = -eqk**2*A(TC,UC,SC,N)*FCQP(1.D0)/N
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = -eqi**2*A(TC,SC,UC,N)*FCQP(1.D0)/N
	VTEMP(14) = t0
	VPART15D(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = -eqk**2*A(TC,UC,SC,N)*FCQP(1.D0)/N
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = -eqi**2*A(TC,SC,UC,N)*FCQP(1.D0)/N
	VTEMP(16) = t0
	VPART15D(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = -eqk**2*A(SC,TC,UC,N)*FCQP(1.D0)/N
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = -eqk**2*A(UC,TC,SC,N)*FCQP(1.D0)/N
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = -eqi**2*FCQP(1.D0)*(A(SC,TC,UC,N)+A(SC,UC,TC,N)+B(SC,TC,UC,N)
     #)/N
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = -eqi**2*FCQP(1.D0)*(A(UC,TC,SC,N)+A(UC,SC,TC,N)+B(UC,TC,SC,N)
     #)/N
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = 0.D0
	VTEMP(21) = t0
	VPART15D(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = -eqk**2*A(SC,TC,UC,N)*FCQP(1.D0)/N
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = -eqk**2*A(UC,TC,SC,N)*FCQP(1.D0)/N
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = -eqi**2*FCQP(1.D0)*(A(SC,TC,UC,N)+A(SC,UC,TC,N)+B(SC,TC,UC,N)
     #)/N
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = -eqi**2*FCQP(1.D0)*(A(UC,TC,SC,N)+A(UC,SC,TC,N)+B(UC,TC,SC,N)
     #)/N
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = 0.D0
	VTEMP(26) = t0
	VPART15D(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = -eqi**2*FCQP(1.D0)*(A(TC,UC,SC,N)+A(TC,SC,UC,N)+B(TC,UC,SC,N)
     #)/N
	VTEMP(27) = t0
	VPART15D(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = -eqi**2*C(SC,TC,UC,N)*FCQP(1.D0)/N
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = 0.D0
	VTEMP(29) = t0
	VPART15D(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = 0.D0
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = eqi**2*C(UC,SC,TC,N)*FCQP(1.D0)/N
	VTEMP(31) = t0
	VPART15D(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = eqi**2*C(TC,SC,UC,N)*FCQP(1.D0)/N
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = eqi**2*C(TC,SC,UC,N)*FCQP(1.D0)/N
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART15D(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C*****************************************************
CC  TERMES QUI VIENNENT DE 5 COLLINEAIRE A 2
C*****************************************************
C PARTIE EN 1/(1-Z2)+
	SUBROUTINE VEC_25ZO(SC,TC,UC,Z2,M,PTM,CQI,CQK,VPART25Z)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART25Z(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART25Z(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = eqk**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(2) = t0
	VPART25Z(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = eqk**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(4) = t0
	VPART25Z(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = eqk**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(6) = t0
	VPART25Z(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = eqk**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(8) = t0
	VPART25Z(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = eqk**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(10) = t0
	VPART25Z(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = eqk**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(12) = t0
	VPART25Z(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = eqk**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(14) = t0
	VPART25Z(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = eqk**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(16) = t0
	VPART25Z(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = 0.D0
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = eqi**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = -eqi**2*E(TC,SC,UC,N)*(ANM4_QQ(z2)+A4_QQ(z2)*dlog(ptm**2/M**2
     #)-FAQQ(z2))
	VTEMP(21) = t0
	VPART25Z(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = 0.D0
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = eqi**2*E(SC,TC,UC,N)*(ANM4_GQ(z2)+A4_GQ(z2)*dlog(ptm**2/M**2)
     #-FAGQ(z2))/CF/2.D0
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = -eqi**2*E(TC,SC,UC,N)*(ANM4_QQ(z2)+A4_QQ(z2)*dlog(ptm**2/M**2
     #)-FAQQ(z2))
	VTEMP(26) = t0
	VPART25Z(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = -eqi**2*E(SC,TC,UC,N)*(-ANM4_GQ(z2)-A4_GQ(z2)*dlog(ptm**2/M**
     #2)+FAGQ(z2))/CF/2.D0
	VTEMP(27) = t0
	VPART25Z(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = 0.D0
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = eqi**2*E(UC,SC,TC,N)*(-ANM4_QQ(z2)-A4_QQ(z2)*dlog(ptm**2/M**2
     #)+FAQQ(z2))
	VTEMP(29) = t0
	VPART25Z(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = eqi**2*E(SC,TC,UC,N)*(ANM4_GG(z2)+A4_GG(z2)*dlog(ptm**2/M**2)
     #-FAGG(z2))
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = -eqi**2*E(TC,SC,UC,N)*(N-1.D0)*(N+1.D0)*(ANM4_QG(z2)+A4_QG(z2
     #)*dlog(ptm**2/M**2)-FAQG(z2))/N
	VTEMP(31) = t0
	VPART25Z(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = -eqi**2*E(UC,SC,TC,N)*(N-1.D0)*(N+1.D0)*(ANM4_QG(z2)+A4_QG(z2
     #)*dlog(ptm**2/M**2)-FAQG(z2))/N
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = -eqi**2*E(UC,SC,TC,N)*(N-1.D0)*(N+1.D0)*(ANM4_QG(z2)+A4_QG(z2
     #)*dlog(ptm**2/M**2)-FAQG(z2))/N
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART25Z(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C PARTIE EN LOG(1-Z2)/(1-Z2)+
	SUBROUTINE VEC_25LO(SC,TC,UC,Z2,CQI,CQK,VPART25L)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART25L(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART25L(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = -eqk**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(2) = t0
	VPART25L(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = -eqk**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(4) = t0
	VPART25L(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = -eqk**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(6) = t0
	VPART25L(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = -eqk**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(8) = t0
	VPART25L(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = -eqk**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(10) = t0
	VPART25L(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = -eqk**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(12) = t0
	VPART25L(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = -eqk**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(14) = t0
	VPART25L(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = -eqk**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(16) = t0
	VPART25L(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = 0.D0
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = -eqi**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = eqi**2*E(TC,SC,UC,N)*FBQQ(z2)
	VTEMP(21) = t0
	VPART25L(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = 0.D0
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = -eqi**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = eqi**2*E(TC,SC,UC,N)*FBQQ(z2)
	VTEMP(26) = t0
	VPART25L(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = -eqi**2*E(SC,TC,UC,N)*FBGQ(z2)/CF/2.D0
	VTEMP(27) = t0
	VPART25L(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = 0.D0
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = eqi**2*E(UC,SC,TC,N)*FBQQ(z2)
	VTEMP(29) = t0
	VPART25L(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = -eqi**2*E(SC,TC,UC,N)*FBGG(z2)
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = eqi**2*E(TC,SC,UC,N)*FBQG(z2)*(N-1.D0)*(N+1.D0)/N
	VTEMP(31) = t0
	VPART25L(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = eqi**2*E(UC,SC,TC,N)*FBQG(z2)*(N-1.D0)*(N+1.D0)/N
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = eqi**2*E(UC,SC,TC,N)*FBQG(z2)*(N-1.D0)*(N+1.D0)/N
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART25L(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C PARTIE EN DELTA(1-Z2)
	SUBROUTINE VEC_25DO(SC,TC,UC,M,PTM,CQI,CQK,VPART25D)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART25D(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART25D(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = -eqk**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(2) = t0
	VPART25D(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = -eqk**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(4) = t0
	VPART25D(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = -eqk**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(6) = t0
	VPART25D(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = -eqk**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(8) = t0
	VPART25D(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = -eqk**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(10) = t0
	VPART25D(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = -eqk**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(12) = t0
	VPART25D(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = -eqk**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(14) = t0
	VPART25D(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = -eqk**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(16) = t0
	VPART25D(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = 0.D0
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = -eqi**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = E(TC,SC,UC,N)*eqi**2*(-dlog(ptm**2/M**2)*B_QQ()+FCQQ(1.D0))
	VTEMP(21) = t0
	VPART25D(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = 0.D0
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = -eqi**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = E(TC,SC,UC,N)*eqi**2*(-dlog(ptm**2/M**2)*B_QQ()+FCQQ(1.D0))
	VTEMP(26) = t0
	VPART25D(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = -eqi**2*E(SC,TC,UC,N)*FCGQ(1.D0)/CF/2.D0
	VTEMP(27) = t0
	VPART25D(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = 0.D0
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = E(UC,SC,TC,N)*eqi**2*(-dlog(ptm**2/M**2)*B_QQ()+FCQQ(1.D0))
	VTEMP(29) = t0
	VPART25D(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = eqi**2*E(SC,TC,UC,N)*(B_GG()*dlog(ptm**2/M**2)-FCGG(1.D0))
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = eqi**2*E(TC,SC,UC,N)*FCQG(1.D0)*(N-1.D0)*(N+1.D0)/N
	VTEMP(31) = t0
	VPART25D(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = eqi**2*E(UC,SC,TC,N)*FCQG(1.D0)*(N-1.D0)*(N+1.D0)/N
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = eqi**2*E(UC,SC,TC,N)*FCQG(1.D0)*(N-1.D0)*(N+1.D0)/N
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART25D(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C*****************************************************
CC  TERMES QUI VIENNENT DE 5 COLLINEAIRE A 3
C*****************************************************
C PARTIE EN LOG(R**2)
	SUBROUTINE VEC_35RO(SC,TC,UC,ZM,R,CQI,CQK,VPART35R)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART35R(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART35R(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(2) = t0
	VPART35R(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(4) = t0
	VPART35R(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(6) = t0
	VPART35R(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(8) = t0
	VPART35R(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(10) = t0
	VPART35R(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(12) = t0
	VPART35R(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(14) = t0
	VPART35R(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(16) = t0
	VPART35R(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = -(zm**3/3.D0+zm/2.D0-zm**2/2.D0-1.D0/6.D0)*dlog(R**2)*eqi**2*
     #E(TC,SC,UC,N)
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = -(zm**3/3.D0+zm/2.D0-zm**2/2.D0-1.D0/6.D0)*dlog(R**2)*eqi**2*
     #E(TC,SC,UC,N)
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = -(zm**3/3.D0+zm/2.D0-zm**2/2.D0-1.D0/6.D0)*dlog(R**2)*eqi**2*
     #E(TC,SC,UC,N)
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = -(zm**3/3.D0+zm/2.D0-zm**2/2.D0-1.D0/6.D0)*dlog(R**2)*eqi**2*
     #E(TC,SC,UC,N)
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = -N*(-2.D0*dlog(1.D0-zm)+2.D0*dlog(zm)-4.D0*zm+zm**2-2.D0/3.D0
     #*zm**3+11.D0/6.D0)*dlog(R**2)*eqi**2*E(TC,SC,UC,N)
	VTEMP(21) = t0
	VPART35R(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = -(zm**3/3.D0+zm/2.D0-zm**2/2.D0-1.D0/6.D0)*dlog(R**2)*eqi**2*
     #E(TC,SC,UC,N)
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = -(zm**3/3.D0+zm/2.D0-zm**2/2.D0-1.D0/6.D0)*dlog(R**2)*eqi**2*
     #E(TC,SC,UC,N)
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = -(zm**3/3.D0+zm/2.D0-zm**2/2.D0-1.D0/6.D0)*dlog(R**2)*eqi**2*
     #E(TC,SC,UC,N)
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = -(zm**3/3.D0+zm/2.D0-zm**2/2.D0-1.D0/6.D0)*dlog(R**2)*eqi**2*
     #E(TC,SC,UC,N)
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = -N*(-2.D0*dlog(1.D0-zm)+2.D0*dlog(zm)-4.D0*zm+zm**2-2.D0/3.D0
     #*zm**3+11.D0/6.D0)*dlog(R**2)*eqi**2*E(TC,SC,UC,N)
	VTEMP(26) = t0
	VPART35R(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = 0.D0
	VTEMP(27) = t0
	VPART35R(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = -(N**2-1.D0)/N*(7.D0/8.D0+2.D0*dlog(2.D0)+2.D0*dlog(zm)-2.D0*
     #zm+zm**2/2.D0)*dlog(R**2)*eqi**2*E(UC,SC,TC,N)/2.D0
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = -(N**2-1.D0)/N*(5.D0/8.D0-2.D0*dlog(2.D0)-2.D0*dlog(1.D0-zm)-
     #zm-zm**2/2.D0)*dlog(R**2)*eqi**2*E(UC,SC,TC,N)/2.D0
	VTEMP(29) = t0
	VPART35R(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = (N**2-1.D0)/N*(5.D0/8.D0-2.D0*dlog(2.D0)-2.D0*dlog(1.D0-zm)-z
     #m-zm**2/2.D0)*dlog(R**2)*eqi**2*E(SC,TC,UC,N)/2.D0
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = (N**2-1.D0)/N*(7.D0/8.D0+2.D0*dlog(2.D0)+2.D0*dlog(zm)-2.D0*z
     #m+zm**2/2.D0)*dlog(R**2)*eqi**2*E(SC,TC,UC,N)/2.D0
	VTEMP(31) = t0
	VPART35R(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = 0.D0
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = 0.D0
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART35R(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C PARTIE EN DELTA(1-Z3)
	SUBROUTINE VEC_35DO(SC,TC,UC,CQI,CQK,VPART35D)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART35D(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART35D(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(2) = t0
	VPART35D(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(4) = t0
	VPART35D(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(6) = t0
	VPART35D(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = 0.D0
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(8) = t0
	VPART35D(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(10) = t0
	VPART35D(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(12) = t0
	VPART35D(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(14) = t0
	VPART35D(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = 0.D0
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(16) = t0
	VPART35D(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 23.D0/36.D0*eqi**2*E(TC,SC,UC,N)
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = 23.D0/36.D0*eqi**2*E(TC,SC,UC,N)
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = 23.D0/36.D0*eqi**2*E(TC,SC,UC,N)
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = 23.D0/36.D0*eqi**2*E(TC,SC,UC,N)
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = -N*(67.D0/9.D0-2.D0/3.D0*0.3141592653589793D1**2)*eqi**2*E(TC
     #,SC,UC,N)
	VTEMP(21) = t0
	VPART35D(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 23.D0/36.D0*eqi**2*E(TC,SC,UC,N)
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = 23.D0/36.D0*eqi**2*E(TC,SC,UC,N)
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = 23.D0/36.D0*eqi**2*E(TC,SC,UC,N)
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = 23.D0/36.D0*eqi**2*E(TC,SC,UC,N)
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = -N*(67.D0/9.D0-2.D0/3.D0*0.3141592653589793D1**2)*eqi**2*E(TC
     #,SC,UC,N)
	VTEMP(26) = t0
	VPART35D(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = 0.D0
	VTEMP(27) = t0
	VPART35D(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = -(N**2-1.D0)/N*(25.D0/8.D0-0.3141592653589793D1**2/3.D0-4.D0*
     #dlog(2.D0)**2.D0-dlog(2.D0)/2.D0)*eqi**2*E(UC,SC,TC,N)/2.D0
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = -(N**2-1.D0)/N*(27.D0/8.D0-0.3141592653589793D1**2/3.D0+4.D0*
     #dlog(2.D0)**2.D0+dlog(2.D0)/2.D0)*eqi**2*E(UC,SC,TC,N)/2.D0
	VTEMP(29) = t0
	VPART35D(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = (N**2-1.D0)/N*(27.D0/8.D0-0.3141592653589793D1**2/3.D0+4.D0*d
     #log(2.D0)**2.D0+dlog(2.D0)/2.D0)*eqi**2*E(SC,TC,UC,N)/2.D0
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = (N**2-1.D0)/N*(25.D0/8.D0-0.3141592653589793D1**2/3.D0-4.D0*d
     #log(2.D0)**2.D0-dlog(2.D0)/2.D0)*eqi**2*E(SC,TC,UC,N)/2.D0
	VTEMP(31) = t0
	VPART35D(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = 0.D0
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = 0.D0
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART35D(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C*****************************************************
CC  TERMES QUI VIENNENT DE 5 COLLINEAIRE A 4
C*****************************************************
C PARTIE EN LOG(R**2)
	SUBROUTINE VEC_45RO(SC,TC,UC,Z4,R,CQI,CQK,VPART45R)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART45R(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART45R(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(2) = t0
	VPART45R(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(4) = t0
	VPART45R(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(6) = t0
	VPART45R(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(8) = t0
	VPART45R(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(10) = t0
	VPART45R(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(12) = t0
	VPART45R(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(14) = t0
	VPART45R(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(16) = t0
	VPART45R(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = 0.D0
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = -A4_QQ(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(TC,SC,UC,N)
	VTEMP(21) = t0
	VPART45R(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = 0.D0
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = -A4_QQ(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(TC,SC,UC,N)
	VTEMP(26) = t0
	VPART45R(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = -A4_QG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(27) = t0
	VPART45R(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = -A4_GQ(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(TC,SC,UC,N)
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = -A4_GG(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(UC,SC,TC,N)
	VTEMP(29) = t0
	VPART45R(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = A4_QQ(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(SC,TC,UC,N)
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = 0.D0
	VTEMP(31) = t0
	VPART45R(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = A4_GQ(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(SC,TC,UC,N)
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = A4_GQ(z4)*dlog(R**2)/(1.D0-z4)*eqi**2*E(SC,TC,UC,N)
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART45R(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C PARTIE EN 1/(1-Z4)+
	SUBROUTINE VEC_45ZO(SC,TC,UC,Z4,MF,PT4,CQI,CQK,VPART45Z)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART45Z(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART45Z(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(2) = t0
	VPART45Z(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(4) = t0
	VPART45Z(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(6) = t0
	VPART45Z(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(8) = t0
	VPART45Z(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(10) = t0
	VPART45Z(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(12) = t0
	VPART45Z(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(14) = t0
	VPART45Z(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(16) = t0
	VPART45Z(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = eqi**2*E(UC,SC,TC,N)*(-ANM4_QG(z4)-A4_QG(z4)*dlog(pt4**2/Mf**
     #2)+DAQG(z4))
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = 0.D0
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = -E(TC,SC,UC,N)*eqi**2*(ANM4_QQ(z4)+A4_QQ(z4)*dlog(pt4**2/Mf**
     #2)-DAQQ(z4))
	VTEMP(21) = t0
	VPART45Z(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = eqi**2*E(UC,SC,TC,N)*(-ANM4_QG(z4)-A4_QG(z4)*dlog(pt4**2/Mf**
     #2)+DAQG(z4))
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = 0.D0
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = -E(TC,SC,UC,N)*eqi**2*(ANM4_QQ(z4)+A4_QQ(z4)*dlog(pt4**2/Mf**
     #2)-DAQQ(z4))
	VTEMP(26) = t0
	VPART45Z(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_QG(z4)+A4_QG(z4)*dlog(pt4**2/Mf**
     #2)-DAQG(z4))
	VTEMP(27) = t0
	VPART45Z(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = eqi**2*E(TC,SC,UC,N)*(-ANM4_GQ(z4)-A4_GQ(z4)*dlog(pt4**2/Mf**
     #2)+DAGQ(z4))
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = -eqi**2*E(UC,SC,TC,N)*(ANM4_GG(z4)+A4_GG(z4)*dlog(pt4**2/Mf**
     #2)-DAGG(z4))
	VTEMP(29) = t0
	VPART45Z(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = eqi**2*E(SC,TC,UC,N)*(ANM4_QQ(z4)+A4_QQ(z4)*dlog(pt4**2/Mf**2
     #)-DAQQ(z4))
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = 0.D0
	VTEMP(31) = t0
	VPART45Z(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = -eqi**2*E(SC,TC,UC,N)*(-ANM4_GQ(z4)-A4_GQ(z4)*dlog(pt4**2/Mf*
     #*2)+DAGQ(z4))
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = eqi**2*E(SC,TC,UC,N)*(ANM4_GQ(z4)+A4_GQ(z4)*dlog(pt4**2/Mf**2
     #)-DAGQ(z4))
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART45Z(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C PARTIE EN LOG(1-Z4)/(1-Z4)+
	SUBROUTINE VEC_45LO(SC,TC,UC,Z4,CQI,CQK,VPART45L)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART45L(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART45L(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(2) = t0
	VPART45L(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(4) = t0
	VPART45L(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(6) = t0
	VPART45L(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(8) = t0
	VPART45L(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(10) = t0
	VPART45L(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(12) = t0
	VPART45L(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(14) = t0
	VPART45L(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(16) = t0
	VPART45L(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = 0.D0
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = E(TC,SC,UC,N)*eqi**2*(DBQQ(z4)-2.D0*A4_QQ(z4))
	VTEMP(21) = t0
	VPART45L(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = -eqi**2*E(UC,SC,TC,N)*(-DBQG(z4)+2.D0*A4_QG(z4))
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = 0.D0
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = E(TC,SC,UC,N)*eqi**2*(DBQQ(z4)-2.D0*A4_QQ(z4))
	VTEMP(26) = t0
	VPART45L(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = eqi**2*E(UC,SC,TC,N)*(DBQG(z4)-2.D0*A4_QG(z4))
	VTEMP(27) = t0
	VPART45L(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = -eqi**2*E(TC,SC,UC,N)*(-DBGQ(z4)+2.D0*A4_GQ(z4))
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = eqi**2*E(UC,SC,TC,N)*(DBGG(z4)-2.D0*A4_GG(z4))
	VTEMP(29) = t0
	VPART45L(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = -eqi**2*E(SC,TC,UC,N)*(DBQQ(z4)-2.D0*A4_QQ(z4))
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = 0.D0
	VTEMP(31) = t0
	VPART45L(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = -eqi**2*E(SC,TC,UC,N)*(DBGQ(z4)-2.D0*A4_GQ(z4))
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = eqi**2*E(SC,TC,UC,N)*(-DBGQ(z4)+2.D0*A4_GQ(z4))
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART45L(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C PARTIE EN DELTA(1-Z4)
	SUBROUTINE VEC_45DO(SC,TC,UC,MF,PT4,CQI,CQK,VPART45D)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPART45D(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPART45D(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(1) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(2) = t0
	VPART45D(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(3) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(4) = t0
	VPART45D(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(5) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(6) = t0
	VPART45D(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(7) = t0
C       ph + qi --> qbk + qk
      t0 = 0.D0
	VTEMP(8) = t0
	VPART45D(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(9) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(10) = t0
	VPART45D(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(11) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(12) = t0
	VPART45D(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(13) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(14) = t0
	VPART45D(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(15) = t0
C       ph + qi --> qk + qbk
      t0 = 0.D0
	VTEMP(16) = t0
	VPART45D(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(17) = t0 + VTEMP(17)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(18) = t0 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(19) = t0
C       ph + qi --> qbi + qi
      t0 = 0.D0
	VTEMP(20) = t0
c      ph + qi --> g + qi 
      t0 = -E(TC,SC,UC,N)*eqi**2*(B_QQ()*dlog(pt4**2/Mf**2)-DCQQ(1.D0))
	VTEMP(21) = t0
	VPART45D(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      t0 = 0.D0
	VTEMP(22) = t0 + VTEMP(22)
C       ph + qi --> qbk + qi
      t0 = 0.D0
	VTEMP(23) = t0 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(24) = t0
C       ph + qi --> qbi + qi
      t0 = 0.D0
	VTEMP(25) = t0
c      ph + qi --> g + qi 
      t0 = -E(TC,SC,UC,N)*eqi**2*(B_QQ()*dlog(pt4**2/Mf**2)-DCQQ(1.D0))
	VTEMP(26) = t0
	VPART45D(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      t0 = eqi**2*E(UC,SC,TC,N)*DCQG(1.D0)
	VTEMP(27) = t0
	VPART45D(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      t0 = eqi**2*E(TC,SC,UC,N)*DCGQ(1.D0)
	VTEMP(28) = t0
c      ph + qi --> qi + g
      t0 = -eqi**2*E(UC,SC,TC,N)*(B_GG()*dlog(pt4**2/Mf**2)-DCGG(1.D0))
	VTEMP(29) = t0
	VPART45D(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      t0 = eqi**2*E(SC,TC,UC,N)*(B_QQ()*dlog(pt4**2/Mf**2)-DCQQ(1.D0))
	VTEMP(30) = t0
c      ph + g --> g + qi
      t0 = 0.D0
	VTEMP(31) = t0
	VPART45D(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      t0 = -eqi**2*E(SC,TC,UC,N)*DCGQ(1.D0)
	VTEMP(32) = t0 + VTEMP(32)
c      ph + g --> qbi + g
      t0 = -eqi**2*E(SC,TC,UC,N)*DCGQ(1.D0)
	VTEMP(33) = t0 + VTEMP(33)
	ENDDO
	VPART45D(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C*****************************************************
CC  TERMES QUI VIENNENT DE LA PARTIE VIRTUELLE
C*****************************************************
	SUBROUTINE VEC_VIO(S,SC,TC,UC,MU,PT,PTM,CQI,CQK,VPARTVI)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VPARTVI(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VPARTVI(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
	MU2 = MU**2
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(1) = TERAJ+TERES
C       ph + qi --> qbk + qk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(2) = TERAJ+TERES
	VPARTVI(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(3) = TERAJ+TERES
C       ph + qi --> qbk + qk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(4) = TERAJ+TERES
	VPARTVI(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(5) = TERAJ+TERES
C       ph + qi --> qbk + qk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(6) = TERAJ+TERES
	VPARTVI(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(7) = TERAJ+TERES
C       ph + qi --> qbk + qk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(8) = TERAJ+TERES
	VPARTVI(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(9) = TERAJ+TERES
C       ph + qi --> qk + qbk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(10) = TERAJ+TERES
	VPARTVI(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(11) = TERAJ+TERES
C       ph + qi --> qk + qbk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(12) = TERAJ+TERES
	VPARTVI(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(13) = TERAJ+TERES
C       ph + qi --> qk + qbk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(14) = TERAJ+TERES
	VPARTVI(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(15) = TERAJ+TERES
C       ph + qi --> qk + qbk
      teraj = 0.D0
      teres = 0.D0
	VTEMP(16) = TERAJ+TERES
	VPARTVI(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(17) = TERAJ+TERES + VTEMP(17)
C       ph + qi --> qbk + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(18) = TERAJ+TERES + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(19) = TERAJ+TERES
C       ph + qi --> qbi + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(20) = TERAJ+TERES
c      ph + qi --> g + qi 
      teraj = B_QQ()*dlog(ptm**2/S)*eqi**2*E(TC,SC,UC,N)+(B_GG()+B_QQ())
     #*dlog(pt**2/S)*eqi**2*E(TC,SC,UC,N)-((N**2-1.D0)/N*dlog(-TC/S)+N*(
     #dlog(SC/S)+dlog(-UC/S)-dlog(-TC/S)))*E(TC,SC,UC,N)*eqi**2*dlog(ptm
     #**2/S)-(A4_GG(1.D0)+A4_QQ(1.D0))*eqi**2*E(TC,SC,UC,N)*(dlog(pt**2/
     #S)**2.D0/4.D0-dlog(pt**2/S)*dlog(ptm**2/S)/2.D0)+A4_QQ(1.D0)*eqi**
     #2*E(TC,SC,UC,N)*dlog(ptm**2/S)**2.D0/4.D0
      s1 = 4.D0*(-11.D0/6.D0*N*dlog(MU2/S)+2.D0/3.D0*GTR*dlog(MU2/S))*(N
     #**2-1.D0)/UC/SC*(SC**2+UC**2)*eqi**2
      s3 = (-2.D0*N**2+2.D0)*eqi**2*(-1.D0/N*(TC**2*dlog(-TC/S)**2.D0+(S
     #C**2+TC**2)*(dlog(SC/S)**2.D0-0.3141592653589793D1**2)+(-2.D0*SC**
     #2-2.D0*TC**2)*dlog(-TC/S)*dlog(SC/S)-2.D0*SC*UC*dlog(-TC/S)+UC*(3.
     #D0*UC+2.D0*SC)*dlog(SC/S)+0.3141592653589793D1**2*TC**2+0.31415926
     #53589793D1**2*SC**2/2.D0+0.3141592653589793D1**2*UC**2/2.D0-7.D0/2
     #.D0*SC**2-7.D0/2.D0*UC**2)+N*(3.D0*UC**2*dlog(SC/S)+(0.31415926535
     #89793D1**2/2.D0-7.D0/2.D0-dlog(SC/S)*dlog(-UC/S))*(SC**2+UC**2)))/
     #UC/SC
      s4 = (-2.D0*N**2+2.D0)*eqi**2*(-1.D0/N*(TC**2*dlog(-TC/S)**2.D0+(U
     #C**2+TC**2)*dlog(-UC/S)**2.D0+(-2.D0*UC**2-2.D0*TC**2)*dlog(-TC/S)
     #*dlog(-UC/S)-2.D0*SC*UC*dlog(-TC/S)+SC*(3.D0*SC+2.D0*UC)*dlog(-UC/
     #S)+0.3141592653589793D1**2*TC**2+0.3141592653589793D1**2*SC**2/2.D
     #0+0.3141592653589793D1**2*UC**2/2.D0-7.D0/2.D0*UC**2-7.D0/2.D0*SC*
     #*2)+N*(3.D0*SC**2*dlog(-UC/S)+(0.3141592653589793D1**2/2.D0-7.D0/2
     #.D0-dlog(SC/S)*dlog(-UC/S))*(SC**2+UC**2)))/SC/UC
      s2 = s3+s4
      teres = s1+s2
	VTEMP(21) = TERAJ+TERES
	VPARTVI(9) = VTEMP(17) + VTEMP(18) +
     #        VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(22) = TERAJ+TERES + VTEMP(22)
C       ph + qi --> qbk + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(23) = TERAJ+TERES + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(24) = TERAJ+TERES
C       ph + qi --> qbi + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(25) = TERAJ+TERES
c      ph + qi --> g + qi 
      teraj = B_QQ()*dlog(ptm**2/S)*eqi**2*E(TC,SC,UC,N)+(B_GG()+B_QQ())
     #*dlog(pt**2/S)*eqi**2*E(TC,SC,UC,N)-((N**2-1.D0)/N*dlog(-TC/S)+N*(
     #dlog(SC/S)+dlog(-UC/S)-dlog(-TC/S)))*E(TC,SC,UC,N)*eqi**2*dlog(ptm
     #**2/S)-(A4_GG(1.D0)+A4_QQ(1.D0))*eqi**2*E(TC,SC,UC,N)*(dlog(pt**2/
     #S)**2.D0/4.D0-dlog(pt**2/S)*dlog(ptm**2/S)/2.D0)+A4_QQ(1.D0)*eqi**
     #2*E(TC,SC,UC,N)*dlog(ptm**2/S)**2.D0/4.D0
      s1 = 4.D0*(-11.D0/6.D0*N*dlog(MU2/S)+2.D0/3.D0*GTR*dlog(MU2/S))*(N
     #**2-1.D0)/UC/SC*(SC**2+UC**2)*eqi**2
      s3 = (-2.D0*N**2+2.D0)*eqi**2*(-1.D0/N*(TC**2*dlog(-TC/S)**2.D0+(S
     #C**2+TC**2)*(dlog(SC/S)**2.D0-0.3141592653589793D1**2)+(-2.D0*SC**
     #2-2.D0*TC**2)*dlog(-TC/S)*dlog(SC/S)-2.D0*SC*UC*dlog(-TC/S)+UC*(3.
     #D0*UC+2.D0*SC)*dlog(SC/S)+0.3141592653589793D1**2*TC**2+0.31415926
     #53589793D1**2*SC**2/2.D0+0.3141592653589793D1**2*UC**2/2.D0-7.D0/2
     #.D0*SC**2-7.D0/2.D0*UC**2)+N*(3.D0*UC**2*dlog(SC/S)+(0.31415926535
     #89793D1**2/2.D0-7.D0/2.D0-dlog(SC/S)*dlog(-UC/S))*(SC**2+UC**2)))/
     #UC/SC
      s4 = (-2.D0*N**2+2.D0)*eqi**2*(-1.D0/N*(TC**2*dlog(-TC/S)**2.D0+(U
     #C**2+TC**2)*dlog(-UC/S)**2.D0+(-2.D0*UC**2-2.D0*TC**2)*dlog(-TC/S)
     #*dlog(-UC/S)-2.D0*SC*UC*dlog(-TC/S)+SC*(3.D0*SC+2.D0*UC)*dlog(-UC/
     #S)+0.3141592653589793D1**2*TC**2+0.3141592653589793D1**2*SC**2/2.D
     #0+0.3141592653589793D1**2*UC**2/2.D0-7.D0/2.D0*UC**2-7.D0/2.D0*SC*
     #*2)+N*(3.D0*SC**2*dlog(-UC/S)+(0.3141592653589793D1**2/2.D0-7.D0/2
     #.D0-dlog(SC/S)*dlog(-UC/S))*(SC**2+UC**2)))/SC/UC
      s2 = s3+s4
      teres = s1+s2
	VTEMP(26) = TERAJ+TERES
	VPARTVI(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(27) = TERAJ+TERES
	VPARTVI(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      teraj = 0.D0
      teres = 0.D0
	VTEMP(28) = TERAJ+TERES
c      ph + qi --> qi + g
      teraj = B_QQ()*dlog(ptm**2/S)*eqi**2*E(UC,SC,TC,N)+(B_QQ()+B_GG())
     #*dlog(pt**2/S)*eqi**2*E(UC,SC,TC,N)-((N**2-1.D0)/N*dlog(-UC/S)+N*(
     #dlog(SC/S)+dlog(-TC/S)-dlog(-UC/S)))*E(UC,SC,TC,N)*eqi**2*dlog(ptm
     #**2/S)-(A4_QQ(1.D0)+A4_GG(1.D0))*eqi**2*E(UC,SC,TC,N)*(dlog(pt**2/
     #S)**2.D0/4.D0-dlog(pt**2/S)*dlog(ptm**2/S)/2.D0)+A4_QQ(1.D0)*eqi**
     #2*E(UC,SC,TC,N)*dlog(ptm**2/S)**2.D0/4.D0
      s1 = 4.D0*(-11.D0/6.D0*N*dlog(MU2/S)+2.D0/3.D0*GTR*dlog(MU2/S))*(N
     #**2-1.D0)/TC/SC*(SC**2+TC**2)*eqi**2
      s3 = (-2.D0*N**2+2.D0)*eqi**2*(-1.D0/N*(UC**2*dlog(-UC/S)**2.D0+(S
     #C**2+UC**2)*(dlog(SC/S)**2.D0-0.3141592653589793D1**2)+(-2.D0*SC**
     #2-2.D0*UC**2)*dlog(-UC/S)*dlog(SC/S)-2.D0*SC*TC*dlog(-UC/S)+TC*(3.
     #D0*TC+2.D0*SC)*dlog(SC/S)+0.3141592653589793D1**2*UC**2+0.31415926
     #53589793D1**2*SC**2/2.D0+0.3141592653589793D1**2*TC**2/2.D0-7.D0/2
     #.D0*SC**2-7.D0/2.D0*TC**2)+N*(3.D0*TC**2*dlog(SC/S)+(0.31415926535
     #89793D1**2/2.D0-7.D0/2.D0-dlog(SC/S)*dlog(-TC/S))*(SC**2+TC**2)))/
     #TC/SC
      s4 = (-2.D0*N**2+2.D0)*eqi**2*(-1.D0/N*(UC**2*dlog(-UC/S)**2.D0+(T
     #C**2+UC**2)*dlog(-TC/S)**2.D0+(-2.D0*TC**2-2.D0*UC**2)*dlog(-UC/S)
     #*dlog(-TC/S)-2.D0*SC*TC*dlog(-UC/S)+SC*(3.D0*SC+2.D0*TC)*dlog(-TC/
     #S)+0.3141592653589793D1**2*UC**2+0.3141592653589793D1**2*SC**2/2.D
     #0+0.3141592653589793D1**2*TC**2/2.D0-7.D0/2.D0*TC**2-7.D0/2.D0*SC*
     #*2)+N*(3.D0*SC**2*dlog(-TC/S)+(0.3141592653589793D1**2/2.D0-7.D0/2
     #.D0-dlog(SC/S)*dlog(-TC/S))*(SC**2+TC**2)))/SC/TC
      s2 = s3+s4
      teres = s1+s2
	VTEMP(29) = TERAJ+TERES
	VPARTVI(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      teraj = -B_GG()*dlog(ptm**2/S)*eqi**2*E(SC,TC,UC,N)-2.D0*B_QQ()*dl
     #og(pt**2/S)*eqi**2*E(SC,TC,UC,N)+((N**2-1.D0)/N*dlog(SC/S)+N*(dlog
     #(-TC/S)+dlog(-UC/S)-dlog(SC/S)))*E(SC,TC,UC,N)*eqi**2*dlog(ptm**2/
     #S)+2.D0*A4_QQ(1.D0)*eqi**2*E(SC,TC,UC,N)*(dlog(pt**2/S)**2.D0/4.D0
     #-dlog(pt**2/S)*dlog(ptm**2/S)/2.D0)-A4_GG(1.D0)*eqi**2*E(SC,TC,UC,
     #N)*dlog(ptm**2/S)**2.D0/4.D0
      s1 = 4.D0*(11.D0/6.D0*N*dlog(MU2/S)-2.D0/3.D0*GTR*dlog(MU2/S))*(N*
     #*2-1.D0)/UC/TC*(TC**2+UC**2)*eqi**2
      s3 = (2.D0*N**2-2.D0)*eqi**2*(-1.D0/N*(SC**2*(dlog(SC/S)**2.D0-0.3
     #141592653589793D1**2)+(TC**2+SC**2)*dlog(-TC/S)**2.D0+(-2.D0*TC**2
     #-2.D0*SC**2)*dlog(SC/S)*dlog(-TC/S)-2.D0*TC*UC*dlog(SC/S)+UC*(3.D0
     #*UC+2.D0*TC)*dlog(-TC/S)+0.3141592653589793D1**2*SC**2+0.314159265
     #3589793D1**2*TC**2/2.D0+0.3141592653589793D1**2*UC**2/2.D0-7.D0/2.
     #D0*TC**2-7.D0/2.D0*UC**2)+N*(3.D0*UC**2*dlog(-TC/S)+(0.31415926535
     #89793D1**2/2.D0-7.D0/2.D0-dlog(-TC/S)*dlog(-UC/S))*(TC**2+UC**2)))
     #/UC/TC
      s4 = (2.D0*N**2-2.D0)*eqi**2*(-1.D0/N*(SC**2*(dlog(SC/S)**2.D0-0.3
     #141592653589793D1**2)+(UC**2+SC**2)*dlog(-UC/S)**2.D0+(-2.D0*UC**2
     #-2.D0*SC**2)*dlog(SC/S)*dlog(-UC/S)-2.D0*TC*UC*dlog(SC/S)+TC*(3.D0
     #*TC+2.D0*UC)*dlog(-UC/S)+0.3141592653589793D1**2*SC**2+0.314159265
     #3589793D1**2*TC**2/2.D0+0.3141592653589793D1**2*UC**2/2.D0-7.D0/2.
     #D0*UC**2-7.D0/2.D0*TC**2)+N*(3.D0*TC**2*dlog(-UC/S)+(0.31415926535
     #89793D1**2/2.D0-7.D0/2.D0-dlog(-TC/S)*dlog(-UC/S))*(TC**2+UC**2)))
     #/TC/UC
      s2 = s3+s4
      teres = s1+s2
	VTEMP(30) = TERAJ+TERES
c      ph + g --> g + qi
      teraj = 0.D0
      teres = 0.D0
	VTEMP(31) = TERAJ+TERES
	VPARTVI(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      teraj = 0.D0
      teres = 0.D0
	VTEMP(32) = TERAJ+TERES + VTEMP(32)
c      ph + g --> qbi + g
      teraj = 0.D0
      teres = 0.D0
	VTEMP(33) = TERAJ+TERES + VTEMP(33)
	ENDDO
	VPARTVI(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
C*****************************************************
CC  TERME IR prop. H34(0)*A34(YS)
C*****************************************************
	SUBROUTINE VEC_VI2O(S,SC,TC,UC,YS,FI,CQI,CQK,VPARTVI2)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	PARAMETER (J0MAX=14)
	DIMENSION VPARTVI2(J0MAX),HH34(J0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX)
	PI=4.D0*DATAN(1.D0)
	DO I = 1,J0MAX
	  VPARTVI2(I) = 0.D0
	  HH34(I) = 0.D0
	ENDDO
C-------------------------------------------------------------------
	s12 = sc/2.d0
	s13 = -tc/2.d0
	s23 = -uc/2.d0
	s14 = s23
	s24 = s13
	s34 = s12
	s15 = 0.d0
	s25 = 0.d0
	s35 = 0.d0
	s45 = 0.d0
	CALL VEC_H34O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     # CQI,CQK,HH34)
	DW=DCOSH(2.D0*YS)+DCOS(2.D0*FI)
	XJ1=DLOG(DSIN(FI))
	XJ2=DSIN(2.D0*FI)*DLOG(DSIN(FI))*DATAN(DSIN(FI)/(1.D0-DCOS(FI)))
	A34=4.D0*XJ2+DSINH(2.D0*YS)*2.D0*YS*XJ1
	FFG=A34/DW+DLOG(2.D0)*DLOG(4.D0*DCOSH(YS)**2)
	DO I = 1,J0MAX
	  VPARTVI2(I) = HH34(I)*(FFG+FFG)/PI
	ENDDO
	RETURN
	END
C*****************************************************
