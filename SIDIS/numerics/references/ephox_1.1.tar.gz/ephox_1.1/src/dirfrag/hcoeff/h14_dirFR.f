C coefficients devant p_1.p_4/(p_1.p_5 p_4.p_5)
C ----------------------------------------------------
	SUBROUTINE VEC_H14O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     #	CQI,CQK,VH14)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VH14(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VH14(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      hh14 = 2.D0*Vc*(s25**2+s35**2+s24**2+s34**2)*(-eqi*eqk*s25*s13*s14
     #+eqi*eqk*s35*s12*s14+eqi*eqk*s24*s15*s13-eqi*eqk*s34*s15*s12+eqk**
     #2*s45*s12*s13+eqi**2*s23*s15*s14)/s14**2/s23/s12/s13
	VTEMP(1) = HH14
C       ph + qi --> qbk + qk
      hh14 = 0.D0
	VTEMP(2) = HH14
	VH14(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      hh14 = 2.D0*Vc*(s25**2+s35**2+s24**2+s34**2)*(-eqi*eqk*s25*s13*s14
     #+eqi*eqk*s35*s12*s14+eqi*eqk*s24*s15*s13-eqi*eqk*s34*s15*s12+eqk**
     #2*s45*s12*s13+eqi**2*s23*s15*s14)/s14**2/s23/s12/s13
	VTEMP(3) = HH14
C       ph + qi --> qbk + qk
      hh14 = 0.D0
	VTEMP(4) = HH14
	VH14(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      hh14 = 2.D0*Vc*(s25**2+s35**2+s24**2+s34**2)*(-eqi*eqk*s25*s13*s14
     #+eqi*eqk*s35*s12*s14+eqi*eqk*s24*s15*s13-eqi*eqk*s34*s15*s12+eqk**
     #2*s45*s12*s13+eqi**2*s23*s15*s14)/s14**2/s23/s12/s13
	VTEMP(5) = HH14
C       ph + qi --> qbk + qk
      hh14 = 0.D0
	VTEMP(6) = HH14
	VH14(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      hh14 = 2.D0*Vc*(s25**2+s35**2+s24**2+s34**2)*(-eqi*eqk*s25*s13*s14
     #+eqi*eqk*s35*s12*s14+eqi*eqk*s24*s15*s13-eqi*eqk*s34*s15*s12+eqk**
     #2*s45*s12*s13+eqi**2*s23*s15*s14)/s14**2/s23/s12/s13
	VTEMP(7) = HH14
C       ph + qi --> qbk + qk
      hh14 = 0.D0
	VTEMP(8) = HH14
	VH14(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      hh14 = 2.D0*Vc*(s24**2+s34**2+s25**2+s35**2)*(-eqi*eqk*s24*s13*s15
     #+eqi*eqk*s34*s12*s15+eqi*eqk*s25*s14*s13-eqi*eqk*s35*s14*s12+eqk**
     #2*s45*s12*s13+eqi**2*s23*s14*s15)/s14**2/s23/s12/s13
	VTEMP(9) = HH14
C       ph + qi --> qk + qbk
      hh14 = 0.D0
	VTEMP(10) = HH14
	VH14(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      hh14 = 2.D0*Vc*(s24**2+s34**2+s25**2+s35**2)*(-eqi*eqk*s24*s13*s15
     #+eqi*eqk*s34*s12*s15+eqi*eqk*s25*s14*s13-eqi*eqk*s35*s14*s12+eqk**
     #2*s45*s12*s13+eqi**2*s23*s14*s15)/s14**2/s23/s12/s13
	VTEMP(11) = HH14
C       ph + qi --> qk + qbk
      hh14 = 0.D0
	VTEMP(12) = HH14
	VH14(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      hh14 = 2.D0*Vc*(s24**2+s34**2+s25**2+s35**2)*(-eqi*eqk*s24*s13*s15
     #+eqi*eqk*s34*s12*s15+eqi*eqk*s25*s14*s13-eqi*eqk*s35*s14*s12+eqk**
     #2*s45*s12*s13+eqi**2*s23*s14*s15)/s14**2/s23/s12/s13
	VTEMP(13) = HH14
C       ph + qi --> qk + qbk
      hh14 = 0.D0
	VTEMP(14) = HH14
	VH14(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      hh14 = 2.D0*Vc*(s24**2+s34**2+s25**2+s35**2)*(-eqi*eqk*s24*s13*s15
     #+eqi*eqk*s34*s12*s15+eqi*eqk*s25*s14*s13-eqi*eqk*s35*s14*s12+eqk**
     #2*s45*s12*s13+eqi**2*s23*s14*s15)/s14**2/s23/s12/s13
	VTEMP(15) = HH14
C       ph + qi --> qk + qbk
      hh14 = 0.D0
	VTEMP(16) = HH14
	VH14(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      hh14 = 0.D0
	VTEMP(17) = HH14 + VTEMP(17)
C       ph + qi --> qbk + qi
      hh14 = 0.D0
	VTEMP(18) = HH14 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      hh14 = 2.D0*Vc*eqi**2*(N*s23*s45*s25**2+N*s23**3*s45+N*s23*s45**3+
     #N*s23*s45*s34**2+N*s24*s35*s25**2+N*s24**3*s35+N*s24*s35*s34**2+N*
     #s24*s35**3-s25**3*s34+s25**2*s23*s45+s25**2*s24*s35-s34**3*s25+s34
     #**2*s23*s45+s34**2*s24*s35)*(s12-s13)/N/s23/s24/s12/s13/s14
	VTEMP(19) = HH14
C       ph + qi --> qbi + qi
      hh14 = 0.D0
	VTEMP(20) = HH14
c      ph + qi --> g + qi 
      hh14 = 0.D0
	VTEMP(21) = HH14
	VH14(9) = VTEMP(17) + VTEMP(18) +
     #	VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      hh14 = 0.D0
	VTEMP(22) = HH14 + VTEMP(22)
C       ph + qi --> qbk + qi
      hh14 = 0.D0
	VTEMP(23) = HH14 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      hh14 = 2.D0*Vc*eqi**2*(N*s23*s45*s25**2+N*s23**3*s45+N*s23*s45**3+
     #N*s23*s45*s34**2+N*s24*s35*s25**2+N*s24**3*s35+N*s24*s35*s34**2+N*
     #s24*s35**3-s25**3*s34+s25**2*s23*s45+s25**2*s24*s35-s34**3*s25+s34
     #**2*s23*s45+s34**2*s24*s35)*(s12-s13)/N/s23/s24/s12/s13/s14
	VTEMP(24) = HH14
C       ph + qi --> qbi + qi
      hh14 = 0.D0
	VTEMP(25) = HH14
c      ph + qi --> g + qi 
      hh14 = 0.D0
	VTEMP(26) = HH14
	VH14(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      hh14 = -2.D0*Vc*eqi**2*(N*s25*s34*s24**2+N*s25**3*s34+N*s25*s34**3
     #+N*s25*s34*s35**2+N*s23*s45*s24**2+N*s23**3*s45+N*s23*s45*s35**2+N
     #*s23*s45**3-s24**3*s35+s24**2*s25*s34+s24**2*s23*s45-s35**3*s24+s3
     #5**2*s25*s34+s35**2*s23*s45)*(-s13+s12)/N/s23/s34/s12/s14/s13
	VTEMP(27) = HH14
	VH14(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      hh14 = 2.D0*Vc*eqi**2*(s12**3*s15+s12*s15**3+s23**3*s35+s23*s35**3
     #+s24**3*s45+s24*s45**3)*(N*s24+2.D0*s34*CF-s34*N)/s14/s34/s23/s12/
     #s24
	VTEMP(28) = HH14
c      ph + qi --> qi + g
      hh14 = 0.D0
	VTEMP(29) = HH14
	VH14(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      hh14 = 0.D0
	VTEMP(30) = HH14
c      ph + g --> g + qi
      hh14 = 0.D0
	VTEMP(31) = HH14
	VH14(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      hh14 = 2.D0*Vc*eqi**2*(s15**3*s13+s15*s13**3+s25**3*s23+s25*s23**3
     #+s45**3*s34+s45*s34**3)*(N*s34+2.D0*s24*CF-s24*N)/s14/s24/s23/s13/
     #s34
	VTEMP(32) = HH14 + VTEMP(32)
c      ph + g --> qbi + g
      hh14 = 2.D0*Vc*eqi**2*(s13**3*s15+s13*s15**3+s23**3*s25+s23*s25**3
     #+s34**3*s45+s34*s45**3)*(N*s34+2.D0*s24*CF-s24*N)/s14/s24/s23/s13/
     #s34
	VTEMP(33) = HH14 + VTEMP(33)
	ENDDO
	VH14(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
