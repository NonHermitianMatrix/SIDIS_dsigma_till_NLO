C constant part G(P5) 
C ----------------------------------------------------
	SUBROUTINE VEC_CONSO(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     #	CQI,CQK,VCONS)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VCONS(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VCONS(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      hcons = 0.D0
	VTEMP(1) = HCONS
C       ph + qi --> qbk + qk
      hcons = 0.D0
	VTEMP(2) = HCONS
	VCONS(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      hcons = 0.D0
	VTEMP(3) = HCONS
C       ph + qi --> qbk + qk
      hcons = 0.D0
	VTEMP(4) = HCONS
	VCONS(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      hcons = 0.D0
	VTEMP(5) = HCONS
C       ph + qi --> qbk + qk
      hcons = 0.D0
	VTEMP(6) = HCONS
	VCONS(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      hcons = 0.D0
	VTEMP(7) = HCONS
C       ph + qi --> qbk + qk
      hcons = 0.D0
	VTEMP(8) = HCONS
	VCONS(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      hcons = 0.D0
	VTEMP(9) = HCONS
C       ph + qi --> qk + qbk
      hcons = 0.D0
	VTEMP(10) = HCONS
	VCONS(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      hcons = 0.D0
	VTEMP(11) = HCONS
C       ph + qi --> qk + qbk
      hcons = 0.D0
	VTEMP(12) = HCONS
	VCONS(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      hcons = 0.D0
	VTEMP(13) = HCONS
C       ph + qi --> qk + qbk
      hcons = 0.D0
	VTEMP(14) = HCONS
	VCONS(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      hcons = 0.D0
	VTEMP(15) = HCONS
C       ph + qi --> qk + qbk
      hcons = 0.D0
	VTEMP(16) = HCONS
	VCONS(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      hcons = 0.D0
	VTEMP(17) = HCONS + VTEMP(17)
C       ph + qi --> qbk + qi
      hcons = 0.D0
	VTEMP(18) = HCONS + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      hcons = 0.D0
	VTEMP(19) = HCONS
C       ph + qi --> qbi + qi
      hcons = 0.D0
	VTEMP(20) = HCONS
c      ph + qi --> g + qi 
      hcons = 0.D0
	VTEMP(21) = HCONS
	VCONS(9) = VTEMP(17) + VTEMP(18) +
     #	VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      hcons = 0.D0
	VTEMP(22) = HCONS + VTEMP(22)
C       ph + qi --> qbk + qi
      hcons = 0.D0
	VTEMP(23) = HCONS + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      hcons = 0.D0
	VTEMP(24) = HCONS
C       ph + qi --> qbi + qi
      hcons = 0.D0
	VTEMP(25) = HCONS
c      ph + qi --> g + qi 
      hcons = 0.D0
	VTEMP(26) = HCONS
	VCONS(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      hcons = 0.D0
	VTEMP(27) = HCONS
	VCONS(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      hcons = 0.D0
	VTEMP(28) = HCONS
c      ph + qi --> qi + g
      hcons = 0.D0
	VTEMP(29) = HCONS
	VCONS(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      hcons = 0.D0
	VTEMP(30) = HCONS
c      ph + g --> g + qi
      hcons = 0.D0
	VTEMP(31) = HCONS
	VCONS(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      hcons = 0.D0
	VTEMP(32) = HCONS + VTEMP(32)
c      ph + g --> qbi + g
      hcons = 0.D0
	VTEMP(33) = HCONS + VTEMP(33)
	ENDDO
	VCONS(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
