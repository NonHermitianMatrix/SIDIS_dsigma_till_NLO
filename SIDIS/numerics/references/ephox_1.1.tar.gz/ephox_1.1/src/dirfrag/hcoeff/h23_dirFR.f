C coefficients devant p_2.p_3/(p_2.p_5 p_3.p_5)
C ----------------------------------------------------
	SUBROUTINE VEC_H23O(S12,S13,S14,S15,S23,S24,S25,S34,S35,S45,
     #	CQI,CQK,VH23)
	IMPLICIT REAL*8 (A-H,L-Z)
	COMMON/COUL/N,CF,GTR
	COMMON/GDF/JNF
	PARAMETER (J0MAX=14,I0MAX=33)
	DIMENSION VH23(J0MAX),VTEMP(I0MAX)
	DIMENSION CQI(J0MAX),CQK(J0MAX),QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
	DO I = 1,J0MAX
	  VH23(I) = 0.D0
	ENDDO
	DO I = 1,I0MAX
	  VTEMP(I) = 0.D0
	ENDDO
	VC = (N**2-1.D0)
C
C	ph + qi --> jet + qk
C
C	j0 = 1 : ph + D --> jet + U
	EQI = CQI(1)
	EQK = CQK(1)
C       ph + qi --> qi + qk
      hh23 = 0.D0
	VTEMP(1) = HH23
C       ph + qi --> qbk + qk
      hh23 = 0.D0
	VTEMP(2) = HH23
	VH23(1) = VTEMP(1) + VTEMP(2)
C      j0 = 2 : ph + U --> jet + D
	EQI = CQI(2)
	EQK = CQK(2)
C       ph + qi --> qi + qk
      hh23 = 0.D0
	VTEMP(3) = HH23
C       ph + qi --> qbk + qk
      hh23 = 0.D0
	VTEMP(4) = HH23
	VH23(2) = VTEMP(3) + VTEMP(4)
C	j0 = 3 : ph + D --> jet + Dp
	EQI = CQI(3)
	EQK = CQK(3)
C       ph + qi --> qi + qk
      hh23 = 0.D0
	VTEMP(5) = HH23
C       ph + qi --> qbk + qk
      hh23 = 0.D0
	VTEMP(6) = HH23
	VH23(3) = VTEMP(5) + VTEMP(6)
C	j0 = 4 : ph + U --> jet + Up
	EQI = CQI(4)
	EQK = CQK(4)
C       ph + qi --> qi + qk
      hh23 = 0.D0
	VTEMP(7) = HH23
C       ph + qi --> qbk + qk
      hh23 = 0.D0
	VTEMP(8) = HH23
	VH23(4) = VTEMP(7) + VTEMP(8)
C
C	ph + qi --> jet + qbk
C
C	j0 = 5 : ph + D --> jet + Ub
	EQI = CQI(5)
	EQK = CQK(5)
C       ph + qi --> qi + qbk
      hh23 = 0.D0
	VTEMP(9) = HH23
C       ph + qi --> qk + qbk
      hh23 = 0.D0
	VTEMP(10) = HH23
	VH23(5) = VTEMP(9) + VTEMP(10)
C	j0 = 6 : ph + U --> jet + Db
	EQI = CQI(6)
	EQK = CQK(6)
C       ph + qi --> qi + qbk
      hh23 = 0.D0
	VTEMP(11) = HH23
C       ph + qi --> qk + qbk
      hh23 = 0.D0
	VTEMP(12) = HH23
	VH23(6) = VTEMP(11) + VTEMP(12)
C	j0 = 7 : ph + D --> jet + Dpb
	EQI = CQI(7)
	EQK = CQK(7)
C       ph + qi --> qi + qbk
      hh23 = 0.D0
	VTEMP(13) = HH23
C       ph + qi --> qk + qbk
      hh23 = 0.D0
	VTEMP(14) = HH23
	VH23(7) = VTEMP(13) + VTEMP(14)
C	j0 = 8 : ph + U --> jet + Upb
	EQI = CQI(8)
	EQK = CQK(8)
C       ph + qi --> qi + qbk
      hh23 = 0.D0
	VTEMP(15) = HH23
C       ph + qi --> qk + qbk
      hh23 = 0.D0
	VTEMP(16) = HH23
	VH23(8) = VTEMP(15) + VTEMP(16)
C
C	j0 = 9 : ph + D --> jet + D
C
	EQI = QCH(1)
	DO I=2,JNF
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      hh23 = 0.D0
	VTEMP(17) = HH23 + VTEMP(17)
C       ph + qi --> qbk + qi
      hh23 = 0.D0
	VTEMP(18) = HH23 + VTEMP(18)
	ENDDO
C       ph + qi --> qi + qi
      hh23 = 0.D0
	VTEMP(19) = HH23
C       ph + qi --> qbi + qi
      hh23 = -2.D0*Vc*eqi**2*(N*s25*s34*s23**2+N*s25**3*s34+N*s25*s34**3
     #+N*s25*s34*s45**2+N*s24*s35*s23**2+N*s24**3*s35+N*s24*s35*s45**2+N
     #*s24*s35**3-s23**3*s45+s23**2*s25*s34+s23**2*s24*s35-s45**3*s23+s4
     #5**2*s25*s34+s45**2*s24*s35)*(s23*s14-s12*s34-s24*s13+s12*s13)/s23
     #/N/s24/s34/s12/s13/s14
	VTEMP(20) = HH23
c      ph + qi --> g + qi 
      hh23 = 2.D0/s23*Vc*eqi**2*N/s12/s14/s34*(s12**3*s14+s12*s14**3+s23
     #**3*s34+s23*s34**3+s25**3*s45+s25*s45**3)
	VTEMP(21) = HH23
	VH23(9) = VTEMP(17) + VTEMP(18) +
     #	VTEMP(19) + VTEMP(20) + VTEMP(21)
C
C	j0 = 10 : ph + U --> jet + U
C
	EQI = QCH(2)
	DO I=1,JNF
	  IF (I.NE.2) THEN
	  EQK = QCH(I)
C       ph + qi --> qk + qi
      hh23 = 0.D0
	VTEMP(22) = HH23 + VTEMP(22)
C       ph + qi --> qbk + qi
      hh23 = 0.D0
	VTEMP(23) = HH23 + VTEMP(23)
	  ENDIF
	ENDDO
C       ph + qi --> qi + qi
      hh23 = 0.D0
	VTEMP(24) = HH23
C       ph + qi --> qbi + qi
      hh23 = -2.D0*Vc*eqi**2*(N*s25*s34*s23**2+N*s25**3*s34+N*s25*s34**3
     #+N*s25*s34*s45**2+N*s24*s35*s23**2+N*s24**3*s35+N*s24*s35*s45**2+N
     #*s24*s35**3-s23**3*s45+s23**2*s25*s34+s23**2*s24*s35-s45**3*s23+s4
     #5**2*s25*s34+s45**2*s24*s35)*(s23*s14-s12*s34-s24*s13+s12*s13)/s23
     #/N/s24/s34/s12/s13/s14
	VTEMP(25) = HH23
c      ph + qi --> g + qi 
      hh23 = 2.D0/s23*Vc*eqi**2*N/s12/s14/s34*(s12**3*s14+s12*s14**3+s23
     #**3*s34+s23*s34**3+s25**3*s45+s25*s45**3)
	VTEMP(26) = HH23
	VH23(10) = VTEMP(22) + VTEMP(23) +
     #	VTEMP(24) + VTEMP(25) + VTEMP(26)
C
C	j0 = 11 : ph + qi --> jet + qbi
C
	EQI = CQI(11)
C       ph + qi --> qi + qbi
      hh23 = 0.D0
	VTEMP(27) = HH23
	VH23(11) = VTEMP(27)
C
C	j0 = 12 : ph + qi --> jet + g
C
	EQI = CQI(12)
c      ph + qi --> g + g
      hh23 = 0.D0
	VTEMP(28) = HH23
c      ph + qi --> qi + g
      hh23 = 2.D0*Vc*eqi**2*(2.D0*CF-N)*(s12**3*s13+s12*s13**3+s24**3*s3
     #4+s24*s34**3+s25**3*s35+s25*s35**3)/s12/s24/s13/s34
	VTEMP(29) = HH23
	VH23(12) = VTEMP(28) + VTEMP(29)
C
C	j0 = 13 : ph + g --> jet + qi
C
	EQI = CQI(13)
c      ph + g --> qbi + qi
      hh23 = 2.D0/s23*Vc*eqi**2*N/s13/s14/s24*(s13**3*s14+s13*s14**3+s23
     #**3*s24+s23*s24**3+s35**3*s45+s35*s45**3)
	VTEMP(30) = HH23
c      ph + g --> g + qi
      hh23 = 2.D0*Vc*eqi**2*(2.D0*CF-N)*(s15**3*s14+s15*s14**3+s25**3*s2
     #4+s25*s24**3+s35**3*s34+s35*s34**3)/s23/s24/s34/s14
	VTEMP(31) = HH23
	VH23(13) = VTEMP(30) + VTEMP(31)
C
C	j0 = 14 : ph + g --> jet + g
C
	DO I=1,JNF
	  EQI = QCH(I)
c      ph + g --> qi + g
      hh23 = 0.D0
	VTEMP(32) = HH23 + VTEMP(32)
c      ph + g --> qbi + g
      hh23 = 0.D0
	VTEMP(33) = HH23 + VTEMP(33)
	ENDDO
	VH23(14) = VTEMP(32) + VTEMP(33)
	RETURN
	END
