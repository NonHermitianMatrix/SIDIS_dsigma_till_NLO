C************************************************************
CC  elements de matrice 2 -> 2 
CC (BORN terms, not averaged over initial spins and colours)
C************************************************************
	SUBROUTINE VEC_BO(SC,TC,UC,N,VBORN)
	IMPLICIT REAL*8 (A-H,L-Z)
	PARAMETER (J0MAX=14)
	PARAMETER (EQD=0.3333333333333333)
	DIMENSION VBORN(J0MAX)
	DIMENSION QCH(6)
	DATA QCH/-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0,
     #	-0.333333333333D0,0.666666666667D0/
c     
	DO I = 1,J0MAX
	  VBORN(I) = 0.D0
	ENDDO
C
C	j0 = 1 : ph + D --> jet + U
	VBORN(1) = 0.D0
C	j0 = 2 : ph + U --> jet + D
	VBORN(2) = 0.D0
C	j0 = 3 : ph + D --> jet + Dp
	VBORN(3) = 0.D0
C	j0 = 4 : ph + U --> jet + Up
	VBORN(4) = 0.D0
C	j0 = 5 : ph + D --> jet + Ub
	VBORN(5) = 0.D0
C	j0 = 6 : ph + U --> jet + Db
	VBORN(6) = 0.D0
C	j0 = 7 : ph + D --> jet + Dpb
	VBORN(7) = 0.D0
C	j0 = 8 : ph + U --> jet + Upb
	VBORN(8) = 0.D0
C	j0 = 9 : ph + D --> jet + D
	EQI = QCH(1)
	VBORN(9) = -eqi**2*E(TC,SC,UC,N)
C	j0 = 10: ph + U --> jet + U
	EQI = QCH(2)
	VBORN(10) = -eqi**2*E(TC,SC,UC,N)
C	j0 = 11: ph + qi--> jet + qbi
	VBORN(11) = 0.D0
C	j0 = 12: ph + qi--> jet + g
	EQI = EQD
	VBORN(12) = -eqi**2*E(UC,SC,TC,N)
C	j0 = 13: ph + g --> jet + qi
	EQI = EQD
	VBORN(13) =  eqi**2*E(SC,TC,UC,N)
C	j0 = 14: ph + g --> jet + g
	VBORN(14) = 0.D0
	RETURN
	END
