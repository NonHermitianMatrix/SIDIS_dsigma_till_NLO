	subroutine isolement(y4,y5,fi45,x4,pt5,gpt4,r_isol,epsilon_h,
     #	isol)
	implicit real*8 (a-h,l-z)
	logical isol
	common/frixione/isofrixione
	common/etfix/isofix
	common/emax/etmax
c	
	r45s = (y4-y5)**2 + fi45**2
	r45 = dsqrt(r45s)
	rcos=(1.d0-cos(r45))/(1.d0-cos(r_isol))
	if (r45.le.r_isol) then
	  et_dep = pt5 + (1.d0-x4)/x4*gpt4
	else
	  et_dep = (1.d0-x4)/x4*gpt4
	endif
	if (isofix.eq.1) then
	  et_max = etmax
	else 
	  if  (isofrixione.eq.1) then
	        et_max = epsilon_h*gpt4*rcos 
	  else  
	        et_max = epsilon_h*gpt4 
	  endif
	endif  
	if (et_dep.le.et_max) then
	  isol = .true.
	else
	  isol = .false.
	endif
	end
