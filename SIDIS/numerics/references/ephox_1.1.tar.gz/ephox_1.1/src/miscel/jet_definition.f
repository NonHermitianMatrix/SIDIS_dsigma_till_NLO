c jet_selection returns if inb_jet (if 1 or 2 jets), 
c components of jet vector and if cuts are passed
c changed 26.11.02 avoid logarithm in ptjet_lead with Snowmass for faster convergence
c jet_cuts renvoie vrai ou faux suivant que le(s) jet(s) sont dans
c les coupures cinematiques de l'experience:
c 1 est le parton de plus grand pt
c
	subroutine jet_selection(y1,y2,fi12,fi1,fi2,pt1,pt2,
     #	algorithm,r_kt,r_c,r_sep,merging,merged,
     #  ptjet_min,ptjet_max,yjet_min,yjet_max,acceptance,inb_jet,
     #	xej,xpjx,xpjy,xpjz,cut_jet)
	implicit real*8 (a-h,l-v,x-z)
	implicit real*4 (w)
	logical merged,cut_jet
	character*2 algorithm,merging,acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
c	common/doublecount/xweightjet
c	
	r12s = (y1-y2)**2 + fi12**2
	r12 = dsqrt(r12s)
c
	call jet_algorithm(r12,pt1,pt2,algorithm,r_kt,r_c,r_sep,merged)
c
	call jet_merging(pt1,y1,fi1,pt2,y2,fi2,merging,merged,
     #	inb_jet,xej,xpjx,xpjy,xpjz)
c
	call jet_cuts(xej,xpjx,xpjy,xpjz,ptjet_min,ptjet_max,
     #	yjet_min,yjet_max,acceptance,merged,cut_jet)
c
c       write(*,*) 'xj =',xej(1),xpjx(1),xpjy(1),xpjz(1) 
	return
	end
c **************************************************************************
	subroutine jet_cuts(xej,xpjx,xpjy,xpjz,ptjet_min,ptjet_max,
     #	yjet_min,yjet_max,acceptance,merged,cut_jet)
	implicit real*8 (a-h,l-z)
	logical cut_pt1,cut_y1,cut_pt2,cut_y2
	logical cut_jet,merged
	character*2 acceptance
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
	common/jetkin/ptj_lead,yj_lead 
	common/jet2/ptjet2,yjet2 
c	common/doublecount/xweightjet
	common/testc/jcount
        dimension temp(4)
c
        xweightjet=1.d0
	cut_pt1=(ptj_lead.le.ptjet_max).and.(ptj_lead.ge.ptjet_min)
	cut_y1 =(yj_lead.le.yjet_max).and.(yj_lead.ge.yjet_min)
c si le jet de plus grand pt (pt1) est dans l'acceptance
cdebug        write(*,*) 'yj_lead jet_def = ', yj_lead
	if (acceptance(1:2).eq.'gp') then
	  if (cut_pt1.and.cut_y1) then
	    cut_jet = .true.
	  else
	    cut_jet = .false.
	  endif
c si un des jets (pt1 ou pt2) est dans l'acceptance
	else if (acceptance(1:2).eq.'up') then
c bug corrected 28.5.04	
	IF (merged) THEN
	  if (cut_pt1.and.cut_y1) then
	    cut_jet = .true.
	  else
	    cut_jet = .false.
	  endif
	ELSE
	  cut_pt2 = (ptjet2.le.ptjet_max).and.(ptjet2.ge.ptjet_min)
	  cut_y2 = (yjet2.le.yjet_max).and.(yjet2.ge.yjet_min)
	  if ((cut_pt1.and.cut_y1).or.(cut_pt2.and.cut_y2)) then
	    cut_jet = .true.
	  else
	    cut_jet = .false.
	  endif
C234567******IOS*********************
      if(cut_pt1.and.cut_y1)then
c     leading jet in acc
      return
      endif
      if(cut_pt2.and.cut_y2)then
c     second jet in acc
      ptj_lead = ptjet2
      yj_lead = yjet2
c     need to put reverse order  xpjx(1) etc also
      temp(1) = xej(1)
      temp(2) = xpjx(1)
      temp(3) = xpjy(1)
      temp(4) = xpjz(1)
      xej(1) = xej(2)
      xpjx(1) = xpjx(2)
      xpjy(1) = xpjy(2)
      xpjz(1) = xpjz(2)
      xej(2) = temp(1)
      xpjx(2) = temp(2)
      xpjy(2) = temp(3)
      xpjz(2) = temp(4)
      endif
C234567*********IOS******************
	ENDIF ! merged
	endif ! accepance.eq.
	return
	end
c **********************************************************************
	subroutine jet_merging(pt1,y1,fi1,pt2,y2,fi2,merging,merged,
     #	inb_jet,xej,xpjx,xpjy,xpjz)
	implicit real*8 (a-h,l-z)
	logical merged
	character*2 merging
	common/jetkin/ptj_lead,yj_lead 
	common/jet2/ptjet2,yjet2 
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
c	
	if (merged) then
	  inb_jet = 1
c regle d'association: snowmass
	  if (merging(1:2).eq.'sn') then
	    ptjet = pt1 + pt2
	    yjet = pt1/ptjet*y1 + pt2/ptjet*y2
	    fijet = pt1/ptjet*fi1 + pt2/ptjet*fi2
	    xej(1) = ptjet*dcosh(yjet)
	    xpjx(1) = ptjet*dcos(fijet)
	    xpjy(1) = ptjet*dsin(fijet)
	    xpjz(1) = ptjet*dsinh(yjet)
	    ptj_lead = ptjet 
	    yj_lead =  yjet 
c regle d'association: houches99 (on somme les 4-vecteurs)
	  else if (merging(1:2).eq.'ho') then
	   xej(1) = pt1*dcosh(y1)+pt2*dcosh(y2)
	   xpjx(1) = pt1*dcos(fi1)+pt2*dcos(fi2)
	   xpjy(1) = pt1*dsin(fi1)+pt2*dsin(fi2)
	   xpjz(1) = pt1*dsinh(y1)+pt2*dsinh(y2)
	   ptj_lead = dsqrt(xpjx(1)**2+xpjy(1)**2)
	   yj_lead = 0.5d0*dlog((xej(1)+xpjz(1))/(xej(1)-xpjz(1)))	   
	  endif
	  xej(2) = 0.d0
	  xpjx(2) = 0.d0
	  xpjy(2) = 0.d0
	  xpjz(2) = 0.d0
	  ptjet2 = 0.d0
          yjet2 =  0.d0 
	else !not merged
	  inb_jet = 2
	  xej(1) = pt1*dcosh(y1)
	  xpjx(1) = pt1*dcos(fi1)
	  xpjy(1) = pt1*dsin(fi1)
	  xpjz(1) = pt1*dsinh(y1)
	  xej(2) = pt2*dcosh(y2)
	  xpjx(2) = pt2*dcos(fi2)
	  xpjy(2) = pt2*dsin(fi2)
	  xpjz(2) = pt2*dsinh(y2)
	  ptj_lead = pt1 
	  yj_lead =  y1 
	  ptjet2 = pt2
          yjet2 =  y2 	  
	endif !endif merged
c	write(*,*) 'fi1,fi2= ',fi1,fi2
c	write(*,*) 'xj =',xej(1),xpjx(1),xpjy(1),xpjz(1) 	
	return
	end
c ***********************************************************************
	subroutine jet_algorithm(r12,pt1,pt2,algorithm,r_kt,r_c,
     #	r_sep,merged)
	implicit real*8 (a-h,l-z)
	logical merged
	character*2 algorithm
c algorithme en kt
c d12 = min(pt2**2,pt1**2)*r12s
c d1 = pt1**2*r_kt**2
c d2 = pt2**2*r_kt**2
c comme pt2<=pt1 la condition d12 <= d1,d2 devient
c r12s <= r_kt**2
	if (algorithm(1:2).eq.'kt') then
	  if (r12.le.r_kt) then
	    merged = .true.
	  else
	    merged = .false.
	  endif
c algorithme en cone
c comme pt2<=pt1, on trace un cone autour de 1, la condition 2 
c appartient a ce cone est:
c r12s <= r_c**2
	else if (algorithm(1:2).eq.'co') then
	  if (r12.le.r_c) then
	    merged = .true.
	  else
	    merged = .false.
	  endif
c algorithme en cone (avec des semences qui ne sont pas dans la direction 
c des partons) on balade un cone dans le plan y-phi, si les deux partons 
c tombent dedans (et si leur distance est plus petite que r_sep alors 
c on associe)
c la condition pour que le parton 1 soit dans le cone est:
c r12 <= p_tjet/pt2*r_c
c la condition pour que le parton 2 soit dans le cone est:
c r12 <= p_tjet/pt1*r_c
c comme pt2<=pt1, la condition pour que les deux partons soient dans le 
c cone est: r12 <= p_tjet/pt1*r_c
c Attention les conditions precedentes utilisent implicitement que la 
c regle d'association est "snow-mass".
	else if (algorithm(1:2).eq.'se') then
	  ptjet = pt1+pt2
	  if (pt1.ne.0.d0) then
	    ptjet_s_pt1 = ptjet/pt1
	  else
	    ptjet_s_pt1 = 1.d+8
	  endif
	  if (r12.le.ptjet_s_pt1*r_c.and.r12.le.r_sep) then
	    merged = .true.
	  else
	    merged = .false.
	  endif
	endif
	return
	end
