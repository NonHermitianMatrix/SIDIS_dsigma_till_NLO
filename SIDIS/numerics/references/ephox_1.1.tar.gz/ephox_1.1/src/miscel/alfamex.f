

	! Compute alphaS with the implicit method and continuity at thresholds
	!=====================================================================

	! Warning: scale must be lower than top threshold.


	! The initialisation routine
	!---------------------------
	
c	subroutine alfas_init(loop)
c		implicit none
c		integer loop
c
c		real*8 M2charm, M2bottom, M2top,Lambda4Square
c		common/alfa/M2charm, M2bottom, M2top,Lambda4Square
c	
c		! uses 
c		real*8 getLambda3Sqr,getLambda5Sqr
c		
c		! internals
c		 
c
c		real*8 Lambda2(3:5)
c		common / AlphaS_Lambdas / Lambda2
c
c		real*8 b0(3:5), b1(3:5)
c		common / AlphaS_betaCoeffs / b0,b1
c		
c	
c
c	real*8 pi
c	data pi / 3.141592653589793 /
c		
c	integer Nf
c
c	do Nf=3,5
c		b0(Nf)=( 33-2*Nf)/(12*pi)
c		b1(Nf)=(153-19*Nf)/(24*pi**2*b0(Nf))
c	enddo
c	
c	if (loop .eq. 1)then
c		Lambda2(3)=lambda4Square**(b0(4)/b0(3) )
c     _			* M2charm**(1 - b0(4)/b0(3))
c		Lambda2(4)=lambda4Square
c		Lambda2(5)=Lambda4Square**( b0(4)/b0(5) ) 
c     _			* M2bottom**(1 - b0(4)/b0(3))
c	elseif(loop .eq. 2) then
c		Lambda2(3)=getLambda3Sqr(lambda4Square, M2charm)
c		Lambda2(4)=lambda4Square
c		Lambda2(5)=getLambda5Sqr(lambda4Square, M2bottom)
c	else
c		write(*,*) 'illegal number of loops in alfas'
c		stop
c	endif
c	end
	

	! The main function
	!------------------

	real*8 function alfas(loop, scale2)
		implicit none	
		integer loop		
		real*8 scale2

	!uses
	real*8 alphaS1loop, alphaS2loop

	if (loop .eq. 1) then
		alfas = alphaS1loop(scale2)
	else if (loop .eq. 2) then
		alfas = alphaS2loop(scale2)
	else
		write(*,*) 'illegal number of loops in alfas'
		stop
	endif

	end


	! Compute AlphaS at 1 loops
	!--------------------------

	real*8 function alphaS1loop(scale2)
		implicit none	
		real*8 scale2

		real*8 M2charm, M2bottom, M2top,Lambda4Square
		common/alfa/M2charm, M2bottom, M2top,Lambda4Square
	
		! internals
		 
		real*8 Lambda2(3:5)
		common / AlphaS_Lambdas / Lambda2

		real*8 b0(3:5), b1(3:5)
		common / AlphaS_betaCoeffs / b0, b1

	if (scale2 .gt. M2bottom) then
		alphaS1loop=1/( b0(5) * log( scale2/Lambda2(5) ) )
	elseif (scale2 .gt. M2charm) then
		alphaS1loop=1/( b0(4) * log( scale2/Lambda2(4) ) )		
	else
		alphaS1loop=1/( b0(3) * log( scale2/Lambda2(3) ) )		
	endif

	end


	! Compute AlphaS at 2 loops
	!--------------------------

	real*8 function alphaS2loop(scale2)
		implicit none	
		real*8 scale2
		
		real*8 M2charm, M2bottom, M2top,Lambda4Square
		common/alfa/M2charm, M2bottom, M2top,Lambda4Square
		! uses 
		real*8 getLambda3Sqr,getLambda5Sqr
		
		! internals
		
		real*8 Lambda2(3:5)
		common / AlphaS_Lambdas / Lambda2

		real*8 b0(3:5), b1(3:5)
		common / AlphaS_betaCoeffs / b0,b1
		
	

	real*8 pi
	data pi / 3.141592653589793 /
			
		! uses
		real*8 alphaSflav, alphaSflavexp
		
		! internals
	integer Nf

	do Nf=3,5
		b0(Nf)=( 33-2*Nf)/(12*pi)
		b1(Nf)=(153-19*Nf)/(24*pi**2*b0(Nf))
	enddo
	
c		Lambda2(3)=lambda4Square**(b0(4)/b0(3) )
c     _			* M2charm**(1 - b0(4)/b0(3))
c		Lambda2(4)=lambda4Square
c		Lambda2(5)=Lambda4Square**( b0(4)/b0(5) ) 
c     _			* M2bottom**(1 - b0(4)/b0(3))
c	elseif(loop .eq. 2) then
c		Lambda2(3)=getLambda3Sqr(lambda4Square, M2charm)
		Lambda2(4)=lambda4Square
		Lambda2(5)=getLambda5Sqr(lambda4Square, M2bottom)
c	else
c		write(*,*) 'illegal number of loops in alfas'
c		stop
c	endif

	if (scale2 .gt. M2bottom) then
		alphaS2loop=alphaSflavexp(scale2, 5, Lambda2(5))
	else       ! (scale2 .gt. M2charm) then
		alphaS2loop=alphaSflavexp(scale2, 4, Lambda2(4))
c	else
c		alphaS2loop=alphaSflav(scale2, 3, Lambda2(3))
        endif
	end



	! Compute alphaS with f flavors at 2 loops
	!-----------------------------------------

	real*8 function alphaSflav(scale2, Nf, Lambda2)
		implicit none
		real*8 scale2
		integer Nf
		real*8 Lambda2
		real*8 b0(3:5), b1(3:5)
		common / AlphaS_betaCoeffs / b0, b1

		! uses
		real*8 oneOverBetaInt, beta

	! The relative precision for the computation of alphaS			
	real*8 eps


	data eps / 1d-5 /

	real*8 Logar, alpha, alpha1

	! We solve the equation whose solution is alphaS with the Newton's
	! method. The initial value is the 1loop value.

	Logar=b0(Nf)*log( scale2/lambda2 )


	alpha1=1/Logar

1	continue
	alpha=alpha1    
	alpha1 = alpha - (oneOverBetaInt(alpha,Nf) - Logar)*beta(alpha,Nf)     
	if ( abs(alpha1-alpha)/alpha .gt. eps ) goto 1

	alphaSflav=alpha1

	end

CCCCCCCCCCCCCCCCCCCCCCCCCCC
c Modification de alphaSflav pour avoir la forme de alphas developpee en log(q2/lambda2)
CCCCCCCCCCCCCCCCCCCCCCCCCCC
	real*8 function alphaSflavexp(scale2, Nf, Lambda2)
		implicit none
		real*8 scale2
		integer Nf
		real*8 Lambda2
                real*8 lnexp, alfex
		real*8 b0(3:5), b1(3:5)
		common / AlphaS_betaCoeffs / b0, b1

		! uses
		real*8 oneOverBetaInt, beta

	! The relative precision for the computation of alphaS			
	real*8 eps


	data eps / 1d-5 /

	real*8 Logar, alpha, alpha1

	! We solve the equation whose solution is alphaS with the Newton's
	! method. The initial value is the 1loop value.

	Logar=b0(Nf)*log( scale2/lambda2 )


	alpha1=1/Logar

c1	continue
c	alpha=alpha1    
c	alpha1 = alpha - (oneOverBetaInt(alpha,Nf) - Logar)*beta(alpha,Nf)     
c	if ( abs(alpha1-alpha)/alpha .gt. eps ) goto 1

        lnexp =dlog(scale2/lambda2)
        alfex=(1.-b1(nf)*dlog(lnexp)/(b0(nf)*lnexp))/lnexp/b0(nf)
        alphaSflavexp = alfex
c        print*, nf,lambda2,scale2,alpha1, alphaSflavexp

	end


	! Compute Lambda5**2 from Lambda4**2 by requiring the continuity of
	! alphaS at the threshold, at 2 loops
	!-------------------------------------------------------------------

	real*8 function getLambda5Sqr(Lambda4Sqr, M2bottom)
		implicit none
		real*8 Lambda4Sqr
		real*8 M2bottom

		real*8 b0(3:5), b1(3:5)
		common / AlphaS_betaCoeffs / b0, b1

		!uses
		real*8 alphaSflav, oneOverBetaInt

	real*8 alpha
		
	alpha=alphaSflav(M2bottom, 4, Lambda4Sqr)
	getLambda5Sqr = M2bottom * exp( -oneOverBetaInt(alpha,5)/b0(5) )
	end


	! Compute Lambda3**2 from Lambda4**2 by requiring the continuity of
	! alphaS at the threshold, at 2 loops
	!-------------------------------------------------------------------

	real*8 function getLambda3Sqr(Lambda4Sqr, M2charm)
		implicit none
		real*8 Lambda4Sqr
		real*8 M2charm

		real*8 b0(3:5), b1(3:5)
		common / AlphaS_betaCoeffs / b0, b1

		!uses
		real*8 alphaSflav, oneOverBetaInt

        	real*8 alpha

	alpha=alphaSflav(M2charm, 4, Lambda4Sqr)
	getLambda3Sqr = M2charm * exp( -oneOverBetaInt(alpha,3)/b0(3) )
	end


	! The primitiv of 1/beta at 2 loop
	!---------------------------------

	real*8 function oneOverBetaInt(alphaS, Nf)
		implicit none
		real*8 alphaS
		integer Nf

		real*8 b0(3:5), b1(3:5)
		common / AlphaS_betaCoeffs / b0, b1

	oneOverBetaInt=
     _		1/alphaS + b1(Nf)*log( b0(Nf)*alphaS/(1 + b1(Nf)*alphaS) )
	end 


	! The beta function at 2 loops
	!-----------------------------

	real*8 function beta(alphaS, Nf)
		implicit none
		real*8 alphaS
		integer Nf

		real*8 b0(3:5), b1(3:5)
		common / AlphaS_betaCoeffs / b0, b1
	
	beta=-b0(Nf)*alphaS**2 * (1 + b1(Nf)*alphaS)
	end


