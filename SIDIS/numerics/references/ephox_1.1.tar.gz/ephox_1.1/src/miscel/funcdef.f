C*****************************************************
C Definition of various small functions
C*****************************************************	
	REAL*8 FUNCTION SCA(P,Q)
	IMPLICIT REAL*8 (A-H,L-Z)
	DIMENSION P(4),Q(4)
	SCA=P(1)*Q(1)-P(2)*Q(2)-P(3)*Q(3)-P(4)*Q(4)
	RETURN
	END
C*********************************************************
	DOUBLE PRECISION FUNCTION ZACOS(X)
	IMPLICIT REAL*8 (A-H,L-Z)
	UN = 1.D0
	UNP = 1.D0 + 1.D-8
	ZERO = 0.D0
	PI=DATAN(1.D0)*4.D0
	IF (DABS(X).LE.UN) THEN
	  ZACOS = DACOS(X)
	ELSE IF (DABS(X).GT.UN.AND.DABS(X).LT.UNP) THEN
	  IF (X.LT.ZERO) THEN
	    ZACOS = PI
	  ELSE
	    ZACOS = 0.D0
	  ENDIF
	ELSE
	  WRITE (*,*) 'ALERTE DANS ZACOS ARGUMENT > 1:',X
	  ZACOS = 0.D0
	ENDIF
	RETURN
	END
C********************************************************************
	double precision function zasin(x)
	implicit real*8 (a-h,l-z)
	un = 1.d0
	unp = 1.d0 + 1.d-8
	zero = 0.d0
	pi=datan(1.d0)*4.d0
	if (dabs(x).le.un) then
	  zasin = dasin(x)
	else if (dabs(x).gt.un.and.dabs(x).lt.unp) then
	  if (x.lt.zero) then
	    zasin = -pi/2.d0
	  else
	    zasin = pi/2.d0
	  endif
	else
	  write (*,*) 'alerte dans zasin argument > 1:',x
	  zasin = 0.d0
	endif
	return
	end
c********************************************************************
C
c	SUBROUTINE XTHET(ZMAX,BSUP)
c	IMPLICIT REAL*8 (A-H,L-Z)
c	UN = 1.D0
c	IF (ZMAX.EQ.UN) THEN
c	  BSUP = UN
c	ELSE IF (ZMAX.LT.UN) THEN
c	  BSUP = 0.D0
c	ENDIF
c	RETURN
c	END 
C********************************************************
	double precision function coshmcos(y,fi)
	implicit real*8 (a-h,l-z)
	petit = 1.d-3
	yy = dabs(y)
	if (yy.le.petit.and.fi.gt.petit) then
	  coshmcos = 1+y**2/2.d0+y**4/24.d0+y**6/720.d0-dcos(fi)
	else if (yy.gt.petit.and.fi.le.petit) then
	  coshmcos = dcosh(y)-(1-fi**2/2.d0+fi**4/24.d0-fi**6/720.d0)
	else if (yy.le.petit.and.fi.le.petit) then
	  coshmcos = (y**2+fi**2)/2.d0+(y**4-fi**4)/24.d0+
     #	  (y**6+fi**6)/720.d0
	else if (yy.gt.petit.and.fi.gt.petit) then
	  coshmcos = dcosh(y)-dcos(fi)
	endif
	end
C********************************************************************
c
c functions needed for subroutine gfill (filling of histograms, see
c src/histo/histo_selection.f) 
c
	real function zsign(x)
	implicit real*8 (a-h,l-z)
	un = 1.d0
	zero = 0.d0
	if (x.le.zero) then
	  zsign = un
	else
	  zsign = zero
	endif
	return
	end
c********************************************************************
c undo principal value of arccos
	real function zinvcos(x,y,pt,pi)
	implicit real*8 (a-h,l-z)
	zero = 0.d0
	if (y.le.zero) then
	  zinvcos = 2.d0*pi-zacos(x/pt)
	else
	  zinvcos = zacos(x/pt)
	endif
	return
	end
C ******************************************************************
