	subroutine ntuple_init(inbevent)
	implicit real*8 (a-h,l-v,x-z)
	implicit real*4 (w)
	integer*4 ntrack,maxtrk,iprov
	parameter (maxtrk=3)
	LOGICAL dir,frag
	CHARACTER*128 PATH_RZFILE
	COMMON/CHEMINRZ/PATH_RZFILE
	COMMON/LONGRZ/ILENRZ
	COMMON/FIXLE/iprov,weight
	COMMON/APPROX/LO,NLO
	COMMON/CALCUL/INTEG,INTEGA,GENER
	COMMON/PCAT/dir,frag
	COMMON/SORTIER/ntrack,WE(maxtrk),WPX(maxtrk),
     #	WPY(maxtrk),WPZ(maxtrk)
	COMMON/SFRAGVR/wx1,wx2
	common/xvar/wxobs,weta
	parameter(iwpawc = 2000000)
	common/pawc/hmemor(iwpawc)
	COMMON/QUEST/IQUEST(100)
c
	iwpawt = 150000*7*inbevent/1000000
	if(iwpawt.gt.iwpawc) then
	  write(6,*)' you must have iwpawc at least ',iwpawt
	stop
	endif
	call hlimit(iwpawc)
	IQUEST(10) = 65000
	CALL HCDIR('//PAWC',' ')
c	
c open file where ntuple will be written	
	CALL HROPEN(50,'GJET',
     #	PATH_RZFILE(1:ILENRZ)//'.rz',
     #	'NQ',8192,ISTAT)
c     
	IF (ISTAT.NE.0) THEN
	  WRITE (8,*) 'ERROR IN HROPEN',ISTAT
	  STOP
	ENDIF
	CALL HBNT(10,'prompt photon EVENTS','D')
        call hldir('//PAWC','T')
        call hldir('//GJET','T')
	call hbname(10,'fixle',iprov,'iprov,weight')
	CALL HBNAME(10,'VARBLOK2',NTRACK,'NTRACK[1,3],'//
     +            'WE(NTRACK), WPX(NTRACK), WPY(NTRACK), WPZ(NTRACK)')
c     	IF (FRAG) THEN
	  call hbname(10,'sfragvr',wx1,'wx1,wx2')
c	ENDIF
	call hbname(10,'xvar',wxobs,'wxobs,weta')
	CALL HBSET('BSIZE',8192,IERR)
	IF (IERR.NE.0) THEN
	  WRITE (8,*) 'ERROR IN HBSET',IERR
	  STOP
	ENDIF
	write(6,*)' before rzldir (for debugging)'	
	call rzldir(' ',' ')
	write(6,*)' after rzldir '
c
	return
	end
