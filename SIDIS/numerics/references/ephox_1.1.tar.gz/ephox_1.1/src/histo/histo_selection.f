c changes:
c 21.05.03 include variable pperp, with p_T^jet either Snowmass or Houches
c 5.11.02: define cut ptmax for photon
c 20.12.01: use double precision numbers for 4-vectors of photon and jet
c
C fills histograms for variables specified in param_histo.indat
c implements cuts, jet definitions, ...
c note that jets can be defined already at integration level or only 
c in event generation
c here photon is particle 3!!!!!!! (in integration routines it is 4)
c z-axis reverted to obtain Zeus conventions, reshift CMS -> LAB done below
c
	subroutine gfill
	implicit real*8 (a-h,l-v,x-z)
	implicit real*4 (w)
	integer*4 iprov,maxtrk,ntrack
        parameter (maxtrk = 3)
	logical rapidite,pete,isol,masscut,sumcut
	logical rapjet,petejet,cut_jet,cut_phi,merged
	logical igampass,xgamcut
	logical rapjzeus,petejzeus
	LOGICAL DDIR,DFRAG,RDIR,RFRAG,dir,oneb
        common/sortier/xe(maxtrk),xpx(maxtrk),
     #	xpy(maxtrk),xpz(maxtrk)
	common/fixle/iprov,weight,ntrack
	common/pclass/DDIR,DFRAG,RDIR,RFRAG
	common/sfragvr/xx1,xx2
	common/xvar/xxobs,xxeta
	common/isophot/iphotisol
	common/frixione/isofrixione
	common/jets/jetmode
	common/jetkin/ptjet_lead,yjet_leadcm 
	common/jet2/ptjet2,yjet2 
	character*2 algorithm,merging,acceptance
	common/algorithme/algorithm,merging,acceptance
	common/testc/jcount
	dimension xej(2),xpjx(2),xpjy(2),xpjz(2)
c	
	xinfty = 1.d+8
	del = 1.d-4
	pi = atan(1.d0)*4.d0
c    
c ************************ begin of cut parameter input **********************
c
	call cuts_etc(rs,yshift,
     #  pt_photmin,pt_photmax,y_photmin,y_photmax,pt_jetmin,
     #  pt_jetmax,y_jetmin,y_jetmax,algorithm,r_kt,r_c,
     #  r_sep,merging,acceptance,x_gam_min,iflag_xgam)
c     
c ****************** end of cut parameter input *****************************
c 
c
	dir = DDIR.OR.RDIR
	oneb= DFRAG.OR.RFRAG
c for debugging (to trace back origin):	
	if (ddir) then 
	  ifl = 1
	else if (dfrag) then
	  ifl = 2
	else if (rdir)  then 
	  ifl = 3 
	else if (rfrag) then 
	  ifl = 4
	endif       
c
	if (dir) then
	  xx1 = 1.d0
	  xx2 = 1.d0
	endif 
	pt3 = sqrt(xpx(1)**2+xpy(1)**2)
	pt4 = sqrt(xpx(2)**2+xpy(2)**2)
c do revert z-axis (e in positive z-direction in CMSmy)
c  shift back to LAB frame
c yLAB_HERA = 1.7 - yCMS_my
c	
	y3cm = dlog((xe(1)+xpz(1))/(xe(1)-xpz(1)))*0.5d0
	y4cm = dlog((xe(2)+xpz(2))/(xe(2)-xpz(2)))*0.5d0
	y3 = yshift - y3cm
	y4 = yshift - y4cm
c
	if (ntrack.eq.3) then
	  pt5 = sqrt(xpx(3)**2+xpy(3)**2)
	  xnumy5 = (xe(3)+xpz(3))
	  xdeny5 = (xe(3)-xpz(3))
	  if (xnumy5.eq.0.d0.or.xdeny5.eq.0.d0) then
	    if (xpz(3).le.0.d0) then
	      y5cm = -xinfty
	    else
	      y5cm = xinfty
	    endif
	  else if (xnumy5.gt.0.d0.and.xdeny5.gt.0.d0) then
	    y5cm = dlog((xe(3)+xpz(3))/(xe(3)-xpz(3)))*0.5d0
	  endif
c shift to HERA LAB frame	  
	  y5 = yshift - y5cm 
	else if (iprov.eq.23) then
	  y5 = y3
	  y5cm = y3cm
	  if (dir) then
	    pt5 = pt4-pt3
	  else if (oneb) then
	    pt5 = pt4-pt3/xx1
	  endif
	else
	  pt5 =0.d0
	  y5 = yshift
	  y5cm=0.d0
	endif
c definition of angles	
	cfi34 = (xpx(1)*xpx(2)+xpy(1)*xpy(2))/(pt3*pt4)
	if (ntrack.eq.3) then
	  cfi35 = (xpx(1)*xpx(3)+xpy(1)*xpy(3))/(pt3*pt5)
	  cfi45 = (xpx(3)*xpx(2)+xpy(3)*xpy(2))/(pt5*pt4)
	  fi35 = zacos(cfi35)
	  fi45 = zacos(cfi45)
	  fi5 = zinvcos(xpx(3),xpy(3),pt5,pi)
	else
	  fi45 = 0.d0
	  fi5 = 0.d0
	endif
	if (dabs(cfi34).gt.1.0001d0) then
	  write (6,*) 'attention, cfi34 gt.1.0001',cfi34
	else if (dabs(cfi34).gt.1.d0) then
	  cfi34 = sign(1.d0,cfi34)
	endif
	fi34 = zacos( cfi34 )
	fi3 = zinvcos(xpx(1),xpy(1),pt3,pi)
	fi4 = zinvcos(xpx(2),xpy(2),pt4,pi)
	tolerance = 1.d-6
	test34 = dmin1(dabs(dabs(fi3-fi4)-fi34),
     #	dabs(2.d0*pi-dabs(fi3-fi4)-fi34))
	if ( test34.gt.tolerance) then
	  write (37,*) 'attention, test34 too big',test34
	endif
	if (ntrack.eq.3) then
	   test35 = dmin1(dabs(dabs(fi3-fi5)-fi35),
     #	   dabs(2.d0*pi-dabs(fi3-fi5)-fi35))
	   test45 = dmin1(dabs(dabs(fi4-fi5)-fi45),
     #	   dabs(2.d0*pi-dabs(fi4-fi5)-fi45))
	   if ( (test35.gt.tolerance).or.
     #	     (test45.gt.tolerance) ) then
	     write (37,*) 'attention, test35 or test45 too big ',
     #	     test35,test45,fi3,fi4,fi5
c	     write (37,*) 'attention1',fi35,fi45,fi34
	   endif
	endif ! end if (ntrack=3)   

c *************** jets **************************************************	     
c 	input values for rapidity cuts are in LAB frame, so shift to CMS
c	since yjet calculated in jet_cuts from xej, xpj is in CMS
	yjet_maxcm = yshift - y_jetmin
	yjet_mincm = yshift - y_jetmax
c
c       jet definition 
c 
c 	in inclusive mode cut_jet is always true
	if (jetmode.eq.0) then
	   cut_jet = .true.
	else    
	   call jet_selection(y4cm,y5cm,fi45,fi4,fi5,pt4,pt5,
     #	   algorithm,r_kt,r_c,r_sep,merging,merged,
     #     pt_jetmin,pt_jetmax,yjet_mincm,yjet_maxcm,acceptance,
     #	   inb_jet,xej,xpjx,xpjy,xpjz,cut_jet)
c leading jet is passed by common jetkin (26.11.02) 
c (first pt in argument of jet_selection must be the bigger pt!)	
	yjet_lead = yshift-yjet_leadcm
c	fijet_leadcm = zinvcos(xpjx(1),xpjy(1),ptjet_lead,pi)
c debug		
c	write(*,*) 'ymin,max,lead =',yjet_leadcm,cut_jet
	cfi_gamma_jet = (xpx(1)*xpjx(1)+xpy(1)*xpjy(1))/(pt3*ptjet_lead)
	fi_gamma_jet = zacos(cfi_gamma_jet)
	qt_gamma_jet = dsqrt((xpx(1)+xpjx(1))**2+(xpy(1)+xpjy(1))**2)
	pperp = dabs(xpx(1)*xpjy(1)-xpy(1)*xpjx(1))/ptjet_lead	
c	
        endif		
c	
c to test how many events are lost if jets are defined only at generation level	   
	IF (.not.cut_jet) THEN
	jcount=jcount+1
	ENDIF
c
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc	
c
c def of x_gamma: xgam^obs also defined in BASES subroutines (xxobs)
c
	xgamobs=(pt3*dexp(y3cm)+ptjet_lead*dexp(yjet_leadcm))/(rs*xxeta)
	xpobs=(pt3*dexp(-y3cm)+ptjet_lead*dexp(-yjet_leadcm))/rs
	xgamll =pt3*(dexp(y3cm)+dexp(yjet_leadcm))/(rs*xxeta)
	xpll =pt3*(dexp(-y3cm)+dexp(-yjet_leadcm))/rs
	xgamobases = xxobs
c	
c 
c def of p_T, p|| as in hep-ex/0104001 paper: 
c plots in k_T paper produced with histo_selection_ori.f
c	ptra = dabs(xpx(1)*pjy_vecsum-xpy(1)*pjx_vecsum)/ptj_vecsum	
c	ppa  = -(xpx(1)*pjx_vecsum+xpy(1)*pjy_vecsum)/ptj_vecsum - ptj_vecsum
c define Seymour kt:
c	vektx=	xpx(1)+pjx_vecsum
c	vekty=	xpy(1)+pjy_vecsum
c	vkt=sqrt(vektx**2+vekty**2)
c					
c ------------ define cut in photon rapidity, pt ------------
c ---------isolation must be done already at integration level in this version !!!---
c
	rapidite = (y3.le.y_photmax.and.y3.ge.y_photmin)
	pete = (pt3.ge.pt_photmin.and.pt3.le.pt_photmax)
	igampass = (rapidite.and.pete)
c	jet: cuts made in subroutine jet_cut above
c       (see jet_definition.f in ../miscel)
c		
c	x_gamma:
        IF(iflag_xgam.eq.1) THEN
	  xgamcut = (xgamobs.ge.x_gam_min)	
	ELSE IF(iflag_xgam.eq.2) THEN	
	  xgamcut = (xgamll.ge.x_gam_min)
	ELSE
	  xgamcut = .true.
	write(6,*) 'warning, flag_xgam not properly defined'
	ENDIF 
c	
c	 
c convert to single precision
	wpt3 = sngl(pt3)
	wy3 = sngl(y3)
	wptjet_lead = sngl(ptjet_lead)
	wyjet_lead = sngl(yjet_lead)
	wfi_gamma_jet = sngl(fi_gamma_jet)
	wqt_gamma_jet = sngl(qt_gamma_jet)
	wxgamll = sngl(xgamll)
	wxgamobs = sngl(xgamobs)
	wxgamobases = sngl(xgamobases)
	wxpll = sngl(xpll)
	wxpobs = sngl(xpobs)
	wx3=sngl(xx1)
	wsum_gaj=wpt3+wptjet_lead
	wmingj=min(wpt3,wptjet_lead)
	wmaxgj=max(wpt3,wptjet_lead)
	wpperp=sngl(pperp)
c
c 
c debug
c 	write(*,*) 'gampass,cutj,cx =', igampass,cut_jet,xgamcut	 
	if (igampass.and.cut_jet.and.xgamcut) then
c       fill histograms (adjust def of histos with working/param_histo.indat)
c
	  call fill_histo(iprov,weight,
     #  wy3,wyjet_lead,wpt3,wptjet_lead,
     #  wxgamobs,wxgamobases,wxgamll,
     #  wxpobs,wxpll,wx3,wxpparton,
     #  wfi_gamma_jet,wqt_gamma_jet,wpperp,
     #  wsum_gaj,wmingj,wmaxgj)
	endif
	end
c **************************************************************************
