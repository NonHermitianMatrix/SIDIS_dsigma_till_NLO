	subroutine histo_init(inbevent)
	implicit real*8 (a-h,l-v,x-z)
	implicit real*4 (w)
	CHARACTER*128 PATH_RZFILE
	COMMON/CHEMINRZ/PATH_RZFILE
	COMMON/LONGRZ/ILENRZ
	parameter(iwpawc = 5250000)
	common/pawc/hmemor(iwpawc)
	parameter (nbhisto=4)
	common/init_close/ibin(4)
	common/xminmax/wxmin(3),wxmax(3)
	common/nonequi/wxbinfi_gam_jetnlo(6)
c
	iwpawt = 150000*7*inbevent/1000000
	if(iwpawt.gt.iwpawc) then
	  write(6,*)' you must have iwpawc at least ',iwpawt
	stop
	endif
	call hlimit(iwpawc)
	call hropen(1,'zeus',PATH_RZFILE(1:ILENRZ)//'.dat'
     #	,'n',1024,istat)
c 
	ibin(1) = 20
	wxmin(1) = -0.7
	wxmax(1) = 0.9
c
	ibin(2) = 5
	wxmin(2) = 0.
	wxmax(2) = 5.
c
	ibin(3) = 5
	wxmin(3) = 0.
	wxmax(3) = 5.
c
c     bins for histo in fi_gam_jet
	ibin(4) = 5
	wxbinfi_gam_jetnlo(1) = 1.745
	wxbinfi_gam_jetnlo(2) = 2.094
	wxbinfi_gam_jetnlo(3) = 2.443
	wxbinfi_gam_jetnlo(4) = 2.793
	wxbinfi_gam_jetnlo(5) = 2.967
	wxbinfi_gam_jetnlo(6) = 3.142
c
	call hbook1(20,'dsigma/detaga',ibin(1),wxmin(1),wxmax(1),0.)
	call hbook1(920,'dummy',ibin(1),wxmin(1),wxmax(1),0.)
	call hbarx(20)
	call hbarx(920)
c
	call hbook1(21,'dsigma/dpperp',ibin(2),wxmin(2),wxmax(2),0.)
	call hbook1(921,'dummy',ibin(2),wxmin(2),wxmax(2),0.)
	call hbarx(21)
	call hbarx(921)
c
	call hbook1(22,'dsigma/dpperp',ibin(3),wxmin(3),wxmax(3),0.)
	call hbook1(922,'dummy',ibin(3),wxmin(3),wxmax(3),0.)
	call hbarx(22)
	call hbarx(922)
c
	call hbookb(23,'dsigma/dfi',ibin(4),wxbinfi_gam_jetnlo,0.)
	call hbookb(923,'dummy',ibin(4),wxbinfi_gam_jetnlo,0.)
	call hbarx(23)
	call hbarx(923)
c
	return
	end
