	subroutine cuts_etc(rs,yshift,
     #  pt_photmin,pt_photmax,y_photmin,y_photmax,pt_jetmin,
     #  pt_jetmax,y_jetmin,y_jetmax,algorithm,r_kt,r_c,
     #  r_sep,merging,acceptance,x_gam_min,iflag_xgam)
	implicit real*8 (a-h,l-z)
	character*2 algorithm,merging,acceptance
c
c	 ordering below by hasard since rewritten by perl
c
c sqrt of S (GeV)  (needed for def of xgamma)
	rs = 300.D0
c rapidity shift to LAB frame 
	yshift = dlog(820.D0/27.5D0)/2.d0
c
	r_kt = 1.d0
	y_jetmax = 1.8d0
	pt_photmin = 5.d0
	r_c = 1.d0
	pt_photmax = 150.d0
	acceptance = 'gp'
	algorithm = 'kt'
	y_photmin = -0.7d0
	merging = 'sn'
	r_sep = 1.d0
	y_photmax = 0.9d0
	pt_jetmin = 3.d0
	pt_jetmax = 150.d0
	iflag_xgam = 1
	x_gam_min = 0.d0
	y_jetmin = -1.5d0
	return
	end
