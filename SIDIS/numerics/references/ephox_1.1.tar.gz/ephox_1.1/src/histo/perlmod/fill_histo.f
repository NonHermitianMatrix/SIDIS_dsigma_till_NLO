	subroutine fill_histo(iprov,weight,
     #  wy3,wyjet_lead,wpt3,wptjet_lead,
     #  wxgamobs,wxgamobases,wxgamll,
     #  wxpobs,wxpll,wx3,wxpparton,
     #  wfi_gamma_jet,wqt_gamma_jet,wpperp,
     #  wave_gaj,wsum_gaj,wmingj,wmaxgj)
	implicit real*4 (a-h,l-z)
c  
	  if (iprov.eq.11) then
	  if  (0.9.le.wxgamobs.and.wxgamobs.le.1.001)
     #	   then
	    call hfill (21,wpperp,0.,weight)
	  endif
	  endif
	  call hfill (20,wy3,0.,weight)
	  if  (0.9.le.wxgamobs.and.wxgamobs.le.1.001)
     #	   then
	    call hfill (22,wpperp,0.,weight)
	  endif
	  call hfill (23,wfi_gamma_jet,0.,weight)
	return
	end
