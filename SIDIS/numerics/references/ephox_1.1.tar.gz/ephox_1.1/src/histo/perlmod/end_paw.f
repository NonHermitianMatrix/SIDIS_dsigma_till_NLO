	subroutine histo_close(inbevent,wfirst_int)
	implicit real*8 (a-h,l-v,x-z)
	implicit real*4 (w)
	parameter (nbhisto=4)
	common/init_close/ibin(4)
	common/xminmax/wxmin(3),wxmax(3)
	common/nonequi/wxbinfi_gam_jetnlo(6)
	dimension wxnormafi_gam_jetnlo(6)
	dimension wbin_size(3),wxnorma(3)
c
	do i=1,3
	  wbin_size(i) = (wxmax(i)-wxmin(i))/float(ibin(i))
	  wxnorma(i) = wfirst_int/(float(inbevent)*wbin_size(i))
	enddo
	 do j=1,ibin(4)
	 wxnormafi_gam_jetnlo(j) = wfirst_int/(float(inbevent)*
     #	(wxbinfi_gam_jetnlo(j+1)-wxbinfi_gam_jetnlo(j)))
	 enddo 
c
	call hopera(20,'+',920,20,wxnorma(1),1.)
	call hopera(21,'+',921,21,wxnorma(2),1.)
	call hopera(22,'+',922,22,wxnorma(3),1.)
	call hpak(923,wxnormafi_gam_jetnlo)
	call hopera(23,'*',923,23,1.,1.)
c
	call hrout(20,ICYCLE,' ')
	call hrout(21,ICYCLE,' ')
	call hrout(22,ICYCLE,' ')
	call hrout(23,ICYCLE,' ')
	call hrend('zeus')
	return
	end
