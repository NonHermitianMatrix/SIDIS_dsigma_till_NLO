c********************************************************************
	subroutine doubletosingleo(rnumb1,pi,poid,iiprov,intrack)
	implicit real*8 (a-h,l-v,x-z)
        implicit real*4 (w)
        logical lhalf
        integer*4 ntrack,iprov,maxtrk
        parameter (maxtrk = 3)
	common/sortie/XPT1,XY1,XPT2,XY2,XFI12,XPT3,XY3,XFI13,
     #	XETA,XGAMOBS,RESFUNC
	common/fixle/iprov,weight
        common/sortier/ntrack,we(maxtrk),wpx(maxtrk),
     #	wpy(maxtrk),wpz(maxtrk)
	common/sfragvr/wx1,wx2
	common/sfragv/xfrag1,xfrag2
	common/xvar/WXOBS,WETA
c	
	iprov = iiprov
	ntrack = intrack
	half = 0.5d0
	dpi = 2.d0*pi     
	xfi = dpi*rnumb1
	xfi1 = xfi
	xfi2 = dmod(xfi12+xfi,dpi)
	xfi3 = dmod(xfi13+xfi,dpi)
	do i = 1,ntrack
	  if(i.eq.1) then
	    we(i) = sngl(xpt1*dcosh(xy1))
	    wpx(i) = sngl(xpt1*dcos(xfi1))
	    wpy(i) = sngl(xpt1*dsin(xfi1))
	    wpz(i) = sngl(xpt1*dsinh(xy1))
	  elseif(i.eq.2)then
	    we(i) = sngl(xpt2*dcosh(xy2))
	    wpx(i) = sngl(xpt2*dcos(xfi2))
	    wpy(i) = sngl(xpt2*dsin(xfi2))
	    wpz(i) = sngl(xpt2*dsinh(xy2))
	  elseif(i.eq.3)then
	    we(i) = sngl(xpt3*dcosh(xy3))
	    wpx(i) = sngl(xpt3*dcos(xfi3))
	    wpy(i) = sngl(xpt3*dsin(xfi3))
	    wpz(i) = sngl(xpt3*dsinh(xy3))
	  endif
	enddo
	wx1 = sngl(xfrag1)
	wx2 = sngl(xfrag2)
	WXOBS = SNGL(xgamobs)
	WETA = SNGL(XETA)
	weight = sngl( dsign(poid,resfunc) )
	return
	end

