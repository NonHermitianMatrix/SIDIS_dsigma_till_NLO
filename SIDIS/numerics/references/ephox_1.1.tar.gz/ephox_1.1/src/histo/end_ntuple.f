	subroutine ntuple_close
	implicit real*8 (a-h,l-v,x-z)
	implicit real*4 (w)
c	
c	write(6,*)' before hcdir //gj'
	CALL HCDIR('//GJET',' ')
	CALL HLDIR('//GJET','T')
	write(6,*)' before rzldir end'
	call rzldir(' ',' ')
	write(6,*)' before hrout'
	CALL HROUT(10,ICYCLE,' ')
        call hldir(' ',' ')
        call hldir(' ','A')
	write(6,*)' before hrend'
	CALL HREND('GJET')
c	
	return
	end
