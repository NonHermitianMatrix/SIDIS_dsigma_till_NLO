c functions needed for subroutine gfill below
	real function wacos(x)
	implicit real*4 (a-h,l-z)
	un = 1.
	unp = 1. + 1.e-4
	zero = 0.
	pi=atan(1.)*4.
	if (abs(x).le.un) then
	  wacos = acos(x)
	else if (abs(x).gt.un.and.abs(x).lt.unp) then
	  if (x.lt.zero) then
	    wacos = pi
	  else
	    wacos = 0.
	  endif
	else
	  write (*,*) 'alerte dans wacos argument > 1:',x
	  wacos = 0.
	endif
	return
	end
C ******************************************************************
C same as jet_algorithm but without double precision numbers
	subroutine jet_algo_histo(r35,pt3,pt5,algorithm,r_kt,r_c,
     #	r_sep,merged)
	implicit real*4 (a-h,l-z)
	logical merged
	character*2 algorithm
c algorithme en kt
c d35 = min(pt5**2,pt3**2)*r35s
c d3 = pt3**2*r_kt**2
c d5 = pt5**2*r_kt**2
c comme pt5<=pt3 la condition d35 <= d3,d5 devient
c r35s <= r_kt**2
	if (algorithm(1:2).eq.'kt') then
	  if (r35.le.r_kt) then
	    merged = .true.
	  else
	    merged = .false.
	  endif
c algorithme en cone
c comme pt5<=pt3, on trace un cone autour de 3, la condition 5 
c appartient a ce cone est:
c r35s <= r_c**2
	else if (algorithm(1:2).eq.'co') then
	  if (r35.le.r_c) then
	    merged = .true.
	  else
	    merged = .false.
	  endif
c algorithme en cone (avec des semences qui ne sont pas dans la direction 
c des partons) on balade un cone dans le plan y-phi, si les deux partons 
c tombent dedans (et si leur distance est plus petite que r_sep alors 
c on associe)
c comme pt5<=pt3, la condition pour que les deux partons soient dans le 
c cone est: r35 <= p_tjet/pt5*r_c
	else if (algorithm(1:2).eq.'se') then
	  ptjet = pt3+pt5
	  if (pt5.ne.0.d0) then
	    ptjet_s_pt5 = ptjet/pt5
	  else
	    ptjet_s_pt5 = 1.d+8
	  endif
** 	  write (*,*)  r35,pt3,pt5,algorithm,r_kt,r_c,
**      #	r_sep 
	  if (r35.le.ptjet_s_pt5*r_c.and.r35.le.r_sep) then
	    merged = .true.
	  else
	    merged = .false.
	  endif
	endif
	return
	end	
c ******************************************************************	
C fills histograms for photon pt, jet pt, phi , pair pt
c implements isolation cuts 
c here photon is particle 3!!!!!!!!!!!!!!!!!!!!
c z-axis reverted to obtain Zeus conventions, reshift CMS -> LAB done below
	subroutine gfill
	implicit real*4 (a-h,l-y)
	integer maxtrk,ntrack
        parameter (maxtrk = 3)
	logical rapidite,pete,isol,masscut,sumcut
	logical rapjet,petejet,isoljet,merged
	logical igampass,xgamcut
	logical rapjzeus,petejzeus
	LOGICAL DDIR,DFRAG,RDIR,RFRAG,dir,oneb
        common/sortier/ntrack,we(maxtrk),wpx(maxtrk),
     #	wpy(maxtrk),wpz(maxtrk)
	common/fixle/iprov,weight
	common/pclass/DDIR,DFRAG,RDIR,RFRAG
	common/sfragvr/wx1,wx2,wxobs,weta
	common/isophot/iphotisol
	common/frixione/isofrixione
	common/jets/jetmode
	character*2 algorithm
	common/algorithme/algorithm
	common/testc/jcount

	xinfty = 1.e+8
	del = 1.e-4
	pi = atan(1.)*4.
c    
c	ZEUS kinematics:
c ************************ begin of cut parameter input **********************
	call cuts_etc(
     #  pt_photmin,pt_jet1min,pt_jet1max,y_photmin,y_photmax,
     #  y_jet1min,y_jet1max,r_iso,epsilon,r_kt,r_c,
     #  r_sep,x_gam_min,iflag_xgam)
c ****************** end of cut parameter input ***************************
c 
c sqrt of S (GeV) and LAB electron energy (needed for def of xgamma)	
	rs = 300.
c rapidity shift to LAB frame 
	yshift = 1.7	
c
	dir = DDIR.OR.RDIR
	oneb= DFRAG.OR.RFRAG
c for debugging (to trace back origin):	
	if (ddir) then 
	  ifl = 1
	else if (dfrag) then
	  ifl = 2
	else if (rdir)  then 
	  ifl = 3 
	else if (rfrag) then 
	  ifl = 4
	endif       
c
	if (dir) then
	  wx1 = 1.
	  wx2 = 1.
	endif 
	pt3 = sqrt(wpx(1)**2+wpy(1)**2)
	pt4 = sqrt(wpx(2)**2+wpy(2)**2)
c do revert z-axis (e in positive z-direction in CMSmy)
c  shift back to LAB frame
c yLAB_HERA = 1.7 - yCMS_my
c	
	y3cm = log((we(1)+wpz(1))/(we(1)-wpz(1)))*0.5
	y4cm = log((we(2)+wpz(2))/(we(2)-wpz(2)))*0.5
	y3 = yshift - y3cm
	y4 = yshift - y4cm
c
	if (ntrack.eq.3) then
	  pt5 = sqrt(wpx(3)**2+wpy(3)**2)
	  xnumy5 = (we(3)+wpz(3))
	  xdeny5 = (we(3)-wpz(3))
	  if (xnumy5.eq.0..or.xdeny5.eq.0.) then
	    if (wpz(3).le.0.) then
	      y5cm = -xinfty
	    else
	      y5cm = xinfty
	    endif
	  else if (xnumy5.gt.0..and.xdeny5.gt.0.) then
	    y5cm = log((we(3)+wpz(3))/(we(3)-wpz(3)))*0.5
	  endif
c shift to HERA LAB frame	  
	  y5 = yshift - y5cm 
	else if (iprov.eq.23) then
	  y5 = y3
	  y5cm = y3cm
	  if (dir) then
	    pt5 = pt4-pt3
	  else if (oneb) then
	    pt5 = pt4-pt3/wx1
	  endif
	else
	  pt5 =0.
	  y5 = yshift
	  y5cm=0.
	endif
	cfi34 = (wpx(1)*wpx(2)+wpy(1)*wpy(2))/(pt3*pt4)
	if (ntrack.eq.3) then
	  cfi35 = (wpx(1)*wpx(3)+wpy(1)*wpy(3))/(pt3*pt5)
	  cfi45 = (wpx(3)*wpx(2)+wpy(3)*wpy(2))/(pt5*pt4)
	  fi35 = wacos(cfi35)
	  fi45 = wacos(cfi45)
	  fi34 = wacos(cfi34)
	endif
c	
c def of qt of the pair photon-parton4	
	qt = sqrt( (wpx(1)+wpx(2))**2+(wpy(1)+wpy(2))**2 )
c
c jet definition (corresponds to kT algorithm for pt5<pt4) 
c Dans le cas de photon + 2 jets, le jet de plus haut pt est le jet1
	if (ntrack.eq.3) then
	  dist45 = sqrt((y4-y5)**2+(fi45)**2)
	  call jet_algo_histo(dist45,pt4,pt5,algorithm,
     #	  r_kt,r_c,r_sep,merged)
	  if (not(merged)) then
	    pt_jet1 = pt4
	    pt_jzeus= pt4
	    y_jet1 = y4
	    y_jzeus = y4
	    if (wpy(2).le.0.) then 
	      phi_jet1 = 2*pi-wacos(wpx(2)/pt4)
	    else 
	      phi_jet1 = wacos(wpx(2)/pt4)
	    endif
	    e_j1 =    we(2)
	    pt_j1x = wpx(2)
	    pt_j1y = wpy(2)
	    p_j1z =  wpz(2)
	    pt_jet2 = pt5
	    y_jet2 = y5
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
	  else if (merged) then
	    pt_jet1 = pt4 + pt5
	    y_jet1 = (y4*pt4 + y5*pt5)/pt_jet1
c	    
c      (absolute fi not needed, take everytihing relative to photon axis)	    
c	    if (wpy(2).le.0.) then 
c	      fi4 = 2*pi-wacos(wpx(2)/pt4)
c	    else 
c	      fi4 = wacos(wpx(2)/pt4)
c	    endif
c	    if (wpy(3).le.0.) then 
c	      fi5 = 2*pi-wacos(wpx(3)/pt5)
c	    else 
c	      fi5 = wacos(wpx(3)/pt5)
c	    endif
 	if  (wpy(1).lt.0.) then 
	  figam = 2*pi-wacos(wpx(1)/pt3)
	else 
	  figam = wacos(wpx(1)/pt3)
	endif
c fix fi34 to be < pi => fi35 originally has been > pi	
	  fi35ori = 2*pi-wacos(cfi35)
	delphi = (fi34*pt4+fi35ori*pt5)/pt_jet1
	tpi=2*pi
	if (delphi.gt.pi.and.delphi.lt.tpi) then
	  delphi = 2*pi-delphi
	endif  
	phi_jet1 = (fi34*pt4+fi35ori*pt5)/pt_jet1 + figam   
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc                                
            e_j1 =    we(2) +  we(3)
     	    pt_j1x = wpx(2) + wpx(3) 
	    pt_j1y = wpy(2) + wpy(3)
	    p_j1z =  wpz(2) + wpz(3)
	    pt_jzeus = sqrt(pt_j1x**2 + pt_j1y**2)
	    y_jzeus = 1/2*log((we(2)+we(3)+wpz(2)+wpz(3))/
     #	    (we(2)+we(3)-wpz(2)-wpz(3)+del))
	  endif
	else
	  pt_jet1 = pt4
	  pt_jzeus= pt4
	  y_jet1 = y4
	  y_jzeus = y4
	  if (wpy(2).le.0.) then 
	     phi_jet1 = 2*pi-wacos(wpx(2)/pt4)
	  else 
	     phi_jet1 = wacos(wpx(2)/pt4)
	  endif
	  e_j1 =    we(2)
	  pt_j1x = wpx(2)
	  pt_j1y = wpy(2)
	  p_j1z =  wpz(2)
	endif
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
	ptsnox = pt_jet1*cos(phi_jet1)
	ptsnoy = pt_jet1*sin(phi_jet1)
	difx = ptsnox - pt_j1x
	dify = ptsnoy - pt_j1y
	if (merged) then 
	  if (pt_j1y.ge.0.) then
	    fijvec = wacos(pt_j1x/pt_jzeus)
	  else 
	    fijvec = 2*pi-wacos(pt_j1x/pt_jzeus)
	  endif
	 dif=abs(fijvec-phi_jet1)
c 0.1 rad <-> about 6 degrees	 
c	  if (dif.gt.0.1) then
c	     write(19,*) phi_jet1,dif
c	  endif
	endif  
c
	cfigj = (wpx(1)*ptsnox + wpy(1)*ptsnoy)/(pt3*pt_jet1)
	cfigjzeus = (wpx(1)*pt_j1x + wpy(1)*pt_j1y)/(pt3*pt_jzeus)
c	
	if (abs(cfigjzeus).gt.1.0001.or.cfigj.gt.1.0001) 
     #	then
	  write (6,*) 'cfigj > 1.0001',cfigjzeus,cfigj
	  cfigj = sign(1.,cfigj)
	 endif
 	  fisno = wacos( cfigj )
c          fisno = delphi
	  fivec = wacos( cfigjzeus )
	  dif2=fivec-delphi
	  dif3=fivec-fisno
	  if (dif3.gt.0.1) then
	     write(17,*) dif2,dif3,fisno,delphi,fivec
	  endif
	 if  (fisno.gt.3.1416.or.fivec.gt.3.1416) then
	   write (19,*) 'fi  > pi ! ', fisnow,fivec,iprov,ifl
	 endif  
c	
c
c def of x_gamma^obs also in BASES subroutines
c
	y_jet1cm = yshift - y_jet1
	xgamobs=(pt3*exp(y3cm)+pt_jet1*exp(y_jet1cm))/(rs*weta)
	xgameas=(we(1)+wpz(1)+e_j1+p_j1z)/(rs*weta)
	xgamll =pt3*(exp(y3cm)+exp(y_jet1cm))/(rs*weta)
	xgamobases = wxobs
c	if (xgamobs.gt.1.00001.and.xgamobs.lt.1.00002) then
c	  write (18,*) 'xgamobs > 1.00001 ! ',xgamobs,xgamobases,
c     #	  iprov,ifl
c	  xgamobs = 1.
c	endif  	
c	if (xgamobases.gt.1.) then
c	  write (19,*) 'xgamobases > 1 ! ',xgamobases,iprov
c	  xgamobases = 1. 
c	endif
c
c def of p_T, p|| as in Osaka exp. paper: 
	ptra = abs(wpx(1)*pt_j1y-wpy(1)*pt_j1x)/pt_jzeus	
	ppa  = -(wpx(1)*pt_j1x+wpy(1)*pt_j1y)/pt_jzeus - pt_jzeus
	sum_gaj=pt3+pt_jet1
c	sumcut = sum_gaj.gt.12.5
c define Seymour kt:
	vektx=	wpx(1)+pt_j1x
	vekty=	wpy(1)+pt_j1y
	vkt=sqrt(vektx**2+vekty**2)
	mingj=min(pt3,pt_jet1)
	maxgj=max(pt3,pt_jet1)
	sumcut=sum_gaj.gt.12.
c		
c			
c define isolation cuts, cut in photon rapidity, pt
c
	if (ntrack.eq.3) then
	  dist35 = sqrt((y3-y5)**2+(fi35)**2)
	  rcos=(1.d0-cos(dist35))/(1.d0-cos(r_iso))
	  if (isofrixione.eq.0) then
	    ethad = epsilon*pt3
	  else 
	    ethad = epsilon*pt3*rcos
	  endif  	  
	  if (dist35.gt.r_iso) then
	    edep3 = (1.-wx1)/wx1*pt3
	    isol = (edep3.le.ethad)
	  else if (dist35.le.r_iso) then
	    edep3 = pt5 + (1.-wx1)/wx1*pt3
	    isol = (edep3.le.ethad)
	  endif
	else if (iprov.eq.23.and.isofrixione.eq.0) then
	  if (dir) then
	    edep3 = pt5 
	  else if (oneb) then
	    edep3 = (1.-wx1)/wx1*pt3+pt5
	  endif
	    isol = (edep3.le.ethad)
	else
	  dist35 = 0.
	  dist45 = 0.
	  rcos=0.
	  if (isofrixione.eq.1) then
	    ethad = epsilon*pt3*rcos
	  else 
	    ethad = epsilon*pt3
	  endif  	  
	  edep3 = (1.-wx1)/wx1*pt3
	  isol = (edep3.le.ethad)
	endif
	x3min = pt3/(pt3+ethad)	
c  
c	photon:	
	rapidite = (y3.le.y_photmax.and.y3.ge.y_photmin)
	pete = pt3.ge.pt_photmin
	igampass = (rapidite.and.pete)
c	jet:	
	rapjet = (y_jet1.le.y_jet1max.and.y_jet1.ge.y_jet1min)
	petejet = (pt_jet1.ge.pt_jet1min.and.pt_jet1.le.pt_jet1max)
c	petejzeus = (pt_jzeus.ge.pt_jet1min.and.pt_jzeus.le.pt_jet1max)
c	Snowmass pt_jet_min is used by ZEUS	
	isoljet = (rapjet.and.petejet)
c	   
	IF (not(isoljet)) THEN
	jcount=jcount+1
	ENDIF	
c	x_gamma:
	IF (iflag_xgam.eq.0) THEN	
	  xgamcut = (xgameas.ge.xgam_min)
	ELSE IF(iflag_xgam.eq.1) THEN
	  xgamcut = (xgamobs.ge.xgam_min)	
	ELSE IF(iflag_xgam.eq.2) THEN	
	  xgamcut = (xgamll.ge.xgam_min)
	ELSE
	  xgamcut = .true.
	write(18,*) 'warning, flag_xgam not properly defined'
	ENDIF 	
c	
c       if no isolation cuts on photon are imposed (iphotisol.eq.0), 
c       photon is always isolated (fulfills any isolation criteria)
c       flag iphotisol is read in in param.f
c
	IF (iphotisol.eq.0) THEN
	   isol = .TRUE.
	ENDIF 
c 	in inclusive mode isoljet is always true
	IF (jetmode.eq.0) THEN
	   isoljet = .TRUE.
	ENDIF  
	if (igampass.and.isol.and.isoljet.and.xgamcut) then
c	
c fill histograms (adjust def of histos with working/param_histo.indat
c and start.pl)
c
	  call fill_histo(iprov,weight,
     #             xgameas,xgamll,vkt,x3,pt_jet1,
     #             ptra,mingj,pt3,y_jet1,maxgj,sum_gaj,
     #             fisno,y3,qt,fivec,ppa,xgamobs)
	endif
	end
