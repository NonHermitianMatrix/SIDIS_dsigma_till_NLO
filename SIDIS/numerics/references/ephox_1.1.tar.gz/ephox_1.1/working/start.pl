#! /usr/bin/perl -w
##! /usr/sue/bin/perl -w
##! /usr/local/bin/perl -w
###############################################################################
# improved version of start.pl (3.4.02) :
# nonequi histo vectors get suffix lo and nlo since otherwise same names are printed twice
##############################################################################
# this program consists of two blocks, one for the input parameters
# and one for the histograms of the generated events
#
# Block 1 of this program generates
# (1) the 4 parameter files to be read in by ephox*.exe
#    (param_ddir_name.dat, param_dfrag_name.dat, 
#     param_resodir_name.dat, param_resofrag_name.dat)
# (2) four subdirectories for each process where .bs and the .log files 
#    will be stored (ddir_name, dfrag_name, resodir_name, resofrag_name)
# (3) a file that launches the selected subprocesses at one time ("run_name.exe")
# 
#
# Block 2 is executed only if event generation has been selected in the input
# Block 2 defines parameters and cuts for filling of histograms and
# rewrites the corresponding Fortran files in src/histo/perlmod accordingly
# makes system call (gmake -f Makefile_x) to recompile (line 771)
#
###############################################################################
# to be able to call start.pl with arguments in command line
# for example to keep *.indat files with different names
# call as "perl start.pl --parameter parameterfilename --histo param_histofilename" 
use Getopt::Long;
GetOptions("parameter=s" => \$paramfile,
           "histo=s" => \$param_histo);
# valeur par defaut des fichiers de parametres
unless ($paramfile) {
  $paramfile = "parameter.indat";
}
unless ($param_histo) {
  $param_histo = "param_histo.indat";
}

# variables used to define cuts and histograms
#---------------------------------------------------------------------
# keys for variables to be written to cuts_etc.f  
#---------------------------------------------------------------------
@listcutph=qw(pt_gam_min pt_gam_max eta_gam_min eta_gam_max );
@listcutjet=qw(pt_jet_min pt_jet_max eta_jet_min eta_jet_max );
@listdefj= qw(algo r_kt r_cone r_sep merging acceptance);
@listcutx= qw(x_gam_min iflag_xgam);
@list_var_histo_clef = (@listcutph,@listcutjet,@listdefj,@listcutx,degree_or_rad);
# --------------------------------------------------------------------
# values for variables to be written to cuts_etc.f
# ------------------------------------------------------------------  
@def_var= qw(pt_photmin pt_photmax y_photmin y_photmax  
pt_jetmin pt_jetmax y_jetmin y_jetmax 
algorithm r_kt r_c r_sep merging acceptance 
x_gam_min iflag_xgam degree);
#@cut_var_string{@list_var_histo_clef}=@def_var;	
# --------------------------------------------------------------------
# to add a new cut variable add an arbitrary name to "@list_var_histo_clef"
# and add the name of the variable to "@def_var" at same position in the 
# two lists;
# in histo_selection.f, you have to add the new variable to the argument list 
# of the subroutine "cuts_etc" (called in histo_selection.f) by hand; 
# the file perlmod/cuts_etc.f containing the subroutine will be 
# adapted automatically 
#---------------------------------------------------------------------
# variables for filling of histograms 
#---------------------------------------------------------------------
# names given on the right-hand side of the arrow have to correspond 
# exactly to the variable names defined in histo_selection.f
# names on the left-hand side are the ones to be used in the input
# parameter file "param_histo.indat"
# if a new variable has been defined in histo_selection.f and should be 
# histogrammed, it has to be added to this list;
# in histo_selection.f, you have to add the new variable to the argument list 
# of the subroutine "fill_histo" (called in histo_selection.f) by hand 
# and also adjust the argument list in the file perlmod/fill_histo.f 
# the definition of the hisograms will then be adapted automatically 
# last change 24.01.02: argument list of fill_histo given explicitly (line 557)
#--------------------------------------------------------------------
%hash_variable = ( "rapidity_gam" => ["wy3"],
		   "rapidity_jet" => ["wyjet_lead"],
		   "x_gam_obs" => ["wxgamobs"],
		   "x_gam_obases" => ["wxgamobases"],
		   "x_gam_meas" => ["wxgameas"],
		   "x_gam_LL" => ["wxgamll"],
		   "x_p_obs" => ["wxpobs"],
		   "x_p_parton" => ["wxpparton"],
		   "x_p_LL" => ["wxpll"],
		   "p_perp" => ["wptra"],
		   "p_parallel" => ["wppa"],
		   "pt_jet" => ["wptjet_lead"],
		   "fi_gam_jet" => ["wfi_gamma_jet"],
		   "pperp" => ["wpperp"],
		   "pt_gam" => ["wpt3"],
		   "qt_gam_jet" => ["wqt_gamma_jet"],
		   "sum_ptgj" => ["wsum_gaj"],
		   "ave_ptgj" => ["wave_gaj"],
		   "min_pt_gj" => ["wmingj"],
		   "max_pt_gj" => ["wmaxgj"],
		   "x_fragmentation" => ["wx3"]);
$rh_variable = \%hash_variable;
#
##########################################################################
#
# Block 1: reads input parameters for integration part of the program 
# and generates param*.dat files and directories for the output
# (see explanations in "Readme")
# 
%hash_proc= ("ddir"=>"jgdd","dfrag"=>"jgdf","resodir"=>"jgrd","resofrag"=>"jgrf");
%hash_var = ();
@hash_var_clef = qw(namebs namepaw path_histo choix_histo choix_pdf flag_phostru 
 groupH1 setH1 H2 groupH2 setH2 fragfu choix_scale cm_M cm_mu cm_MF 
 loop_alfaem loop_alfas active_flavour hbarr_c ymin ymax q2max box_nobox  
 ptm r_th choix_process ho lo integ_function integ_abs_function generation 
 colli_fix_target sqrt_s eproton eelectron etamin etamax ptmin ptmax 
 iso_flag cone ifix eps_iso etmax jet_flag algo r_kt r_cone r_sep
 merging acceptance etajmin etajmax ptjmin ptjmax 
 nb_generated nb_itera_grid nb_itera_integ nb_call_two_to_three 
 nb_call_q_two_to_two nb_call_two_to_two nb_try accuracy
 weightg_ga jmin_dd jmax_dd jmin_df jmax_df jmin_rd jmax_rd jmin_rf jmax_rf);
$ivar = 0;
# read parameter input file and fill hash %hash_var
open (EREAD,$paramfile) || die "cannot open $paramfile";
#open (ETEST,">result");
while(<EREAD>) {
  chomp;
# chop white spaces at beginning of lines (and between words)
  s/^\s+//;
  unless (/^#/) {
    s/\s+//g; 
#    print ETEST "$hash_var_clef[$ivar]\n";
    $hash_var{$hash_var_clef[$ivar]} = "$_";
#    print ETEST "$hash_var{$hash_var_clef[$ivar]}\n";
    $ivar++;
  }
}
#close (ETEST);
close (EREAD);
#
# name to form path for directory where .bs files are stored
$name = $hash_var{"namebs"};
if ($name =~/\W/) {
    print "The 'name of the run' given in $paramfile contains special characters.\n";
    print "Please choose a name composed only of letters, numbers, underscore\n";
    exit; }
$namepaw = $hash_var{"namepaw"};
if ($namepaw =~/\W/) {
    print "The name for the histogram/ntuple file given in $paramfile contains special characters.\n";
    print "Please choose a name composed only of letters, numbers, underscore\n";
    exit; }
#to choose mrs99,pdflib
$pdf = $hash_var{"choix_pdf"};
$pdf =~ tr/A-Z/a-z/;
if ($pdf eq "mrs99") {$pdf = "mrst99"};
if ($pdf eq "mrst99" || $pdf eq "mrst01" || $pdf eq "mrst03" || $pdf eq "cteq5" || $pdf eq "cteq6") {
$pdflib_ornot_pdflib_hadron = "not_pdflib";}
elsif ($pdf eq "pdflib") {$pdflib_ornot_pdflib_hadron = "pdflib";}
else {print "You have to choose mrst99, mrst01, mrst03, cteq5, cteq6 or pdflib 
for the hadron structure functions !\n"; exit;}
#to choose output in histogram or ntuple form
$histo = $hash_var{"choix_histo"};
# for photon structure (AFG from grid or GRV etc. from pdflib)
$phostru = $hash_var{"flag_phostru"};
$phostru=~ tr/A-Z/a-z/;
unless ($phostru eq "afg" || $phostru eq "afg04" || $phostru eq "pdflib") {
   print "please check input for photon structure functions, \n";
   print "only the choices AFG, AFG04 or pdflib are possible for the photon structure functions!\n";
   exit;
}
if ($phostru eq "afg" || $phostru eq "afg04") {
$hash_var{"flag_phostru"} = "true";}
elsif ($phostru eq "pdflib")
{$hash_var{"flag_phostru"} = "false";}
#
################################################################################
# attribute ntype according to choice of pdfs
################################################################################
if ( $pdflib_ornot_pdflib_hadron eq "pdflib" ) {
  if ( ($hash_var{"H2"} == 1) || ($hash_var{"H2"} == 2) ) {
    $hash_var{"typeH2"} = 1
  }
  elsif ( $hash_var{"H2"} == 3 ) {
    $hash_var{"typeH2"} = 2
  }
  else {
    print "PDFLIB has been chosen for the hadron, 
    the choice of the type must be 1 (for a proton) or 2 (for an antiproton)
    or 3 (for a pion)\n";
    exit 4;
  }
}
else {
  if ( ($hash_var{"H2"} == 1) || ($hash_var{"H2"} == 2) ) {
    $hash_var{"typeH2"} = 1
  }
  elsif ( $hash_var{"H2"} == 3 ) {
    print "You cannot use $hash_var{\"choix_pdf\"} for a pion\n";
    exit 3;
  }
  else { print "Your input for the type of the initial hadron does 
  not match your choice of pdfs \n"; exit;
  }  
   if ( ($pdf eq "mrst99") || ($pdf eq "mrst01") || ($pdf eq "mrst03") ) {
	    $hash_var{"groupH2"} = 3;
	    if ( ($pdf eq "mrst99") && 
	      (($hash_var{"setH2"} < 199) || ($hash_var{"setH2"} > 210) )){
	      print "nset for mrst99 pdfs has to be a number 198 < nset < 210\n";
	      exit;
	      }
	    elsif ( ($pdf eq "mrst01") && 
	      ( ($hash_var{"setH2"} < 200) || ($hash_var{"setH2"} > 203) )){
	      print "nset for mrst01 pdfs has to be a number 199 < nset < 204\n";
	      exit;
	      }
	    elsif ( ($pdf eq "mrst03") && 
	      ( ($hash_var{"setH2"} < 200) || ($hash_var{"setH2"} > 201) )){
	      print "nset for mrst03 pdfs has to be a number 199 < nset < 202\n";
	      exit;
	      }
	    }
   elsif ( ($hash_var{"choix_pdf"} eq "cteq5") || 
              ($hash_var{"choix_pdf"} eq "cteq6") ) {
	      $hash_var{"groupH2"} = 4;
	      if ( ($pdf eq "cteq5") && 
	        (($hash_var{"setH2"} < 1) || ($hash_var{"setH2"} > 7)) ){
	        print "nset for cteq5 pdfs has to be a number 1 <= nset <= 7\n";
		exit;
		}
	      elsif ( ($pdf eq "cteq6") && 
	        ( ($hash_var{"setH2"} < 1) || ($hash_var{"setH2"} > 3)) ){
	        print "nset for cteq6 pdfs has to be a number 0 <= nset <= 3\n";
		exit;
		}
   }	
   else { 
        print "The PDFS you chose are not implemented. Choose either 
	       'pdflib' or use mrst99, mrst01, mrst03, cteq5 or cteq6 \n";
        exit 6;
   }	
}
##########################################################################
# check if hadron or photon frag functions have been selected and
# modify/compile Makefile accordingly
$makefi="Makefile";
$frag=$hash_var{"fragfu"};
@listfrag=split(//,$frag);
#$centaine=$listfrag[0];
$dizaine=$listfrag[1];
#$unite=$listfrag[2];
#print "$centaine,$dizaine,$unite\n";
if ($dizaine==0) {
  $phothad="photon";
  $makeoption="ephox$name";
  }
elsif ($dizaine>7) {
  print "Please check the number which selects the fragmentation functions\n";
  print "The set you chose is not implemented !\n";
}
else {$phothad="hadron";
      $makeoption="ephad$name";
      }
#print "$phothad\n";
############### modify the Makefile if necessary #######################
open(EP,$makefi) || die "cannot open $makefi" ;
open(ES,">Makefile_temp") || die "cannot create Makefile_temp" ;
while (<EP>) {
 chomp;
 if (/\bCHOIXPDF\t=/) {
   s/CHOIXPDF\t=\s(\w+)/CHOIXPDF\t= $pdf/;
 }
 if (/\bPHOTSTRU\t=/) {
   s/PHOTSTRU\t=\s*(\w+)/PHOTSTRU\t= $phostru/;
 }
 if (/\bCHOIXHISTO\t=/) {
   s/CHOIXHISTO\t=\s(\w+)/CHOIXHISTO\t= $histo/;
 }
 if ($phothad eq "photon") {
     if (/\bephox.*:/) {
     s/ephox.*:/ephox$name:/;
     }
 }
  if ($phothad eq "hadron") {
     if (/\bephad.*:/) {
     s/ephad.*:/ephad$name:/;
     }
 }      
 print ES "$_\n";
}
close(EP);
close(ES);
system("mv Makefile_temp $makefi");
#
# create directory where results will be stored (subdirectories for selected 
# subprocesses will be created later)
$res_directory ="result".$name;
unless (-e $res_directory) {
  system("mkdir $res_directory");
}
# list of subprocesses selected by the user
@list_process = split(/,/,$hash_var{"choix_process"});
#
open(EALL,">run$name.exe") || die "cannot create run$name.exe" ;
foreach $process (@list_process) {
#open(EALL,">run$name$process.exe") || die "cannot create run$name$process.exe" ;
# print EALL "#!/bin/csh\n";
# print EALL "#\n";
# print EALL "#\$ -l medium\n";
# print EALL "#\$ -N $name$process\n";
# print EALL "#\$ -cwd\n";
 unless ($process eq "ddir" || $process eq "resodir" || $process eq "dfrag" || 
         $process eq "resofrag") {
	 print "Possible subprocess contributions are only ddir,dfrag,resodir,resofrag \n";
	 exit;
	 }
 if ( ($process eq "ddir" || $process eq "resodir") && ($phothad eq "hadron") ) {
    print "You cannot choose subprocesses with a 'direct' final state for the production of hadrons !\n";
    print "Please choose a photon fragmentation function if you would like to produce photons, \n";
    print "or only fragmentation subprocesses if you would like to produce hadrons\n";
    exit;
    }
 $ntuple = $hash_proc{"$process"};
 @list = ($process,$name);
 $name_dir = join("",@list);
 @list_nt = ($ntuple,$namepaw);
 $name_histo = join("",@list_nt);
 @list_path = ($hash_var{"path_histo"},$name_histo);
 $name_path = join("/",@list_path);
 @list_name = ("param",$process);
 $name_dat = join("_",@list_name);
#
# create subdirectory for subprocess $process if it doesn't exist already
$res_subdir=$res_directory."/".$name_dir;
unless (-e $res_subdir) {
   system("mkdir $res_subdir");
 }
#
 open(ES,">$name_dat$name.dat") || die "cannot create $name_dat$name.dat" ;
 print ES "'$res_directory/$name_dir/' \t path for the .bs file\n";
# print ES "'$namepaw' \t name for the histo .dat file or ntuple\n";
 print ES "'$name_path' \t path for the ntuple\n";
 print ES "$hash_var{\"flag_phostru\"} \t\t local grid (AFG) or pdflib used for photon structure\n";
 print ES "3 \t\t for pdflib (resolved photon): ntype\n";
 print ES "$hash_var{\"groupH1\"} \t\t for pdflib(resolved photon): ngroup\n";
 print ES "$hash_var{\"setH1\"} \t\t for pdflib(resolved photon): nset\n";
 print ES "$hash_var{\"H2\"} \t\t type of hadron: 1 proton, 0 anti-proton, 3 pion\n";
# print ES "2 \t\t type of other incoming particle fixed: 2 = e -> photon\n";
 print ES "$hash_var{\"typeH2\"} \t\t for pdflib(hadron h2): ntype\n";
 print ES "$hash_var{\"groupH2\"} \t\t for pdflib(hadron h2): ngroup\n";
 print ES "$hash_var{\"setH2\"} \t\t for pdflib(hadron h2): nset\n";
 print ES "$hash_var{\"fragfu\"} \t\t type of fragmentation functions: 301 owens, 402 bourhis set2 \n";
 print ES "$hash_var{\"choix_scale\"} \t\t choice of the scale: 1 pt_gamma*cm, 2 (pt3+pt_gam)*cm\n";
 print ES "$hash_var{\"cm_M\"} \t\t value of cm for initial state factorisation scale\n";
 print ES "$hash_var{\"cm_mu\"} \t\t value of cm for renormalisation scale\n";
 print ES "$hash_var{\"cm_MF\"} \t\t value of cm for final state factorisation scale\n";
 print ES "$hash_var{\"loop_alfaem\"} \t\t nb of loops in alpha_em:0 constant else jetset\n";
 print ES "$hash_var{\"loop_alfas\"} \t\t nb of loops in alpha_s:1 LO, 2 NLO\n";
 print ES "$hash_var{\"active_flavour\"} \t\t nb of active flavours\n";
 print ES "$hash_var{\"hbarr_c\"}\t\t value of (hbarr*c)^2\n";
 print ES "$hash_var{\"ymin\"}\t\t value of yinf for Gamstru\n";
 print ES "$hash_var{\"ymax\"}\t\t value of ysup for Gamstru \n";
 print ES "$hash_var{\"q2max\"}\t\t value of q2maxw for Weizsaecker-Will.\n";
 print ES "$hash_var{\"box_nobox\"} \t\t for the direct part:0 born only,1 box only, 2 born+box\n"; 
# print ES "$hash_var\t\t cut (from below) on x_gam^obs\n";
 print ES "$hash_var{\"ptm\"} \t\t value of PTM in GeV\n";
 print ES "$hash_var{\"r_th\"} \t\t value of R_th\n";
#
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"ho"})])->{$process};
 print ES "$temp \t\t to select NLO\n";
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"lo"})])->{$process};
 print ES "$temp \t\t to select LO\n";
 print ES "$hash_var{\"integ_function\"} \t\t if true only integration (integrated cross-section)\n";
 print ES "$hash_var{\"integ_abs_function\"} \t\t if true only integration (just to make the grid, no physical meaning)\n";
 print ES "$hash_var{\"generation\"} \t\t if true only generation\n";
# KINEMATICS
 print ES "$hash_var{\"colli_fix_target\"} \t\t 0 collider mode, 1 fixed target mode\n";
 print ES "$hash_var{\"sqrt_s\"} \t\t value of sqrt(s) (GeV)\n";
 print ES "$hash_var{\"eproton\"} \t\t value of proton energy in LAB frame (GeV)\n";
 print ES "$hash_var{\"eelectron\"} \t\t value of electron energy in LAB frame (GeV) \n";
# print ES "1/2.d0*dlog($hash_var{\"eproton\"}/$hash_var{\"eelectron\"})\t\t value of rapidity shift to go from LAB_HERA to CMS frame\n";
 print ES "$hash_var{\"etamin\"} \t\t value of min rapidity for photon\n";
 print ES "$hash_var{\"etamax\"} \t\t value of max rapidity for photon\n";
# integrate parton 3 (if 4 is photon) always over full range; jets are defined below
# print ES "-4.3D0 \t\t value of min rapidity for final parton \n";
# print ES " 7.7D0\t\t value of max rapidity for final parton \n";
 print ES "$hash_var{\"ptmin\"} \t\t value of ptmin of photon in GeV\n";
 print ES "$hash_var{\"ptmax\"} \t\t value of ptmax of photon in GeV\n";
# print ES "150.D0 \t\t value of ptmax of final parton in GeV\n";
# print ES "0.D0 \t\t value of ptmin of final parton in GeV\n";
 print ES "$hash_var{\"iso_flag\"} \t\t turns on/off isolation for photon: 0 no isolation, 1 isolation\n";
# print ES "$hash_var{\"flagfrix\"} \t\t choice of isolation criterion: 0 usual cone isolation, 1 Frixione\n";
 print ES "$hash_var{\"cone\"} \t\t value of photon isolation cone radius\n";
 print ES "$hash_var{\"ifix\"} \t\t flag to choose between an Et_max which depends on the photon pt and a fixed Et_max \n";
 print ES "$hash_var{\"eps_iso\"} \t\t if 0 has been chosen before: value of epsilon to define Edep_max in isolation cone\n";
 print ES "$hash_var{\"etmax\"} \t\t value to define fixed Et_max \n";
 print ES "$hash_var{\"jet_flag\"} \t\t flag for inclusive or jets; 0:inclusive, 1:jets\n";
 print ES "'$hash_var{\"algo\"}' \t\t choice of jet algorithm\n";
 print ES "$hash_var{\"r_kt\"}\t\t value of r_kt for kt algorithm\n";
 print ES "$hash_var{\"r_cone\"} \t\t value of r_cone for cone algorithm\n";
 print ES "$hash_var{\"r_sep\"} \t\t value of r_sep for cone algorithm with seeds\n";
 print ES "'$hash_var{\"merging\"}' \t\t merging rules\n";
 print ES "'$hash_var{\"acceptance\"}' \t\t acceptance of the events\n";
 print ES "$hash_var{\"etajmin\"} \t\t value of min jet rapidity\n";
 print ES "$hash_var{\"etajmax\"} \t\t value of maximal jet rapidity \n";
 print ES "$hash_var{\"ptjmin\"} \t\t value of Etjet_min\n";
 print ES "$hash_var{\"ptjmax\"} \t\t value of Etjet_max\n";
# BASES/SPRING 
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"nb_generated"})])
 ->{$process};
 print ES "$temp \t\t nb of generated events\n";
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"nb_itera_grid"})])
 ->{$process};
 print ES "$temp \t\t nb of iterations for the grid step\n";
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"nb_itera_integ"})])
 ->{$process};
 print ES "$temp \t\t nb of iterations for the integration step\n";
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"nb_call_two_to_three"})])
 ->{$process};
 print ES "$temp \t\t nb of calls per iteration for two to three\n";
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"nb_call_q_two_to_two"})])
 ->{$process};
 print ES "$temp \t\t nb of calls per iteration for quasi two to two\n";
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"nb_call_two_to_two"})])
 ->{$process};
 print ES "$temp \t\t nb of calls per iteration for true two to two\n";
 print ES "$hash_var{\"nb_try\"} \t\t nb of tries for spring\n";
 $temp = 
 list_to_hash1(\@list_process,[split(/,/,$hash_var{"accuracy"})])->{$process};
 print ES "$temp \t\t accuracy in per cent for Bases\n";
#
 if ($process eq "ddir")  {
    print ES "TRUE \t\t to select the  initial direct final direct part\n";
    print ES "FALSE \t\t to select the initial direct final frag part\n";
    print ES "FALSE \t\t to select the initial resolved final direct part\n";
    print ES "FALSE \t\t to select the initial resolved final frag part\n";}
  elsif ($process eq "dfrag") {
    print ES "FALSE \t\t to select the initial direct final direct part\n";
    print ES "TRUE \t\t to select the  initial direct final frag part\n";
    print ES "FALSE \t\t to select the initial resolved final direct part\n";
    print ES "FALSE \t\t to select the initial resolved final frag part\n";}
  elsif ($process eq "resodir") {
    print ES "FALSE \t\t to select the initial direct final direct part\n";
    print ES "FALSE \t\t to select the initial direct final frag part\n";
    print ES "TRUE \t\t to select the initial resolved final direct part\n";
    print ES "FALSE \t\t to select the initial resolved final frag part\n";}
   elsif ($process eq "resofrag") {
    print ES "FALSE \t\t to select the initial direct final direct part\n";
    print ES "FALSE \t\t to select the initial direct final frag part\n";
    print ES "FALSE \t\t to select the initial resolved final direct part\n";
    print ES "TRUE \t\t to select the initial resolved final frag part\n";} 
# FOR TESTS
 print ES "$hash_var{\"weightg_ga\"} \t\t weight to scale gluon distribution in the photon\n";
 print ES "$hash_var{\"jmin_dd\"} \t\t to select j_processd_min in direct direct part\n";
 print ES "$hash_var{\"jmax_dd\"} \t\t to select j_processd_max in direct direct part\n";
 print ES "$hash_var{\"jmin_df\"} \t\t to select j_processo_min in direct frag part\n";
 print ES "$hash_var{\"jmax_df\"} \t\t to select j_processo_max in direct frag part\n";
 print ES "$hash_var{\"jmin_rd\"} \t\t to select j_processresd_min in resolved direct part\n";
 print ES "$hash_var{\"jmax_rd\"} \t\t to select j_processresd_max in resolved direct part\n";
 print ES "$hash_var{\"jmin_rf\"} \t\t to select j_processreso_min in resolved frag part\n";
 print ES "$hash_var{\"jmax_rf\"} \t\t to select j_processreso_max in resolved frag part\n";
 close(ES);
 # creation du fichier executable
 print EALL "./$makeoption.exe < $name_dat$name.dat > $res_directory/$name_dir/ephox.log\n";
# print EALL "rm $name_dat$name.dat";  
# close(EALL);
# system("chmod +x run$name$process.exe"); 
}
 close(EALL);
 system("chmod +x run$name.exe"); 
#
#
##############################################################
# Block 2: histo_gener.pl part
##############################################################
# generates Fortran subroutines  which fill histograms
# according to parameters specified in param_histo.indat
# Block 2 is skipped if generation is not required or if output is stored in Ntuples
#
$gt = $hash_var{"generation"};
# remove possible blanks at beginning and end
$gt =~ s/^\s*\W.*//;
$histo =~ s/^\s*\W.*//;
if ($gt =~ /TRUE.*/i and $histo =~ /histo/i) {
#print "generation of FORTRAN files for filling of histograms OK\n";
#print "(based on the input parameters you gave in the file $param_histo)\n";
#print "\n";
#print "please do not forget to recompile if parameters for histos have changed\n";
#print "\n";
#
$path_histo = "../src/histo/perlmod";
#$path_histo = ".";
$namepaw=$hash_var{"namepaw"}; #for file that summarizes histo input parameters
$fortran_init = "$path_histo/init_paw.f";
$fortran_end = "$path_histo/end_paw.f";
$nomgfill = "$path_histo/fill_histo.f";
$nomkinem = "$path_histo/cuts_etc.f";
$nb_temp = [split(/,/,$hash_var{"nb_generated"})];
$nb_event = $nb_temp->[0];
# 
$ivar = 0;
$ihisto_equi = 0;
$ihisto_nonequi = 0;
%hash_var_histo = ();
@list_nom = ();
@list_order = ();
@list_cut = ();
@list_titre = ();
@list_nb_bin = ();
@list_xmin = ();
@list_xmax = ();
@list_ref_bin_value= ();
@list_ref_histo_equi = ();
@list_ref_histo_nonequi = ();
#---------------------------------------------------------------------
# read input parameters for histos and fill %hash_var_histo and write an 
# info on chosen parameters into histo$namepaw.outdat
# also fill a list @list_cutvalues with the read parameters (serves
# to keep order of arguments for subroutines cuts_ets and fill_histo)
@list_cutvalues=();
open (EREAD,$param_histo) || die "cannot open $param_histo";
open (EWRITE,">$res_directory/histo$namepaw.outdat") || die "cannot open
$res_directory/histo$namepaw.outdat";
#open (EWRITE,">$res_directory/histo.outdat") || die "cannot open $res_directory/histo.outdat";
while(<EREAD>) {
  chomp;
    s/^\s+//;
  unless (/^#/ || /^histo_equi/ || /^histo_nonequi/ || /^scatter_equi/) {  
# remove blanks
    s/\s+//g; 
    $hash_var_histo{$list_var_histo_clef[$ivar]} = "$_";
    push (@list_cutvalues, $_);
    print EWRITE "$list_var_histo_clef[$ivar]  $_\n";
    $ivar++;
  }
  if (/^histo_equi/) {
    s/\s$//;
    s/\s+/ /g;
    print EWRITE "$_\n";
    my ($temp_dummy,$temp_nom,$temp_order,$temp_cut,$temp_titre,$temp_nb_bin,$temp_xmin,$temp_xmax);
    ($temp_dummy,$temp_nom,$temp_order,$temp_cut,$temp_titre,$temp_nb_bin,$temp_xmin,$temp_xmax) = 
    			split(/ /,$_);
    push (@list_nom,$temp_nom);
    push (@list_order,$temp_order);
    push (@list_cut,$temp_cut);
    push (@list_titre,$temp_titre);
    push (@list_nb_bin,$temp_nb_bin);
    push (@list_xmin,$temp_xmin);
    push (@list_xmax,$temp_xmax);
    $ihisto_equi++;
  }
  if (/^histo_nonequi/) {
    s/\s$//;
    s/\s+/ /g;
    print EWRITE "$_\n";
     if ($ihisto_equi==0) {
     $nonequifirst="true";
     }
     else {$nonequifirst="false";
     }
    my ($temp_dummy,$temp_nom,$temp_order,$temp_cut,$temp_titre,
    $temp_nb_bin,@temp_bin_value,$rl_temp);
    ($temp_dummy,$temp_nom,$temp_order,$temp_cut,$temp_titre,
    $temp_nb_bin,@temp_bin_value) = 
    			split(/ /,$_);
    push (@list_nom,$temp_nom);
    push (@list_order,$temp_order);
    push (@list_cut,$temp_cut);
    push (@list_titre,$temp_titre);
    push (@list_nb_bin,$temp_nb_bin);
    $rl_temp=\@temp_bin_value;
    push (@list_ref_bin_value,$rl_temp);
    $ihisto_nonequi++;
#    print "temp_cut=$temp_cut\n";
#    foreach $l (@$rl_temp) { print "binedge = $l\n";}
  }  
}
close (EREAD);
close (EWRITE);
@listval{@def_var}=@list_cutvalues;
##################################################################################
# include warnings if jet definitions and cuts for histo are not compatible with
# those uesed for the grid
# photon/hadron rapidity and pt cuts:
       $vetamin="$hash_var{\"etamin\"}";
       $hietamin="$listval{\"y_photmin\"}";
       $vetamin=~tr/A-Z/a-z/;
       $vetamin=~s/d0//;
       $hietamin=~tr/A-Z/a-z/;
       $hietamin=~s/d0//;
#       $vetamin=~s/^.(\d)/0.$1/;
       $vetaminabs=abs($vetamin);
       $hietaminabs=abs($hietamin);
       if ($vetamin<0) {$negv="true"}
       else {$negv="false"}
       if ($hietamin<0) { $neghi="true"}
       else {$neghi="false"}
#        print "vetamin= $vetamin\n";
	if ($negv eq "true" and $neghi eq "true") {
             if ($hietaminabs gt $vetaminabs) {
              print "Warning: You defined a lower cut on the $phothad rapidity of '$vetamin' in $paramfile,
	    which is larger than the cut '$hietamin' you chose in $param_histo. 
	    If your grid has been made with eta_${phothad}_min = $vetamin 
	    there will be no events for eta_${phothad}_min < $vetamin \n";
	       }
         }
	 elsif ($negv eq "false" and $neghi eq "true") {
         print "Warning: You defined a lower cut on the $phothad rapidity of '$vetamin' in $paramfile,
	    which is larger than the cut '$hietamin' you chose in $param_histo. 
	    If your grid has been made with eta_${phothad}_min = $vetamin 
	    there will be no events for eta_${phothad}_min < $vetamin \n";	 
	 }
	 elsif ($negv eq "false" and $neghi eq "false") {
	     if ($hietaminabs lt $vetaminabs) {
              print "Warning: You defined a lower cut on the $phothad rapidity of '$vetamin' in $paramfile,
	    which is larger than the cut '$hietamin' you chose in $param_histo. 
	    If your grid has been made with eta_${phothad}_min = $vetamin 
	    there will be no events for eta_${phothad}_min < $vetamin \n";
	       }
         }
       $vetamax="$hash_var{\"etamax\"}";
       $vetamax=~tr/A-Z/a-z/;
       $vetamax=~s/d0//;
       $hietamax="$listval{\"y_photmax\"}";
       $hietamax=~tr/A-Z/a-z/;
       $hietamax=~s/d0//;       
       if ("$hietamax" ne "$vetamax") {
          if ("$hietamax" gt "$vetamax") {
           print "Warning: You defined an upper cut on the $phothad rapidity of '$vetamax' in $paramfile,
	 which is smaller than the cut '$hietamax' you chose in $param_histo. 
	 If your grid has been made with eta_${phothad}_max = $vetamax 
	 there will be no events for eta_${phothad}_max > $vetamax \n";
	    }
        }
       $vptmin="$hash_var{\"ptmin\"}";
       $vptmin=~tr/A-Z/a-z/;
       $vptmin=~s/d0//;
       $hiptmin="$listval{\"pt_photmin\"}";
       $hiptmin=~tr/A-Z/a-z/;
       $hiptmin=~s/d0//;       
       if ("$hiptmin" ne "$vptmin") {
          if ("$hiptmin" lt "$vptmin") {
           print "Warning: You defined a lower cut on the $phothad pT of '$vptmin' in $paramfile,
	 which is larger than the cut '$hiptmin' you chose in $param_histo. 
	 If your grid has been made with pt_${phothad}_min = $vptmin 
	 there will be no events for pt_${phothad}_min < $vptmin \n";
	    }
	  else {print "Warning: The lower cut on the $phothad pT of '$vptmin' in $paramfile,
	 is different from the cut '$hiptmin' you chose in $param_histo. 
	 Please verify that this was your intention.\n";	    
         }
	} 
       $vptmax="$hash_var{\"ptmax\"}";
       $vptmax=~tr/A-Z/a-z/;
       $vptmax=~s/d0//;
       $hiptmax="$listval{\"pt_photmax\"}";
       $hiptmax=~tr/A-Z/a-z/;
       $hiptmax=~s/d0//;       
#       print "pt_photmax = $listval{\"pt_photmax\"}\n";
       if ("$hiptmax" ne "$vptmax") {
          if ("$hiptmax" gt "$vptmax") {
           print "Warning: You defined an upper cut on the $phothad pT of '$vptmax' in $paramfile,
	 which is smaller than the cut '$hiptmax' you chose in $param_histo. 
	 If your grid has been made with pt_${phothad}_max = $vptmax 
	 there will be no events for pt_${phothad}_max > $vptmax \n";
	    }
	    else {print "Warning: The upper cut on the $phothad pT of '$vptmax' in $paramfile,
	 is different from the cut '$hiptmax' you chose in $param_histo. 
	 Please verify that this was your intention.\n";}
        }
################ JETS: #########################################################
if ("$hash_var{\"jet_flag\"}" eq "1") {
#
#  foreach $l (keys(%listval)) {
#    print  "$l, $listval{$l}\n"; 
#  }   
    if ("$hash_var{\"algo\"}" ne "$listval{\"algorithm\"}") {
        print "Warning: You chose '$hash_var{\"algo\"}' as jet algorithm in $paramfile 
	 and '$listval{\"algorithm\"}' as jet algorithm in $param_histo. 
	 These two choices are not compatible.\n"; exit;
     }
     if ("$hash_var{\"merging\"}" ne "$listval{\"merging\"}") {
         print "Warning: You chose '$hash_var{\"merging\"}' as jet merging rule in $paramfile 
	 and '$listval{\"merging\"}' as merging rule in $param_histo. 
	 These two choices are not compatible.\n"; exit;
     }
    if ("$hash_var{\"acceptance\"}" ne "$listval{\"acceptance\"}") {
        print "Warning: You chose '$hash_var{\"acceptance\"}' as acceptance in $paramfile 
	 and '$listval{\"acceptance\"}' as acceptance in $param_histo. 
	 These two choices are not compatible.\n"; exit;
     }
    if  ("$hash_var{\"algo\"}" eq "kt") {
       $vpar="$hash_var{\"r_kt\"}";
       $vpar=~tr/A-Z/a-z/;
       $vpar=~s/d0//;
       $hipar="$listval{\"r_kt\"}";
       $hipar=~tr/A-Z/a-z/;
       $hipar=~s/d0//;       
       if ("$hipar" ne "$vpar") {
         if ("$hipar" gt "$vpar") {
          print "Warning: You defined a cone radius of '$vpar' in $paramfile,
	   which is smaller than the cone radius '$listval{\"r_kt\"}' you chose in $param_histo. 
	   As your grid has been made with cone radius $vpar, 
	   defining a larger cone radius at histogrammation level makes no sense. \n";exit;
         }
	 else {
	       print "Warning: The cone radius '$vpar' defined in $paramfile
	 is different from the cone radius '$listval{\"r_kt\"}' chosen in $param_histo.
	 Please verify that this was your intention.\n";
	 }
       }
     }
    if  ("$hash_var{\"algo\"}" eq "co" || "$hash_var{\"algo\"}" eq "se" ) {
       $vpar="$hash_var{\"r_cone\"}";
       $vpar=~tr/A-Z/a-z/;
       $vpar=~s/d0//;
       $hipar="$listval{\"r_c\"}";
       $hipar=~tr/A-Z/a-z/;
       $hipar=~s/d0//;
#       print "vpar = $vpar\n";
       if ("$hipar" ne "$vpar") {
          if ("$hipar" gt "$vpar") {
           print "Warning: You defined a cone radius of '$vpar' in $paramfile,
	    which is smaller than the cone radius '$listval{\"r_c\"}' you chose in $param_histo. 
	    As your grid has been made with cone radius $vpar, 
	    defining a larger cone radius at histogrammation level makes no sense. \n";exit;
	    }
	   else {
	       print "Warning: The cone radius '$vpar' defined in $paramfile
	 is different from the cone radius '$listval{\"r_c\"}' chosen in $param_histo.
	 Please verify that this was your intention.\n";
	   }
        }
     }
    if  ("$hash_var{\"algo\"}" eq "se") {
       $vpar="$hash_var{\"r_sep\"}";
       $vpar=~tr/A-Z/a-z/;
       $vpar=~s/d0//;
       $hipar="$listval{\"r_sep\"}";
       $hipar=~tr/A-Z/a-z/;
       $hipar=~s/d0//;
#       print "vpar = $vpar\n";
       if ("$hipar" ne "$vpar") {
	  print "Warning: The value '$vpar' for r_sep defined in $paramfile 
	  is different from the value  '$listval{\"r_sep\"}' for r_sep chosen in $param_histo.
	  Please verify that this was your intention.\n";
	   }
     }
# jet rapidity and pt cuts:
       $vetajmin="$hash_var{\"etajmin\"}";
       $hietajmin="$listval{\"y_jetmin\"}";
       $vetajmin=~tr/A-Z/a-z/;
       $vetajmin=~s/d0//;       
       $hietajmin=~tr/A-Z/a-z/;
       $hietajmin=~s/d0//;
       $vetajminabs=abs($vetajmin);
       $hietajminabs=abs($hietajmin);
       if ($vetajmin<0) {$negv="true"}
       else {$negv="false"}
       if ($hietajmin<0) { $neghi="true"}
       else {$neghi="false"}
#        print "vetajmin= $vetajmin\n";
	if ($negv eq "true" and $neghi eq "true") {
             if ($hietajminabs gt $vetajminabs) {
              print "Warning: You defined a lower cut on the jet rapidity of '$vetajmin' in $paramfile,
	    which is larger than the cut '$listval{\"y_jetmin\"}' you chose in $param_histo. 
	    If your grid has been made with etajet_min = $vetajmin 
	    there will be no events for etajet_min < $vetajmin \n";
	       }
         }
	 elsif ($negv eq "false" and $neghi eq "true") {
         print "Warning: You defined a lower cut on the jet rapidity of '$vetajmin' in $paramfile,
	    which is larger than the cut '$listval{\"y_jetmin\"}' you chose in $param_histo. 
	    If your grid has been made with etajet_min = $vetajmin 
	    there will be no events for etajet_min < $vetajmin \n";	 
	 }
	 elsif ($negv eq "false" and $neghi eq "false") {
	     if ($hietajminabs lt $vetajminabs) {
              print "Warning: You defined a lower cut on the jet rapidity of '$vetajmin' in $paramfile,
	    which is larger than the cut '$listval{\"y_jetmin\"}' you chose in $param_histo. 
	    If your grid has been made with etajet_min = $vetajmin 
	    there will be no events for etajet_min < $vetajmin \n";
	       }
         }

       $vetajmax="$hash_var{\"etajmax\"}";
       $hietajmax="$listval{\"y_jetmax\"}";
       $vetajmax=~tr/A-Z/a-z/;
       $vetajmax=~s/d0//;
       $hietajmax=~tr/A-Z/a-z/;
       $hietajmax=~s/d0//;
       if ("$hietajmax" ne "$vetajmax") {
          if ("$hietajmax" gt "$vetajmax") {
           print "Warning: You defined an upper cut on the jet rapidity of '$vetajmax' in $paramfile,
	 which is smaller than the cut '$listval{\"y_jetmax\"}' you chose in $param_histo. 
	 If your grid has been made with etajet_max = $vetajmax 
	 there will be no events for etajet_max > $vetajmax \n";
	    }
        }
       $vptjmin="$hash_var{\"ptjmin\"}";
       $hiptjmin="$listval{\"pt_jetmin\"}";
       $vptjmin=~tr/A-Z/a-z/;
       $vptjmin=~s/d0//;
       $hiptjmin=~tr/A-Z/a-z/;
       $hiptjmin=~s/d0//;       
       if ("$hiptjmin" ne "$vptjmin") {
          if ("$hiptjmin" lt "$vptjmin") {
           print "Warning: You defined a lower cut on the jet pT of '$vptjmin' in $paramfile,
	 which is larger than the cut '$listval{\"pt_jetmin\"}' you chose in $param_histo. 
	 If your grid has been made with ptjet_min = $vptjmin 
	 there will be no events for ptjet_min < $vptjmin \n";
	    }
        }
       $vptjmax="$hash_var{\"ptjmax\"}";
       $hiptjmax="$listval{\"pt_jetmax\"}";
       $vptjmax=~tr/A-Z/a-z/;
       $vptjmax=~s/d0//;
       $hiptjmax=~tr/A-Z/a-z/;
       $hiptjmax=~s/d0//;
       if ("$hiptjmax" ne "$vptjmax") {
          if ("$hiptjmax" gt "$vptjmax") {
           print "Warning: You defined an upper cut on the jet pT of '$vptjmax' in $paramfile,
	 which is smaller than the cut '$listval{\"pt_jetmax\"}' you chose in $param_histo. 
	 If your grid has been made with ptjet_max = $vptjmax 
	 there will be no events for ptjet_max > $vptjmax \n";
	    }
        }


} # end if $hash_var{\"jet_flag\"} eq 1
#
#  foreach $l (@list_cut) {print "$l\n";}
#
#
############ end of filling of lists ##################################
# pour chaque histo, on donne (dans param_histo.indat):
# le nombre de bin
# un flag pour savoir si les bins sont equi distants
# le maximum et minimum ou un tableau donnant les valeurs inferieurs de chaque bin + la valeur superieure pour le dernier bin
# un identificateur
# un titre
# ici on cree une reference a tous les objets du package Histo_equi ou
# Histo_non equi
# 
# order of definition for histo_equi and histo_non_equi in paw_param.dat 
# should not matter!
#
#
$nb_histo=$ihisto_equi+$ihisto_nonequi;
if ($ihisto_nonequi==0) {
$nonequifirst="false";
}
if ($nonequifirst eq "true") {
#   print "$ihisto_nonequi nonequidistant histos have been defined first\n";
   $ihn = $ihisto_nonequi;
   }
else  {$ihn = 0;}  
for ($ih=$ihn;$ih < $ihisto_equi+$ihn;$ih++) {
    $help=eval($ih-$ihn);
    my $r_histo = Histo_equi::new(eval($ih+1),eval(20+$ih),
		    $list_nom[$ih],$list_order[$ih],$list_cut[$ih],
		    $list_titre[$ih],$list_nb_bin[$ih],
		    $list_xmin[$help],$list_xmax[$help]);
    push (@list_ref_histo_equi,$r_histo);
#    print "nom = $list_nom[$ih]\n";
#    print "maxbin = $list_xmax[$help]\n";
}
if ($nonequifirst eq "true") {
   $ih = 0;
   }
else {
   $ih = $ihisto_equi;
   }
# $list_nodouble serves to write name of histos for same variables but 
# different binnings or cuts only once into the common block
# but lo and nlo for same variable each need an entry!
# (this was a bug, corrected 12.1.04)
@list_nodouble=();
$firstneq=eval($ih+1);
$count_same=0;
$count_order=1;
#$othervar=0;
for ($j=$ih+1; $j <= $ih+$ihisto_nonequi;$j++) {
    $l = $j-$ihisto_equi-1;
    my $r_histo = Histo_nonequi::new(eval($j),eval(19+$j),
		    $list_nom[$j-1],$list_order[$j-1],$list_cut[$j-1],
		    $list_titre[$j-1],$list_nb_bin[$j-1],
		    $list_ref_bin_value[$l]);
    if ($j eq $ih+1) {
    push (@list_ref_histo_nonequi,$r_histo);
    push (@list_nodouble,$r_histo);
    }
    else {
    	push (@list_ref_histo_nonequi,$r_histo);            
	if ($list_nom[$j-1] eq $list_nom[$firstneq-1]) {
	      $count_same++;
#	      print "j=$j\n";
#              print "count_same=$count_same\n";
#              print "list_nom=$list_nom[$j-1]\n";
#              print "list_order=$list_order[$j-1]\n";
	      unless ($list_order[$j-1] eq $list_order[$firstneq-1]) {
	          if ($count_order<2) {
		    $count_order++;
#		    push (@list_ref_histo_nonequi,$r_histo);
		    push (@list_nodouble,$r_histo);
		  }
	      }
	    }  
	    else {
	    $count_order=1;
	    $count_same_old=$count_same;
	    $count_same=0;
	    $firstneq=$firstneq+$count_same_old+1;
#	    print "firstneq=$firstneq\n";
#            push (@list_ref_histo_nonequi,$r_histo);
	    push (@list_nodouble,$r_histo);
	    }
     }	    	    
}
#
$leprelist_nodouble=eval(@list_nodouble);
#print "leprelist_nodouble=$leprelist_nodouble\n"; 
$lelist_nodouble=minoflist($leprelist_nodouble,$ihisto_nonequi);
#print "ihisto_nonequi=$ihisto_nonequi\n"; 
#######################################################
# write cut variables to subroutine cuts_etc
open (HISTO,">$nomkinem")|| die "cannot create  $nomkinem";
$histo = *HISTO;
print HISTO "\tsubroutine cuts_etc(rs,yshift,\n";
print HISTO  "     #  ";
$k=1;
$lecutv = eval(@list_var_histo_clef-1);
$lecheck = eval(@def_var-1);
if ($lecutv != $lecheck) { 
   print "warning: number of cut variables does not correspond to number of keys
   in list_var_histo_clef !\n";
}
foreach $l (@def_var) {
  $helpa=int($k % 6);
#  print "$helpa\n";
  if ($l eq "rad" || $l eq "degree") {
     print HISTO "";}
  else {  
       if ($helpa == 0) {
          print HISTO "\n";
          print HISTO "     #  $l,";
       }
       else { 
             if ($k < eval($lecutv)) {
                 print HISTO "$l,"; 
             }
             else { print HISTO "$l)\n"; }	  
       }
   $k++;
  }
}
#@stringhash{values(%cut_var_string)}= values(%hash_var_histo);
print HISTO "\timplicit real*8 (a-h,l-z)\n";
print HISTO "\tcharacter*2 algorithm,merging,acceptance\n";
print HISTO "c\n";
print HISTO "c\t ordering below by hasard since rewritten by perl\n";
print HISTO "c\n";
print HISTO "c sqrt of S (GeV)  (needed for def of xgamma)\n";
print HISTO "\trs = $hash_var{\"sqrt_s\"}\n";
print HISTO "c rapidity shift to LAB frame \n";
print HISTO "\tyshift = dlog($hash_var{\"eproton\"}/$hash_var{\"eelectron\"})/2.d0\n";
print HISTO "c\n";
while (($key,$value) = each(%listval)) {
   if ($key eq "algorithm" || $key eq "merging" || $key eq "acceptance"){
   print HISTO "\t$key = '$value'\n";}
   else{
     unless ($value eq "rad" || $value eq "degree") {
        print HISTO "\t$key = $value\n";
        } 
      }     
}
# print ethad last since it needs value of epsilon
# no, do not print ethad before pt3 has been defined !!!
#print HISTO "\tepsilon= $hash_var_histo{\"epsilon\"}\n";
#print HISTO "\tethad = $hash_var_histo{\"ethad\"}\n";
print_return($histo);
close (HISTO);
#
# creation du fichier de remplissage des histogrammes
# the following is commented out since argument list is 
# better not rewritten automatically!
# write all variables into a single list
#@listvalues=();
#foreach $key (keys(%hash_variable)) {
#     for ($i=0; $i<=10; $i++) {
#       if ($hash_variable{$key}[$i]) { 
#	 push (@listvalues,$hash_variable{$key}[$i]);
#        }
#        if ($hash_variable{$key}[11]) { 
#         print "attention, list of values in hash_variable contains more than 11 elements!\n";
#	 print "automatic filling of arguments in fill_histo subroutine failed\n";
#	 print " 12. variable: ".$hash_variable{$key}[11]."\n";
#        }
#   } #end for ($i=0; $i<=10; $i++)
#}
#$leli = eval(@listvalues);
#
open (REMPLISSAGE,">$nomgfill")|| die "cannot create  $nomgfill";
$remplissage = *REMPLISSAGE;
print REMPLISSAGE "\tsubroutine fill_histo(iprov,weight,\n";
print REMPLISSAGE "     #  wy3,wyjet_lead,wpt3,wptjet_lead,\n";
print REMPLISSAGE "     #  wxgamobs,wxgamobases,wxgamll,\n";
print REMPLISSAGE "     #  wxpobs,wxpll,wx3,wxpparton,\n";
print REMPLISSAGE "     #  wfi_gamma_jet,wqt_gamma_jet,wpperp,\n";
print REMPLISSAGE "     #  wave_gaj,wsum_gaj,wmingj,wmaxgj)\n";
#$k=1;
#foreach $l (@listvalues) {
#  $helpa=int($k % 6);
#  if ($helpa == 0 and $k < $leli) {
#      print REMPLISSAGE "\n";
#      print REMPLISSAGE "     #  $l,";
# }
#  else { 
#      if ($k < $leli) {
#          print REMPLISSAGE "$l,"; 
#      }
#      else { print REMPLISSAGE "$l)\n"; }	  
#  }
#   $k++;
#}
print REMPLISSAGE "\timplicit real*4 (a-h,l-z)\n";
if ($hash_var_histo{degree_or_rad} eq "degree") {
  print REMPLISSAGE "\t  wfi_gamma_jet = wfi_gamma_jet*180/3.141592654\n";
}
$order = "lo";
print REMPLISSAGE "c  \n";
print REMPLISSAGE "\t  if (iprov.eq.11) then\n";
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_remplissage($remplissage,$order,$rh_variable);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_remplissage($remplissage,$order,$rh_variable);
}
#foreach $r_scatter (@list_ref_scatter_equi) {
#    $r_scatter->print_remplissage($remplissage,$order,$rh_variable);
#}
print REMPLISSAGE "\t  endif\n";
$order = "nlo";
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_remplissage($remplissage,$order,$rh_variable);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_remplissage($remplissage,$order,$rh_variable);
}
#foreach $r_scatter (@list_ref_scatter_equi) {
#    $r_scatter->print_remplissage($remplissage,$order,$rh_variable);
#}
print_return($remplissage);
close (REMPLISSAGE);
#
# creation du fichier d'initialisation de paw
open (INITCREATE,">$fortran_init")|| 
die "cannot create  $fortran_init";
$valeur_de_ipawc = 150000*7*$nb_event/1000000;
$init = *INITCREATE;
print INITCREATE "\tsubroutine histo_init(inbevent)\n";
print INITCREATE "\timplicit real*8 (a-h,l-v,x-z)\n";
print INITCREATE "\timplicit real*4 (w)\n";
print INITCREATE "\tCHARACTER*128 PATH_RZFILE\n";
print INITCREATE "\tCOMMON/CHEMINRZ/PATH_RZFILE\n";
print INITCREATE "\tCOMMON/LONGRZ/ILENRZ\n";
print INITCREATE "\tparameter(iwpawc = $valeur_de_ipawc)\n";
print INITCREATE "\tcommon/pawc/hmemor(iwpawc)\n";
print INITCREATE "\tparameter (nbhisto=$nb_histo)\n";
print INITCREATE "\tcommon/init_close/ibin($nb_histo)\n";
unless ($ihisto_equi==0) {
print INITCREATE "\tcommon/xminmax/wxmin($ihisto_equi),wxmax($ihisto_equi)\n";
}
unless ($ihisto_nonequi eq 0) {
  print INITCREATE "\tcommon/nonequi/";
  $count=1;
  foreach $r_histo (@list_nodouble) {
  $r_histo->print_common($init,$count,$ihisto_nonequi,$lelist_nodouble);
  $count=$count+1;  
  }
}
#
print INITCREATE "c\n";
print INITCREATE "\tiwpawt = 150000*7*inbevent/1000000\n";
print INITCREATE "\tif(iwpawt.gt.iwpawc) then\n";
print INITCREATE "\t  write(6,*)' you must have iwpawc at least ',iwpawt\n"; 
print INITCREATE "\tstop\n";  
print INITCREATE "\tendif\n";
print INITCREATE "\tcall hlimit(iwpawc)\n";
print INITCREATE "\tcall hropen(1,'zeus',PATH_RZFILE(1:ILENRZ)//'.dat'\n";
print INITCREATE "     #\t,'n',1024,istat)\n";
print INITCREATE "c \n";
#
#
foreach $r_histo (@list_ref_histo_equi) {
# run the subroutine print_value on the $r_histo object of package Histo_equi
# with $init as an argument
    $r_histo->print_value($init);
}
foreach $r_histo (@list_ref_histo_nonequi) {
# run the subroutine print_value on the $r_histo object 
# of package Histo_nonequi with $init as an argument
    $r_histo->print_value($init);
}
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_hbook($init);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_hbook($init);
}
print_return($init);
close (INITCREATE);
#
# creation du fichier de fermeture paw
open (ENDCREATE,">$fortran_end")|| die "cannot create  $fortran_end";
$endcr = *ENDCREATE;
print ENDCREATE "\tsubroutine histo_close(inbevent,wfirst_int)\n";
print ENDCREATE "\timplicit real*8 (a-h,l-v,x-z)\n";
print ENDCREATE "\timplicit real*4 (w)\n";
print ENDCREATE "\tparameter (nbhisto=$nb_histo)\n";
print ENDCREATE "\tcommon/init_close/ibin($nb_histo)\n";
unless ($ihisto_equi==0) {
print ENDCREATE "\tcommon/xminmax/wxmin($ihisto_equi),wxmax($ihisto_equi)\n";
}
if ($ihisto_nonequi!=0) {
 print ENDCREATE "\tcommon/nonequi/";
#
 $count=1;
 foreach $r_histo (@list_nodouble) {
 $r_histo->print_common($endcr,$count,$ihisto_nonequi,$lelist_nodouble);
 $count=$count+1;
 }
 print ENDCREATE "\tdimension ";
 $count=1;
 foreach $r_histo (@list_nodouble) {
 $r_histo->print_dim($endcr,$count,$ihisto_nonequi,$lelist_nodouble);
 $count=$count+1;
 }
} # end of if $ihisto_nonequi!=0 
unless ($ihisto_equi==0) { 
print ENDCREATE "\tdimension wbin_size($ihisto_equi),wxnorma($ihisto_equi)\n";
print ENDCREATE "c\n";
print ENDCREATE "\tdo i=1,$ihisto_equi\n";
print ENDCREATE "\t  wbin_size(i) = (wxmax(i)-wxmin(i))/float(ibin(i))\n";
print ENDCREATE "\t  wxnorma(i) = wfirst_int/(float(inbevent)*wbin_size(i))\n"; 
print ENDCREATE "\tenddo\n";
}
#
foreach $r_histo (@list_ref_histo_nonequi) {
$r_histo->print_norma($endcr); 
} 
print ENDCREATE "c\n";  
#
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_opera($endcr);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_opera($endcr);
}
foreach $r_histo (@list_ref_histo_equi) {
    $r_histo->print_out($endcr);
}
foreach $r_histo (@list_ref_histo_nonequi) {
    $r_histo->print_out($endcr);
}
print ENDCREATE "\tcall hrend('zeus')\n";  
print_return($endcr);
close (ENDCREATE);
#
} # end of if ($gt =~ /TRUE/i) statement
########### compilation #####################################
#print "makeoption=$makeoption\n";
system("gmake  $makeoption");
#######################################################################
# define global subroutines
#######################################################################
sub print_return {
  my ($fichier) = @_;
  print $fichier "\treturn\n";
  print $fichier "\tend\n";
}
##############################################################
# this subroutine takes two lists @list1 and @list2 
# and makes a hash out of it with @list1 as keys and @list2 as values
sub list_to_hash {
  my ($rl_list1,$rl_list2) = @_;
  my ($nb_element1,$nb_element2,$i,%hash_temp,$rh_hash_temp);
  $nb_element1 = @$rl_list1;
  $nb_element2 = @$rl_list2;
  if ($nb_element1 == $nb_element2) {
    for ($i=0;$i<$nb_element1;$i++) {
      $hash_temp{"$rl_list1->[$i]"} = $rl_list2->[$i];
    }
  }
  else {
    print "Error due to different lengths of two lists  \n";
    print "The number of input specifications for certain variables\n";
    print "must correspond to the number of selected contributions (ddir,dfrag,...)\n";
    print "number of selected contributions: $nb_element1\n";
    print "number of input values for list variable : $nb_element2\n";
    print "\n";
    print "Please check carefully your input in the file $paramfile\n";
 }
  $rh_hash_temp = {%hash_temp};
  return($rh_hash_temp);
}
#
################################################################################
# cette routine est comme la precedente sauf que on n'exige pas
# que les deux listes aient le meme nombre d'elements
# if list1 longer than list2 fill list 2 with first element of list1
################################################################################
sub list_to_hash1 {
  my ($rl_list1,$rl_list2) = @_;
  my ($nb_element1,$nb_element2,$i,%hash_temp,$rh_hash_temp);
  $nb_element1 = @$rl_list1;
  $nb_element2 = @$rl_list2;
  if ($nb_element1 <= $nb_element2) {
    for ($i=0;$i<$nb_element1;$i++) {
      $hash_temp{"$rl_list1->[$i]"} = $rl_list2->[$i];
    }
  }
  elsif ($nb_element1 > $nb_element2) {
    for ($i=0;$i<$nb_element1;$i++) {
      if ($rl_list2->[$i]) {
        $hash_temp{"$rl_list1->[$i]"} = $rl_list2->[$i];
      }
      else {
        $rl_list2->[$i] = $rl_list2->[0];
        $hash_temp{"$rl_list1->[$i]"} = $rl_list2->[$i];
      }
    }
  }
  $rh_hash_temp = {%hash_temp};
  return($rh_hash_temp);
}
###############################################################################
# define subroutine which removes doublers from a list
#############################################################################
sub listnodouble {
  my (@inputlist) = @_;
  $nbelements=@inputlist;
  @prelist=@inputlist;
  @outputlist=();
#  print "$nbelements\n";
  for ($i=0;$i<$nbelements;$i++) {
#     print "$inputlist[$i]\n";
    for ($j=$i+1;$j<$nbelements;$j++) {
        if ($inputlist[$j] eq $inputlist[$i]) {
           $prelist[$j]="";
        }
     }     
  }
  for ($i=0;$i<$nbelements;$i++) {
    if ($prelist[$i] ne "") {
        push(@outputlist,$prelist[$i]);
    }	
  }
  return(@outputlist); 
}
##############################################################
# define subroutine writefromuntil which reads a file and rewrites it
# from $stringtobegin until $stringtostop (included)
# arguments are $filetoread, $filetowrite, $stringtobegin, $stringtostop, writemode
# last argument specifies if $filetowrite is new or if writing should append
#
sub writefromuntil {
open (EREAD,"$_[0]") || die "cannot open $_[0]";
if ($_[4] eq "new") {
     open (EWRITE,">$_[1]") || die "cannot open $_[1]";
     }
elsif ($_[4] eq "append") {
     open (EWRITE,">>$_[1]") || die "cannot open $_[1]"; 
     }
elsif ($_[4] ne "append" or "new") {  
     print "specify \`new\` or \`append\` as last argument\n";
     return;
     };  
$start = 0;
LINE: while(<EREAD>) {
  chomp;
    if (/$_[2]/) {
        $start = 1;}
    if ($start == 1) {
     print EWRITE "$_\n";
    }
  last LINE if /$_[3]/;
  } #close while 
close (EREAD);
close (EWRITE);   
} #close sub
##########################################################################
sub maxoflist {
  my (@inputlist) = @_;
  $nbelements=@inputlist;
  $max=0;
#  print "$nbelements\n";
  for ($i=0;$i<$nbelements;$i++) {
    for ($j=$i;$j<$nbelements;$j++) {
       if ($inputlist[$j]>$max) {$max=$inputlist[$j]}
     }     
  }
  return($max); 
}
# returns minimum value of a list of positive or zero numbers
sub minoflist {
  my (@inputlist) = @_;
  $nbelements=@inputlist;
  $min=maxoflist(@inputlist);
  for ($i=0;$i<$nbelements-1;$i++) {
    for ($j=$i;$j<$nbelements;$j++) {
       if ($inputlist[$j]<$min) {$min=$inputlist[$j]}
#      print "$min\n"; 
     }     
  }
  return($min); 
}
#######################################################################
# define packages
######################################################################
# $i = number of histo, $id = PAW histo identifier
package Histo_equi;
sub new {
  my ($i,$id,$nomvar,$order,$cut,$title,$nb_bin,$xmin,$xmax) = @_;
  my $r_hash_histo = {
    "id" => $id,
    "nomvar" => $nomvar,
    "order" => $order,
    "cut" => $cut,
    "title" => $title,
    "nb_bin" => "ibin($i)",
    "value_nb_bin" => $nb_bin,
    "min_bin" => "wxmin($i)",
    "value_min_bin" => $xmin,
    "max_bin" => "wxmax($i)",
    "value_max_bin" => $xmax,
    "normalisation" => "wxnorma($i)"
  };
  bless $r_hash_histo,'Histo_equi';
  return $r_hash_histo;
}
#
#
sub print_value {
  my ($r_histo,$df) = @_;
  print $df "\t".$r_histo->{"nb_bin"}." = ".$r_histo->{"value_nb_bin"}."\n";
  print $df "\t".$r_histo->{"min_bin"}." = ".$r_histo->{"value_min_bin"}."\n";
  print $df "\t".$r_histo->{"max_bin"}." = ".$r_histo->{"value_max_bin"}."\n";
  print $df "c\n";
}
#
sub print_hbook {
  my ($r_histo,$df) = @_;
  print $df "\tcall hbook1(".$r_histo->{"id"}.",'".
  $r_histo->{"title"}."',".
  $r_histo->{"nb_bin"}.",".
  $r_histo->{"min_bin"}.",".
  $r_histo->{"max_bin"}.",".
  "0.)\n";
  print $df "\tcall hbook1(9".$r_histo->{"id"}.",'dummy',".
  $r_histo->{"nb_bin"}.",".
  $r_histo->{"min_bin"}.",".
  $r_histo->{"max_bin"}.",".
  "0.)\n";
  print $df "\tcall hbarx(".$r_histo->{"id"}.")\n";
  print $df "\tcall hbarx(9".$r_histo->{"id"}.")\n";
  print $df "c\n";
}
#
sub print_opera {
  my ($r_histo,$df) = @_;
  print $df "\tcall hopera(".$r_histo->{"id"}.",'+',9".
  $r_histo->{"id"}.",".
  $r_histo->{"id"}.",".
  $r_histo->{"normalisation"}.",1.)\n";
}
#
sub print_remplissage {
  my ($r_histo,$df,$order,$rh_variable) = @_;
  my ($rl_temp,$first_parenthese,$last_parenthese,$machin,$truc,$variable);
  if ($r_histo->{"order"} eq $order) {
    eval('$rl_temp = '.$r_histo->{"cut"});
    $first_parenthese = "";
    $last_parenthese = "";
    if (scalar(@$rl_temp) > 3){
      $first_parenthese = "(";
      $last_parenthese = ")";
    }
# debug    
#    foreach $l (@$rl_temp){print "$l\n"; }
#    
    if ($rl_temp->[0]) {
      for ($i=1;$i<=scalar(@$rl_temp);$i=$i+3) {	  
        $midvar=$rl_temp->[$i];
	if (not defined(@{$rh_variable->{"$midvar"}})) {
	    print "one of the cut variables for histo_equi not defined,\n"; 
	    print "please check spelling in param_histo.indat\n";
	}		
          $machin = ($i==1)? "\t  if  $first_parenthese":"     #\t  .and.";
          print $df "$machin";
#	  print "midvar = $midvar\n";
#	  print $rh_variable->{$midvar}[0];
#	  print "\n";
	  $le_varlist=scalar(@{$rh_variable->{$midvar}});
          for ($j=1;$j<=$le_varlist;$j++) {
#	  print @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1];
 	     $truc = ($j == 1)? "":"     #\t  .and.";
              print $df "$truc($rl_temp->[$i-1].le.".
 	     @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1]
 	     .".and.".
 	     @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1]
 	     .".le.$rl_temp->[$i+1])\n";
 	  }
	}  # end for ($i=1;$i<=scalar(@$rl_temp);$i=$i+3)  
         print $df "     #\t  $last_parenthese then\n";
#   print $r_histo->{"nomvar"};
         foreach $variable (@{$rh_variable->{$r_histo->{"nomvar"}}}) {
            print $df "\t    call hfill (".$r_histo->{"id"}.",$variable,0.,weight)\n";
         }
         print $df "\t  endif\n";
    } # end if ($rl_temp->[0])
    else {
        foreach $variable (@{$rh_variable->{$r_histo->{"nomvar"}}}) {
        print $df "\t  call hfill (".$r_histo->{"id"}.",$variable,0.,weight)\n";
        }
   } 
  } # end if ($r_histo->{"order"} eq $order)
}
#
sub print_out {
  my ($r_histo,$df) = @_;
  print $df "\tcall hrout(".$r_histo->{"id"}.",ICYCLE,' ')\n";
}
#
########################################################################
# 
package Histo_nonequi;
sub new {
  my ($i,$id,$nomvar,$order,$cut,$title,$nb_bin,$rl_bin_value) = @_;
  my $r_hash_histo = {
    "id" => $id,
    "nomvar" => $nomvar,
    "order" => $order,
    "cut" => $cut,
    "title" => $title,
    "nb_bin" => "ibin($i)",
    "value_nb_bin" => $nb_bin,
    "binvec" => "wxbin$nomvar",
    "value_binvec" => $rl_bin_value,
    "normalisation" => "wxnorma$nomvar"
  };
# debug  
#      foreach $l (@$rl_bin_value) {
#     print "$l\n";
#   };
#   $leng=@rl_bin_value;
#   print "length of wxbin$nomvar = $leng\n";
  bless $r_hash_histo,'Histo_nonequi';
  return $r_hash_histo;
}
#
sub print_value {
  my ($r_histo,$fichier) = @_;
  print $fichier "c     bins for histo in ".$r_histo->{"nomvar"}."\n";
  print $fichier "\t".$r_histo->{"nb_bin"}." = ".$r_histo->{"value_nb_bin"}."\n";
  for ($l = 0; $l<=$r_histo->{"value_nb_bin"}; $l++) {
  $lp=eval($l+1);
  print $fichier "\t".$r_histo->{"binvec"}.$r_histo->{"order"}."($lp) = ".$r_histo->{"value_binvec"}[$l]."\n";
  }
  print $fichier "c\n";
}
#
sub print_common {
  my ($r_histo,$fichier,$count,$nbnonequi,$lelist_nodouble) = @_;
    $nbb=eval($r_histo->{"value_nb_bin"}+1);
    $ndoub=eval($nbnonequi-$lelist_nodouble); 
    if ($count<$lelist_nodouble){
  print $fichier $r_histo->{"binvec"}.$r_histo->{"order"}."($nbb),\n";
  print $fichier "     #   ";
  }
  if ($count==$lelist_nodouble){
  print $fichier $r_histo->{"binvec"}.$r_histo->{"order"}."($nbb)\n";
  }
}
sub print_dim {
  my ($r_histo,$fichier,$count,$nbnonequi,$lelist_nodouble) = @_;
    $nb=$r_histo->{"value_nb_bin"};
    $ndoub=eval($nbnonequi-$lelist_nodouble); 
    $nbb=eval($r_histo->{"value_nb_bin"}+1);
    if ($count< $lelist_nodouble){
  print $fichier $r_histo->{"normalisation"}.$r_histo->{"order"}."($nbb),\n";
  print $fichier "     #   ";
  }
  if ($count== $lelist_nodouble){
#  print "$count\n";
  print $fichier $r_histo->{"normalisation"}.$r_histo->{"order"}."($nbb)\n";
  }
}
#
sub print_hbook {
  my ($r_histo,$fichier) = @_;
# Born histo id has 1 in front of HO histo id    
#  print $fichier "\tcall hbookb(1".$r_histo->{"id"}.",'Born ".
#  $r_histo->{"title"}."',".
#  $r_histo->{"nb_bin"}.",".
#  $r_histo->{"binvec"}.",".
#  "0.)\n";
  print $fichier "\tcall hbookb(".$r_histo->{"id"}.",'".
  $r_histo->{"title"}."',".
  $r_histo->{"nb_bin"}.",".
  $r_histo->{"binvec"}.$r_histo->{"order"}.",".
  "0.)\n";
  print $fichier "\tcall hbookb(9".$r_histo->{"id"}.",'dummy',".
  $r_histo->{"nb_bin"}.",".
  $r_histo->{"binvec"}.$r_histo->{"order"}.",".
  "0.)\n";
#  print $fichier "\tcall hbarx(1".$r_histo->{"id"}.")\n";
  print $fichier "\tcall hbarx(".$r_histo->{"id"}.")\n";
  print $fichier "\tcall hbarx(9".$r_histo->{"id"}.")\n";
  print $fichier "c\n";
}
#
sub print_norma {
  my ($r_histo,$fichier) = @_;
    $nb=$r_histo->{"value_nb_bin"};
    $ibin=$r_histo->{"nb_bin"};
    $normvec=$r_histo->{"normalisation"}.$r_histo->{"order"};
    $binvec=$r_histo->{"binvec"}.$r_histo->{"order"};
  print $fichier "\t do j=1,$ibin\n";
  print $fichier "\t $normvec(j) = wfirst_int/(float(inbevent)*\n";
  print $fichier "     #	($binvec(j+1)-$binvec(j)))\n";
  print $fichier "\t enddo \n";
}
#
sub print_opera {
  my ($r_histo,$fichier) = @_;
  print $fichier "\tcall hpak(9".$r_histo->{"id"}.",".$r_histo->{"normalisation"}.$r_histo->{"order"}.")\n";
#  print $fichier "\tcall hopera(1".$r_histo->{"id"}.",'*',9".
#  $r_histo->{"id"}.",1".
#  $r_histo->{"id"}.",".
#  "1.,1.)\n";
  print $fichier "\tcall hopera(".$r_histo->{"id"}.",'*',9".
  $r_histo->{"id"}.",".
  $r_histo->{"id"}.",".
  "1.,1.)\n";
  print $fichier "c\n";
}
#
sub print_remplissage {
  my ($r_histo,$df,$order,$rh_variable) = @_;
  my ($rl_temp,$first_parenthese,$last_parenthese,$machin,$truc,$var);
  if ($r_histo->{"order"} eq $order) {
    eval('$rl_temp = '.$r_histo->{"cut"});
    $first_parenthese = "";
    $last_parenthese = "";
    if (scalar(@$rl_temp) > 3){
      $first_parenthese = "(";
      $last_parenthese = ")";
    }
    if (scalar(@$rl_temp) > 0) {
      for ($i=1;$i<=scalar(@$rl_temp);$i=$i+3) {
       $midvar=$rl_temp->[$i];
       if (not defined(@{$rh_variable->{"$midvar"}})) {
	    print "one of the cut variables for histo_equi not defined,\n"; 
	    print "please check spelling in param_histo.indat\n";
	}	       
        $machin = ($i==1)? "\t  if  $first_parenthese":"     #\t  .and.";
        print $df "$machin";
        for ($j=1;$j<=scalar(@{$rh_variable->{$rl_temp->[$i]}});$j++) {
	  $truc = ($j == 1)? "":"     #\t  .and.";
          print $df "$truc($rl_temp->[$i-1].le.".
	  @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1]
	  .".and.".
	  @{$rh_variable->{"$rl_temp->[$i]"}}[$j-1]
	  .".le.$rl_temp->[$i+1])\n";
	}
      }	# end for ($i=1;$i<=scalar(@$rl_temp);$i=$i+3)	
      print $df "     #\t  $last_parenthese then\n";
      foreach $var (@{$rh_variable->{$r_histo->{"nomvar"}}}) {
      print $df "\t  call hfill (".$r_histo->{"id"}.",$var,0.,weight)\n";
      }
      print $df "\t  endif\n";
    } # end if (scalar(@$rl_temp) > 0)      
     else {
       foreach $var (@{$rh_variable->{$r_histo->{"nomvar"}}}) {
       print $df "\t  call hfill (".$r_histo->{"id"}.",$var,0.,weight)\n";
       }
     }
 }
}
#
#
sub print_fillhisto {
  my ($r_histo,$fichier) = @_;
  print $fichier "\tcall hfill(".$r_histo->{"id"}.","
  .$r_histo->{"nomvar"}.",0.,weight)\n";
}
#
sub print_out {
  my ($r_histo,$df) = @_;
  print $df "\tcall hrout(".$r_histo->{"id"}.",ICYCLE,' ')\n";
}
#
########################################################################

